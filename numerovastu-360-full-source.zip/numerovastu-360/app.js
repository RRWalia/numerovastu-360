/* ============================================================
   NumeroVastu 360 — calculation engine + report renderer
   All computation is local. Multi-language support: English, Hindi, Gujarati.
   ============================================================ */

(function () {
  "use strict";

  /* ---------------- helpers ---------------- */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function reduce(n) {
    n = Math.abs(n);
    while (n > 9) n = String(n).split("").reduce((a, d) => a + Number(d), 0);
    return n || 9; // guard: 0 shouldn't occur
  }
  const digitSum = (str) => str.replace(/\D/g, "").split("").reduce((a, d) => a + Number(d), 0);
  const digitsOf = (str) => str.replace(/\D/g, "").split("").map(Number).filter((d) => d > 0);
  // The Foundation uses the classical Lo Shu magic-square coordinates. The
  // advanced Vedic Ank Kundali remains a separate birth-only comparison.
  const LO_SHU_GRID_LAYOUT = [[4, 9, 2], [3, 5, 7], [8, 1, 6]];
  const LO_SHU_PLANE_CELLS = [
    [4, 9, 2], [3, 5, 7], [8, 1, 6], [4, 3, 8],
    [9, 5, 1], [2, 7, 6], [4, 5, 6], [8, 5, 2]
  ];
  const LO_SHU_ARROW_LINES = LO_SHU_PLANE_CELLS.map((cells) => cells.slice());
  const VEDIC_GRID_LAYOUT = [[3, 1, 9], [6, 7, 5], [2, 8, 4]];
  const DEFAULT_VEDIC_PLANES = [
    { key: "practical", cells: [3, 1, 9], element: "Fire", governs: "Vision, executive drive, leadership and proactive execution." },
    { key: "materialistic", cells: [6, 7, 5], element: "Air", governs: "Wealth accumulation, luxury, analytical thinking, business acumen and networking." },
    { key: "emotional", cells: [2, 8, 4], element: "Water", governs: "Intuition, emotional balance, perseverance, discipline and systematic planning." }
  ];
  // The Vastu compass is a separate Vedic planetary mapping — grid positions
  // must never be mistaken for Lo Shu / Bagua directional positions.
  const VEDIC_VASTU_COMPASS_PLANETS = Object.freeze({ N: 5, NE: 3, E: 1, SE: 6, S: 9, SW: 4, W: 8, NW: 2 });
  /* 5 (Mercury) maps to the North — the Kubera sector of the Vedic compass
     (N → 5) — after the 2026-09 audit; only 7 (Ketu, no compass sector)
     keeps the NE / Center axis. */
  const VEDIC_DASHA_ZONES = Object.freeze({
    1: "East", 2: "North-West", 3: "North-East", 4: "South-West", 5: "North",
    6: "South-East", 7: "North-East / Center Axis", 8: "West", 9: "South"
  });
  const KARMIC_DEBT_POOL = [13, 14, 16, 19];

  /* Vedic Ank Kundali input is deliberately filtered differently from a
     Lo Shu chart. Keep this as a small, pure function so every part of the
     report (remedies, name support and dasha weighting) reads the same birth
     grid and the calculation can be independently audited. */
  function calendarInteger(value) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0;
  }

  function calendarText(value, width) {
    const raw = String(value === undefined || value === null ? "" : value).replace(/\D/g, "");
    const fallback = String(calendarInteger(value));
    return (raw || fallback).padStart(width, "0");
  }

  function nonZeroCalendarDigits(text) {
    return String(text).split("").filter((d) => d !== "0").map(Number);
  }

  function generateVedicGrid(day, month, year) {
    const dayNumber = calendarInteger(day);
    const monthNumber = calendarInteger(month);
    const yearNumber = calendarInteger(year);
    const dayText = calendarText(day, 2);
    const monthText = calendarText(month, 2);
    const yearText = calendarText(year, 4);
    const yearTailText = yearText.slice(-2);
    const centuryText = yearText.slice(0, -2);

    // Moolank is the reduced birth day. Bhagyank intentionally uses the full
    // DOB calculation (including the century) even though century digits are
    // not placed into the 9-cell natal matrix.
    const rulingNo = reduce(dayNumber);
    const destinyNo = reduce(dayNumber + monthNumber + yearNumber);
    const destinyDigitSum = digitSum(`${dayText}${monthText}${yearText}`);

    const dayDigits = nonZeroCalendarDigits(dayText);
    const monthDigits = nonZeroCalendarDigits(monthText);
    const yearDigits = nonZeroCalendarDigits(yearTailText);
    const nonZeroDayValue = dayDigits.length ? Number(dayDigits.join("")) : null;
    const dayDeduplicated = nonZeroDayValue === rulingNo;

    const entries = [];
    const add = (source, values) => values.forEach((number) => entries.push({ source, number }));
    // A one-digit day (including 10/20/30 after zero removal) is represented
    // by the ruling number once, never as a duplicated raw-day digit.
    if (!dayDeduplicated) add("day", dayDigits);
    add("month", monthDigits);
    add("year", yearDigits);
    add("ruling", [rulingNo]);
    add("destiny", [destinyNo]);

    const counts = {};
    for (let i = 1; i <= 9; i++) counts[i] = 0;
    entries.forEach(({ number }) => { if (number >= 1 && number <= 9) counts[number]++; });

    const zeroCount = (text) => (String(text).match(/0/g) || []).length;
    return {
      layout: VEDIC_GRID_LAYOUT.map((row) => row.slice()),
      entries,
      digits: entries.map(({ number }) => number),
      counts,
      rulingNo,
      destinyNo,
      driver: rulingNo,
      conductor: destinyNo,
      sourceDigits: { day: dayDigits, month: monthDigits, year: yearDigits },
      raw: { day: dayText, month: monthText, year: yearText, yearTail: yearTailText, century: centuryText },
      excluded: {
        zeros: { day: zeroCount(dayText), month: zeroCount(monthText), year: zeroCount(yearText) },
        century: centuryText,
        dayDeduplicated,
        nonZeroDayValue
      },
      calculations: {
        rulingDigitSum: digitSum(dayText),
        destinyDigitSum,
        destinyCalendarSum: dayNumber + monthNumber + yearNumber
      }
    };
  }

  /* Classic Lo Shu plotting deliberately differs from the advanced Vedic
     comparison. It keeps every non-zero digit of the complete DD-MM-YYYY
     date (including 19/20 century digits), then adds Moolank and Bhagyank.
     This pure engine is the sole source for Foundation remedy obligations. */
  function generateLoShuGrid(day, month, year) {
    const dayNumber = calendarInteger(day);
    const monthNumber = calendarInteger(month);
    const yearNumber = calendarInteger(year);
    const dayText = calendarText(day, 2);
    const monthText = calendarText(month, 2);
    const yearText = calendarText(year, 4);
    const rulingNo = reduce(dayNumber);
    const destinyNo = reduce(dayNumber + monthNumber + yearNumber);
    const dayDigits = nonZeroCalendarDigits(dayText);
    const monthDigits = nonZeroCalendarDigits(monthText);
    const yearDigits = nonZeroCalendarDigits(yearText);
    const entries = [];
    const add = (source, values) => values.forEach((number) => entries.push({ source, number }));
    add("day", dayDigits);
    add("month", monthDigits);
    add("year", yearDigits);
    add("ruling", [rulingNo]);
    add("destiny", [destinyNo]);
    const counts = {};
    for (let i = 1; i <= 9; i++) counts[i] = 0;
    entries.forEach(({ number }) => { if (number >= 1 && number <= 9) counts[number]++; });
    const zeroCount = (text) => (String(text).match(/0/g) || []).length;
    return {
      layout: LO_SHU_GRID_LAYOUT.map((row) => row.slice()),
      entries,
      digits: entries.map(({ number }) => number),
      counts,
      rulingNo,
      destinyNo,
      driver: rulingNo,
      conductor: destinyNo,
      sourceDigits: { day: dayDigits, month: monthDigits, year: yearDigits },
      raw: { day: dayText, month: monthText, year: yearText },
      excluded: { zeros: { day: zeroCount(dayText), month: zeroCount(monthText), year: zeroCount(yearText) } },
      calculations: {
        rulingDigitSum: digitSum(dayText),
        destinyDigitSum: digitSum(`${dayText}${monthText}${yearText}`),
        destinyCalendarSum: dayNumber + monthNumber + yearNumber
      }
    };
  }

  function relation(a, b) {
    // Rahu (4) and Moon (2) form the eclipse axis (Grahan); never label
    // Moon as friendly inside a Rahu period, even when a custom pack omits it.
    if ((a === 4 && b === 2) || (a === 2 && b === 4)) return "enemy";
    if (a === b) return "friendly"; // a planet is never its own enemy
    const f = (window.DB && window.DB.friendship) ? window.DB.friendship[a] : null;
    if (!f) return "neutral";
    if (f.friends.includes(b)) return "friendly";
    if (f.neutral.includes(b)) return "neutral";
    return "enemy";
  }

  /* ---------------- Classical Sambhandha (Dasha relationship) ----------------
     An Antardasha never runs in isolation: it operates *inside* the house and
     climate of its Mahadasha lord. The operative verdict is therefore
     MD × AD, never Driver × AD (that produced a green "Friendly to you" badge
     on Moon AD inside a Rahu MD, contradicting the Grahan Yoga synthesis).
     A small set of pairs is hostile in both directions in classical practice
     even when a knowledge pack lists one side as neutral: the eclipse axis
     (Rahu–Moon, Rahu–Sun), Sun–Saturn, Mars–Saturn and the Deva/Asura gurus
     Jupiter–Venus. Only when MD × AD is genuinely neutral does the native's
     own Driver decide how the sub-period lands. */
  /* ---- Age & safety thresholds -------------------------------------------
     The report computes a plain completed-age figure from the DOB against
     the device clock. It is used ONLY to soften prescriptive intensity:
     under-18 charts defer heavy planetary gems to gentle substitutes and
     route the family to lifestyle anchors instead of stones. */
  const MINOR_AGE_LIMIT = 18;
  function currentAgeYears(day, month, year, nowMs) {
    const now = nowMs !== undefined && nowMs !== null ? new Date(nowMs) : new Date();
    let age = now.getFullYear() - year;
    const m = now.getMonth() + 1;
    if (m < month || (m === month && now.getDate() < day)) age -= 1;
    return Math.max(0, age);
  }
  function isMinorProfile(p) {
    return !!p && Number.isFinite(p.ageYears) && p.ageYears < MINOR_AGE_LIMIT;
  }

  /* ---- Solar-load signal ---------------------------------------------------
     Digit 1 repeated 3+ times in the Lo Shu birth grid is an "over-lit Sun".
     The number kits, dosha baseline and Tattva kits stay canonical (packed,
     versioned data); this flag only adds clearly-labelled cooling overlays so
     a 3×/4× Sun is not prescribed MORE solar fire. */
  function solarLoadOf(p) {
    return (p && p.loShuCounts && p.loShuCounts[1]) || 0;
  }
  function solarOverload(p) {
    return solarLoadOf(p) >= 3;
  }
  function pittaInBaseline(p) {
    const tags = (p && p.doshaProfile && p.doshaProfile.primaryTags) || [];
    return tags.includes("Pitta");
  }
  /* ---- Heavy-planet gem class ---------------------------------------------
     Saturn / Rahu / Ketu stones are classically "trial-only" prescriptions.
     For under-18 charts the crystal row leads with the gentle substitute and
     defers the heavy gem until adulthood, echoing the caution already carried
     by the canonical data ("wear only after an expert check"). */
  const HEAVY_GEM_BY_NUMBER = {
    4: { heavy: "Hessonite (Gomed)", gentle: "Smoky Quartz" },
    7: { heavy: "Cat's Eye (Lehsunia)", gentle: "Tiger's Eye" },
    8: { heavy: "Blue Sapphire (Neelam)", gentle: "Amethyst or Lapis Lazuli" }
  };
  const HEAVY_GEM_PICK_SWAP = {
    "Blue Sapphire": "Amethyst",
    "Hessonite": "Smoky Quartz",
    "Cat's Eye": "Tiger's Eye"
  };

  /* Canonical cooling reference for an over-lit Sun: Chandra Bhedana plus
     evening grounding. When the 4A Tattva section actually renders for this
     chart the note cites the section; otherwise it names the practice
     directly so the instruction never points at a missing page. */
  function solarModerationNote(p, lang, opts) {
    const o = opts || {};
    if (!solarOverload(p)) return "";
    const context = o.context || "dosha";
    // The constitution and Agni-plane overlays apply specifically to the
    // hot pairing the note moderates: repeated Sun against a Pitta baseline.
    if ((context === "dosha" || context === "agni") && !pittaInBaseline(p)) return "";
    const count = solarLoadOf(p);
    let anchors = [];
    try { anchors = vedicTattvaAnchors(p, lang) || []; } catch (e) { anchors = []; }
    const tattvaShown = anchors.length > 0;
    const emotionalShown = anchors.some((a) => a.key === "emotional");
    const coolingRef = {
      en: tattvaShown
        ? (emotionalShown ? "the Section 4A Tattva anchors — especially Chandra Bhedana and the evening grounding anchors"
                          : "the Section 4A Tattva anchors and a nightly Chandra Bhedana (left-nostril) practice with evening grounding")
        : "a nightly Chandra Bhedana (left-nostril) practice and evening grounding",
      hi: tattvaShown
        ? (emotionalShown ? "खंड 4A के तत्व आधार — विशेष रूप से चंद्र भेदन और शाम के भूमि-संपर्क आधार"
                          : "खंड 4A के तत्व आधार तथा रात्रि का चंद्र भेदन (बाईं नासिका) अभ्यास और शाम का भूमि-संपर्क")
        : "रात्रि का चंद्र भेदन (बाईं नासिका) अभ्यास और शाम का भूमि-संपर्क",
      gu: tattvaShown
        ? (emotionalShown ? "વિભાગ 4A ના તત્વ આધાર — ખાસ કરીને ચંદ્ર ભેદન અને સાંજના ભૂમિ-સંપર્ક આધાર"
                          : "વિભાગ 4A ના તત્વ આધાર અને રાત્રિનો ચંદ્ર ભેદન (ડાબી નાસિકા) અભ્યાસ તથા સાંજનો ભૂમિ-સંપર્ક")
        : "રાત્રિનો ચંદ્ર ભેદન (ડાબી નાસિકા) અભ્યાસ અને સાંજનો ભૂમિ-સંપર્ક"
    }[lang] || (tattvaShown ? "the Section 4A Tattva anchors — especially Chandra Bhedana and the evening grounding anchors" : "a nightly Chandra Bhedana (left-nostril) practice and evening grounding");

    if (context === "excess") {
      const text = lang === "hi"
        ? `अधिकता को ठंडा करें: सूर्य पहले से ${count}× दोहराया है, इसलिए जल-अर्पण संक्षिप्त, शांत और केवल सूर्योदय पर रखें — फिर ${coolingRef} से सूर्य-अग्नि संतुलित होगी। अतिरिक्त सौर ऊष्मा सबसे पहले पूर्णतावाद, सिर की गर्मी और अधीरता के रूप में दिखती है।`
        : lang === "gu"
          ? `વધારાને ઠંડો કરો: સૂર્ય પહેલેથી ${count}× પુનરાવર્તિત છે, એટલે જળ-અર્પણ ટૂંકું, શાંત અને ફક્ત સૂર્યોદયે રાખો — પછી ${coolingRef} થી સૂર્ય-અગ્નિ સંતુલિત થશે. વધુ સૌર ગરમી પહેલા સંપૂર્ણતાવાદ, માથાની ગરમી અને અધીરાઈ રૂપે દેખાય છે.`
          : `Cool the surplus: with the Sun already repeated ${count}×, keep the water-offering brief, calm and at sunrise only — then let ${coolingRef} balance the solar fire. Extra solar heat surfaces first as perfectionism, head-heat and impatience.`;
      return `<div class="kit-value solar-moderation" data-solar-moderation="excess" data-authority="lo-shu-overlay"><strong>${lang === "hi" ? `सूर्य ${count}×:` : lang === "gu" ? `સૂર્ય ${count}×:` : `Sun ${count}×:`}</strong> ${esc(text)}</div>`;
    }

    if (context === "agni") {
      // Inside 4A itself, point at the neighbouring Emotional-plane card
      // rather than re-naming the section the reader is already in.
      const coolingLocal = emotionalShown
        ? (lang === "hi" ? "नीचे भावनात्मक तल के चंद्र भेदन और शाम के भूमि-संपर्क आधारों"
          : lang === "gu" ? "નીચે ભાવનાત્મક સ્તરના ચંદ્ર ભેદન અને સાંજના ભૂમિ-સંપર્ક આધારો"
            : "the Emotional plane's Chandra Bhedana and evening grounding anchors below")
        : (lang === "hi" ? "रात्रि के चंद्र भेदन (बाईं नासिका) अभ्यास और शाम के भूमि-संपर्क"
          : lang === "gu" ? "રાત્રિના ચંદ્ર ભેદન (ડાબી નાસિકા) અભ્યાસ અને સાંજના ભૂમિ-સંપર્ક"
            : "a nightly Chandra Bhedana (left-nostril) practice and evening grounding");
      const text = lang === "hi"
        ? `सूर्य पहले से ${count}× दोहराया है और प्रकृति पित्त है — इन अग्नि आधारों को सबसे हल्के रूप में चलाएं: सूर्य भेदन और दोपहर का सूर्य सक्रियण छोड़ दें, और ${coolingLocal} से इस पट्टिका का शीतलन कराएं।`
        : lang === "gu"
          ? `સૂર્ય પહેલેથી ${count}× પુનરાવર્તિત છે અને પ્રકૃતિ પિત્ત છે — આ અગ્નિ આધારો સૌથી હળવા રૂપે ચલાવો: સૂર્ય ભેદન અને બપોરનું સૂર્ય સક્રિયકરણ છોડી દો, અને ${coolingLocal} થી આ પટ્ટિકાનું શીતલન કરાવો.`
          : `The Sun already repeats ${count}× against a Pitta constitution — run these Agni anchors in their mildest form: skip Surya Bhedana and the midday Solar Activation, and let ${coolingLocal} carry the cooling for this chart.`;
      return `<div class="kit-row solar-moderation" data-solar-moderation="agni"><div class="kit-ico">☾</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "सूर्य-भार संयम" : lang === "gu" ? "સૂર્ય-ભાર સંયમ" : "Solar-load moderation"}</div><div class="kit-value">${esc(text)}</div></div></div>`;
    }

    // context === "dosha"
    const text = lang === "hi"
      ? `प्रैक्टिशनर नोट — सूर्य संयम (${count}× सूर्य + पित्त): ऊपर की सूर्य दिनचर्या धीमी आंच पर रखें — सूर्योदय पर संक्षिप्त, शांत अर्घ्य पर्याप्त है; दीर्घ सूर्य-दर्शन या ऊष्मा बढ़ाने वाला अभ्यास नहीं। संतुलन ठंडी आदतों से आएगा — खंड 3 का channeling कार्ड तथा ${coolingRef}। पूर्णतावाद, सिर की गर्मी और अधीरता ही नज़र रखने योग्य संकेत हैं।`
      : lang === "gu"
        ? `પ્રેક્ટિશનર નોંધ — સૂર્ય સંયમ (${count}× સૂર્ય + પિત્ત): ઉપરની સૂર્ય દિનચર્યા ધીમી તપાસે રાખો — સૂર્યોદયે ટૂંકો, શાંત અર્ઘ્ય પૂરતો; લાંબું સૂર્ય-દર્શન કે ગરમી વધારતો અભ્યાસ નહીં. સંતુલન ઠંડી ટેવોથી આવશે — વિભાગ 3 નું channeling કાર્ડ અને ${coolingRef}. સંપૂર્ણતાવાદ, માથાની ગરમી અને અધીરાઈ એ નજર રાખવાના સંકેતો છે.`
        : `Practitioner note — solar moderation (${count}× Sun + Pitta): keep the Sun routine above at a low flame — a brief, calm arghya at sunrise is enough; no prolonged sun-gazing or heat-building practice. Let the cooling habits carry the balance — the channeling card in Section 3 and ${coolingRef}. Perfectionism, head-heat and impatience are the tells to watch.`;
    return `<div class="kit-value solar-moderation" data-solar-moderation="dosha" data-authority="lo-shu-overlay"><strong>${lang === "hi" ? "Overlay (दोहराव-स्तर):" : lang === "gu" ? "ઓવરલે (પુનરાવૃત્તિ-સ્તર):" : "Overlay (repeated-number layer):"}</strong> ${esc(text)}</div>`;
  }

  /* ---- Moon-cold clinical guardrail (Number 2 / Chandra) -------------------
     Raw lunar remedies carry Sheeta Guna (cold potency): the full Moon Beej
     mantra, Monday cold fasts, a Pearl/Moonstone trial and raw or
     refrigerated milk can aggravate an active cold, sinus congestion or
     allergic rhinitis (Vataja Pratishyaya). The canonical Number 2 kit in
     data.js stays untouched; this flag only adds a clearly-labelled
     warm-substitute overlay, using the same additive pattern as
     solarModerationNote and the under-18 gemstone guardrail.
     Triggers (any one, for every DOB — never a hard-coded chart):
       - declared: the intake Health sub-tag "Allergies / Respiratory / Cold"
       - Vata channel in the Driver/Conductor dosha baseline (a Tridoshic
         Mercury baseline carries a Vata channel, so Driver/Conductor 5
         charts read as Pitta-Vata even when the blended headline is Pitta)
       - Mercury 5 as Driver or Conductor (nervous-system Vata)
       - Health focus selected (the Moon governs the Health focus)
     Declared sensitivity uses firmer "run warm only" wording; potential
     sensitivity uses conditional "if prone to…" wording so charts without
     symptoms are guided, not alarmed. */
  const HEALTH_TAG_VALUES = ["respiratory", "heat", "fatigue"];
  const HEALTH_TAG_RESPIRATORY = "respiratory";
  function healthTagsOf(p) {
    const raw = (p && p.healthTags) || [];
    return raw.map((tag) => String(tag || "").trim().toLowerCase())
      .filter((tag) => HEALTH_TAG_VALUES.includes(tag));
  }
  function hasRespiratoryTag(p) {
    return healthTagsOf(p).includes(HEALTH_TAG_RESPIRATORY);
  }
  function vataInBaseline(p) {
    if (!p || !p.doshaProfile) return false;
    const tags = p.doshaProfile.primaryTags || [];
    if (tags.includes("Vata")) return true;
    const driverType = String((p.doshaProfile.driverDosha || {}).dominant || "").toLowerCase();
    const conductorType = String((p.doshaProfile.conductorDosha || {}).dominant || "").toLowerCase();
    // A Tridoshic (Mercury 5) baseline carries all three channels including Vata.
    return [driverType, conductorType].some((entry) => entry.includes("vata") || entry.includes("tridoshic"));
  }
  function mercuryVataNumber(p) {
    return !!p && (Number(p.driver) === 5 || Number(p.conductor) === 5);
  }
  function hasHealthFocus(p) {
    return !!p && Array.isArray(p.goals) && p.goals.includes("Health");
  }
  function moonColdSensitivity(p) {
    if (!p) return null;
    const reasons = [];
    if (hasRespiratoryTag(p)) reasons.push("declared-respiratory");
    if (vataInBaseline(p)) reasons.push("vata-baseline");
    if (mercuryVataNumber(p)) reasons.push("mercury-5");
    if (hasHealthFocus(p)) reasons.push("health-focus");
    if (!reasons.length) return null;
    return { level: hasRespiratoryTag(p) ? "declared" : "potential", reasons };
  }
  function healthTagLabel(tag, lang) {
    const l = lang || getLang();
    const key = String(tag || "").toLowerCase();
    if (key === "respiratory") return l === "hi" ? "एलर्जी / श्वसन / सर्दी" : l === "gu" ? "એલર્જી / શ્વસન / શરદી" : "Allergies / Respiratory / Cold";
    if (key === "heat") return l === "hi" ? "एसिडिटी / सूजन / गर्मी" : l === "gu" ? "એસિડિટી / સોજો / ગરમી" : "Acidity / Inflammation / Heat";
    if (key === "fatigue") return l === "hi" ? "जोड़ / पाचन / थकान" : l === "gu" ? "સાંધા / પાચન / થાક" : "Joints / Digestion / Fatigue";
    return String(tag || "");
  }
  /* Advisory shape used across the report: getRemedyClinicalGuardrail(2, p)
     returns the badge + note for the Moon kit, or null for every other
     number and for charts with no cold-sensitivity signal. */
  function getRemedyClinicalGuardrail(num, profile, langOverride) {
    const guardrailNum = Number(num);
    // Numbers 1 and 3-9 run the generic Dosha x planet path; Number 2 keeps
    // the bespoke Moon-cold guardrail below.
    if (guardrailNum !== 2) return doshaContraGuardrail(guardrailNum, profile, langOverride);
    if (!profile) return null;
    const sensitivity = moonColdSensitivity(profile);
    if (!sensitivity) return null;
    const lang = langOverride || getLang();
    const declared = sensitivity.level === "declared";
    const badge = lang === "hi"
      ? "🛡 नैदानिक सुरक्षा — श्वसन व सर्दी संवेदनशीलता"
      : lang === "gu"
        ? "🛡 ક્લિનિકલ સલામતી — શ્વસન અને શરદી સંવેદનશીલતા"
        : "🛡 Clinical Safety Guardrail — Respiratory & Cold Sensitivity";
    const note = lang === "hi"
      ? (declared
        ? "आपने एलर्जी / श्वसन / सर्दी चुनी है — इस चंद्र किट को केवल उष्ण रूप में चलाएं: कच्चा चंद्र बीज मंत्र (Om Shram Shreem…), सोमवार का ठंडा उपवास, Pearl/Moonstone परीक्षण और कच्चा या फ्रिज का दूध रोकें। ये शीत गुण और कफ-भार बढ़ाते हैं। विकल्प में भगवान शिव (चंद्रशेखर) जप (Om Namah Shivaya), चांदी के बर्तन का गुनगुना जल और नाड़ी शोधन अपनाएं; वायुमार्ग साफ होने तक रत्न व उपवास होल्ड पर रखें — रंग, दान व भूमि-संपर्क जारी रखें।"
        : "यदि पुराना जुकाम, एलर्जिक राइनाइटिस, साइनस सूजन या सुबह की छींकें (वातज प्रतिश्याय) रहती हैं, तो कच्चे चंद्र बीज मंत्र, ठंडे उपवास या अत्यधिक कच्चे दूध से सख्त परहेज करें। ये शीत गुण और कफ-भार बढ़ाते हैं। विकल्प में भगवान शिव (चंद्रशेखर) जप, गुनगुना चांदी-जल और नाड़ी शोधन प्राणायाम अपनाएं।")
      : lang === "gu"
        ? (declared
          ? "તમે એલર્જી / શ્વસન / શરદી પસંદ કરી છે — આ ચંદ્ર કિટ ફક્ત ઉષ્ણ રૂપે ચલાવો: કાચો ચંદ્ર બીજ મંત્ર (Om Shram Shreem…), સોમવારનો ઠંડો ઉપવાસ, Pearl/Moonstone અજમાયશ અને કાચું કે ફ્રિજનું દૂધ રોકો. આ શીત ગુણ અને કફ-ભાર વધારે છે. વિકલ્પે ભગવાન શિવ (ચંદ્રશેખર) જાપ (Om Namah Shivaya), ચાંદીના વાસણનું ગુનગુનું જળ અને નાડી શોધન અપનાવો; શ્વાસમાર્ગ સાફ થાય ત્યાં સુધી રત્ન અને ઉપવાસ હોલ્ડ પર રાખો — રંગ, દાન અને ભૂમિ-સંપર્ક ચાલુ રાખો."
          : "જો જૂની શરદી, એલર્જિક રાઇનાઇટિસ, સાઇનસ સોજો કે સવારની છીંકો (વાતજ પ્રતિશ્યાય) રહેતી હોય, તો કાચા ચંદ્ર બીજ મંત્ર, ઠંડા ઉપવાસ કે વધુ પડતા કાચા દૂધથી સખત પરહેજ કરો. આ શીત ગુણ અને કફ-ભાર વધારે છે. વિકલ્પે ભગવાન શિવ (ચંદ્રશેખર) જાપ, ગુનગુનું ચાંદી-જળ અને નાડી શોધન પ્રાણાયામ અપનાવો.")
        : (declared
          ? "You flagged Allergies / Respiratory / Cold — run this Moon kit in its warm form only: pause the raw Moon Beej mantra (Om Shram Shreem…), Monday cold fasts, Pearl/Moonstone trial and raw or refrigerated milk. These raise Sheeta Guna (coldness) and mucus load. Substitute with Lord Shiva (Chandrashekhara) japa (Om Namah Shivaya), lukewarm water from a silver vessel, and Nadi Shodhana (alternate-nostril) breathwork. Keep Pearl/Moonstone and Monday fasts on hold until the airway is clear — colour, charity and grounding cues continue."
          : "If dealing with chronic cold, allergic rhinitis, sinus inflammation, or morning sneezing (Vataja Pratishyaya), strictly avoid raw Moon Beej mantras, cold fasts, or excessive raw milk. These increase Sheeta Guna (coldness) and mucus buildup. Substitute with Lord Shiva (Chandrashekhara) japa, lukewarm silver-infused water, and Nadi Shodhana breathwork.");
    return { type: "warning", level: sensitivity.level, reasons: sensitivity.reasons, badge, note };
  }
  /* Kit-card banner rendered as the first row of the Number 2 kit — directly
     below the planet title — so Section 4 and every goal focus share it.
     The number gate keeps every other kit (Jupiter, Rahu, …) clean. */
  function moonColdKitGuardrailHtml(n, p, lang) {
    if (Number(n) !== 2) return "";
    const guardrail = getRemedyClinicalGuardrail(2, p, lang || getLang());
    if (!guardrail) return "";
    return `<div class="kit-row clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="moon-cold" data-guardrail-level="${esc(guardrail.level)}"><div class="kit-ico">🛡</div><div class="kit-body"><div class="kit-label">${esc(guardrail.badge)}</div><div class="kit-value">${esc(guardrail.note)}</div></div></div>`;
  }
  /* Section 4A Emotional-plane overlay. Breathwork and water only — never a
     mantra, mineral or Lo Shu instruction — so the 4A banned-word rule
     (no fast/crystal/rudraksha/yantra/beej/ring/mala) keeps holding. */
  function moonColdTattvaOverlayHtml(p, lang) {
    const sensitivity = moonColdSensitivity(p);
    if (!sensitivity) return "";
    const l = lang || getLang();
    const label = l === "hi" ? "सर्दी-संवेदनशीलता overlay" : l === "gu" ? "શરદી-સંવેદનશીલતા ઓવરલે" : "Cold-sensitivity overlay";
    const text = l === "hi"
      ? "सुबह की छींक, जकड़न या साइनस-ठंड हो तो: सारा जल गुनगुना रखें (चांदी का बर्तन उत्तम); फ्रिज के पेय, बर्फ या रात के ठंडे तरल बिल्कुल नहीं। लंबी शीतल श्वास के बजाय नाड़ी शोधन (संतुलित, एकांतर नासिका) अपनाएं; सीधे बैठें, पहले नाक साफ करें, और जकड़न हो तो श्वास-अभ्यास रोकें — भूमि-संपर्क और गुनगुना पैर-स्नान जारी रखें।"
      : l === "gu"
        ? "સવારની છીંક, જકડાણ કે સાઇનસ-ઠંડી હોય તો: બધું જળ ગુનગુનું રાખો (ચાંદીનું વાસણ ઉત્તમ); ફ્રિજના પીણાં, બરફ કે રાત્રિના ઠંડા પ્રવાહી બિલકુલ નહીં. લાંબા શીતળ શ્વાસને બદલે નાડી શોધન (સંતુલિત, એકાંતર નાસિકા) અપનાવો; સીધા બેસો, પહેલાં નાક સાફ કરો, અને જકડાણ હોય તો શ્વાસ-અભ્યાસ રોકો — ભૂમિ-સંપર્ક અને ગુનગુનું પગ-સ્નાન ચાલુ રાખો."
        : "If prone to morning sneezing, congestion or sinus chill: keep all water lukewarm (a silver vessel is ideal); strictly no refrigerated drinks, ice or late-night cooling fluids. Prefer Nadi Shodhana (balanced, alternate-nostril) over prolonged cooling breath; sit upright, clear the nose first, and pause breathwork while actively congested — grounding and the warm foot-soak continue.";
    return `<div class="kit-row clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="moon-cold" data-guardrail-level="${esc(sensitivity.level)}"><div class="kit-ico">🛡</div><div class="kit-body"><div class="kit-label">${esc(label)}</div><div class="kit-value">${esc(text)}</div></div></div>`;
  }
  /* One-line practitioner flag for the cockpit core cell. */
  function moonColdCockpitFactHtml(p, lang) {
    const sensitivity = moonColdSensitivity(p);
    if (!sensitivity) return "";
    const l = lang || getLang();
    /* Kept to one line: the cockpit core cell is ~34 characters wide in
       print, so the full substitution list lives in the Section 4 banner. */
    const text = l === "hi"
      ? "🌙 चंद्र २ — सर्दी-संवेदनशील: केवल उष्ण चंद्र किट"
      : l === "gu"
        ? "🌙 ચંદ્ર ૨ — શરદી-સંવેદનશીલ: ફક્ત ઉષ્ણ ચંદ્ર કિટ"
        : "🌙 Moon 2 — cold-sensitive: warm lunar kit only";
    return `<div class="cockpit-fact" data-cockpit-guardrail="moon-cold" data-guardrail-level="${esc(sensitivity.level)}">${esc(text)}</div>`;
  }
  /* Health-focus section banner (Section 19+): the Moon governs Health, so a
     Health chart carries the guardrail even when Number 2 is not missing. */
  function moonColdHealthFocusHtml(p, lang) {
    if (!hasHealthFocus(p)) return "";
    const guardrail = getRemedyClinicalGuardrail(2, p, lang || getLang());
    if (!guardrail) return "";
    return `<div class="card clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="moon-cold" data-guardrail-level="${esc(guardrail.level)}"><div class="goal-head"><div class="card-title">${esc(guardrail.badge)}</div></div><div class="kit-value">${esc(guardrail.note)}</div></div>`;
  }
  /* Crystal Guide note: Pearl / Moonstone / White Opal are Sheeta stones, so
     a cold-sensitive chart trials them only on a clear airway. */
  const MOON_STONE_KEYS = ["Pearl", "Moonstone", "White Opal"];
  function moonColdCrystalNoteHtml(p, picks, lang) {
    const sensitivity = moonColdSensitivity(p);
    if (!sensitivity) return "";
    const list = picks || [];
    if (!list.some((key) => MOON_STONE_KEYS.includes(key))) return "";
    const l = lang || getLang();
    const text = l === "hi"
      ? "सर्दी-संवेदनशीलता: Pearl/Moonstone की आज़माइश तभी करें जब श्वासमार्ग साफ हो; तब तक चांदी, गुनगुने जल की आदत और नाड़ी शोधन पर रहें।"
      : l === "gu"
        ? "શરદી-સંવેદનશીલતા: Pearl/Moonstone અજમાયશ ત્યારે જ કરો જ્યારે શ્વાસમાર્ગ સાફ હોય; ત્યાં સુધી ચાંદી, ગુનગુના જળની ટેવ અને નાડી શોધન પર રહો."
        : "Cold-sensitive: trial Pearl/Moonstone only when the airway is clear; until then work silver, lukewarm water habits and Nadi Shodhana.";
    return `<div class="card clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="moon-cold" data-guardrail-level="${esc(sensitivity.level)}"><div class="kit-value">🛡 ${esc(text)}</div></div>`;
  }

  /* ---- Dosha x planet clinical contraindication overlay (Numbers 1-9) ----
     Generalisation of the Moon-cold guardrail above. Every planetary kit
     carries an Ayurvedic quality load - Ushna (heating) for Sun/Ketu/Mars,
     Sheeta-damp (cold) for Venus, Guru (heavy) for Jupiter and
     Ruksha/Chala (dry/mobile) for Saturn/Rahu/Mercury - and each load
     clashes with a matching dosha channel in the client's Driver/Conductor
     baseline, a declared Health intake tag, or (for Health-governed
     planets) a selected Health focus. The canonical kits in data.js stay
     untouched; every touchpoint renders an additive overlay row, using the
     same pattern as moonColdKitGuardrailHtml and the solar/under-18
     guardrails. Number 2 keeps its bespoke Moon-cold copy and reason
     vocabulary byte-identical: the generic path below only renders for
     numbers 1 and 3-9 (data-clinical-guardrail="dosha-contra"). */
  const HEALTH_GOVERNED_NUMBERS = [1, 2, 7, 9];
  const DOSHA_CONTRA_RULES = {
    1: { channel: "pitta", tags: ["heat"], health: true, mercury: false }, // Sun: Ushna x Pitta
    3: { channel: "kapha", tags: ["fatigue"], health: false, mercury: false }, // Jupiter: Guru x Kapha
    4: { channel: "vata", tags: ["fatigue"], health: false, mercury: true }, // Rahu: Chala x Vata
    5: { channel: "vata", tags: ["fatigue"], health: false, mercury: true }, // Mercury: Chala x Vata
    6: { channel: "kapha", tags: ["respiratory"], health: false, mercury: false }, // Venus: Sheeta-damp x Kapha
    7: { channel: "pitta", tags: ["heat"], health: true, mercury: false }, // Ketu: smoky Ushna x Pitta
    8: { channel: "vata", tags: ["respiratory", "fatigue"], health: false, mercury: true }, // Saturn: Ruksha x Vata
    9: { channel: "pitta", tags: ["heat"], health: true, mercury: false } // Mars: Ushna x Pitta
  };
  /* A dosha channel is present when either the Driver or the Conductor
     dosha names it explicitly. A Tridoshic (Mercury 5) baseline carries a
     Vata channel only - the nervous-system leg - so Tridoshic charts flag
     the Vata rules (4/5/8) but never the Pitta/Kapha rules on that basis.
     For "vata" this is exactly vataInBaseline; the other two channels have
     no legacy equivalent. */
  function doshaChannelInBaseline(p, channel) {
    if (!p || !p.doshaProfile) return false;
    const needle = String(channel || "").toLowerCase();
    if (!needle) return false;
    const types = [
      String((p.doshaProfile.driverDosha || {}).dominant || ""),
      String((p.doshaProfile.conductorDosha || {}).dominant || "")
    ].join(" ").toLowerCase();
    if (types.includes(needle)) return true;
    if (needle === "vata" && types.includes("tridoshic")) return true;
    if (types.includes("tridoshic")) return false;
    const tags = p.doshaProfile.primaryTags || [];
    return tags.includes(needle[0].toUpperCase() + needle.slice(1));
  }
  /* Per-number sensitivity: declared intake tags escalate the level to
     "declared"; a dosha channel, Mercury 5 (Vata rules) or the Health
     focus (Health-governed planets) yield "potential" guidance. */
  function doshaContraSensitivity(n, p) {
    const num = Number(n);
    if (num === 2 || !p) return null; // Number 2 keeps the bespoke Moon path
    const rule = DOSHA_CONTRA_RULES[num];
    if (!rule) return null;
    const reasons = [];
    const tags = healthTagsOf(p);
    rule.tags.forEach((tag) => { if (tags.includes(tag)) reasons.push("declared-" + tag); });
    if (doshaChannelInBaseline(p, rule.channel)) reasons.push(rule.channel + "-baseline");
    if (rule.mercury && mercuryVataNumber(p)) reasons.push("mercury-5");
    if (rule.health && hasHealthFocus(p)) reasons.push("health-focus");
    if (!reasons.length) return null;
    const declared = rule.tags.some((tag) => tags.includes(tag));
    return { level: declared ? "declared" : "potential", reasons };
  }
  const DOSHA_CONTRA_SAFETY = { en: "Clinical Safety Guardrail", hi: "\u0928\u0948\u0926\u093e\u0928\u093f\u0915 \u0938\u0941\u0930\u0915\u094d\u0937\u093e", gu: "\u0a95\u0acd\u0ab2\u0abf\u0aa8\u0abf\u0a95\u0ab2 \u0ab8\u0ab2\u0abe\u0aae\u0aa4\u0ac0" };
  const DOSHA_CONTRA_LOAD = { en: "Load", hi: "\u092d\u093e\u0930", gu: "\u0aad\u0abe\u0ab0" };
  const DOSHA_CONTRA_COPY = {
    1: {
      planet: { en: "Sun", hi: "\u0938\u0942\u0930\u094d\u092f", gu: "\u0ab8\u0ac2\u0ab0\u0acd\u0aaf" },
      declared: {
        en: "You flagged Acidity / Inflammation / Heat \u2014 run this Sun kit cool: keep the water-offering brief and at sunrise only, skip prolonged sun-gazing and midday solar practices. These add Ushna (heating) load to a Pitta channel. Balance with Chandra Bhedana (left-nostril) breathing and evening grounding; colour, charity and routine cues continue.",
        hi: "\u0906\u092a\u0928\u0947 \u090f\u0938\u093f\u0921\u093f\u091f\u0940 / \u0938\u0942\u091c\u0928 / \u0917\u0930\u094d\u092e\u0940 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u0938\u0942\u0930\u094d\u092f \u0915\u093f\u091f \u0915\u094b \u0920\u0902\u0921\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u091c\u0932-\u0905\u0930\u094d\u092a\u0923 \u0938\u0902\u0915\u094d\u0937\u093f\u092a\u094d\u0924 \u0914\u0930 \u0915\u0947\u0935\u0932 \u0938\u0942\u0930\u094d\u092f\u094b\u0926\u092f \u092a\u0930 \u0930\u0916\u0947\u0902, \u0932\u0902\u092c\u093e \u0938\u0942\u0930\u094d\u092f-\u0926\u0930\u094d\u0936\u0928 \u0914\u0930 \u0926\u094b\u092a\u0939\u0930 \u0915\u0947 \u0938\u094c\u0930 \u0905\u092d\u094d\u092f\u093e\u0938 \u091b\u094b\u0921\u093c\u0947\u0902\u0964 \u092f\u0947 \u092a\u093f\u0924\u094d\u0924-\u092e\u093e\u0930\u094d\u0917 \u092e\u0947\u0902 \u0909\u0937\u094d\u0923 (\u0917\u0930\u094d\u092e) \u092d\u093e\u0930 \u092c\u0922\u093c\u093e\u0924\u0947 \u0939\u0948\u0902\u0964 \u091a\u0902\u0926\u094d\u0930 \u092d\u0947\u0926\u0928 (\u092c\u093e\u0908\u0902 \u0928\u093e\u0938\u093f\u0915\u093e) \u0936\u094d\u0935\u093e\u0938 \u0914\u0930 \u0936\u093e\u092e \u0915\u0947 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0938\u0947 \u0938\u0902\u0924\u0941\u0932\u0928 \u0915\u0930\u0947\u0902; \u0930\u0902\u0917, \u0926\u093e\u0928 \u0914\u0930 \u0926\u093f\u0928\u091a\u0930\u094d\u092f\u093e \u0938\u0902\u0915\u0947\u0924 \u091c\u093e\u0930\u0940 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0 / \u0ab8\u0acb\u0a9c\u0acb / \u0a97\u0ab0\u0aae\u0ac0 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0ac0 \u0a9b\u0ac7 \u2014 \u0a86 \u0ab8\u0ac2\u0ab0\u0acd\u0aaf \u0a95\u0abf\u0a9f \u0aa0\u0a82\u0aa1\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0a9c\u0ab3-\u0a85\u0ab0\u0acd\u0aaa\u0aa3 \u0a9f\u0ac2\u0a82\u0a95\u0ac1\u0a82 \u0a85\u0aa8\u0ac7 \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ac2\u0ab0\u0acd\u0aaf\u0acb\u0aa6\u0aaf\u0ac7 \u0ab0\u0abe\u0a96\u0acb, \u0ab2\u0abe\u0a82\u0aac\u0ac1\u0a82 \u0ab8\u0ac2\u0ab0\u0acd\u0aaf-\u0aa6\u0ab0\u0acd\u0ab6\u0aa8 \u0a85\u0aa8\u0ac7 \u0aac\u0aaa\u0acb\u0ab0\u0aa8\u0abe \u0ab8\u0acc\u0ab0 \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8 \u0a9b\u0acb\u0aa1\u0acb. \u0a86 \u0aaa\u0abf\u0aa4\u0acd\u0aa4-\u0aae\u0abe\u0ab0\u0acd\u0a97\u0aae\u0abe\u0a82 \u0a89\u0ab7\u0acd\u0aa3 (\u0a97\u0ab0\u0aae) \u0aad\u0abe\u0ab0 \u0ab5\u0aa7\u0abe\u0ab0\u0ac7 \u0a9b\u0ac7. \u0a9a\u0a82\u0aa6\u0acd\u0ab0 \u0aad\u0ac7\u0aa6\u0aa8 (\u0aa1\u0abe\u0aac\u0ac0 \u0aa8\u0abe\u0ab8\u0abf\u0a95\u0abe) \u0ab6\u0acd\u0ab5\u0abe\u0ab8 \u0a85\u0aa8\u0ac7 \u0ab8\u0abe\u0a82\u0a9c\u0aa8\u0abe \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95\u0aa5\u0ac0 \u0ab8\u0a82\u0aa4\u0ac1\u0ab2\u0aa8 \u0a95\u0ab0\u0acb; \u0ab0\u0a82\u0a97, \u0aa6\u0abe\u0aa8 \u0a85\u0aa8\u0ac7 \u0aa6\u0abf\u0aa8\u0a9a\u0ab0\u0acd\u0aaf\u0abe \u0ab8\u0a82\u0a95\u0ac7\u0aa4 \u0a9a\u0abe\u0ab2\u0ac1 \u0ab0\u0abe\u0a96\u0acb."
      },
      potential: {
        en: "Sun remedies carry Ushna (heating) load. If prone to acidity, skin flare-ups, headaches or a short temper, keep the arghya brief and at sunrise only \u2014 no prolonged sun-gazing or heat-building practice. Let Chandra Bhedana and evening grounding carry the cooling.",
        hi: "\u0938\u0942\u0930\u094d\u092f \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u0909\u0937\u094d\u0923 (\u0917\u0930\u094d\u092e) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u090f\u0938\u093f\u0921\u093f\u091f\u0940, \u0924\u094d\u0935\u091a\u093e-\u0935\u093f\u0915\u093e\u0930, \u0938\u093f\u0930\u0926\u0930\u094d\u0926 \u092f\u093e \u091c\u0932\u094d\u0926\u0940 \u0915\u094d\u0930\u094b\u0927 \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u0905\u0930\u094d\u0918\u094d\u092f \u0938\u0902\u0915\u094d\u0937\u093f\u092a\u094d\u0924 \u0914\u0930 \u0915\u0947\u0935\u0932 \u0938\u0942\u0930\u094d\u092f\u094b\u0926\u092f \u092a\u0930 \u0930\u0916\u0947\u0902 \u2014 \u0932\u0902\u092c\u093e \u0938\u0942\u0930\u094d\u092f-\u0926\u0930\u094d\u0936\u0928 \u092f\u093e \u0917\u0930\u094d\u092e\u0940 \u092c\u0922\u093c\u093e\u0928\u0947 \u0935\u093e\u0932\u093e \u0905\u092d\u094d\u092f\u093e\u0938 \u0928\u0939\u0940\u0902\u0964 \u0936\u0940\u0924\u0932\u0928 \u091a\u0902\u0926\u094d\u0930 \u092d\u0947\u0926\u0928 \u0914\u0930 \u0936\u093e\u092e \u0915\u0947 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0938\u0947 \u0915\u0930\u093e\u090f\u0902\u0964",
        gu: "\u0ab8\u0ac2\u0ab0\u0acd\u0aaf \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0a89\u0ab7\u0acd\u0aa3 (\u0a97\u0ab0\u0aae) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0, \u0aa4\u0acd\u0ab5\u0a9a\u0abe-\u0ab5\u0abf\u0a95\u0abe\u0ab0, \u0aae\u0abe\u0aa5\u0abe\u0aa8\u0acb \u0aa6\u0ac1\u0a96\u0abe\u0ab5\u0acb \u0a95\u0ac7 \u0a9c\u0ab2\u0acd\u0aa6\u0ac0 \u0a97\u0ac1\u0ab8\u0acd\u0ab8\u0abe\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0a85\u0ab0\u0acd\u0a98\u0acd\u0aaf \u0a9f\u0ac2\u0a82\u0a95\u0acb \u0a85\u0aa8\u0ac7 \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ac2\u0ab0\u0acd\u0aaf\u0acb\u0aa6\u0aaf\u0ac7 \u0ab0\u0abe\u0a96\u0acb \u2014 \u0ab2\u0abe\u0a82\u0aac\u0ac1\u0a82 \u0ab8\u0ac2\u0ab0\u0acd\u0aaf-\u0aa6\u0ab0\u0acd\u0ab6\u0aa8 \u0a95\u0ac7 \u0a97\u0ab0\u0aae\u0ac0 \u0ab5\u0aa7\u0abe\u0ab0\u0aa4\u0acb \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8 \u0aa8\u0ab9\u0ac0\u0a82. \u0ab6\u0ac0\u0aa4\u0ab2\u0aa8 \u0a9a\u0a82\u0aa6\u0acd\u0ab0 \u0aad\u0ac7\u0aa6\u0aa8 \u0a85\u0aa8\u0ac7 \u0ab8\u0abe\u0a82\u0a9c\u0aa8\u0abe \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95\u0aa5\u0ac0 \u0a95\u0ab0\u0abe\u0ab5\u0acb."
      },
      micro: {
        en: "run it cool \u2014 brief sunrise arghya only, Chandra Bhedana at night",
        hi: "\u0907\u0938\u0947 \u0920\u0902\u0921\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u0915\u0947\u0935\u0932 \u0938\u0902\u0915\u094d\u0937\u093f\u092a\u094d\u0924 \u0938\u0942\u0930\u094d\u092f\u094b\u0926\u092f \u0905\u0930\u094d\u0918\u094d\u092f, \u0930\u093e\u0924 \u092e\u0947\u0902 \u091a\u0902\u0926\u094d\u0930 \u092d\u0947\u0926\u0928",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0aa0\u0a82\u0aa1\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0aab\u0a95\u0acd\u0aa4 \u0a9f\u0ac2\u0a82\u0a95\u0acb \u0ab8\u0ac2\u0ab0\u0acd\u0aaf\u0acb\u0aa6\u0aaf \u0a85\u0ab0\u0acd\u0a98\u0acd\u0aaf, \u0ab0\u0abe\u0aa4\u0acd\u0ab0\u0ac7 \u0a9a\u0a82\u0aa6\u0acd\u0ab0 \u0aad\u0ac7\u0aa6\u0aa8"
      }
    },
    3: {
      planet: { en: "Jupiter", hi: "\u0917\u0941\u0930\u0941", gu: "\u0a97\u0ac1\u0ab0\u0ac1" },
      declared: {
        en: "You flagged Joints / Digestion / Fatigue \u2014 run this Jupiter kit light: shorten the morning japa sitting, keep Thursday food light and sattvic, and go easy on sweet charity. These add Guru (heavy) load that deepens fatigue and sluggish digestion. Support with a daily walk and lukewarm water through the day.",
        hi: "\u0906\u092a\u0928\u0947 \u091c\u094b\u0921\u093c / \u092a\u093e\u091a\u0928 / \u0925\u0915\u093e\u0928 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u0917\u0941\u0930\u0941 \u0915\u093f\u091f \u0915\u094b \u0939\u0932\u094d\u0915\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u0938\u0941\u092c\u0939 \u0915\u093e \u091c\u092a-\u0906\u0938\u0928 \u091b\u094b\u091f\u093e \u0930\u0916\u0947\u0902, \u0917\u0941\u0930\u0941\u0935\u093e\u0930 \u0915\u093e \u092d\u094b\u091c\u0928 \u0939\u0932\u094d\u0915\u093e \u0914\u0930 \u0938\u093e\u0924\u094d\u0935\u093f\u0915 \u0930\u0916\u0947\u0902, \u092e\u0940\u0920\u0947 \u0926\u093e\u0928 \u092e\u0947\u0902 \u0938\u0902\u092f\u092e \u0930\u0916\u0947\u0902\u0964 \u092f\u0947 \u0917\u0941\u0930\u0941 (\u092d\u093e\u0930\u0940) \u092d\u093e\u0930 \u092c\u0922\u093c\u093e\u0924\u0947 \u0939\u0948\u0902 \u091c\u094b \u0925\u0915\u093e\u0928 \u0914\u0930 \u092e\u0902\u0926 \u092a\u093e\u091a\u0928 \u0915\u094b \u0917\u0939\u0930\u093e \u0915\u0930\u0924\u093e \u0939\u0948\u0964 \u0930\u094b\u091c \u0938\u0948\u0930 \u0914\u0930 \u0926\u093f\u0928\u092d\u0930 \u0917\u0941\u0928\u0917\u0941\u0928\u0947 \u092a\u093e\u0928\u0940 \u0938\u0947 \u0938\u0939\u093e\u0930\u093e \u0926\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0ab8\u0abe\u0a82\u0aa7\u0abe / \u0aaa\u0abe\u0a9a\u0aa8 / \u0aa5\u0abe\u0a95 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0acd\u0aaf\u0acb \u0a9b\u0ac7 \u2014 \u0a86 \u0a97\u0ac1\u0ab0\u0ac1 \u0a95\u0abf\u0a9f \u0ab9\u0ab3\u0ab5\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0ab8\u0ab5\u0abe\u0ab0\u0aa8\u0ac1\u0a82 \u0a9c\u0abe\u0aaa-\u0a86\u0ab8\u0aa8 \u0a9f\u0ac2\u0a82\u0a95\u0ac1\u0a82 \u0ab0\u0abe\u0a96\u0acb, \u0a97\u0ac1\u0ab0\u0ac1\u0ab5\u0abe\u0ab0\u0aa8\u0ac1\u0a82 \u0aad\u0acb\u0a9c\u0aa8 \u0ab9\u0ab3\u0ab5\u0ac1\u0a82 \u0a85\u0aa8\u0ac7 \u0ab8\u0abe\u0aa4\u0acd\u0ab5\u0abf\u0a95 \u0ab0\u0abe\u0a96\u0acb, \u0aae\u0ac0\u0aa0\u0abe \u0aa6\u0abe\u0aa8\u0aae\u0abe\u0a82 \u0ab8\u0a82\u0aaf\u0aae \u0ab0\u0abe\u0a96\u0acb. \u0a86 \u0a97\u0ac1\u0ab0\u0ac1 (\u0aad\u0abe\u0ab0\u0ac7) \u0aad\u0abe\u0ab0 \u0ab5\u0aa7\u0abe\u0ab0\u0ac7 \u0a9b\u0ac7 \u0a9c\u0ac7 \u0aa5\u0abe\u0a95 \u0a85\u0aa8\u0ac7 \u0aae\u0a82\u0aa6 \u0aaa\u0abe\u0a9a\u0aa8\u0aa8\u0ac7 \u0a8a\u0a82\u0aa1\u0ac1\u0a82 \u0a95\u0ab0\u0ac7 \u0a9b\u0ac7. \u0ab0\u0acb\u0a9c \u0a9a\u0abe\u0ab2\u0ab5\u0abe \u0a85\u0aa8\u0ac7 \u0aa6\u0abf\u0ab5\u0ab8\u0aad\u0ab0 \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0abe \u0aaa\u0abe\u0aa3\u0ac0\u0aa5\u0ac0 \u0a9f\u0ac7\u0a95\u0acb \u0a86\u0aaa\u0acb."
      },
      potential: {
        en: "Jupiter remedies carry Guru (heavy) load. If prone to heaviness, sluggish digestion or low daytime energy, keep the japa sitting short, food light and charity simple. A daily walk and lukewarm water keep the Kapha channel moving.",
        hi: "\u0917\u0941\u0930\u0941 \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u0917\u0941\u0930\u0941 (\u092d\u093e\u0930\u0940) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u092d\u093e\u0930\u0940\u092a\u0928, \u092e\u0902\u0926 \u092a\u093e\u091a\u0928 \u092f\u093e \u0926\u093f\u0928 \u092e\u0947\u0902 \u0915\u092e \u090a\u0930\u094d\u091c\u093e \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u091c\u092a-\u0906\u0938\u0928 \u091b\u094b\u091f\u093e, \u092d\u094b\u091c\u0928 \u0939\u0932\u094d\u0915\u093e \u0914\u0930 \u0926\u093e\u0928 \u0938\u0930\u0932 \u0930\u0916\u0947\u0902\u0964 \u0930\u094b\u091c \u0938\u0948\u0930 \u0914\u0930 \u0917\u0941\u0928\u0917\u0941\u0928\u093e \u092a\u093e\u0928\u0940 \u0915\u092b-\u092e\u093e\u0930\u094d\u0917 \u0915\u094b \u0917\u0924\u093f\u0936\u0940\u0932 \u0930\u0916\u0924\u0947 \u0939\u0948\u0902\u0964",
        gu: "\u0a97\u0ac1\u0ab0\u0ac1 \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0a97\u0ac1\u0ab0\u0ac1 (\u0aad\u0abe\u0ab0\u0ac7) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0aad\u0abe\u0ab0\u0ac7\u0aaa\u0aa3\u0ac1\u0a82, \u0aae\u0a82\u0aa6 \u0aaa\u0abe\u0a9a\u0aa8 \u0a95\u0ac7 \u0aa6\u0abf\u0ab5\u0ab8\u0ac7 \u0a93\u0a9b\u0ac0 \u0a8a\u0ab0\u0acd\u0a9c\u0abe\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0a9c\u0abe\u0aaa-\u0a86\u0ab8\u0aa8 \u0a9f\u0ac2\u0a82\u0a95\u0ac1\u0a82, \u0aad\u0acb\u0a9c\u0aa8 \u0ab9\u0ab3\u0ab5\u0ac1\u0a82 \u0a85\u0aa8\u0ac7 \u0aa6\u0abe\u0aa8 \u0ab8\u0ab0\u0ab3 \u0ab0\u0abe\u0a96\u0acb. \u0ab0\u0acb\u0a9c \u0a9a\u0abe\u0ab2\u0ab5\u0ac1\u0a82 \u0a85\u0aa8\u0ac7 \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0ac1\u0a82 \u0aaa\u0abe\u0aa3\u0ac0 \u0a95\u0aab-\u0aae\u0abe\u0ab0\u0acd\u0a97\u0aa8\u0ac7 \u0a97\u0aa4\u0abf\u0ab6\u0ac0\u0ab2 \u0ab0\u0abe\u0a96\u0ac7 \u0a9b\u0ac7."
      },
      micro: {
        en: "run it light \u2014 short morning japa, light food, a daily walk",
        hi: "\u0907\u0938\u0947 \u0939\u0932\u094d\u0915\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u091b\u094b\u091f\u093e \u0938\u0941\u092c\u0939-\u091c\u092a, \u0939\u0932\u094d\u0915\u093e \u092d\u094b\u091c\u0928, \u0930\u094b\u091c \u0938\u0948\u0930",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0ab9\u0ab3\u0ab5\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0a9f\u0ac2\u0a82\u0a95\u0acb \u0ab8\u0ab5\u0abe\u0ab0-\u0a9c\u0abe\u0aaa, \u0ab9\u0ab3\u0ab5\u0ac1\u0a82 \u0aad\u0acb\u0a9c\u0aa8, \u0ab0\u0acb\u0a9c \u0a9a\u0abe\u0ab2\u0ab5\u0ac1\u0a82"
      }
    },
    4: {
      planet: { en: "Rahu", hi: "\u0930\u093e\u0939\u0941", gu: "\u0ab0\u0abe\u0ab9\u0ac1" },
      declared: {
        en: "You flagged Joints / Digestion / Fatigue \u2014 run this Rahu kit steady: fix one sleep window, eat warm meals at set times, and avoid erratic fasting or all-night screen runs. Rahu's Chala (mobile) load scatters Vata and deepens fatigue. Ground with a warm oil foot massage at night; colour and charity cues continue.",
        hi: "\u0906\u092a\u0928\u0947 \u091c\u094b\u0921\u093c / \u092a\u093e\u091a\u0928 / \u0925\u0915\u093e\u0928 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u0930\u093e\u0939\u0941 \u0915\u093f\u091f \u0915\u094b \u0938\u094d\u0925\u093f\u0930 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u0938\u094b\u0928\u0947 \u0915\u093e \u090f\u0915 \u0928\u093f\u092f\u0924 \u0938\u092e\u092f \u0930\u0916\u0947\u0902, \u0928\u093f\u092f\u0924 \u0938\u092e\u092f \u092a\u0930 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928 \u0915\u0930\u0947\u0902, \u0905\u0928\u093f\u092f\u092e\u093f\u0924 \u0909\u092a\u0935\u093e\u0938 \u0914\u0930 \u0930\u093e\u0924\u092d\u0930 \u0938\u094d\u0915\u094d\u0930\u0940\u0928 \u0938\u0947 \u092c\u091a\u0947\u0902\u0964 \u0930\u093e\u0939\u0941 \u0915\u093e \u091a\u0932 (\u0905\u0938\u094d\u0925\u093f\u0930) \u092d\u093e\u0930 \u0935\u093e\u0924 \u0915\u094b \u092c\u093f\u0916\u0947\u0930\u0924\u093e \u0914\u0930 \u0925\u0915\u093e\u0928 \u092c\u0922\u093c\u093e\u0924\u093e \u0939\u0948\u0964 \u0930\u093e\u0924 \u092e\u0947\u0902 \u0917\u0930\u094d\u092e \u0924\u0947\u0932 \u0915\u0940 \u092a\u0948\u0930-\u092e\u093e\u0932\u093f\u0936 \u0938\u0947 \u0938\u094d\u0925\u093f\u0930\u0924\u093e \u0932\u093e\u090f\u0902; \u0930\u0902\u0917 \u0914\u0930 \u0926\u093e\u0928 \u0938\u0902\u0915\u0947\u0924 \u091c\u093e\u0930\u0940 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0ab8\u0abe\u0a82\u0aa7\u0abe / \u0aaa\u0abe\u0a9a\u0aa8 / \u0aa5\u0abe\u0a95 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0acd\u0aaf\u0acb \u0a9b\u0ac7 \u2014 \u0a86 \u0ab0\u0abe\u0ab9\u0ac1 \u0a95\u0abf\u0a9f \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0ab8\u0ac2\u0ab5\u0abe\u0aa8\u0acb \u0a8f\u0a95 \u0aa8\u0abf\u0aaf\u0aa4 \u0ab8\u0aae\u0aaf \u0ab0\u0abe\u0a96\u0acb, \u0aa8\u0abf\u0aaf\u0aa4 \u0ab8\u0aae\u0aaf\u0ac7 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8 \u0a95\u0ab0\u0acb, \u0a85\u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a89\u0aaa\u0ab5\u0abe\u0ab8 \u0a85\u0aa8\u0ac7 \u0ab0\u0abe\u0aa4\u0aad\u0ab0 \u0ab8\u0acd\u0a95\u0acd\u0ab0\u0ac0\u0aa8\u0aa5\u0ac0 \u0aac\u0a9a\u0acb. \u0ab0\u0abe\u0ab9\u0ac1\u0aa8\u0acb \u0a9a\u0ab2 (\u0a85\u0ab8\u0acd\u0aa5\u0abf\u0ab0) \u0aad\u0abe\u0ab0 \u0ab5\u0abe\u0aa4\u0aa8\u0ac7 \u0ab5\u0ac7\u0ab0\u0ab5\u0abf\u0a96\u0ac7\u0ab0 \u0a95\u0ab0\u0ac7 \u0a85\u0aa8\u0ac7 \u0aa5\u0abe\u0a95 \u0ab5\u0aa7\u0abe\u0ab0\u0ac7 \u0a9b\u0ac7. \u0ab0\u0abe\u0aa4\u0acd\u0ab0\u0ac7 \u0a97\u0ab0\u0aae \u0aa4\u0ac7\u0ab2\u0aa8\u0abe \u0aaa\u0a97-\u0aae\u0abe\u0ab2\u0abf\u0ab6\u0aa5\u0ac0 \u0ab8\u0acd\u0aa5\u0abf\u0ab0\u0aa4\u0abe \u0ab2\u0abe\u0ab5\u0acb; \u0ab0\u0a82\u0a97 \u0a85\u0aa8\u0ac7 \u0aa6\u0abe\u0aa8 \u0ab8\u0a82\u0a95\u0ac7\u0aa4 \u0a9a\u0abe\u0ab2\u0ac1 \u0ab0\u0abe\u0a96\u0acb."
      },
      potential: {
        en: "Rahu remedies carry Chala (mobile, restless) load. If prone to disturbed sleep, anxiety or irregular appetite, keep the practice rhythmic \u2014 fixed sleep, warm regular meals, no erratic fasts. A nightly warm oil foot massage steadies the Vata channel.",
        hi: "\u0930\u093e\u0939\u0941 \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u091a\u0932 (\u0905\u0938\u094d\u0925\u093f\u0930, \u092c\u0947\u091a\u0948\u0928) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u0928\u0940\u0902\u0926 \u092e\u0947\u0902 \u0916\u0932\u0932, \u091a\u093f\u0902\u0924\u093e \u092f\u093e \u0905\u0928\u093f\u092f\u092e\u093f\u0924 \u092d\u0942\u0916 \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u0905\u092d\u094d\u092f\u093e\u0938 \u0932\u092f\u092c\u0926\u094d\u0927 \u0930\u0916\u0947\u0902 \u2014 \u0928\u093f\u092f\u0924 \u0928\u0940\u0902\u0926, \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928, \u0905\u0928\u093f\u092f\u092e\u093f\u0924 \u0909\u092a\u0935\u093e\u0938 \u0928\u0939\u0940\u0902\u0964 \u0930\u093e\u0924 \u0915\u0940 \u0917\u0930\u094d\u092e \u0924\u0947\u0932 \u092a\u0948\u0930-\u092e\u093e\u0932\u093f\u0936 \u0935\u093e\u0924-\u092e\u093e\u0930\u094d\u0917 \u0915\u094b \u0938\u094d\u0925\u093f\u0930 \u0915\u0930\u0924\u0940 \u0939\u0948\u0964",
        gu: "\u0ab0\u0abe\u0ab9\u0ac1 \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0a9a\u0ab2 (\u0a85\u0ab8\u0acd\u0aa5\u0abf\u0ab0, \u0aac\u0ac7\u0a9a\u0ac7\u0aa8) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0a8a\u0a82\u0a98\u0aae\u0abe\u0a82 \u0a96\u0ab2\u0ac7\u0ab2, \u0a9a\u0abf\u0a82\u0aa4\u0abe \u0a95\u0ac7 \u0a85\u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0aad\u0ac2\u0a96\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8 \u0ab2\u0aaf\u0aac\u0aa6\u0acd\u0aa7 \u0ab0\u0abe\u0a96\u0acb \u2014 \u0aa8\u0abf\u0aaf\u0aa4 \u0a8a\u0a82\u0a98, \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8, \u0a85\u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a89\u0aaa\u0ab5\u0abe\u0ab8 \u0aa8\u0ab9\u0ac0\u0a82. \u0ab0\u0abe\u0aa4\u0acd\u0ab0\u0abf\u0aa8\u0ac1\u0a82 \u0a97\u0ab0\u0aae \u0aa4\u0ac7\u0ab2 \u0aaa\u0a97-\u0aae\u0abe\u0ab2\u0abf\u0ab6 \u0ab5\u0abe\u0aa4-\u0aae\u0abe\u0ab0\u0acd\u0a97\u0aa8\u0ac7 \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0a95\u0ab0\u0ac7 \u0a9b\u0ac7."
      },
      micro: {
        en: "run it steady \u2014 fixed sleep window, warm oil foot massage",
        hi: "\u0907\u0938\u0947 \u0938\u094d\u0925\u093f\u0930 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u0928\u093f\u092f\u0924 \u0928\u0940\u0902\u0926, \u0917\u0930\u094d\u092e \u0924\u0947\u0932 \u092a\u0948\u0930-\u092e\u093e\u0932\u093f\u0936",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0aa8\u0abf\u0aaf\u0aa4 \u0a8a\u0a82\u0a98, \u0a97\u0ab0\u0aae \u0aa4\u0ac7\u0ab2 \u0aaa\u0a97-\u0aae\u0abe\u0ab2\u0abf\u0ab6"
      }
    },
    5: {
      planet: { en: "Mercury", hi: "\u092c\u0941\u0927", gu: "\u0aac\u0ac1\u0aa7" },
      declared: {
        en: "You flagged Joints / Digestion / Fatigue \u2014 run this Mercury kit calm: regular warm meals, single-tasking and an early wind-down beat extra japa volume. Mercury's Chala load overstimulates tired nerves; trial Emerald only after sleep stabilizes. Wednesday charity and green accents continue.",
        hi: "\u0906\u092a\u0928\u0947 \u091c\u094b\u0921\u093c / \u092a\u093e\u091a\u0928 / \u0925\u0915\u093e\u0928 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u092c\u0941\u0927 \u0915\u093f\u091f \u0915\u094b \u0936\u093e\u0902\u0924 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928, \u090f\u0915 \u0938\u092e\u092f \u092e\u0947\u0902 \u090f\u0915 \u0915\u093e\u092e \u0914\u0930 \u091c\u0932\u094d\u0926\u0940 \u0935\u093f\u0936\u094d\u0930\u093e\u092e \u2014 \u0905\u0927\u093f\u0915 \u091c\u092a \u0938\u0947 \u092c\u0947\u0939\u0924\u0930 \u0939\u0948\u0902\u0964 \u092c\u0941\u0927 \u0915\u093e \u091a\u0932 \u092d\u093e\u0930 \u0925\u0915\u0940 \u0928\u0938\u094b\u0902 \u0915\u094b \u0905\u0924\u093f-\u0909\u0924\u094d\u0924\u0947\u091c\u093f\u0924 \u0915\u0930\u0924\u093e \u0939\u0948; \u0928\u0940\u0902\u0926 \u0938\u094d\u0925\u093f\u0930 \u0939\u094b\u0928\u0947 \u0915\u0947 \u092c\u093e\u0926 \u0939\u0940 \u092a\u0928\u094d\u0928\u093e \u0906\u091c\u092e\u093e\u090f\u0902\u0964 \u092c\u0941\u0927\u0935\u093e\u0930 \u0915\u093e \u0926\u093e\u0928 \u0914\u0930 \u0939\u0930\u0947 \u0938\u0902\u0915\u0947\u0924 \u091c\u093e\u0930\u0940 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0ab8\u0abe\u0a82\u0aa7\u0abe / \u0aaa\u0abe\u0a9a\u0aa8 / \u0aa5\u0abe\u0a95 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0acd\u0aaf\u0acb \u0a9b\u0ac7 \u2014 \u0a86 \u0aac\u0ac1\u0aa7 \u0a95\u0abf\u0a9f \u0ab6\u0abe\u0a82\u0aa4 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8, \u0a8f\u0a95 \u0ab8\u0aae\u0aaf\u0ac7 \u0a8f\u0a95 \u0a95\u0abe\u0aae \u0a85\u0aa8\u0ac7 \u0ab5\u0ab9\u0ac7\u0ab2\u0acb \u0ab5\u0abf\u0ab6\u0acd\u0ab0\u0abe\u0aae \u2014 \u0ab5\u0aa7\u0ac1 \u0a9c\u0abe\u0aaa \u0a95\u0ab0\u0aa4\u0abe\u0a82 \u0ab8\u0abe\u0ab0\u0abe \u0a9b\u0ac7. \u0aac\u0ac1\u0aa7\u0aa8\u0acb \u0a9a\u0ab2 \u0aad\u0abe\u0ab0 \u0aa5\u0abe\u0a95\u0ac7\u0ab2\u0ac0 \u0aa8\u0ab8\u0acb\u0aa8\u0ac7 \u0a85\u0aa4\u0abf-\u0a89\u0aa4\u0acd\u0aa4\u0ac7\u0a9c\u0abf\u0aa4 \u0a95\u0ab0\u0ac7 \u0a9b\u0ac7; \u0a8a\u0a82\u0a98 \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0aa5\u0aaf\u0abe \u0aaa\u0a9b\u0ac0 \u0a9c \u0ab2\u0ac0\u0ab2\u0aae \u0a85\u0a9c\u0aae\u0abe\u0ab5\u0acb. \u0aac\u0ac1\u0aa7\u0ab5\u0abe\u0ab0\u0aa8\u0ac1\u0a82 \u0aa6\u0abe\u0aa8 \u0a85\u0aa8\u0ac7 \u0ab2\u0ac0\u0ab2\u0abe \u0ab8\u0a82\u0a95\u0ac7\u0aa4 \u0a9a\u0abe\u0ab2\u0ac1 \u0ab0\u0abe\u0a96\u0acb."
      },
      potential: {
        en: "Mercury remedies carry Chala (mobile) load on the nervous system. If prone to overthinking, broken sleep or frayed nerves, keep the routine rhythmic \u2014 regular warm meals, single-tasking, early nights. Trial Emerald only once sleep is steady.",
        hi: "\u092c\u0941\u0927 \u0909\u092a\u093e\u092f \u0924\u0902\u0924\u094d\u0930\u093f\u0915\u093e-\u0924\u0902\u0924\u094d\u0930 \u092a\u0930 \u091a\u0932 (\u0905\u0938\u094d\u0925\u093f\u0930) \u092d\u093e\u0930 \u0921\u093e\u0932\u0924\u0947 \u0939\u0948\u0902\u0964 \u092f\u0926\u093f \u0905\u0924\u093f\u0935\u093f\u091a\u093e\u0930, \u091f\u0942\u091f\u0940 \u0928\u0940\u0902\u0926 \u092f\u093e \u091a\u093f\u0921\u093c\u091a\u093f\u0921\u093c\u0940 \u0928\u0938\u094b\u0902 \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u0926\u093f\u0928\u091a\u0930\u094d\u092f\u093e \u0932\u092f\u092c\u0926\u094d\u0927 \u0930\u0916\u0947\u0902 \u2014 \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928, \u090f\u0915 \u0938\u092e\u092f \u092e\u0947\u0902 \u090f\u0915 \u0915\u093e\u092e, \u091c\u0932\u094d\u0926\u0940 \u0938\u094b\u0928\u093e\u0964 \u0928\u0940\u0902\u0926 \u0938\u094d\u0925\u093f\u0930 \u0939\u094b\u0928\u0947 \u092a\u0930 \u0939\u0940 \u092a\u0928\u094d\u0928\u093e \u0906\u091c\u092e\u093e\u090f\u0902\u0964",
        gu: "\u0aac\u0ac1\u0aa7 \u0a89\u0aaa\u0abe\u0aaf\u0acb \u0a9a\u0ac7\u0aa4\u0abe-\u0aa4\u0a82\u0aa4\u0acd\u0ab0 \u0aaa\u0ab0 \u0a9a\u0ab2 (\u0a85\u0ab8\u0acd\u0aa5\u0abf\u0ab0) \u0aad\u0abe\u0ab0 \u0aa8\u0abe\u0a96\u0ac7 \u0a9b\u0ac7. \u0a9c\u0acb \u0a85\u0aa4\u0abf\u0ab5\u0abf\u0a9a\u0abe\u0ab0, \u0aa4\u0ac2\u0a9f\u0ac7\u0ab2\u0ac0 \u0a8a\u0a82\u0a98 \u0a95\u0ac7 \u0a9a\u0abf\u0aa1\u0abe\u0aaf\u0ac7\u0ab2\u0ac0 \u0aa8\u0ab8\u0acb\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0aa6\u0abf\u0aa8\u0a9a\u0ab0\u0acd\u0aaf\u0abe \u0ab2\u0aaf\u0aac\u0aa6\u0acd\u0aa7 \u0ab0\u0abe\u0a96\u0acb \u2014 \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8, \u0a8f\u0a95 \u0ab8\u0aae\u0aaf\u0ac7 \u0a8f\u0a95 \u0a95\u0abe\u0aae, \u0ab5\u0ab9\u0ac7\u0ab2\u0abe \u0ab8\u0ac2\u0ab5\u0ac1\u0a82. \u0a8a\u0a82\u0a98 \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0aa5\u0aaf\u0abe \u0aaa\u0a9b\u0ac0 \u0a9c \u0ab2\u0ac0\u0ab2\u0aae \u0a85\u0a9c\u0aae\u0abe\u0ab5\u0acb."
      },
      micro: {
        en: "run it calm \u2014 regular warm meals, single-tasking, early nights",
        hi: "\u0907\u0938\u0947 \u0936\u093e\u0902\u0924 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928, \u090f\u0915 \u0938\u092e\u092f \u092e\u0947\u0902 \u090f\u0915 \u0915\u093e\u092e, \u091c\u0932\u094d\u0926\u0940 \u0928\u0940\u0902\u0926",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0ab6\u0abe\u0a82\u0aa4 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8, \u0a8f\u0a95 \u0ab8\u0aae\u0aaf\u0ac7 \u0a8f\u0a95 \u0a95\u0abe\u0aae, \u0ab5\u0ab9\u0ac7\u0ab2\u0ac0 \u0a8a\u0a82\u0a98"
      }
    },
    6: {
      planet: { en: "Venus", hi: "\u0936\u0941\u0915\u094d\u0930", gu: "\u0ab6\u0ac1\u0a95\u0acd\u0ab0" },
      declared: {
        en: "You flagged Allergies / Respiratory / Cold \u2014 run this Venus kit light: ease off sweets and heavy dairy, keep water lukewarm, and move the body each morning. Venus carries a Sheeta-damp load that thickens Kapha and mucus. Diamond/Opal trials wait until the airway is clear; Friday charity in moderation continues.",
        hi: "\u0906\u092a\u0928\u0947 \u090f\u0932\u0930\u094d\u091c\u0940 / \u0936\u094d\u0935\u0938\u0928 / \u0938\u0930\u094d\u0926\u0940 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u0936\u0941\u0915\u094d\u0930 \u0915\u093f\u091f \u0915\u094b \u0939\u0932\u094d\u0915\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u092e\u093f\u0920\u093e\u0908 \u0914\u0930 \u092d\u093e\u0930\u0940 \u0921\u0947\u092f\u0930\u0940 \u0915\u092e \u0915\u0930\u0947\u0902, \u092a\u093e\u0928\u0940 \u0917\u0941\u0928\u0917\u0941\u0928\u093e \u0930\u0916\u0947\u0902, \u0939\u0930 \u0938\u0941\u092c\u0939 \u0936\u0930\u0940\u0930 \u0939\u093f\u0932\u093e\u090f\u0902\u0964 \u0936\u0941\u0915\u094d\u0930 \u092e\u0947\u0902 \u0936\u0940\u0924-\u0928\u092e \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948 \u091c\u094b \u0915\u092b \u0914\u0930 \u092c\u0932\u0917\u092e \u092c\u0922\u093c\u093e\u0924\u093e \u0939\u0948\u0964 \u0936\u094d\u0935\u093e\u0938\u092e\u093e\u0930\u094d\u0917 \u0938\u093e\u092b \u0939\u094b\u0928\u0947 \u0924\u0915 \u0939\u0940\u0930\u093e/\u0913\u092a\u0932 \u0906\u091c\u092e\u093e\u090f\u0902; \u0938\u0902\u092f\u092e\u093f\u0924 \u0936\u0941\u0915\u094d\u0930\u0935\u093e\u0930 \u0926\u093e\u0928 \u091c\u093e\u0930\u0940 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0a8f\u0ab2\u0ab0\u0acd\u0a9c\u0ac0 / \u0ab6\u0acd\u0ab5\u0ab8\u0aa8 / \u0ab6\u0ab0\u0aa6\u0ac0 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0ac0 \u0a9b\u0ac7 \u2014 \u0a86 \u0ab6\u0ac1\u0a95\u0acd\u0ab0 \u0a95\u0abf\u0a9f \u0ab9\u0ab3\u0ab5\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0aae\u0ac0\u0aa0\u0abe\u0a88 \u0a85\u0aa8\u0ac7 \u0aad\u0abe\u0ab0\u0ac7 \u0aa1\u0ac7\u0ab0\u0ac0 \u0a93\u0a9b\u0ac0 \u0a95\u0ab0\u0acb, \u0aaa\u0abe\u0aa3\u0ac0 \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0ac1\u0a82 \u0ab0\u0abe\u0a96\u0acb, \u0aa6\u0ab0 \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0ab6\u0ab0\u0ac0\u0ab0 \u0ab9\u0ab2\u0abe\u0ab5\u0acb. \u0ab6\u0ac1\u0a95\u0acd\u0ab0\u0aae\u0abe\u0a82 \u0ab6\u0ac0\u0aa4-\u0aad\u0ac7\u0a9c \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7 \u0a9c\u0ac7 \u0a95\u0aab \u0a85\u0aa8\u0ac7 \u0ab6\u0acd\u0ab2\u0ac7\u0ab7\u0acd\u0aae \u0ab5\u0aa7\u0abe\u0ab0\u0ac7 \u0a9b\u0ac7. \u0ab6\u0acd\u0ab5\u0abe\u0ab8\u0aae\u0abe\u0ab0\u0acd\u0a97 \u0ab8\u0abe\u0aab \u0aa5\u0abe\u0aaf \u0aaa\u0a9b\u0ac0 \u0a9c \u0ab9\u0ac0\u0ab0\u0acb/\u0a93\u0aaa\u0ab2 \u0a85\u0a9c\u0aae\u0abe\u0ab5\u0acb; \u0ab8\u0a82\u0aaf\u0aae\u0abf\u0aa4 \u0ab6\u0ac1\u0a95\u0acd\u0ab0\u0ab5\u0abe\u0ab0 \u0aa6\u0abe\u0aa8 \u0a9a\u0abe\u0ab2\u0ac1 \u0ab0\u0abe\u0a96\u0acb."
      },
      potential: {
        en: "Venus remedies carry a Sheeta (cool, damp) load. If prone to congestion, morning heaviness or sweet cravings, lighten sweets and dairy, drink lukewarm water, and add morning movement. Trial Diamond/Opal only on a clear airway.",
        hi: "\u0936\u0941\u0915\u094d\u0930 \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u0936\u0940\u0924 (\u0920\u0902\u0921\u093e, \u0928\u092e) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u091c\u0915\u0921\u093c\u0928, \u0938\u0941\u092c\u0939 \u092d\u093e\u0930\u0940\u092a\u0928 \u092f\u093e \u092e\u093f\u0920\u093e\u0908 \u0915\u0940 \u0932\u093e\u0932\u0938\u093e \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u092e\u093f\u0920\u093e\u0908-\u0921\u0947\u092f\u0930\u0940 \u0939\u0932\u094d\u0915\u0940 \u0915\u0930\u0947\u0902, \u0917\u0941\u0928\u0917\u0941\u0928\u093e \u092a\u093e\u0928\u0940 \u092a\u093f\u090f\u0902, \u0938\u0941\u092c\u0939 \u0917\u0924\u093f \u091c\u094b\u0921\u093c\u0947\u0902\u0964 \u0936\u094d\u0935\u093e\u0938\u092e\u093e\u0930\u094d\u0917 \u0938\u093e\u092b \u0939\u094b\u0928\u0947 \u092a\u0930 \u0939\u0940 \u0939\u0940\u0930\u093e/\u0913\u092a\u0932 \u0906\u091c\u092e\u093e\u090f\u0902\u0964",
        gu: "\u0ab6\u0ac1\u0a95\u0acd\u0ab0 \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0ab6\u0ac0\u0aa4 (\u0aa0\u0a82\u0aa1\u0acb, \u0aad\u0ac7\u0a9c\u0ab5\u0abe\u0ab3\u0acb) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0a9c\u0a95\u0aa1\u0abe\u0aa3, \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0aad\u0abe\u0ab0\u0ac7\u0aaa\u0aa3\u0ac1\u0a82 \u0a95\u0ac7 \u0aae\u0ac0\u0aa0\u0abe\u0a88\u0aa8\u0ac0 \u0ab2\u0abe\u0ab2\u0ab8\u0abe\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0aae\u0ac0\u0aa0\u0abe\u0a88-\u0aa1\u0ac7\u0ab0\u0ac0 \u0ab9\u0ab3\u0ab5\u0ac0 \u0a95\u0ab0\u0acb, \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0ac1\u0a82 \u0aaa\u0abe\u0aa3\u0ac0 \u0aaa\u0ac0\u0a93, \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0a97\u0aa4\u0abf \u0a89\u0aae\u0ac7\u0ab0\u0acb. \u0ab6\u0acd\u0ab5\u0abe\u0ab8\u0aae\u0abe\u0ab0\u0acd\u0a97 \u0ab8\u0abe\u0aab \u0ab9\u0acb\u0aaf \u0aa4\u0acd\u0aaf\u0abe\u0ab0\u0ac7 \u0a9c \u0ab9\u0ac0\u0ab0\u0acb/\u0a93\u0aaa\u0ab2 \u0a85\u0a9c\u0aae\u0abe\u0ab5\u0acb."
      },
      micro: {
        en: "run it light \u2014 ease off sweets, lukewarm water, morning movement",
        hi: "\u0907\u0938\u0947 \u0939\u0932\u094d\u0915\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u092e\u093f\u0920\u093e\u0908 \u0915\u092e, \u0917\u0941\u0928\u0917\u0941\u0928\u093e \u092a\u093e\u0928\u0940, \u0938\u0941\u092c\u0939 \u0917\u0924\u093f",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0ab9\u0ab3\u0ab5\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0aae\u0ac0\u0aa0\u0abe\u0a88 \u0a93\u0a9b\u0ac0, \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0ac1\u0a82 \u0aaa\u0abe\u0aa3\u0ac0, \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0a97\u0aa4\u0abf"
      }
    },
    7: {
      planet: { en: "Ketu", hi: "\u0915\u0947\u0924\u0941", gu: "\u0a95\u0ac7\u0aa4\u0ac1" },
      declared: {
        en: "You flagged Acidity / Inflammation / Heat \u2014 run this Ketu kit cool: practise in the morning or evening only, avoid noon heat and over-fasting, and keep the detachment discipline gentle. Ketu's smoky Ushna load feeds Pitta flare-ups. Cool with moonlight grounding and silver-vessel water; charity cues continue.",
        hi: "\u0906\u092a\u0928\u0947 \u090f\u0938\u093f\u0921\u093f\u091f\u0940 / \u0938\u0942\u091c\u0928 / \u0917\u0930\u094d\u092e\u0940 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u0915\u0947\u0924\u0941 \u0915\u093f\u091f \u0915\u094b \u0920\u0902\u0921\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u0915\u0947\u0935\u0932 \u0938\u0941\u092c\u0939 \u092f\u093e \u0936\u093e\u092e \u0905\u092d\u094d\u092f\u093e\u0938 \u0915\u0930\u0947\u0902, \u0926\u094b\u092a\u0939\u0930 \u0915\u0940 \u0917\u0930\u094d\u092e\u0940 \u0914\u0930 \u0905\u0924\u093f-\u0909\u092a\u0935\u093e\u0938 \u0938\u0947 \u092c\u091a\u0947\u0902, \u0935\u0948\u0930\u093e\u0917\u094d\u092f-\u0905\u0928\u0941\u0936\u093e\u0938\u0928 \u0915\u094b\u092e\u0932 \u0930\u0916\u0947\u0902\u0964 \u0915\u0947\u0924\u0941 \u0915\u093e \u0927\u0942\u092e\u093f\u0932 \u0909\u0937\u094d\u0923 \u092d\u093e\u0930 \u092a\u093f\u0924\u094d\u0924-\u092a\u094d\u0930\u0915\u094b\u092a \u092c\u0922\u093c\u093e\u0924\u093e \u0939\u0948\u0964 \u091a\u093e\u0902\u0926\u0928\u0940 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0914\u0930 \u091a\u093e\u0902\u0926\u0940 \u0915\u0947 \u092c\u0930\u094d\u0924\u0928 \u0915\u0947 \u091c\u0932 \u0938\u0947 \u0920\u0902\u0921\u0915 \u0932\u093e\u090f\u0902; \u0926\u093e\u0928 \u0938\u0902\u0915\u0947\u0924 \u091c\u093e\u0930\u0940 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0 / \u0ab8\u0acb\u0a9c\u0acb / \u0a97\u0ab0\u0aae\u0ac0 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0ac0 \u0a9b\u0ac7 \u2014 \u0a86 \u0a95\u0ac7\u0aa4\u0ac1 \u0a95\u0abf\u0a9f \u0aa0\u0a82\u0aa1\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0a95\u0ac7 \u0ab8\u0abe\u0a82\u0a9c\u0ac7 \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8 \u0a95\u0ab0\u0acb, \u0aac\u0aaa\u0acb\u0ab0\u0aa8\u0ac0 \u0a97\u0ab0\u0aae\u0ac0 \u0a85\u0aa8\u0ac7 \u0a85\u0aa4\u0abf-\u0a89\u0aaa\u0ab5\u0abe\u0ab8\u0aa5\u0ac0 \u0aac\u0a9a\u0acb, \u0ab5\u0ac8\u0ab0\u0abe\u0a97\u0acd\u0aaf-\u0ab6\u0abf\u0ab8\u0acd\u0aa4 \u0a95\u0acb\u0aae\u0ab3 \u0ab0\u0abe\u0a96\u0acb. \u0a95\u0ac7\u0aa4\u0ac1\u0aa8\u0acb \u0aa7\u0ac1\u0a82\u0aa7\u0ab3\u0acb \u0a89\u0ab7\u0acd\u0aa3 \u0aad\u0abe\u0ab0 \u0aaa\u0abf\u0aa4\u0acd\u0aa4-\u0aaa\u0acd\u0ab0\u0a95\u0acb\u0aaa \u0ab5\u0aa7\u0abe\u0ab0\u0ac7 \u0a9b\u0ac7. \u0a9a\u0abe\u0a82\u0aa6\u0aa8\u0ac0 \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95 \u0a85\u0aa8\u0ac7 \u0a9a\u0abe\u0a82\u0aa6\u0ac0\u0aa8\u0abe \u0ab5\u0abe\u0ab8\u0aa3\u0aa8\u0abe \u0a9c\u0ab3\u0aa5\u0ac0 \u0aa0\u0a82\u0aa1\u0a95 \u0ab2\u0abe\u0ab5\u0acb; \u0aa6\u0abe\u0aa8 \u0ab8\u0a82\u0a95\u0ac7\u0aa4 \u0a9a\u0abe\u0ab2\u0ac1 \u0ab0\u0abe\u0a96\u0acb."
      },
      potential: {
        en: "Ketu remedies carry a smoky Ushna (heating) load. If prone to acidity, rashes or a burning temper, practise morning or evening only \u2014 never at noon \u2014 and keep fasts gentle. Moonlight grounding and silver-vessel water carry the cooling.",
        hi: "\u0915\u0947\u0924\u0941 \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u0927\u0942\u092e\u093f\u0932 \u0909\u0937\u094d\u0923 (\u0917\u0930\u094d\u092e) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u090f\u0938\u093f\u0921\u093f\u091f\u0940, \u091a\u0915\u0924\u094d\u0924\u0947 \u092f\u093e \u091c\u0932\u0924\u0947 \u0915\u094d\u0930\u094b\u0927 \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u0915\u0947\u0935\u0932 \u0938\u0941\u092c\u0939 \u092f\u093e \u0936\u093e\u092e \u0905\u092d\u094d\u092f\u093e\u0938 \u0915\u0930\u0947\u0902 \u2014 \u0926\u094b\u092a\u0939\u0930 \u092e\u0947\u0902 \u0915\u092d\u0940 \u0928\u0939\u0940\u0902 \u2014 \u0914\u0930 \u0909\u092a\u0935\u093e\u0938 \u0915\u094b\u092e\u0932 \u0930\u0916\u0947\u0902\u0964 \u091a\u093e\u0902\u0926\u0928\u0940 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0914\u0930 \u091a\u093e\u0902\u0926\u0940 \u0915\u0947 \u092c\u0930\u094d\u0924\u0928 \u0915\u093e \u091c\u0932 \u0936\u0940\u0924\u0932\u0928 \u0915\u0930\u093e\u0924\u0947 \u0939\u0948\u0902\u0964",
        gu: "\u0a95\u0ac7\u0aa4\u0ac1 \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0aa7\u0ac1\u0a82\u0aa7\u0ab3\u0acb \u0a89\u0ab7\u0acd\u0aa3 (\u0a97\u0ab0\u0aae) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0, \u0aab\u0acb\u0ab2\u0acd\u0ab2\u0ac0\u0a93 \u0a95\u0ac7 \u0aac\u0ab3\u0aa4\u0abe \u0a97\u0ac1\u0ab8\u0acd\u0ab8\u0abe\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0a95\u0ac7 \u0ab8\u0abe\u0a82\u0a9c\u0ac7 \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8 \u0a95\u0ab0\u0acb \u2014 \u0aac\u0aaa\u0acb\u0ab0\u0ac7 \u0a95\u0acd\u0aaf\u0abe\u0ab0\u0ac7\u0aaf \u0aa8\u0ab9\u0ac0\u0a82 \u2014 \u0a85\u0aa8\u0ac7 \u0a89\u0aaa\u0ab5\u0abe\u0ab8 \u0a95\u0acb\u0aae\u0ab3 \u0ab0\u0abe\u0a96\u0acb. \u0a9a\u0abe\u0a82\u0aa6\u0aa8\u0ac0 \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95 \u0a85\u0aa8\u0ac7 \u0a9a\u0abe\u0a82\u0aa6\u0ac0\u0aa8\u0abe \u0ab5\u0abe\u0ab8\u0aa3\u0aa8\u0ac1\u0a82 \u0a9c\u0ab3 \u0ab6\u0ac0\u0aa4\u0ab2\u0aa8 \u0a95\u0ab0\u0abe\u0ab5\u0ac7 \u0a9b\u0ac7."
      },
      micro: {
        en: "run it cool \u2014 moonlight grounding, never at noon",
        hi: "\u0907\u0938\u0947 \u0920\u0902\u0921\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u091a\u093e\u0902\u0926\u0928\u0940 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915, \u0926\u094b\u092a\u0939\u0930 \u092e\u0947\u0902 \u0915\u092d\u0940 \u0928\u0939\u0940\u0902",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0aa0\u0a82\u0aa1\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0a9a\u0abe\u0a82\u0aa6\u0aa8\u0ac0 \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95, \u0aac\u0aaa\u0acb\u0ab0\u0ac7 \u0a95\u0acd\u0aaf\u0abe\u0ab0\u0ac7\u0aaf \u0aa8\u0ab9\u0ac0\u0a82"
      }
    },
    8: {
      planet: { en: "Saturn", hi: "\u0936\u0928\u093f", gu: "\u0ab6\u0aa8\u0abf" },
      declared: {
        en: "You flagged a respiratory or fatigue sensitivity \u2014 run this Saturn kit warm and oiled: regular warm meals, steady sleep hours, and a warm sesame oil massage. Saturn's Ruksha (dry) load deepens Vata dryness \u2014 avoid dry fasting and cold exposure. Blue Sapphire/Amethyst trials wait until sleep and breath are steady.",
        hi: "\u0906\u092a\u0928\u0947 \u0936\u094d\u0935\u0938\u0928 \u092f\u093e \u0925\u0915\u093e\u0928 \u0915\u0940 \u0938\u0902\u0935\u0947\u0926\u0928\u0936\u0940\u0932\u0924\u093e \u092c\u0924\u093e\u0908 \u0939\u0948 \u2014 \u0907\u0938 \u0936\u0928\u093f \u0915\u093f\u091f \u0915\u094b \u0917\u0930\u094d\u092e \u0914\u0930 \u0938\u094d\u0928\u093f\u0917\u094d\u0927 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928, \u0938\u094d\u0925\u093f\u0930 \u0928\u0940\u0902\u0926 \u0915\u0947 \u0918\u0902\u091f\u0947 \u0914\u0930 \u0917\u0930\u094d\u092e \u0924\u093f\u0932-\u0924\u0947\u0932 \u092e\u093e\u0932\u093f\u0936\u0964 \u0936\u0928\u093f \u0915\u093e \u0930\u0942\u0915\u094d\u0937 (\u0936\u0941\u0937\u094d\u0915) \u092d\u093e\u0930 \u0935\u093e\u0924-\u0936\u0941\u0937\u094d\u0915\u0924\u093e \u092c\u0922\u093c\u093e\u0924\u093e \u0939\u0948 \u2014 \u0936\u0941\u0937\u094d\u0915 \u0909\u092a\u0935\u093e\u0938 \u0914\u0930 \u0920\u0902\u0921 \u0938\u0947 \u092c\u091a\u0947\u0902\u0964 \u0928\u0940\u0902\u0926 \u0914\u0930 \u0936\u094d\u0935\u093e\u0938 \u0938\u094d\u0925\u093f\u0930 \u0939\u094b\u0928\u0947 \u0924\u0915 Blue Sapphire/Amethyst \u0928 \u0906\u091c\u092e\u093e\u090f\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0ab6\u0acd\u0ab5\u0ab8\u0aa8 \u0a95\u0ac7 \u0aa5\u0abe\u0a95\u0aa8\u0ac0 \u0ab8\u0a82\u0ab5\u0ac7\u0aa6\u0aa8\u0ab6\u0ac0\u0ab2\u0aa4\u0abe \u0aac\u0aa4\u0abe\u0ab5\u0ac0 \u0a9b\u0ac7 \u2014 \u0a86 \u0ab6\u0aa8\u0abf \u0a95\u0abf\u0a9f \u0a97\u0ab0\u0aae \u0a85\u0aa8\u0ac7 \u0ab8\u0acd\u0aa8\u0abf\u0a97\u0acd\u0aa7 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8, \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0a8a\u0a82\u0a98\u0aa8\u0abe \u0a95\u0ab2\u0abe\u0a95\u0acb \u0a85\u0aa8\u0ac7 \u0a97\u0ab0\u0aae \u0aa4\u0ab2-\u0aa4\u0ac7\u0ab2 \u0aae\u0abe\u0ab2\u0abf\u0ab6. \u0ab6\u0aa8\u0abf\u0aa8\u0acb \u0ab0\u0ac2\u0a95\u0acd\u0ab7 (\u0ab6\u0ac1\u0ab7\u0acd\u0a95) \u0aad\u0abe\u0ab0 \u0ab5\u0abe\u0aa4-\u0ab6\u0ac1\u0ab7\u0acd\u0a95\u0aa4\u0abe \u0ab5\u0aa7\u0abe\u0ab0\u0ac7 \u0a9b\u0ac7 \u2014 \u0ab6\u0ac1\u0ab7\u0acd\u0a95 \u0a89\u0aaa\u0ab5\u0abe\u0ab8 \u0a85\u0aa8\u0ac7 \u0aa0\u0a82\u0aa1\u0ac0\u0aa5\u0ac0 \u0aac\u0a9a\u0acb. \u0a8a\u0a82\u0a98 \u0a85\u0aa8\u0ac7 \u0ab6\u0acd\u0ab5\u0abe\u0ab8 \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0aa5\u0abe\u0aaf \u0aa4\u0acd\u0aaf\u0abe\u0a82 \u0ab8\u0ac1\u0aa7\u0ac0 Blue Sapphire/Amethyst \u0a85\u0a9c\u0aae\u0abe\u0ab5\u0ab6\u0acb \u0aa8\u0ab9\u0ac0\u0a82."
      },
      potential: {
        en: "Saturn remedies carry Ruksha (dry, rough) load. If prone to dry skin, constipation, joint stiffness or light broken sleep, oil the routine \u2014 warm sesame oil massage, regular warm meals, fixed bedtime. Trial the stone only once sleep and breath are steady.",
        hi: "\u0936\u0928\u093f \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u0930\u0942\u0915\u094d\u0937 (\u0936\u0941\u0937\u094d\u0915, \u0916\u0941\u0930\u0926\u0930\u093e) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u0936\u0941\u0937\u094d\u0915 \u0924\u094d\u0935\u091a\u093e, \u0915\u092c\u094d\u091c, \u091c\u094b\u0921\u093c\u094b\u0902 \u0915\u0940 \u091c\u0915\u0921\u093c\u0928 \u092f\u093e \u0939\u0932\u094d\u0915\u0940 \u091f\u0942\u091f\u0940 \u0928\u0940\u0902\u0926 \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u0926\u093f\u0928\u091a\u0930\u094d\u092f\u093e \u0915\u094b \u0938\u094d\u0928\u093f\u0917\u094d\u0927 \u0915\u0930\u0947\u0902 \u2014 \u0917\u0930\u094d\u092e \u0924\u093f\u0932-\u0924\u0947\u0932 \u092e\u093e\u0932\u093f\u0936, \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928, \u0928\u093f\u092f\u0924 \u0938\u094b\u0928\u0947 \u0915\u093e \u0938\u092e\u092f\u0964 \u0928\u0940\u0902\u0926-\u0936\u094d\u0935\u093e\u0938 \u0938\u094d\u0925\u093f\u0930 \u0939\u094b\u0928\u0947 \u092a\u0930 \u0939\u0940 \u0930\u0924\u094d\u0928 \u0906\u091c\u092e\u093e\u090f\u0902\u0964",
        gu: "\u0ab6\u0aa8\u0abf \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0ab0\u0ac2\u0a95\u0acd\u0ab7 (\u0ab6\u0ac1\u0ab7\u0acd\u0a95, \u0a96\u0ab0\u0aac\u0a9a\u0aa1\u0acb) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0ab6\u0ac1\u0ab7\u0acd\u0a95 \u0aa4\u0acd\u0ab5\u0a9a\u0abe, \u0a95\u0aac\u0a9c\u0abf\u0aaf\u0abe\u0aa4, \u0ab8\u0abe\u0a82\u0aa7\u0abe\u0aa8\u0ac0 \u0a9c\u0a95\u0aa1\u0abe\u0aa3 \u0a95\u0ac7 \u0ab9\u0ab3\u0ab5\u0ac0 \u0aa4\u0ac2\u0a9f\u0ac7\u0ab2\u0ac0 \u0a8a\u0a82\u0a98\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0aa6\u0abf\u0aa8\u0a9a\u0ab0\u0acd\u0aaf\u0abe\u0aa8\u0ac7 \u0ab8\u0acd\u0aa8\u0abf\u0a97\u0acd\u0aa7 \u0a95\u0ab0\u0acb \u2014 \u0a97\u0ab0\u0aae \u0aa4\u0ab2-\u0aa4\u0ac7\u0ab2 \u0aae\u0abe\u0ab2\u0abf\u0ab6, \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8, \u0aa8\u0abf\u0aaf\u0aa4 \u0ab8\u0ac2\u0ab5\u0abe\u0aa8\u0acb \u0ab8\u0aae\u0aaf. \u0a8a\u0a82\u0a98-\u0ab6\u0acd\u0ab5\u0abe\u0ab8 \u0ab8\u0acd\u0aa5\u0abf\u0ab0 \u0aa5\u0aaf\u0abe \u0aaa\u0a9b\u0ac0 \u0a9c \u0ab0\u0aa4\u0acd\u0aa8 \u0a85\u0a9c\u0aae\u0abe\u0ab5\u0acb."
      },
      micro: {
        en: "run it oiled \u2014 warm sesame oil massage, regular warm meals",
        hi: "\u0907\u0938\u0947 \u0938\u094d\u0928\u093f\u0917\u094d\u0927 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u0917\u0930\u094d\u092e \u0924\u093f\u0932-\u0924\u0947\u0932 \u092e\u093e\u0932\u093f\u0936, \u0928\u093f\u092f\u092e\u093f\u0924 \u0917\u0930\u094d\u092e \u092d\u094b\u091c\u0928",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0ab8\u0acd\u0aa8\u0abf\u0a97\u0acd\u0aa7 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0a97\u0ab0\u0aae \u0aa4\u0ab2-\u0aa4\u0ac7\u0ab2 \u0aae\u0abe\u0ab2\u0abf\u0ab6, \u0aa8\u0abf\u0aaf\u0aae\u0abf\u0aa4 \u0a97\u0ab0\u0aae \u0aad\u0acb\u0a9c\u0aa8"
      }
    },
    9: {
      planet: { en: "Mars", hi: "\u092e\u0902\u0917\u0932", gu: "\u0aae\u0a82\u0a97\u0ab3" },
      declared: {
        en: "You flagged Acidity / Inflammation / Heat \u2014 run this Mars kit cool: morning-only Hanuman practice, no noon exertion or overheated argument, and keep Tuesday food simple. Mars adds Ushna (heating) load to a Pitta channel. Cool with moonlight grounding and lukewarm water; keep Red Coral trials brief and supervised.",
        hi: "\u0906\u092a\u0928\u0947 \u090f\u0938\u093f\u0921\u093f\u091f\u0940 / \u0938\u0942\u091c\u0928 / \u0917\u0930\u094d\u092e\u0940 \u091a\u0941\u0928\u0940 \u0939\u0948 \u2014 \u0907\u0938 \u092e\u0902\u0917\u0932 \u0915\u093f\u091f \u0915\u094b \u0920\u0902\u0921\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902: \u0915\u0947\u0935\u0932 \u0938\u0941\u092c\u0939 \u0939\u0928\u0941\u092e\u093e\u0928-\u0905\u092d\u094d\u092f\u093e\u0938, \u0926\u094b\u092a\u0939\u0930 \u092e\u0947\u0902 \u092a\u0930\u093f\u0936\u094d\u0930\u092e \u092f\u093e \u0917\u0930\u094d\u092e \u092c\u0939\u0938 \u0928\u0939\u0940\u0902, \u092e\u0902\u0917\u0932\u0935\u093e\u0930 \u0915\u093e \u092d\u094b\u091c\u0928 \u0938\u093e\u0926\u093e \u0930\u0916\u0947\u0902\u0964 \u092e\u0902\u0917\u0932 \u092a\u093f\u0924\u094d\u0924-\u092e\u093e\u0930\u094d\u0917 \u092e\u0947\u0902 \u0909\u0937\u094d\u0923 (\u0917\u0930\u094d\u092e) \u092d\u093e\u0930 \u091c\u094b\u0921\u093c\u0924\u093e \u0939\u0948\u0964 \u091a\u093e\u0902\u0926\u0928\u0940 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0914\u0930 \u0917\u0941\u0928\u0917\u0941\u0928\u0947 \u092a\u093e\u0928\u0940 \u0938\u0947 \u0920\u0902\u0921\u0915 \u0932\u093e\u090f\u0902; Red Coral \u0915\u0940 \u0906\u091c\u092e\u093e\u0907\u0936 \u0938\u0902\u0915\u094d\u0937\u093f\u092a\u094d\u0924 \u0914\u0930 \u0926\u0947\u0916\u0930\u0947\u0916 \u092e\u0947\u0902 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aa4\u0aae\u0ac7 \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0 / \u0ab8\u0acb\u0a9c\u0acb / \u0a97\u0ab0\u0aae\u0ac0 \u0aaa\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0ac0 \u0a9b\u0ac7 \u2014 \u0a86 \u0aae\u0a82\u0a97\u0ab3 \u0a95\u0abf\u0a9f \u0aa0\u0a82\u0aa1\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb: \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0ab9\u0aa8\u0ac1\u0aae\u0abe\u0aa8-\u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8, \u0aac\u0aaa\u0acb\u0ab0\u0ac7 \u0aaa\u0ab0\u0bbf\u0ab6\u0acd\u0ab0\u0aae \u0a95\u0ac7 \u0a97\u0ab0\u0aae \u0aa6\u0ab2\u0ac0\u0ab2 \u0aa8\u0ab9\u0ac0\u0a82, \u0aae\u0a82\u0a97\u0ab3\u0ab5\u0abe\u0ab0\u0aa8\u0ac1\u0a82 \u0aad\u0acb\u0a9c\u0aa8 \u0ab8\u0abe\u0aa6\u0ac1\u0a82 \u0ab0\u0abe\u0a96\u0acb. \u0aae\u0a82\u0a97\u0ab3 \u0aaa\u0abf\u0aa4\u0acd\u0aa4-\u0aae\u0abe\u0ab0\u0acd\u0a97\u0aae\u0abe\u0a82 \u0a89\u0ab7\u0acd\u0aa3 (\u0a97\u0ab0\u0aae) \u0aad\u0abe\u0ab0 \u0a89\u0aae\u0ac7\u0ab0\u0ac7 \u0a9b\u0ac7. \u0a9a\u0abe\u0a82\u0aa6\u0aa8\u0ac0 \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95 \u0a85\u0aa8\u0ac7 \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0abe \u0aaa\u0abe\u0aa3\u0ac0\u0aa5\u0ac0 \u0aa0\u0a82\u0aa1\u0a95 \u0ab2\u0abe\u0ab5\u0acb; Red Coral \u0a85\u0a9c\u0aae\u0abe\u0aaf\u0ab6 \u0a9f\u0ac2\u0a82\u0a95\u0ac0 \u0a85\u0aa8\u0ac7 \u0aa6\u0ac7\u0a96\u0ab0\u0ac7\u0a96 \u0ab9\u0ac7\u0aa0\u0ab3 \u0ab0\u0abe\u0a96\u0acb."
      },
      potential: {
        en: "Mars remedies carry Ushna (heating) load. If prone to acidity, inflammation or a quick temper, practise in the morning only, avoid noon heat and heated confrontation. Moonlight grounding and lukewarm water carry the cooling; keep Red Coral trials brief.",
        hi: "\u092e\u0902\u0917\u0932 \u0909\u092a\u093e\u092f\u094b\u0902 \u092e\u0947\u0902 \u0909\u0937\u094d\u0923 (\u0917\u0930\u094d\u092e) \u092d\u093e\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964 \u092f\u0926\u093f \u090f\u0938\u093f\u0921\u093f\u091f\u0940, \u0938\u0942\u091c\u0928 \u092f\u093e \u091c\u0932\u094d\u0926\u0940 \u0915\u094d\u0930\u094b\u0927 \u0915\u0940 \u092a\u094d\u0930\u0935\u0943\u0924\u094d\u0924\u093f \u0939\u094b, \u0924\u094b \u0915\u0947\u0935\u0932 \u0938\u0941\u092c\u0939 \u0905\u092d\u094d\u092f\u093e\u0938 \u0915\u0930\u0947\u0902, \u0926\u094b\u092a\u0939\u0930 \u0915\u0940 \u0917\u0930\u094d\u092e\u0940 \u0914\u0930 \u0917\u0930\u094d\u092e \u091f\u0915\u0930\u093e\u0935 \u0938\u0947 \u092c\u091a\u0947\u0902\u0964 \u091a\u093e\u0902\u0926\u0928\u0940 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0914\u0930 \u0917\u0941\u0928\u0917\u0941\u0928\u093e \u092a\u093e\u0928\u0940 \u0936\u0940\u0924\u0932\u0928 \u0915\u0930\u093e\u0924\u0947 \u0939\u0948\u0902; Red Coral \u0915\u0940 \u0906\u091c\u092e\u093e\u0907\u0936 \u0938\u0902\u0915\u094d\u0937\u093f\u092a\u094d\u0924 \u0930\u0916\u0947\u0902\u0964",
        gu: "\u0aae\u0a82\u0a97\u0ab3 \u0a89\u0aaa\u0abe\u0aaf\u0acb\u0aae\u0abe\u0a82 \u0a89\u0ab7\u0acd\u0aa3 (\u0a97\u0ab0\u0aae) \u0aad\u0abe\u0ab0 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7. \u0a9c\u0acb \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0, \u0ab8\u0acb\u0a9c\u0acb \u0a95\u0ac7 \u0a9c\u0ab2\u0acd\u0aa6\u0ac0 \u0a97\u0ac1\u0ab8\u0acd\u0ab8\u0abe\u0aa8\u0ac0 \u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf, \u0aa4\u0acb \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8 \u0a95\u0ab0\u0acb, \u0aac\u0aaa\u0acb\u0ab0\u0aa8\u0ac0 \u0a97\u0ab0\u0aae\u0ac0 \u0a85\u0aa8\u0ac7 \u0a97\u0ab0\u0aae \u0a9f\u0a95\u0ab0\u0abe\u0ab5\u0aa5\u0ac0 \u0aac\u0a9a\u0acb. \u0a9a\u0abe\u0a82\u0aa6\u0aa8\u0ac0 \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95 \u0a85\u0aa8\u0ac7 \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0ac1\u0a82 \u0aaa\u0abe\u0aa3\u0ac0 \u0ab6\u0ac0\u0aa4\u0ab2\u0aa8 \u0a95\u0ab0\u0abe\u0ab5\u0ac7 \u0a9b\u0ac7; Red Coral \u0a85\u0a9c\u0aae\u0abe\u0aaf\u0ab6 \u0a9f\u0ac2\u0a82\u0a95\u0ac0 \u0ab0\u0abe\u0a96\u0acb."
      },
      micro: {
        en: "run it cool \u2014 morning-only practice, no noon exertion",
        hi: "\u0907\u0938\u0947 \u0920\u0902\u0921\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902 \u2014 \u0915\u0947\u0935\u0932 \u0938\u0941\u092c\u0939 \u0905\u092d\u094d\u092f\u093e\u0938, \u0926\u094b\u092a\u0939\u0930 \u092e\u0947\u0902 \u092a\u0930\u093f\u0936\u094d\u0930\u092e \u0928\u0939\u0940\u0902",
        gu: "\u0aa4\u0ac7\u0aa8\u0ac7 \u0aa0\u0a82\u0aa1\u0abe \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb \u2014 \u0aab\u0a95\u0acd\u0aa4 \u0ab8\u0ab5\u0abe\u0ab0\u0ac7 \u0a85\u0aad\u0acd\u0aaf\u0abe\u0ab8, \u0aac\u0aaa\u0acb\u0ab0\u0ac7 \u0aaa\u0ab0\u0bbf\u0ab6\u0acd\u0ab0\u0aae \u0aa8\u0ab9\u0ac0\u0a82"
      }
    }
  };
  function doshaContraBadge(n, lang) {
    const num = Number(n);
    const l = lang || "en";
    const copy = DOSHA_CONTRA_COPY[num] || {};
    const planet = ((copy.planet || {}))[l] || copy.planet.en;
    const rule = DOSHA_CONTRA_RULES[num] || {};
    const dosha = doshaLabel(rule.channel, l);
    return `🛡 ${DOSHA_CONTRA_SAFETY[l] || DOSHA_CONTRA_SAFETY.en} \u2014 ${planet} \u00d7 ${dosha} ${DOSHA_CONTRA_LOAD[l] || DOSHA_CONTRA_LOAD.en}`;
  }
  /* Advisory shape mirroring getRemedyClinicalGuardrail(2, p): badge + note
     for a loaded number, or null when no rule leg fires. */
  function doshaContraGuardrail(num, profile, langOverride) {
    const n = Number(num);
    if (n === 2) return null;
    const sensitivity = doshaContraSensitivity(n, profile);
    if (!sensitivity) return null;
    const lang = langOverride || getLang();
    const copy = DOSHA_CONTRA_COPY[n];
    if (!copy) return null;
    const declared = sensitivity.level === "declared";
    const note = declared ? (copy.declared[lang] || copy.declared.en) : (copy.potential[lang] || copy.potential.en);
    return { type: "warning", level: sensitivity.level, reasons: sensitivity.reasons, badge: doshaContraBadge(n, lang), note };
  }
  /* Kit-card banner rendered as the first overlay row of a loaded kit, below
     any Moon-cold banner (which only Number 2 carries) and above the
     canonical Beej mantra row. Section 4, goal focuses, triage Tier-1 and
     the daily ritual share it through this one helper. */
  function doshaContraKitGuardrailHtml(n, p, lang) {
    const num = Number(n);
    if (num === 2) return "";
    const guardrail = doshaContraGuardrail(num, p, lang || getLang());
    if (!guardrail) return "";
    return `<div class="kit-row clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="dosha-contra" data-contra-number="${num}" data-guardrail-level="${esc(guardrail.level)}"><div class="kit-ico">🛡</div><div class="kit-body"><div class="kit-label">${esc(guardrail.badge)}</div><div class="kit-value">${esc(guardrail.note)}</div></div></div>`;
  }
  /* Latent Tier-2 suffix: one short clause, mirroring moonLatentSuffix. */
  function doshaContraLatentSuffix(item, p, lang) {
    const num = Number(item && item.n);
    if (num === 2 || !doshaContraSensitivity(num, p)) return "";
    const copy = DOSHA_CONTRA_COPY[num];
    if (!copy) return "";
    const l = lang || getLang();
    const micro = copy.micro[l] || copy.micro.en;
    return l === "hi" ? ` \u0938\u0915\u094d\u0930\u093f\u092f \u0939\u094b\u0928\u0947 \u092a\u0930 ${micro}\u0964` : l === "gu" ? ` \u0ab8\u0a95\u0acd\u0ab0\u0abf\u0aaf \u0aa5\u0abe\u0aaf \u0aa4\u0acd\u0aaf\u0abe\u0ab0\u0ac7 ${micro}.` : ` When it activates, ${micro}.`;
  }
  /* One-line practitioner flag for the cockpit core cell. Unlike the Moon
     fact, this one always renders beside it: the two flags never overlap
     (Moon 2 is excluded here) and the cockpit must show every loaded
     missing number at a glance. */
  function doshaContraCockpitFactHtml(p, lang) {
    if (!p) return "";
    const flagged = (p.loShuMissing || []).map(Number).filter((n) => doshaContraSensitivity(n, p));
    if (!flagged.length) return "";
    const l = lang || getLang();
    const nums = flagged.join(" \u00b7 ");
    /* One line only (narrow print cell); the per-kit banners carry detail. */
    const text = l === "hi"
      ? `\u26a0 \u0926\u094b\u0937-\u0935\u093f\u0930\u0941\u0926\u094d\u0927 ${nums} \u2014 \u091a\u093f\u0939\u094d\u0928\u093f\u0924 \u0915\u093f\u091f \u0939\u0932\u094d\u0915\u0947 \u0930\u0942\u092a \u092e\u0947\u0902`
      : l === "gu"
        ? `\u26a0 \u0aa6\u0acb\u0ab7-\u0ab5\u0abf\u0ab0\u0ac1\u0aa6\u0acd\u0aa7 ${nums} \u2014 \u0a9a\u0abf\u0ab9\u0acd\u0aa8\u0abf\u0aa4 \u0a95\u0abf\u0a9f \u0ab9\u0ab3\u0ab5\u0abe \u0ab0\u0ac2\u0aaa\u0ac7`
        : `\u26a0 Dosha-contra ${nums} \u2014 run flagged kits mild`;
    return `<div class="cockpit-fact" data-cockpit-guardrail="dosha-contra" data-contra-numbers="${esc(flagged.join(","))}">${esc(text)}</div>`;
  }
  /* Health-focus section card (Section 19+): Health-governed kits 1/7/9
     carry the overlay at section level under a Health focus, mirroring
     moonColdHealthFocusHtml for Number 2. */
  function doshaContraHealthFocusHtml(p, lang) {
    if (!hasHealthFocus(p)) return "";
    const flagged = HEALTH_GOVERNED_NUMBERS.filter((n) => n !== 2 && doshaContraSensitivity(n, p));
    if (!flagged.length) return "";
    const l = lang || getLang();
    const nums = flagged.join(" \u00b7 ");
    const title = l === "hi" ? "🛡 \u0928\u0948\u0926\u093e\u0928\u093f\u0915 \u0938\u0941\u0930\u0915\u094d\u0937\u093e \u2014 \u0938\u094d\u0935\u093e\u0938\u094d\u0925\u094d\u092f-\u0936\u093e\u0938\u093f\u0924 \u0915\u093f\u091f" : l === "gu" ? "🛡 \u0a95\u0acd\u0ab2\u0abf\u0aa8\u0abf\u0a95\u0ab2 \u0ab8\u0ab2\u0abe\u0aae\u0aa4\u0ac0 \u2014 \u0a86\u0ab0\u0acb\u0a97\u0acd\u0aaf-\u0ab6\u0abe\u0ab8\u0abf\u0aa4 \u0a95\u0abf\u0a9f" : "🛡 Clinical Safety Guardrail \u2014 Health-Governed Kits";
    const body = l === "hi"
      ? `\u0905\u0902\u0915 ${nums} \u0938\u094d\u0935\u093e\u0938\u094d\u0925\u094d\u092f \u0915\u0947 \u0936\u093e\u0938\u0915 \u0939\u0948\u0902 \u0914\u0930 \u0907\u0938 \u091a\u093e\u0930\u094d\u091f \u0915\u0947 \u0935\u093f\u0930\u0941\u0926\u094d\u0927 \u0926\u094b\u0937-\u092d\u093e\u0930 \u0930\u0916\u0924\u0947 \u0939\u0948\u0902 \u2014 \u0907\u0928\u0915\u0947 \u0915\u093f\u091f \u0928\u0940\u091a\u0947 \u0926\u093f\u090f \u092c\u0948\u0928\u0930\u094b\u0902 \u0915\u0947 \u0939\u0932\u094d\u0915\u0947 \u0928\u0948\u0926\u093e\u0928\u093f\u0915 \u0930\u0942\u092a \u092e\u0947\u0902 \u091a\u0932\u093e\u090f\u0902\u0964 \u0930\u0902\u0917, \u0926\u093e\u0928 \u0914\u0930 \u092d\u0942\u092e\u093f-\u0938\u0902\u092a\u0930\u094d\u0915 \u0938\u0902\u0915\u0947\u0924 \u092f\u0925\u093e\u0935\u0924 \u091c\u093e\u0930\u0940 \u0930\u0916\u0947\u0902\u0964`
      : l === "gu"
        ? `\u0a85\u0a82\u0a95 ${nums} \u0a86\u0ab0\u0acb\u0a97\u0acd\u0aaf\u0aa8\u0abe \u0ab6\u0abe\u0ab8\u0a95 \u0a9b\u0ac7 \u0a85\u0aa8\u0ac7 \u0a86 \u0a9a\u0abe\u0ab0\u0acd\u0a9f \u0ab5\u0abf\u0ab0\u0ac1\u0aa6\u0acd\u0aa7 \u0aa6\u0acb\u0ab7-\u0aad\u0abe\u0ab0 \u0ab0\u0abe\u0a96\u0ac7 \u0a9b\u0ac7 \u2014 \u0aa4\u0ac7\u0aa8\u0abe \u0a95\u0abf\u0a9f \u0aa8\u0ac0\u0a9a\u0ac7 \u0a86\u0aaa\u0ac7\u0ab2\u0abe \u0aac\u0ac7\u0aa8\u0ab0\u0acb\u0aa8\u0abe \u0ab9\u0ab3\u0ab5\u0abe \u0a95\u0acd\u0ab2\u0abf\u0aa8\u0abf\u0a95\u0ab2 \u0ab0\u0ac2\u0aaa\u0ac7 \u0a9a\u0ab2\u0abe\u0ab5\u0acb. \u0ab0\u0a82\u0a97, \u0aa6\u0abe\u0aa8 \u0a85\u0aa8\u0ac7 \u0aad\u0ac2\u0aae\u0abf-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95 \u0ab8\u0a82\u0a95\u0ac7\u0aa4 \u0aaf\u0aa5\u0abe\u0ab5\u0aa4 \u0a9a\u0abe\u0ab2\u0ac1 \u0ab0\u0abe\u0a96\u0acb.`
        : `Numbers ${nums} govern Health and carry a dosha load against this chart \u2014 run their kits in the mild clinical form shown in the banners below. Colour, charity and grounding cues continue unchanged.`;
    return `<div class="card clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="dosha-contra" data-contra-scope="health-focus" data-contra-numbers="${esc(flagged.join(","))}"><div class="goal-head"><div class="card-title">${esc(title)}</div></div><div class="kit-value">${esc(body)}</div></div>`;
  }
  /* Crystal Guide note: Ruby / Red Coral / Carnelian are Ushna stones, so a
     Pitta-loaded chart trials them briefly and on cool skin. */
  const HEAT_STONE_KEYS = ["Ruby", "Red Coral", "Carnelian", "Red Jasper", "Red Aventurine"];
  function doshaContraCrystalNoteHtml(p, picks, lang) {
    if (!p) return "";
    const list = picks || [];
    if (!list.some((key) => HEAT_STONE_KEYS.includes(key))) return "";
    if (![1, 7, 9].some((n) => doshaContraSensitivity(n, p))) return "";
    const l = lang || getLang();
    const text = l === "hi"
      ? "\u0917\u0930\u094d\u092e\u0940-\u0938\u0902\u0935\u0947\u0926\u0928\u0936\u0940\u0932\u0924\u093e: Ruby / Red Coral / Carnelian \u0915\u0940 \u0906\u091c\u092e\u093e\u0907\u0936 \u0938\u0902\u0915\u094d\u0937\u093f\u092a\u094d\u0924 \u0914\u0930 \u0920\u0902\u0921\u0940 \u0924\u094d\u0935\u091a\u093e \u092a\u0930 \u0915\u0930\u0947\u0902; \u090f\u0938\u093f\u0921\u093f\u091f\u0940-\u092a\u094d\u0930\u0935\u0923 \u0939\u094b\u0902 \u0924\u094b \u0932\u093e\u0932-\u092a\u0924\u094d\u0925\u0930 \u0915\u0947 \u0938\u093e\u0925 \u091a\u093e\u0902\u0926\u0928\u0940-\u0938\u0902\u092a\u0930\u094d\u0915\u093f\u0924 \u091a\u093e\u0902\u0926\u0940 \u0914\u0930 \u0917\u0941\u0928\u0917\u0941\u0928\u0947 \u092a\u093e\u0928\u0940 \u0915\u0940 \u0906\u0926\u0924 \u0930\u0916\u0947\u0902\u0964"
      : l === "gu"
        ? "\u0a97\u0ab0\u0aae\u0ac0-\u0ab8\u0a82\u0ab5\u0ac7\u0aa6\u0aa8\u0ab6\u0ac0\u0ab2\u0aa4\u0abe: Ruby / Red Coral / Carnelian \u0a85\u0a9c\u0aae\u0abe\u0aaf\u0ab6 \u0a9f\u0ac2\u0a82\u0a95\u0ac0 \u0a85\u0aa8\u0ac7 \u0aa0\u0a82\u0aa1\u0ac0 \u0aa4\u0acd\u0ab5\u0a9a\u0abe \u0aaa\u0ab0 \u0a95\u0ab0\u0acb; \u0a8f\u0ab8\u0abf\u0aa1\u0abf\u0a9f\u0ac0-\u0ab5\u0ac3\u0aa4\u0acd\u0aa4\u0abf \u0ab9\u0acb\u0aaf \u0aa4\u0acb \u0ab2\u0abe\u0ab2-\u0aaa\u0aa5\u0acd\u0aa5\u0ab0 \u0ab8\u0abe\u0aa5\u0ac7 \u0a9a\u0abe\u0a82\u0aa6\u0aa8\u0ac0-\u0ab8\u0a82\u0aaa\u0ab0\u0acd\u0a95\u0abf\u0aa4 \u0a9a\u0abe\u0a82\u0aa6\u0ac0 \u0a85\u0aa8\u0ac7 \u0a97\u0ac1\u0aa8\u0a97\u0ac1\u0aa8\u0abe \u0aaa\u0abe\u0aa3\u0ac0\u0aa8\u0ac0 \u0a9f\u0ac7\u0ab5 \u0ab0\u0abe\u0a96\u0acb."
        : "Heat-sensitive: trial Ruby / Red Coral / Carnelian briefly and on cool skin; if acidity-prone, favour moonlight-charged silver and lukewarm water habits alongside any red-stone trial.";
    return `<div class="card clinical-guardrail-banner guardrail-warning" data-clinical-guardrail="dosha-contra" data-contra-scope="crystal-heat"><div class="kit-value">🛡 ${esc(text)}</div></div>`;
  }

  /* NON-REMOVABLE classical safety boundary. These pairs are owned by the
     application, not by the knowledge pack: db.dasha.relationshipPolicy can
     only ADD pairs, never clear these. Any change here must be mirrored in
     knowledge-pack/schema.json → db.dasha.relationshipPolicy
     → x-classicalSafetyPairs (smoke.test.js asserts the two stay in sync),
     and in the "Friendship matrix overrides" note in README.md. */
  const CLASSICAL_GRAHAN_PAIRS = new Set(["4-2", "2-4", "4-1", "1-4"]);
  const CLASSICAL_SAMBANDHA_HOSTILE_PAIRS = new Set([
    "4-2", "2-4", // Rahu – Moon (Grahan / eclipse axis)
    "4-1", "1-4", // Rahu – Sun (Grahan / eclipse axis)
    "1-8", "8-1", // Sun – Saturn
    "9-8", "8-9", // Mars – Saturn
    "3-6", "6-3"  // Jupiter – Venus (Deva guru vs Asura guru)
  ]);

  function configuredDashaPairs(key) {
    const configured = getActiveDB().dasha && getActiveDB().dasha.relationshipPolicy && getActiveDB().dasha.relationshipPolicy[key];
    return new Set(Array.isArray(configured) ? configured.map((pair) => String(pair)) : []);
  }

  function getDashaRelationship(mdLord, adLord, driver) {
    const md = Number(mdLord), ad = Number(adLord);
    const pairKey = `${md}-${ad}`;
    const grahan = CLASSICAL_GRAHAN_PAIRS.has(pairKey) || configuredDashaPairs("grahanPairs").has(pairKey);
    const configuredHostile = configuredDashaPairs("additionalHostilePairs").has(pairKey);
    const packRelation = relation(md, ad);
    if (grahan || CLASSICAL_SAMBANDHA_HOSTILE_PAIRS.has(pairKey) || configuredHostile || packRelation === "enemy") {
      return {
        md, ad, relation: "enemy", grahan,
        source: grahan ? "grahan" : configuredHostile ? "pack-sambandha-hostile" : "sambandha-hostile",
        status: "Conflicting / Caution",
        tone: "bad",                 // existing badge palette
        cssClass: "badge-conflict",  // never green
        guidance: grahan
          ? "Grahan (eclipse) sub-period — the guest lord is eclipsed by its host. Neutralise the sector and defer irreversible commitments."
          : "Adversarial sub-period — the Antardasha lord runs inside a hostile Mahadasha climate. Neutralise with targeted remedies."
      };
    }
    if (packRelation === "friendly") {
      return {
        md, ad, relation: "friendly", grahan: false, source: "md-ad",
        status: "Favourable", tone: "good", cssClass: "badge-friendly",
        guidance: "Host and guest lords cooperate — this sub-period converts with ordinary effort."
      };
    }
    // MD × AD is neutral: fall back to how the sub-lord meets the natal Driver.
    const driverRelation = relation(Number(driver), ad);
    const harmonious = driverRelation === "friendly";
    return {
      md, ad, relation: "neutral", grahan: false, source: "driver-fallback",
      driverRelation,
      status: harmonious ? "Favourable" : "Neutral / Active",
      tone: harmonious ? "good" : "info",
      cssClass: harmonious ? "badge-friendly" : "badge-neutral",
      guidance: harmonious
        ? "The pairing is neutral, but the sub-lord aligns with your natal foundation — energy flows smoothly."
        : "A neutral pairing: results follow deliberate effort rather than momentum."
    };
  }

  /* Ayurvedic dosha profile — determined only by the Driver + Conductor.
     Foundation/Lo Shu count signals never alter this baseline. It enriches
     the Health interpretation without adding PII or asking any medical
     measurement. Read as traditional wellness guidance only. */
  function buildDoshaProfile(src) {
    const db = getActiveDB();
    const map = db.dosha || (window.DB && window.DB.dosha) || {};
    const ddriver = map[src.driver] || {};
    const dconductor = map[src.conductor] || {};
    const counts = { pitta: 0, vata: 0, kapha: 0 };
    const addType = (label) => {
      String(label || "").toLowerCase().split(/[\s\u2013\-/,]+/).forEach((tok) => {
        const k = tok.replace(/[^a-z]/g, "");
        if (counts[k] !== undefined) counts[k]++;
      });
    };
    addType(ddriver.dominant);
    addType(dconductor.dominant);
    const driverT = String(ddriver.dominant || "").toLowerCase();
    const conductorT = String(dconductor.dominant || "").toLowerCase();
    if (driverT.includes("tridoshic") || conductorT.includes("tridoshic")) {
      counts.pitta++; counts.vata++; counts.kapha++;
    }
    const max = Math.max(counts.pitta, counts.vata, counts.kapha);
    const cap = (x) => x === "pitta" ? "Pitta" : x === "vata" ? "Vata" : "Kapha";
    const top = ["pitta", "vata", "kapha"].filter((k) => counts[k] === max && max > 0);
    const primary = top.map(cap).join(top.length > 1 ? "–" : "");
    return {
      driverNumber: src.driver,
      conductorNumber: src.conductor,
      driverType: ddriver.dominant || "",
      conductorType: dconductor.dominant || "",
      driverDosha: ddriver,
      conductorDosha: dconductor,
      counts,
      primary,
      primaryTags: top.map(cap)
    };
  }

  /* Ishta Devta (deity protection) profile — pure function over the Driver +
     Conductor numbers using the classical number → deity correspondence.
     It names the personal guardian deity (ishta devta) behind each key
     number and turns the deity's chant, 108× round and offerings into a
     small, concrete protection practice. Read as traditional spiritual
     guidance — the reader's own family tradition and guru's instruction
     always take priority. */
  function buildDeityProfile(src) {
    const db = getActiveDB();
    const map = db.deity || (window.DB && window.DB.deity) || {};
    const driverDeity = map[src.driver] || null;
    const conductorDeity = map[src.conductor] || null;
    const getGodName = (d) => d && (d.archetypes ? (d.archetypes.en || d.archetypes) : (d.god ? (d.god.en || d.god) : ""));
    const sameDeity = !!(driverDeity && conductorDeity &&
      getGodName(driverDeity) && getGodName(conductorDeity) &&
      getGodName(driverDeity) === getGodName(conductorDeity) &&
      driverDeity.mantra === conductorDeity.mantra);
    return {
      driverNumber: src.driver,
      conductorNumber: src.conductor,
      driverDeity,
      conductorDeity,
      sameDeity
    };
  }

  const APP_VERSION = ($('meta[name="nv-version"]') && $('meta[name="nv-version"]').content) || "2.18.0";
  const BUILD_LABEL = ($('meta[name="nv-build-label"]') && $('meta[name="nv-build-label"]').content) || "Build 2026-09-19";
  const DEFAULT_MANIFEST_PATH = "knowledge-pack/latest.json";
  const STORAGE_KEYS = {
    lang: "nv_lang",
    packCache: "nv360.packCache.v1",
    history: "nv360.history.v1",
    practice: "nv360.practice.v1",
    journal: "nv360.journal.v1",
    plan: "nv360.plan.v1",
    contributionEnabled: "nv360.contributionEnabled.v1",
    contributionOutbox: "nv360.contributionOutbox.v1",
    fieldMode: "nv360.fieldMode.v1",
    // Conditional section bundling for the PDF export: "client" prints a
    // punchy dossier (technical telemetry, JSON scaffolds and the practitioner
    // cockpit are suppressed); "practitioner" prints the full compendium.
    reportMode: "nv360.reportMode.v1",
    // Primary Dasha engine: "ank" (Ank Jyotish, default) or "vimshottari".
    // The non-primary engine is cordoned off as an explicit cross-reference
    // appendix so the two systems never read as contradicting each other.
    dashaEngine: "nv360.dashaEngine.v1"
  };
  const SECTION = { core: 1, traits: 2, grid: 3, weak: 4, tattva: "4A", zodiac: 5, name: 6, nameArch: "6A", mobile: 7, vehicle: 8, premises: "8A", watch: 9, crystal: 10, colours: 11, career: 12, timing: 13, cycles: "13a", dasha: 14, memory: 15, vastu: 16, compass: "16A", kua: 17, western: "17A", compatibility: 18, goalsStart: 19 };

  /* ---------------- Scaled Sadhana (client lifestyle bandwidth) ----------------
     A consultation fails on adherence, not on knowledge: a corporate consultee
     with two hours of commute cannot hold a 108x mala, and a full-time sadhak
     is not served by an 11x token count. The client therefore picks the depth
     of practice they can genuinely sustain, and the report sizes the daily
     practice to it.

     What the scale may change:  the japa count, whether a dedicated mala is
                                used, the breathwork minutes, the aushadhi snan
                                form, the charity cadence and the decluttering
                                cadence — nothing else.
     What the scale may never change:
       • the Lo Shu remedy target (the grid chooses it, not the client);
       • the triage tiers (one acute target stays one acute target);
       • a clinical guardrail. A held japa stays held, the Moon-cold form
         stays warm, the dosha x planet mild form and the solar-load
         moderation still cap the dose, and the under-18 gem deferral stands.
     Ordering: beginner (Minimalist / Corporate) → intermediate (Practitioner /
     Sadhak, the historical 27x quarter-mala dose, and therefore the default so
     an existing chart's prescription cannot silently change) → classical (one
     full 108x mala, full aushadhi snan, weekly power-day charity). */
  const SADHANA_LEVELS = ["beginner", "intermediate", "classical"];
  const SADHANA_DEFAULT = "intermediate";
  const SADHANA_SCALE = {
    beginner: { key: "beginner", japa: 11, dedicatedMala: false, breathMinutes: 5, snan: "colour-cue", charity: "monthly", space: "declutter" },
    intermediate: { key: "intermediate", japa: 27, dedicatedMala: true, breathMinutes: 10, snan: "power-day", charity: "weekly", space: "sector" },
    classical: { key: "classical", japa: 108, dedicatedMala: true, breathMinutes: 20, snan: "every-practice-day", charity: "weekly", space: "sector" }
  };
  /* i18n key profile per level — one place to keep the report and the intake
     chips reading from the same copy. */
  const SADHANA_I18N = {
    beginner: { title: "sadhanaBeginnerTitle", desc: "sadhanaBeginnerDesc", japa: "sadhanaJapaBeginner", breath: "sadhanaBreathBeginner", snan: "sadhanaSnanBeginner", charity: "sadhanaCharityBeginner", space: "sadhanaSpaceBeginner", dose: "sadhanaDoseBeginner", deepen: "sadhanaDeepenBeginner" },
    intermediate: { title: "sadhanaIntermediateTitle", desc: "sadhanaIntermediateDesc", japa: "sadhanaJapaIntermediate", breath: "sadhanaBreathIntermediate", snan: "sadhanaSnanIntermediate", charity: "sadhanaCharityPractitioner", space: "sadhanaSpacePractitioner", dose: "sadhanaDoseIntermediate", deepen: "sadhanaDeepenIntermediate" },
    classical: { title: "sadhanaClassicalTitle", desc: "sadhanaClassicalDesc", japa: "sadhanaJapaClassical", breath: "sadhanaBreathClassical", snan: "sadhanaSnanClassical", charity: "sadhanaCharityPractitioner", space: "sadhanaSpacePractitioner", dose: "sadhanaDoseClassical", deepen: "sadhanaDeepenClassical" }
  };

  function normalizeSadhana(value) {
    const key = String(value == null ? "" : value).trim().toLowerCase();
    return SADHANA_LEVELS.indexOf(key) >= 0 ? key : SADHANA_DEFAULT;
  }
  function sadhanaScaleOf(p) {
    return SADHANA_SCALE[normalizeSadhana(p && p.sadhana)] || SADHANA_SCALE[SADHANA_DEFAULT];
  }
  function sadhanaI18n(key) {
    return SADHANA_I18N[normalizeSadhana(key)] || SADHANA_I18N[SADHANA_DEFAULT];
  }
  /* Devanagari / Gujarati numerals for practice counts. The app localises its
     prose but prints ASCII digits by default; japa counts are the one place
     where a Hindi or Gujarati reader expects ११ / ૨૭, so the scaled counts are
     rendered through this map. */
  const LOCAL_DIGITS = {
    hi: ["०", "१", "२", "३", "४", "५", "६", "७", "८", "९"],
    gu: ["૦", "૧", "૨", "૩", "૪", "૫", "૬", "૭", "૮", "૯"]
  };
  function localNumber(value, lang) {
    const text = String(value == null ? "" : value);
    const map = LOCAL_DIGITS[lang || getLang()];
    if (!map) return text;
    return text.replace(/\d/g, (d) => map[Number(d)]);
  }
  /* Upfront Ethical & Health Notice, printed directly inside the Northstar
     Summary (page 2 of the report). It states plainly what the frameworks are
     and are not, and it is the sentence the Scaled Sadhana Classical depth
     points back to before any intense breathwork or herbal routine. It carries
     the framework-note authority: it never prescribes and never renders a
     remedy obligation. */
  function clinicalNoticeHtml() {
    return `<aside class="summary-notice" role="note" data-authority="framework-note" data-clinical-notice="upfront">
      <p class="summary-notice-title">${t("clinicalNoticeTitle", "Ethical &amp; Health Notice")}</p>
      <p class="summary-notice-body">${t("clinicalNoticeBody", "Numerology, Vedic Dasha timelines, and elemental tattva suggestions are traditional interpretive frameworks for personal reflection and lifestyle harmonization. They do not constitute medical, psychological, legal, or financial diagnoses. Always consult a licensed healthcare professional before initiating new dietary fasts, herbal routines, or intense breathwork regimens.")}</p>
    </aside>`;
  }

  /* The Scaled Sadhana card: the client's chosen practice depth, rendered with
     the Lo Shu remedy authority it annotates. Purely additive — it sizes the
     daily practice and never re-sources the remedy target or overrides a
     clinical guardrail. */
  function sadhanaPlanBlock(p, plan) {
    const lang = getLang();
    const scale = sadhanaScaleOf(p);
    const copy = sadhanaI18n(scale.key);
    const levelTitle = t(copy.title, "Practitioner / Sadhak");
    /* A held japa is a clinical verdict, not a bandwidth setting: the scale
       reports the dose it will resume, and says so. */
    const holdJapa = !!(plan && plan.holdJapa);
    const japaValue = holdJapa
      ? `${t(copy.japa, "")} — ${t("sadhanaJapaHeld", "held this cycle by the Remedy Triage; the dose resumes when the target activates.")}`
      : t(copy.japa, "");
    const rows = [
      { key: "japa", ico: "🔢", label: t("sadhanaRowJapa", "Japa / affirmation dose"), value: japaValue },
      { key: "mala", ico: "📿", label: t("sadhanaRowMala", "Mala"), value: scale.dedicatedMala ? t("sadhanaMalaDedicated", "One dedicated mala, kept only for this japa.") : t("sadhanaMalaOptional", "No mala needed — count the short mantra on your fingers.") },
      { key: "breath", ico: "🌬", label: t("sadhanaRowBreath", "Breathwork"), value: t(copy.breath, "") },
      { key: "snan", ico: "🛁", label: t("sadhanaRowSnan", "Aushadhi snan"), value: t(copy.snan, "") },
      { key: "charity", ico: "🎁", label: t("sadhanaRowCharity", "Charity cadence"), value: t(copy.charity, "") },
      { key: "space", ico: "🧹", label: t("sadhanaRowSpace", "Space"), value: t(copy.space, "") }
    ];
    /* Guardrails are annotations, never rewrites: a held japa stays held, the
       Moon-cold form stays warm, and the classical depth is the only one that
       adds an intensity caveat. */
    const notes = [t("sadhanaScaleNote", "The scale sizes the practice; it never changes the Lo Shu remedy target, and a clinical guardrail always caps the dose.")];
    if (scale.key === "classical") notes.push(t("sadhanaIntenseNotice", "Classical depth adds an intense breathwork and aushadhi snan regimen — clear it with a licensed healthcare professional first (see the Ethical & Health Notice in the Northstar Summary)."));
    if (isMinorProfile(p)) notes.push(t("sadhanaMinorNote", "Under-18 chart: a parent or guardian supervises this practice, and the breathwork stays gentle — no breath retention holds."));
    return `<div class="card sadhana-card" data-remedy-authority="lo-shu" data-sadhana-scale="${scale.key}">
      <div class="goal-head">
        <div class="card-title">${t("sadhanaCardTitle", "Your Scaled Sadhana — practice depth")}: <strong>${esc(levelTitle)}</strong></div>
        <span class="badge info">${localNumber(scale.japa, lang)}×</span>
      </div>
      <div class="card-sub">${t("sadhanaCardDesc", "Your chosen practice depth. It sizes the daily practice only — the Lo Shu target, the triage tiers and every clinical guardrail stay exactly as prescribed.")}</div>
      <div class="kit">
        ${rows.map((row) => `<div class="kit-row" data-sadhana-row="${row.key}"><div class="kit-ico">${row.ico}</div><div class="kit-body"><div class="kit-label">${esc(row.label)}</div><div class="kit-value">${esc(row.value)}</div></div></div>`).join("")}
      </div>
      <div class="judge-note">${notes.map((line) => `<p>${esc(line)}</p>`).join("")}<p>${t("sadhanaEditHint", "Change this any time in Edit Details → Practice Depth.")}</p></div>
    </div>`;
  }

  const state = {
    lang: "en",
    pack: null,
    history: [],
    contributionEnabled: false,
    lastInput: null,
    activeProfileKey: "",
    reportModule: "foundation",
    toastTimer: null,
    updatePromise: null,
    // Conditional section bundling — see STORAGE_KEYS.reportMode.
    reportMode: "client",
    // Primary Dasha engine — see STORAGE_KEYS.dashaEngine.
    dashaEngine: "ank"
  };

  try {
    const savedLang = localStorage.getItem(STORAGE_KEYS.lang);
    if (savedLang && ["en", "hi", "gu"].includes(savedLang)) {
      state.lang = savedLang;
    }
    const savedMode = localStorage.getItem(STORAGE_KEYS.reportMode);
    if (savedMode === "practitioner") state.reportMode = "practitioner";
    const savedEngine = localStorage.getItem(STORAGE_KEYS.dashaEngine);
    if (savedEngine === "vimshottari") state.dashaEngine = "vimshottari";
  } catch (e) {}

  /* Report mode drives conditional section bundling. Client mode suppresses
     every practitioner-only block (cockpit, telemetry, JSON scaffolds,
     Vimshottari internals) on screen AND in the PDF; Practitioner mode
     expands the full compendium. The class lives on <body> so both the live
     view and the print stylesheet react to the same switch. */
  function applyReportModeClass() {
    try {
      const mode = state.reportMode === "practitioner" ? "practitioner" : "client";
      if (typeof document !== "undefined" && document.body) {
        document.body.classList.toggle("report-mode-practitioner", mode === "practitioner");
        document.body.classList.toggle("report-mode-client", mode === "client");
        document.body.setAttribute("data-report-mode", mode);
      }
    } catch (e) {}
  }

  function setReportMode(mode) {
    const next = mode === "practitioner" ? "practitioner" : "client";
    state.reportMode = next;
    try { localStorage.setItem(STORAGE_KEYS.reportMode, next); } catch (e) {}
    applyReportModeClass();
    $$("[data-report-mode-btn]").forEach((btn) => {
      const active = btn.dataset.reportModeBtn === next;
      btn.classList.toggle("active", active);
      btn.setAttribute("aria-pressed", String(active));
    });
    const sel = $("#reportModeSelect");
    if (sel) sel.value = next;
    if (lastProfile) showReport(lastProfile, { preserveScroll: true });
  }

  function setDashaEngine(engine) {
    const next = engine === "vimshottari" ? "vimshottari" : "ank";
    state.dashaEngine = next;
    try { localStorage.setItem(STORAGE_KEYS.dashaEngine, next); } catch (e) {}
    $$("[data-dasha-engine-select]").forEach((sel) => { sel.value = next; });
    if (lastProfile) showReport(lastProfile, { preserveScroll: true });
  }

  function getLang() {
    return state.lang || "en";
  }

  function getI18nPack(lang) {
    const l = lang || getLang();
    return (window.I18N && window.I18N[l]) || (window.I18N && window.I18N.en) || null;
  }

  function t(key, fallback) {
    const p = getI18nPack();
    if (p && p.ui && p.ui[key] !== undefined) return p.ui[key];
    const en = window.I18N && window.I18N.en && window.I18N.en.ui;
    if (en && en[key] !== undefined) return en[key];
    return fallback || "";
  }

  /* Localised knowledge-pack text — entries shaped { en, hi, gu } with
     English as the guaranteed fallback (same pattern as excessEnergy). */
  const loc = (field, lang) => {
    const l = lang || getLang();
    return (field && (field[l] || field.en)) || "";
  };

  function getActiveDB() {
    const base = window.DB || {};
    const pack = getI18nPack() || {};
    const merged = Object.assign({}, base, pack);

    // Keep the two grids explicit and independent. Localised legacy Lo Shu
    // plane/arrow prose may live at the top level of a language pack, but it
    // only decorates the Foundation's canonical Lo Shu data; it can never
    // replace either coordinate system.
    if (base.loShuGrid) {
      merged.loShuGrid = Object.assign({}, base.loShuGrid, {
        layout: base.loShuGrid.layout,
        planes: Array.isArray(pack.planes) ? pack.planes : base.loShuGrid.planes,
        arrows: Array.isArray(pack.arrows) ? pack.arrows : base.loShuGrid.arrows
      });
    }
    if (base.vedicGrid) merged.vedicGrid = base.vedicGrid;
    delete merged.planes;
    delete merged.arrows;
    delete merged.loshuLayout;
    return merged;
  }

  const DAY_NAMES = {
    en: { 1: "Sunday", 2: "Monday", 9: "Tuesday", 5: "Wednesday", 3: "Thursday", 6: "Friday", 8: "Saturday", 4: "Saturday", 7: "Tuesday" },
    hi: { 1: "रविवार", 2: "सोमवार", 9: "मंगलवार", 5: "बुधवार", 3: "गुरुवार", 6: "शुक्रवार", 8: "शनिवार", 4: "शनिवार", 7: "मंगलवार" },
    gu: { 1: "રવિવાર", 2: "સોમવાર", 9: "મંગળવાર", 5: "બુધવાર", 3: "ગુરુવાર", 6: "શુક્રવાર", 8: "શનિવાર", 4: "શનિવાર", 7: "મંગળવાર" }
  };
  const DAY_OF = DAY_NAMES.en;

  function dayOf(n) {
    const lang = getLang();
    return (DAY_NAMES[lang] && DAY_NAMES[lang][n]) || DAY_NAMES.en[n] || "Sunday";
  }

  function relBadge(r) {
    const lang = getLang();
    const labels = {
      en: { friendly: "Harmonious", neutral: "Neutral", enemy: "Conflicting" },
      hi: { friendly: "अनुकूल (मित्र)", neutral: "सामान्य (सम)", enemy: "प्रतिकूल (शत्रु)" },
      gu: { friendly: "અનુકૂળ (મિત્ર)", neutral: "સામાન્ય (સમ)", enemy: "પ્રતિકૂળ (શત્રુ)" }
    }[lang] || { friendly: "Harmonious", neutral: "Neutral", enemy: "Conflicting" };

    return r === "friendly" ? `<span class="badge good">${labels.friendly}</span>`
      : r === "neutral" ? `<span class="badge warn">${labels.neutral}</span>`
      : `<span class="badge bad">${labels.enemy}</span>`;
  }

  function safeJSONParse(value, fallback) {
    if (!value) return fallback;
    try { return JSON.parse(value); } catch { return fallback; }
  }
  function readStore(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return safeJSONParse(raw, fallback);
    } catch {
      return fallback;
    }
  }
  function writeStore(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  }

  function compareVersions(a, b) {
    const pa = String(a || "0").split(".").map(Number);
    const pb = String(b || "0").split(".").map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const va = pa[i] || 0, vb = pb[i] || 0;
      if (va > vb) return 1;
      if (va < vb) return -1;
    }
    return 0;
  }
  function isoDate(d) {
    return (d instanceof Date ? d : d ? new Date(d) : new Date()).toISOString();
  }
  function prettyDate(input) {
    if (!input) return "";
    const d = new Date(input);
    if (isNaN(d.getTime())) return String(input);
    const lang = getLang();
    const loc = lang === "hi" ? "hi-IN" : lang === "gu" ? "gu-IN" : "en-IN";
    try {
      return d.toLocaleDateString(loc, { day: "numeric", month: "short", year: "numeric" });
    } catch (e) {
      return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
    }
  }
  /* Unambiguous, locale-aware birth-date line for the report hero.
     Built from the profile's numeric day/month/year in UTC — never from a
     parsed date string — so a viewer's timezone can never shift the birth
     date by a day, and rendered through the active locale so a Hindi or
     Gujarati report reads its month names in that language. "Short" month
     names also keep the hero consistent with every other date in the report
     (en-GB renders September as "Sept", exactly like the Dasha tables). */
  function formatBirthDate(p) {
    if (!p || !p.day || !p.month || !p.year) return "";
    const lang = getLang();
    const loc = lang === "hi" ? "hi-IN" : lang === "gu" ? "gu-IN" : "en-GB";
    try {
      return new Date(Date.UTC(p.year, p.month - 1, p.day)).toLocaleDateString(loc, { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
    } catch (e) {
      const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      return `${p.day} ${MONTHS[p.month - 1]} ${p.year}`;
    }
  }
  /* Report generation stamp, same locale rules as formatBirthDate. */
  function formatStampDate(d) {
    const lang = getLang();
    const loc = lang === "hi" ? "hi-IN" : lang === "gu" ? "gu-IN" : "en-GB";
    try {
      return (d instanceof Date ? d : new Date(d)).toLocaleDateString(loc, { day: "numeric", month: "short", year: "numeric" });
    } catch (e) {
      return new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
    }
  }
  function formatBirthTime(t) {
    if (!t) return "";
    const [hh, mm] = t.split(":").map(Number);
    if (isNaN(hh) || isNaN(mm)) return t;
    const ampm = hh >= 12 ? "PM" : "AM";
    const h12 = hh % 12 || 12;
    return `${h12}:${String(mm).padStart(2, "0")} ${ampm}`;
  }
  function profileKeyOf(input) {
    return `${input.name || "anonymous"}|${input.dob || ""}`;
  }

  /* Full reduction chain for a total, e.g. 30 → [30, 3], 38 → [38, 11, 2].
     Used so printed formulas never skip an intermediate step. */
  function reductionChain(total) {
    const chain = [Math.abs(Number(total)) || 0];
    while (chain[chain.length - 1] > 9) {
      chain.push(String(chain[chain.length - 1]).split("").reduce((a, d) => a + Number(d), 0));
    }
    return chain;
  }

  /* Deterministic, printable digit breakdown for a root-number equation.
     Built straight from the digits of the date itself — never by string
     surgery on a previously formatted label — so no character can be dropped,
     duplicated or replaced by an artifact such as "$". Zeros are filtered for
     the classical display; because a zero adds nothing, the printed sum stays
     mathematically identical to the full digit sum.
       formatConductorBreakdown("1978-01-31", 3) → "3 + 1 + 1 + 1 + 9 + 7 + 8 = 30 → 3"
     The digit ORDER follows the string given: pass "DDMMYYYY" (or a
     "DD-MM-YYYY" string) for a day → month → year reading. */
  function formatConductorBreakdown(dobString, conductorNumber) {
    const raw = String(dobString === undefined || dobString === null ? "" : dobString).trim();
    // An ISO date ("YYYY-MM-DD") is re-ordered to the classical day → month →
    // year reading; any other input keeps the order it was given in.
    const iso = raw.match(/^(\d{4})\D(\d{1,2})\D(\d{1,2})$/);
    const ordered = iso ? `${iso[3]}${iso[2]}${iso[1]}` : raw;
    const cleanDigits = ordered.replace(/\D/g, "").split("").map(Number);
    const nonZeroDigits = cleanDigits.filter((d) => d !== 0);
    if (!nonZeroDigits.length) return "";
    const sumFormula = nonZeroDigits.join(" + ");
    const rawSum = nonZeroDigits.reduce((acc, curr) => acc + curr, 0);
    const target = Number(conductorNumber) || reductionChain(rawSum)[reductionChain(rawSum).length - 1];
    if (rawSum === target) return `${sumFormula} = ${rawSum}`;
    const steps = reductionChain(rawSum).slice(1);
    if (steps[steps.length - 1] !== target) steps.push(target);
    return `${sumFormula} = ${rawSum} → ${steps.join(" → ")}`;
  }

  /* Root-number equation rendered as explicit, grouped digit tokens. Every
     digit (including 0) is its own <span>, groups are separated by a visible
     divider and the result is stated in words. This is intentionally not a
     monospace digit string: PDF renderers/OCR mis-read mono zeros as 8 and
     a wrapped leading "3 +" as "$". */
  function rootFormulaMarkup(groups, digitSum, root, lang) {
    const digitTokens = (digits) => String(digits).split("").map((d) => `<span class="root-digit">${d}</span>`).join(`<span class="root-op">+</span>`);
    const groupMarkup = groups.map((g) => `<span class="root-group" aria-label="${esc(g.label)}"><span class="root-group-label">${esc(g.label)}</span><span class="root-group-digits">${digitTokens(g.digits)}</span></span>`).join(`<span class="root-op root-op-group">+</span>`);
    // Intermediate totals only (e.g. 38 → 11); the final root is the bold result.
    const intermediate = reductionChain(digitSum).slice(0, -1);
    const steps = intermediate.length
      ? intermediate.map((v, i) => `${i === 0 ? "" : `<span class="root-arrow">→</span>`}<span class="${i === 0 ? "root-total" : "root-step"}">${v}</span>`).join("") + `<span class="root-arrow">→</span>`
      : "";
    const words = intermediate.length
      ? (lang === "hi" ? `सभी अंकों का योग ${digitSum}, जो ${root} में सिमटता है` : lang === "gu" ? `બધા અંકોનો સરવાળો ${digitSum}, જે ${root} માં સંકોચાય છે` : `all digits add to ${digitSum}, which reduces to ${root}`)
      : (lang === "hi" ? `अंकों का योग सीधे ${root} है` : lang === "gu" ? `અંકોનો સરવાળો સીધો ${root} છે` : `the digits add directly to ${root}`);
    // Canonical plain-text equation, generated by formatConductorBreakdown
    // from the raw digits. It is the machine-checkable copy of the same maths
    // and the string a practitioner can quote verbatim to a client.
    const plain = formatConductorBreakdown(groups.map((g) => g.digits).join(""), root);
    return `<div class="root-formula" data-digit-sum="${digitSum}" data-root="${root}"><div class="root-formula-line">${groupMarkup}<span class="root-op">=</span>${steps}<strong class="root-result">${root}</strong></div><div class="root-formula-words">${words}</div><div class="root-formula-plain" data-plain-formula="${esc(plain)}">${esc(plain)}</div></div>`;
  }

  function normalizePack(raw, source) {
    if (!raw || typeof raw !== "object") return null;
    const db = raw.db || window.DB || {};
    return {
      app: raw.app || "NumeroVastu 360",
      schemaVersion: raw.schemaVersion || 2,
      packVersion: raw.packVersion || "2.9.0",
      generatedAt: raw.generatedAt || isoDate(),
      manifestPath: raw.manifestPath || DEFAULT_MANIFEST_PATH,
      source: source || "bundled",
      contribution: Object.assign({
        mode: "scaffold",
        endpoint: null,
        description: "Anonymous aggregate counts only. Off by default; no names, DOBs, phones or raw free-text are sent."
      }, raw.contribution || {}),
      db
    };
  }

  function validatePack(pack) {
    if (!pack || typeof pack !== "object") return { ok: false, errors: ["pack must be an object"] };
    const errs = [];
    if (!Number.isInteger(pack.schemaVersion) || pack.schemaVersion < 2) errs.push("schemaVersion must be 2 or newer for the hybrid pack");
    if (!pack.packVersion || typeof pack.packVersion !== "string") errs.push("missing packVersion");
    if (!pack.db || typeof pack.db !== "object") errs.push("missing db object");
    else {
      const db = pack.db;
      ["numbers", "traits", "loShuGrid", "vedicGrid", "dasha", "vastu", "crystals", "careers", "personalYear"].forEach((k) => {
        if (!db[k] || typeof db[k] !== "object") errs.push(`db.${k} missing or invalid`);
      });
      if (db.loShuGrid) {
        const layout = db.loShuGrid.layout;
        const cells = Array.isArray(layout) ? layout.flat() : [];
        const canonicalCells = LO_SHU_GRID_LAYOUT.flat();
        if (!Array.isArray(layout) || layout.length !== 3 || layout.some((row) => !Array.isArray(row) || row.length !== 3) || cells.join(",") !== canonicalCells.join(",")) {
          errs.push("db.loShuGrid.layout must be the canonical 4–9–2 / 3–5–7 / 8–1–6 template");
        }
        const planes = db.loShuGrid.planes;
        const validPlanes = Array.isArray(planes) && planes.length === LO_SHU_PLANE_CELLS.length &&
          planes.every((plane, index) => plane && Array.isArray(plane.cells) && plane.cells.join(",") === LO_SHU_PLANE_CELLS[index].join(","));
        if (!validPlanes) errs.push("db.loShuGrid.planes must define the canonical eight Lo Shu planes");
        const arrows = db.loShuGrid.arrows;
        const validArrows = Array.isArray(arrows) && arrows.length === LO_SHU_ARROW_LINES.length &&
          arrows.every((arrow, index) => arrow && Array.isArray(arrow.line) && arrow.line.join(",") === LO_SHU_ARROW_LINES[index].join(","));
        if (!validArrows) errs.push("db.loShuGrid.arrows must define the canonical eight Lo Shu arrows");
        const plotting = db.loShuGrid.plotting;
        if (!plotting || ["zeros", "year", "calculations"].some((key) => typeof plotting[key] !== "string")) {
          errs.push("db.loShuGrid.plotting must document zero, full-year and calculation rules");
        }
      }
      if (db.vedicGrid) {
        const layout = db.vedicGrid.layout;
        const cells = Array.isArray(layout) ? layout.flat() : [];
        const canonicalCells = VEDIC_GRID_LAYOUT.flat();
        if (!Array.isArray(layout) || layout.length !== 3 || layout.some((row) => !Array.isArray(row) || row.length !== 3) || cells.join(",") !== canonicalCells.join(",")) {
          errs.push("db.vedicGrid.layout must be the canonical 3–1–9 / 6–7–5 / 2–8–4 template");
        }
        const validPlanes = Array.isArray(db.vedicGrid.planes) && db.vedicGrid.planes.length === DEFAULT_VEDIC_PLANES.length &&
          db.vedicGrid.planes.every((plane, index) => plane && plane.key === DEFAULT_VEDIC_PLANES[index].key &&
            Array.isArray(plane.cells) && plane.cells.join(",") === DEFAULT_VEDIC_PLANES[index].cells.join(","));
        if (!validPlanes) errs.push("db.vedicGrid.planes must define the canonical Practical, Materialistic and Emotional horizontal planes");
        const filtering = db.vedicGrid.filtering;
        if (!filtering || ["zeros", "century", "dateDeduplication", "calculations"].some((key) => typeof filtering[key] !== "string")) {
          errs.push("db.vedicGrid.filtering must document zero, century, date de-duplication and calculation rules");
        }
      }
      const compass = db.vastu && db.vastu.directions;
      if (!compass || Object.entries(VEDIC_VASTU_COMPASS_PLANETS).some(([direction, planet]) => !compass[direction] || Number(compass[direction].planet) !== planet)) {
        errs.push("db.vastu.directions must retain the canonical Vedic planetary compass mapping");
      }
      // The Timeline is part of the hybrid contract, so every release pack
      // must carry Dasha zones matching the Vedic compass (including Ketu's
      // North-East / Center axis), never a legacy grid axis.
      if (db.dasha && Object.entries(VEDIC_DASHA_ZONES).some(([number, zone]) => !db.dasha[number] || !db.dasha[number].zone || db.dasha[number].zone.en !== zone)) {
        errs.push("db.dasha zones must retain the canonical Vedic planetary direction mapping");
      }
      if (db.dasha && db.dasha.relationshipPolicy) {
        ["additionalHostilePairs", "grahanPairs"].forEach((key) => {
          if (!Array.isArray(db.dasha.relationshipPolicy[key]) || db.dasha.relationshipPolicy[key].some((pair) => !/^[1-9]-[1-9]$/.test(String(pair)))) {
            errs.push(`db.dasha.relationshipPolicy.${key} must contain only number-pair strings such as 4-2`);
          }
        });
      }
      if (db.numbers) {
        for (let i = 1; i <= 9; i++) {
          if (!db.numbers[i]) errs.push(`db.numbers[${i}] missing`);
        }
      }
    }
    return { ok: errs.length === 0, errors: errs };
  }

  /* ---- Field read mode --------------------------------------------------
     A phone-first reading mode for consultations away from a desk. It is a
     presentation-only switch: no engine, pack or authority behaviour changes,
     and it is suppressed in print so the A4 cockpit sheet is unaffected.
     Declared here (above the boot sequence) so the stored preference can be
     applied on load without hitting the temporal dead zone. */
  let fieldMode = false;
  try { fieldMode = window.localStorage.getItem(STORAGE_KEYS.fieldMode) === "1"; } catch (err) { fieldMode = false; }

  function applyFieldMode() {
    document.body.classList.toggle("field-mode", fieldMode);
    const btn = $("#fieldBtn");
    if (!btn) return;
    btn.setAttribute("aria-pressed", fieldMode ? "true" : "false");
    const label = t(fieldMode ? "fieldModeOff" : "fieldModeOn", fieldMode ? "Exit field mode" : "Field mode");
    const span = $(".btn-text", btn);
    if (span) span.textContent = label;
    btn.setAttribute("title", label);
  }

  function toggleFieldMode() {
    fieldMode = !fieldMode;
    try { window.localStorage.setItem(STORAGE_KEYS.fieldMode, fieldMode ? "1" : "0"); } catch (err) { /* private mode */ }
    applyFieldMode();
    showToast(t(fieldMode ? "fieldModeOnToast" : "fieldModeOffToast",
      fieldMode ? "Field mode on — larger type, single column, reduced clutter." : "Field mode off."), "info");
  }

  function showToast(message, tone) {
    const vp = $("#toastViewport");
    if (!vp) return;
    vp.innerHTML = `<div class="toast toast-${tone || "info"}" role="status">${esc(message)}</div>`;
    if (state.toastTimer) clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => {
      vp.innerHTML = "";
      state.toastTimer = null;
    }, 2800);
  }

  function bundledPack() {
    return normalizePack(window.__NV_BUNDLED_PACK || { db: window.DB }, "bundled");
  }
  function activePack() {
    return state.pack || bundledPack();
  }
  function setActivePack(pack, source, persist) {
    const norm = normalizePack(pack, source);
    const valid = validatePack(norm);
    if (!valid.ok) return false;
    state.pack = norm;
    if (norm.db) window.DB = norm.db;
    if (persist) writeStore(STORAGE_KEYS.packCache, norm);
    updateKnowledgeUI();
    return true;
  }
  function latestSnapshot() {
    return state.history[0] || null;
  }

  function hydrateState() {
    state.history = readStore(STORAGE_KEYS.history, []);
    state.contributionEnabled = !!readStore(STORAGE_KEYS.contributionEnabled, false);
    const cached = readStore(STORAGE_KEYS.packCache, null);
    const bundled = bundledPack();
    /* A stale cached pack could silently shadow newer bundled content after an
       upgrade — only restore the cache when it is at least as new as the bundle,
       and overwrite a stale cache with the fresh bundled pack. */
    if (cached && cached.packVersion && compareVersions(cached.packVersion, bundled.packVersion) >= 0) {
      setActivePack(cached, "cached", false);
    } else {
      setActivePack(bundled, "bundled", !!cached);
    }
  }

  function updateContributionUI() {
    const cb = $("#contributeAnonymous");
    if (cb) cb.checked = state.contributionEnabled;
    const hint = $("#contributionHint");
    if (hint) {
      hint.textContent = state.contributionEnabled
        ? "Enabled. Only anonymous aggregate counts will be staged for contribution."
        : "Off by default. No names, dates of birth, phone numbers, vehicle numbers or free-text journal notes are shared.";
    }
  }

  function updateKnowledgeUI() {
    const pack = activePack();
    const label = `Knowledge pack v${pack ? pack.packVersion : APP_VERSION}`;
    const sourceText = pack ? (pack.source === "remote" ? "Live update active" : pack.source === "cached" ? "Cached update active" : "Bundled pack active") : "Bundled pack active";
    if ($("#knowledgeBadge")) $("#knowledgeBadge").textContent = label;
    if ($("#appBadge")) $("#appBadge").textContent = `App v${APP_VERSION} · On-device engine`;
    if ($("#buildBadge")) $("#buildBadge").textContent = BUILD_LABEL;
    if ($("#knowledgeVersionText")) $("#knowledgeVersionText").textContent = `v${pack ? pack.packVersion : APP_VERSION}`;
    if ($("#knowledgeStatusText")) $("#knowledgeStatusText").textContent = `${sourceText}. The app works instantly offline, then can optionally fetch a newer public knowledge pack.`;
    if ($("#knowledgeSubtext")) $("#knowledgeSubtext").textContent = pack && pack.generatedAt
      ? `Published ${prettyDate(pack.generatedAt)} · schema v${pack.schemaVersion}`
      : "Uses bundled content instantly, then quietly checks for a newer pack.";
  }

  function updateMemoryUI() {
    const snap = latestSnapshot();
    if ($("#memoryBadge")) $("#memoryBadge").textContent = state.history.length ? `${state.history.length} local snapshot${state.history.length > 1 ? "s" : ""}` : "Local memory ready";
    if ($("#memorySummaryText")) $("#memorySummaryText").textContent = state.history.length ? `${state.history.length} saved chart${state.history.length > 1 ? "s" : ""}` : "No saved charts yet";
    if ($("#memoryStatusText")) $("#memoryStatusText").textContent = snap
      ? `Latest: ${snap.name} · ${prettyDate(snap.savedAt)} · Driver ${snap.driver}, Conductor ${snap.conductor}`
      : "Saved reports stay on this device only.";
    if ($("#loadLatestBtn")) $("#loadLatestBtn").classList.toggle("hidden", !snap);
  }

  async function refreshKnowledgePack(opts) {
    const options = Object.assign({ silent: true }, opts || {});
    if (state.updatePromise) return state.updatePromise;
    const pack = activePack();
    if (!window.fetch || !pack || !pack.manifestPath) return null;
    state.updatePromise = (async () => {
      try {
        if ($("#knowledgeStatusText")) $("#knowledgeStatusText").textContent = "Checking for a newer knowledge pack…";
        const manifestRes = await window.fetch(`${pack.manifestPath}?t=${Date.now()}`, { cache: "no-store" });
        if (!manifestRes.ok) throw new Error(`manifest ${manifestRes.status}`);
        const manifest = await manifestRes.json();
        const latestVersion = String(manifest.latestVersion || manifest.packVersion || pack.packVersion);
        if (compareVersions(latestVersion, pack.packVersion) <= 0) {
          updateKnowledgeUI();
          if (!options.silent) showToast(`Already on knowledge pack v${pack.packVersion}`, "info");
          return null;
        }
        const nextUrl = manifest.packUrl || manifest.url;
        if (!nextUrl) throw new Error("manifest missing packUrl");
        const packRes = await window.fetch(`${nextUrl}?v=${encodeURIComponent(latestVersion)}`, { cache: "no-store" });
        if (!packRes.ok) throw new Error(`pack ${packRes.status}`);
        const incoming = normalizePack(await packRes.json(), "remote");
        const check = validatePack(incoming);
        if (!check.ok) throw new Error(check.errors.join(", "));
        setActivePack(incoming, "remote", true);
        if (state.lastInput) {
          lastProfile = computeProfile(state.lastInput);
          showReport(lastProfile, { preserveScroll: true });
        }
        showToast(`Knowledge updated to v${incoming.packVersion}`, "good");
        return incoming;
      } catch (err) {
        updateKnowledgeUI();
        if (!options.silent) showToast(`Knowledge update unavailable right now`, "warn");
        return null;
      } finally {
        state.updatePromise = null;
      }
    })();
    return state.updatePromise;
  }

  function chaldeanValue(name) {
    const chaldean = (window.DB && window.DB.chaldean) || {};
    return name.toUpperCase().split("").reduce((a, ch) => a + (chaldean[ch] || 0), 0);
  }

  /* ---------------- dual name layer: public identity vs legal record ----------------
     A person carries two names, and they rarely vibrate the same:

       • Everyday / Professional — business cards, LinkedIn, WhatsApp, email
         signature, bank card, digital profiles. This is the identity the world
         actually uses, so it drives the primary Name Number, the Lo Shu Name
         grid, the Dasha identity band and the hero.
       • Full legal — the exact string printed on Aadhaar / PAN / passport /
         incorporation papers, patronymic included. It is reported beside the
         everyday total as the Document / Legal Total.

     Indian naming contracts the family patronymic all the time
     ("Amarkumar Kishorbhai Sambhvani" → "Amar K Sambhvani"), and the two
     strings carry different Chaldean totals — 80 → 8 against 38 → 2 in the
     reference chart. Reading only one of them hides the vibration the client
     lives inside, and reading only the other invents a name they never use.

     The legal patronymic is also the single most valuable input we can ask
     for: it tells the engine which middle initial is *real* ("Kishorbhai" → K,
     "Ravindra" → R). Suggestion generation therefore prefers that authentic
     family letter over any invented one — an initial the client already owns
     on their own documents is a name change with zero cultural cost, and it
     is offered before any spelling alteration of the first or last name. */
  function nameTokens(name) {
    return String(name == null ? "" : name).trim().split(/\s+/).filter(Boolean);
  }
  function tidyNameString(name) {
    return nameTokens(name).join(" ");
  }
  const nameKey = (name) => tidyNameString(name).toUpperCase();
  function firstLetterOf(token) {
    const m = String(token || "").match(/[A-Za-z\u0900-\u097F\u0A80-\u0AFF]/);
    return m ? m[0].toUpperCase() : "";
  }
  /* A middle token is an initial when exactly one letter survives punctuation
     removal — "K", "K.", "R" all qualify, "Kishorbhai" does not. */
  function isInitialToken(token) {
    const letters = String(token || "").replace(/[^\p{L}]/gu, "");
    return letters.length === 1;
  }
  /* Pure resolution of the two intake strings, shared by the engine and the
     report so both always agree on which name is which. */
  function nameIdentity(everydayName, legalName) {
    const everyday = tidyNameString(everydayName);
    const legalInput = tidyNameString(legalName);
    const legal = legalInput || everyday;
    const everydayTokens = nameTokens(everyday);
    const legalTokens = nameTokens(legal);
    /* Dual only when the client actually typed a different legal string —
       otherwise the report stays exactly as it is today. */
    const dual = !!everyday && !!legalInput && nameKey(legal) !== nameKey(everyday);
    /* Patronymic tokens = every token between the first and the last of the
       LEGAL string, and only when a distinct legal string was actually given.
       A two-token legal name ("Randeep Walia") exposes none, which is precisely
       why the everyday form may not invent one — and an everyday string that
       already carries a full middle token is never mined for a letter to
       duplicate beside it. */
    const patronymics = (dual && legalTokens.length >= 3 ? legalTokens.slice(1, -1) : [])
      .map((token, i) => ({
        token,
        initial: firstLetterOf(token),
        abbreviated: isInitialToken(token),
        position: i + 1
      }))
      .filter((p) => !!p.initial);
    const middleTokensOf = (tokens) => tokens.slice(1, Math.max(1, tokens.length - 1));
    const everydayInitials = middleTokensOf(everydayTokens).filter(isInitialToken).map(firstLetterOf);
    /* Authentic letters are the ones the family record actually owns. A letter
       with no Chaldean value cannot be scored, so it is listed but never
       offered as a numeric lever. */
    const authenticInitials = [];
    patronymics.forEach((p) => {
      /* A middle token already written as an initial on the legal record
         ("Amarkumar K Sambhvani") is just as authentic as the full patronymic —
         the letter is simply already abbreviated, so it can still be activated
         on the everyday name when that form omits it. */
      if (authenticInitials.some((a) => a.letter === p.initial)) return;
      authenticInitials.push({
        letter: p.initial, token: p.token, chaldean: chaldeanValue(p.initial),
        /* The token may already live in the everyday name in full
           ("Amar Kishorbhai Sambhvani") — then the lever is compression, never
           a duplicated letter next to it. */
        inEverydayFull: everydayTokens.some((t) => nameKey(t) === nameKey(p.token) && !isInitialToken(t))
      });
    });
    const usedAuthenticInitials = authenticInitials.filter((a) => everydayInitials.includes(a.letter));
    const availableAuthenticInitials = authenticInitials
      .filter((a) => !everydayInitials.includes(a.letter) && !a.inEverydayFull && a.chaldean > 0);
    return {
      everyday, legal, dual,
      everydayTokens, legalTokens,
      middleTokens: middleTokensOf(everydayTokens),
      /* A three-token everyday name already carries a middle token — the
         golden rule then forbids dropping a random letter next to it. */
      hasOwnMiddleToken: middleTokensOf(everydayTokens).length > 0,
      patronymics,
      patronymicTokens: patronymics.map((p) => p.token),
      patronymicInitials: patronymics.map((p) => p.initial),
      authenticInitials,
      availableAuthenticInitials,
      usedAuthenticInitials,
      everydayInitials
    };
  }

  const compoundMeaning = (n) => {
    const db = getActiveDB();
    return (n >= 1 && n <= 108 && db.compound) ? db.compound[n] : null;
  };
  const masterNumber = (n) => {
    const db = getActiveDB();
    return (db.masterNumbers && db.masterNumbers[n]) || null;
  };

  const ZRANGES = [
    ["Aries", [3, 21], [4, 19]], ["Taurus", [4, 20], [5, 20]], ["Gemini", [5, 21], [6, 20]],
    ["Cancer", [6, 21], [7, 22]], ["Leo", [7, 23], [8, 22]], ["Virgo", [8, 23], [9, 22]],
    ["Libra", [9, 23], [10, 22]], ["Scorpio", [10, 23], [11, 21]], ["Sagittarius", [11, 22], [12, 21]],
    ["Capricorn", [12, 22], [1, 19]], ["Aquarius", [1, 20], [2, 18]], ["Pisces", [2, 19], [3, 20]]
  ];
  const SRANGES = [
    ["Aries", [4, 14], [5, 14]], ["Taurus", [5, 15], [6, 14]], ["Gemini", [6, 15], [7, 15]],
    ["Cancer", [7, 16], [8, 16]], ["Leo", [8, 17], [9, 16]], ["Virgo", [9, 17], [10, 17]],
    ["Libra", [10, 18], [11, 16]], ["Scorpio", [11, 17], [12, 15]], ["Sagittarius", [12, 16], [1, 14]],
    ["Capricorn", [1, 15], [2, 12]], ["Aquarius", [2, 13], [3, 14]], ["Pisces", [3, 15], [4, 13]]
  ];
  function zodiacFromRanges(d, m, ranges) {
    const v = m * 100 + d;
    for (const [name, s, e] of ranges) {
      const sv = s[0] * 100 + s[1], ev = e[0] * 100 + e[1];
      if (sv <= ev ? (v >= sv && v <= ev) : (v >= sv || v <= ev)) return name;
    }
    return ranges[ranges.length - 1][0];
  }
  const zodiacSign = (d, m) => zodiacFromRanges(d, m, ZRANGES);           // Sayana (tropical)
  const zodiacSignSidereal = (d, m) => zodiacFromRanges(d, m, SRANGES);   // Nirayana (Vedic)

  function kuaNumber(gender, year) {
    if (!gender || !year) return null;
    const yy = year % 100;
    const n = yy === 0 ? 0 : reduce(yy);
    const post2000 = year >= 2000;
    let k = gender === "male" ? (post2000 ? 9 - n : 10 - n) : (post2000 ? n + 6 : n + 5);
    k = reduce(k);
    if (k === 5) k = gender === "male" ? 2 : 8;
    return k;
  }

  const DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  const dirLabel = (d) => {
    const db = getActiveDB();
    return (db.vastu && db.vastu.directions && db.vastu.directions[d]) ? db.vastu.directions[d].label : d;
  };

  /* ---------------- intake setup ---------------- */
  function populateDirectionSelects() {
    const roomSelects = ["entrance", "kitchen", "bedroom", "toilet", "study", "staircase"];
    const unsureLabel = getLang() === "hi" ? "निश्चित नहीं" : getLang() === "gu" ? "નક્કી નથી" : "Not sure";
    roomSelects.forEach((id) => {
      const sel = $("#" + id);
      if (!sel) return;
      const curVal = sel.value || "unsure";
      const opts = [`<option value="unsure">${unsureLabel}</option>`]
        .concat(DIRS.map((d) => `<option value="${d}">${dirLabel(d)}</option>`));
      sel.innerHTML = opts.join("");
      sel.value = curVal;
    });
  }

  /* Birthplace: prefix suggestions only (never dump the 15k atlas into the datalist). */
  const PHOTON_CACHE_KEY = "nv-photon-places";
  const ATLAS_CHUNKS_LOADED = { in: true, gcc: false, world: false };

  function parseManualGeo(input) {
    const lat = parseFloat(String((input && input.birthLat) || "").trim());
    const lon = parseFloat(String((input && input.birthLon) || "").trim());
    const tzN = parseFloat(String((input && input.birthTz) || "").trim());
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
    if (Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;
    const tz = (Number.isFinite(tzN) && Math.abs(tzN) <= 14) ? tzN : 5.5;
    return { lat, lon, tz };
  }

  function resolveAstroPlaceQuery(input) {
    const geo = parseManualGeo(input);
    if (geo) return geo.lat + ", " + geo.lon + ", " + geo.tz;
    return String((input && input.birthPlace) || "").trim();
  }

  function guessPlaceTz(lat, lon, country) {
    const c = String(country || "").toLowerCase();
    if (c === "india" || c === "in" || c === "bharat") return 5.5;
    if (window.NVAstro && typeof window.NVAstro.nearestPlaces === "function") {
      const near = window.NVAstro.nearestPlaces(lat, lon, { maxKm: 25, limit: 1 })[0];
      if (near && Number.isFinite(near.tz)) return near.tz;
    }
    return Math.round(lon / 15);
  }

  function readPhotonCache() {
    try {
      const raw = window.localStorage && window.localStorage.getItem(PHOTON_CACHE_KEY);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list.filter((s) => typeof s === "string" && s.trim()) : [];
    } catch (e) { return []; }
  }

  function rememberPhotonPlace(label) {
    const s = String(label || "").trim();
    if (!s) return;
    const next = [s].concat(readPhotonCache().filter((x) => x !== s)).slice(0, 40);
    try { window.localStorage.setItem(PHOTON_CACHE_KEY, JSON.stringify(next)); } catch (e) {}
  }

  /* Shared atlas autocomplete. The partner birthplace field is wired to the
     very same searchPlaces() index as the primary birthplace field, so the two
     intakes cannot drift into different place vocabularies. */
  function fillPlaceList(listId, query) {
    const list = $("#" + listId);
    if (!list || !window.NVAstro || typeof window.NVAstro.searchPlaces !== "function") return;
    const q = String(query || "").trim();
    list.innerHTML = "";
    if (q.length < 2) return;
    window.NVAstro.searchPlaces(q, 12).forEach((hit) => {
      const opt = document.createElement("option");
      opt.value = hit.label;
      list.appendChild(opt);
    });
  }

  function fillBirthPlaceList(query) { fillPlaceList("birthPlaceList", query); }
  function fillPartnerBirthPlaceList(query) { fillPlaceList("partnerBirthPlaceList", query); }

  function bindBirthPlaceUi() {
    const input = $("#birthPlace");
    const list = $("#birthPlaceList");
    if (input) {
      input.addEventListener("input", () => fillBirthPlaceList(input.value));
      input.addEventListener("focus", () => fillBirthPlaceList(input.value));
    }
    if (list) list.innerHTML = "";

    const partnerInput = $("#partnerBirthPlace");
    const partnerList = $("#partnerBirthPlaceList");
    if (partnerInput) {
      partnerInput.addEventListener("input", () => fillPartnerBirthPlaceList(partnerInput.value));
      partnerInput.addEventListener("focus", () => fillPartnerBirthPlaceList(partnerInput.value));
    }
    if (partnerList) partnerList.innerHTML = "";

    const photonBtn = $("#photonLookupBtn");
    const results = $("#birthPlacePhotonResults");
    if (photonBtn && input) {
      photonBtn.addEventListener("click", () => lookupPhoton(input.value.trim()));
    }

    function hidePhotonResults() {
      if (!results) return;
      results.hidden = true;
      results.innerHTML = "";
    }

    function showPhotonResults(hits, notice) {
      if (!results) return;
      results.innerHTML = "";
      if (notice) {
        const li = document.createElement("li");
        li.className = "photon-notice";
        li.textContent = notice;
        results.appendChild(li);
      }
      hits.forEach((hit) => {
        const li = document.createElement("li");
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "photon-pick";
        btn.textContent = hit.label;
        btn.addEventListener("click", () => {
          if (window.NVAstro && typeof window.NVAstro.registerPlace === "function") {
            window.NVAstro.registerPlace({
              name: hit.name, state: hit.state, country: hit.country,
              lat: hit.lat, lon: hit.lon, tz: hit.tz, dst: false, source: "photon"
            });
          }
          input.value = hit.label;
          rememberPhotonPlace(hit.label);
          fillBirthPlaceList(hit.label);
          hidePhotonResults();
        });
        li.appendChild(btn);
        results.appendChild(li);
      });
      results.hidden = results.childNodes.length === 0;
    }

    function lookupPhoton(q) {
      if (!q || q.length < 2) {
        showPhotonResults([], t("photonNeedQuery", "Type a city name first, then look up."));
        return;
      }
      photonBtn.disabled = true;
      const url = "https://photon.komoot.io/api/?q=" + encodeURIComponent(q) + "&limit=8";
      const done = (hits, notice) => {
        photonBtn.disabled = false;
        showPhotonResults(hits, notice);
      };
      if (typeof fetch !== "function") {
        done([], t("photonError", "Online lookup is not available in this browser."));
        return;
      }
      fetch(url).then((res) => {
        if (!res.ok) throw new Error("photon " + res.status);
        return res.json();
      }).then((data) => {
        const feats = (data && data.features) || [];
        const hits = [];
        feats.forEach((f) => {
          const props = f.properties || {};
          const coords = (f.geometry && f.geometry.coordinates) || [];
          const lon = Number(coords[0]), lat = Number(coords[1]);
          if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
          const name = props.name || q;
          const state = props.state || props.county || "";
          const country = props.country || "";
          hits.push({
            name, state, country, lat, lon,
            tz: guessPlaceTz(lat, lon, country),
            label: [name, state, country].filter(Boolean).join(", ")
          });
        });
        done(hits, hits.length ? "" : t("photonNoResults", "No Photon matches. Try a nearby district, or enter coordinates."));
      }).catch(() => {
        done([], t("photonError", "Photon lookup failed. Stay offline or enter coordinates."));
      });
    }

    function loadAtlasChunk(id, btn) {
      if (ATLAS_CHUNKS_LOADED[id]) {
        showToast(t("atlasAlreadyLoaded", "That atlas is already loaded."), "info");
        return;
      }
      const key = id.toUpperCase();
      if (window.NV_ATLAS && window.NV_ATLAS[key] && window.NVAstro && window.NVAstro.ingestAtlas) {
        window.NVAstro.ingestAtlas(window.NV_ATLAS[key]);
        ATLAS_CHUNKS_LOADED[id] = true;
        if (typeof showToast === "function") showToast(t("atlasLoaded", "Offline atlas loaded."), "good");
        if (input) fillBirthPlaceList(input.value);
        if (partnerInput) fillPartnerBirthPlaceList(partnerInput.value);
        return;
      }
      if (btn) btn.disabled = true;
      const s = document.createElement("script");
      s.src = "atlas/atlas-" + id + ".js";
      s.onload = () => {
        ATLAS_CHUNKS_LOADED[id] = true;
        if (btn) btn.disabled = false;
        if (typeof showToast === "function") showToast(t("atlasLoaded", "Offline atlas loaded."), "good");
        if (input) fillBirthPlaceList(input.value);
        if (partnerInput) fillPartnerBirthPlaceList(partnerInput.value);
      };
      s.onerror = () => {
        if (btn) btn.disabled = false;
        if (typeof showToast === "function") showToast(t("atlasLoadError", "Could not load that atlas chunk."), "warn");
      };
      document.head.appendChild(s);
    }

    const gccBtn = $("#loadAtlasGccBtn");
    const worldBtn = $("#loadAtlasWorldBtn");
    if (gccBtn) gccBtn.addEventListener("click", () => loadAtlasChunk("gcc", gccBtn));
    if (worldBtn) worldBtn.addEventListener("click", () => loadAtlasChunk("world", worldBtn));
  }
  bindBirthPlaceUi();

  const selectedGoals = new Set();
  /* Optional Health sub-tags. Shown only while the Health focus is selected;
     "respiratory" (Allergies / Respiratory / Cold) switches Moon kits to
     their warm clinical form. The tags are Health details, so deselecting
     Health clears them. */
  const selectedHealthTags = new Set();
  /* Scaled Sadhana depth (Beginner / Intermediate / Classical). Exactly one
     level is always active; it defaults to the Practitioner / Sadhak 27x
     quarter-mala dose, so a chart that never touches this control keeps the
     prescription it has always received. */
  let selectedSadhana = SADHANA_DEFAULT;
  function syncSadhanaChips(value) {
    selectedSadhana = normalizeSadhana(value);
    $$("#sadhanaOptions .sadhana-option").forEach((btn) => {
      const on = btn.dataset.sadhana === selectedSadhana;
      btn.classList.toggle("selected", on);
      btn.setAttribute("aria-pressed", on ? "true" : "false");
    });
  }
  $$("#sadhanaOptions .sadhana-option").forEach((btn) => {
    btn.addEventListener("click", () => syncSadhanaChips(btn.dataset.sadhana));
  });
  syncSadhanaChips(SADHANA_DEFAULT);
  function syncHealthTagChips(tags) {
    selectedHealthTags.clear();
    const incoming = new Set((tags || []).map((tag) => String(tag || "").trim().toLowerCase()));
    $$("#healthTagChips .chip").forEach((chip) => {
      const on = incoming.has(chip.dataset.healthTag);
      chip.classList.toggle("selected", on);
      if (on) selectedHealthTags.add(chip.dataset.healthTag);
    });
  }
  function updateHealthTagsVisibility() {
    const wrap = $("#healthTagsWrap");
    if (!wrap) return;
    const show = selectedGoals.has("Health");
    wrap.classList.toggle("hidden", !show);
    if (!show) syncHealthTagChips([]);
  }
  function syncGoalChips(goals) {
    selectedGoals.clear();
    const incoming = new Set(goals || []);
    $$("#goalChips .chip").forEach((chip) => {
      const on = incoming.has(chip.dataset.goal);
      chip.classList.toggle("selected", on);
      if (on) selectedGoals.add(chip.dataset.goal);
    });
    if ($("#err-goals")) $("#err-goals").hidden = selectedGoals.size > 0;
    updateHealthTagsVisibility();
  }
  $$("#goalChips .chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const g = chip.dataset.goal;
      if (selectedGoals.has(g)) { selectedGoals.delete(g); chip.classList.remove("selected"); }
      else { selectedGoals.add(g); chip.classList.add("selected"); }
      if ($("#err-goals")) $("#err-goals").hidden = selectedGoals.size > 0;
      updateHealthTagsVisibility();
    });
  });
  $$("#healthTagChips .chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const tag = chip.dataset.healthTag;
      if (selectedHealthTags.has(tag)) { selectedHealthTags.delete(tag); chip.classList.remove("selected"); }
      else { selectedHealthTags.add(tag); chip.classList.add("selected"); }
    });
  });

  function fillFormFromSnapshot(snapshot) {
    if (!snapshot || !snapshot.input) return;
    if ($("#fullName")) $("#fullName").value = snapshot.input.name || "";
    // Snapshots saved before the dual-name intake carry no legalName — they
    // restore exactly as before, with the second field simply left empty.
    if ($("#legalName")) $("#legalName").value = snapshot.input.legalName || "";
    if ($("#dob")) $("#dob").value = formatDobForDisplay(snapshot.input.dob || "");
    if ($("#mobile")) $("#mobile").value = snapshot.input.mobile || "";
    if ($("#vehicle")) $("#vehicle").value = snapshot.input.vehicle || "";
    // Snapshots saved before the premises intake carry neither field; they
    // restore exactly as before with the inputs left at their defaults.
    if ($("#premises")) $("#premises").value = snapshot.input.premises || "";
    if ($("#premisesKind")) $("#premisesKind").value = snapshot.input.premisesKind || "home";
    ["entranceDeg", "kitchenDeg", "bedroomDeg", "waterDeg"].forEach((key) => {
      if ($("#" + key)) $("#" + key).value = snapshot.input[key] || "";
    });
    if ($("#entrance")) $("#entrance").value = snapshot.input.entrance || "unsure";
    if ($("#kitchen")) $("#kitchen").value = snapshot.input.kitchen || "unsure";
    if ($("#bedroom")) $("#bedroom").value = snapshot.input.bedroom || "unsure";
    if ($("#toilet")) $("#toilet").value = snapshot.input.toilet || "unsure";
    if ($("#study")) $("#study").value = snapshot.input.study || "unsure";
    if ($("#staircase")) $("#staircase").value = snapshot.input.staircase || "unsure";
    if ($("#plotShape")) $("#plotShape").value = snapshot.input.plotShape || "unsure";
    if ($("#watchType")) $("#watchType").value = snapshot.input.watchType || "none";
    if ($("#gender")) $("#gender").value = snapshot.input.gender || "";
    if ($("#birthTime")) $("#birthTime").value = snapshot.input.birthTime || "";
    if ($("#birthPlace")) $("#birthPlace").value = snapshot.input.birthPlace || "";
    if ($("#birthLat")) $("#birthLat").value = snapshot.input.birthLat || "";
    if ($("#birthLon")) $("#birthLon").value = snapshot.input.birthLon || "";
    if ($("#birthTz")) $("#birthTz").value = snapshot.input.birthTz || "";
    if ($("#brand")) $("#brand").value = snapshot.input.brand || "";
    if ($("#partnerName")) $("#partnerName").value = snapshot.input.partnerName || "";
    if ($("#partnerDob")) $("#partnerDob").value = formatDobForDisplay(snapshot.input.partnerDob || "");
    if ($("#partnerBirthTime")) $("#partnerBirthTime").value = snapshot.input.partnerBirthTime || "";
    if ($("#partnerBirthPlace")) $("#partnerBirthPlace").value = snapshot.input.partnerBirthPlace || "";
    syncGoalChips(snapshot.input.goals || []);
    syncSadhanaChips(snapshot.input.sadhana);
    syncHealthTagChips(snapshot.input.healthTags || []);
    updateHealthTagsVisibility();
  }

  /* ---------------- DOB input (dd-mm-yyyy) ----------------
     The DOB field is a plain text input that expects day-month-year order
     (e.g. 05-08-1976). Internally every engine and saved snapshot keeps a
     canonical ISO "YYYY-MM-DD" string; we only translate at the form
     boundary so grids, Dasha math, astro.js and stored reports never see a
     format they were not built for. Parsing is tolerant of the separators
     "-", "/", "." or spaces and also accepts a legacy ISO "YYYY-MM-DD"
     value (e.g. an old snapshot or test), but a 4-digit-leading token is
     always read as the year. */
  function normalizeDobInput(raw) {
    const text = String(raw == null ? "" : raw).trim();
    if (!text) return "";
    let compact = text.replace(/[/.,\s]+/g, "-").replace(/[^\d-]/g, "");
    const parts = compact.split("-").filter((p) => p.length > 0);
    if (parts.length !== 3) return "";
    const yearLeading = parts[0].length === 4;
    let d, m, y;
    if (yearLeading) { y = parts[0]; m = parts[1]; d = parts[2]; }
    else { d = parts[0]; m = parts[1]; y = parts[2]; }
    d = Number(d); m = Number(m); y = Number(y);
    if (!(d >= 1 && d <= 31 && m >= 1 && m <= 12 && y >= 1000 && y <= 2100)) return "";
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return "";
    return `${String(y).padStart(4, "0")}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  function formatDobForDisplay(value) {
    const s = String(value == null ? "" : value).trim();
    if (!s) return "";
    const parts = s.split(/[-/.]/).filter((p) => p.length > 0);
    if (parts.length !== 3) return s;
    if (parts[0].length === 4) return `${parts[2].padStart(2, "0")}-${parts[1].padStart(2, "0")}-${parts[0]}`;
    return `${parts[0].padStart(2, "0")}-${parts[1].padStart(2, "0")}-${parts[2]}`;
  }
  function isFutureIso(iso) {
    const d = new Date(iso + "T00:00:00Z");
    const now = new Date();
    return !isNaN(d.getTime()) && d > now;
  }
  /* Live typing mask: allow digits (max 8) and insert "-" after the day and
     month so the field self-formats to dd-mm-yyyy as the user types. A
     clearly year-leading "yyyy-mm-dd" value (e.g. a pasted ISO date or an
     old saved value) is left untouched so the tolerant parser can read it. */
  function looksLikeYearLeadingIso(value) {
    const digits = value.replace(/\D/g, "");
    if (digits.length < 8) return false;
    // First four digits are the year (19xx/20xx) and precede a separator.
    return /^(19|20)\d\d[-/.]/.test(value) && value.slice(0, 4) === digits.slice(0, 4);
  }
  function maskDobInput(el) {
    el.addEventListener("input", () => {
      const before = el.value;
      if (looksLikeYearLeadingIso(before)) return;
      const digits = before.replace(/\D/g, "").slice(0, 8);
      let out = "";
      for (let i = 0; i < digits.length; i++) {
        if (i === 2 || i === 4) out += "-";
        out += digits[i];
      }
      if (before !== out) el.value = out;
    });
  }

  /* ---------------- validation ---------------- */
  function setErr(id, on) {
    if ($("#err-" + id)) $("#err-" + id).hidden = !on;
    if ($("#" + id)) $("#" + id).classList.toggle("error", on);
  }
  function validate() {
    let ok = true, first = null;
    const name = ($("#fullName") && $("#fullName").value.trim()) || "";
    const badName = name.length < 2 || !/[a-zA-Z\u0900-\u097F\u0A80-\u0AFF]/.test(name);
    setErr("fullName", badName); if (badName) { ok = false; first = first || $("#fullName"); }

    // The legal name is optional by design (the everyday name alone reproduces
    // the pre-dual-layer report exactly), so it is only checked once the client
    // has actually typed something into it.
    const legalName = ($("#legalName") && $("#legalName").value.trim()) || "";
    const badLegalName = !!legalName && (legalName.length < 2 || !/[a-zA-Z\u0900-\u097F\u0A80-\u0AFF]/.test(legalName));
    setErr("legalName", badLegalName); if (badLegalName) { ok = false; first = first || $("#legalName"); }

    const dob = ($("#dob") && $("#dob").value) || "";
    const dobIso = normalizeDobInput(dob);
    const badDob = !dobIso || isFutureIso(dobIso);
    setErr("dob", badDob); if (badDob) { ok = false; first = first || $("#dob"); }

    const mob = ($("#mobile") && $("#mobile").value.replace(/\D/g, "")) || "";
    // 8+ digits AND at least one non-zero digit — an all-zero number has no
    // planetary vibration and would otherwise surface as a phantom "9".
    const badMob = mob.length < 8 || !/[1-9]/.test(mob);
    setErr("mobile", badMob); if (badMob) { ok = false; first = first || $("#mobile"); }

    const badGoals = selectedGoals.size === 0;
    if ($("#err-goals")) $("#err-goals").hidden = !badGoals;
    if (badGoals) ok = false;

    if (first) first.focus();
    return ok;
  }

  /* ---------------- core engine ---------------- */
  function computeProfile(input) {
    const [y, m, d] = input.dob.split("-").map(Number);
    // Both engines read the same DOB but retain deliberately different
    // plotting rules. Driver/Conductor derive from the DOB itself, not from
    // a grid, so the Dasha engine has no grid dependency.
    const loShuGrid = generateLoShuGrid(d, m, y);
    const vedicGrid = generateVedicGrid(d, m, y);
    const driver = reduce(d);
    const dobCompound = digitSum(input.dob);
    const conductor = reduce(d + m + y);
    const signalSets = (counts) => ({
      missing: Object.keys(counts).filter((k) => counts[k] === 0).map(Number),
      repeated: Object.keys(counts).filter((k) => counts[k] >= 3).map(Number),
      weak: Object.keys(counts).filter((k) => counts[k] === 1).map(Number)
    });
    const loShuSignals = signalSets(loShuGrid.counts);
    const vedicSignals = signalSets(vedicGrid.counts);

    // Name (Chaldean): Name and Combined grids belong to the Lo Shu
    // Foundation only. The advanced Vedic view remains birth-grid-only.
    const nameCompound = chaldeanValue(input.name);
    const nameNum = reduce(nameCompound);
    const nameRelD = relation(driver, nameNum);
    const nameRelC = relation(conductor, nameNum);

    // Dual name layer (2026-09 intake): the everyday / professional string is
    // the primary identity — it is what the world uses and what every other
    // engine already reads. The full legal string is scored in parallel and
    // reported as the Document / Legal Total, and its patronymic tokens are the
    // only source of an AUTHENTIC middle initial. When no legal name was
    // entered the identity collapses to the everyday name and the report is
    // byte-for-byte what it was before.
    const identity = nameIdentity(input.name, input.legalName);
    const legalName = identity.legal;
    const legalNameCompound = chaldeanValue(legalName);
    const legalNameNum = reduce(legalNameCompound);
    const legalNameRelD = relation(driver, legalNameNum);
    const legalNameRelC = relation(conductor, legalNameNum);

    // Karmic Debt scan (13 / 14 / 16 / 19) — the classical rule checks the
    // UNREDUCED totals: the birth day itself, the full birth-date digit sum,
    // and the full Chaldean name total. When one of them lands on a karmic
    // number, the reduced Driver/Conductor/Name carries that lesson.
    const karmicDebts = [];
    if (KARMIC_DEBT_POOL.includes(d)) karmicDebts.push({ n: d, source: "driver" });
    if (KARMIC_DEBT_POOL.includes(dobCompound)) karmicDebts.push({ n: dobCompound, source: "conductor" });
    if (KARMIC_DEBT_POOL.includes(nameCompound)) karmicDebts.push({ n: nameCompound, source: "name" });
    // A legal string that reduces to a karmic total still governs a passport or
    // a bank record, so it is scanned too — reported as its own source.
    if (identity.dual && KARMIC_DEBT_POOL.includes(legalNameCompound)) karmicDebts.push({ n: legalNameCompound, source: "legalName" });

    const loShuNameCounts = {};
    for (let i = 1; i <= 9; i++) loShuNameCounts[i] = 0;
    const chaldeanMap = (window.DB && window.DB.chaldean) || {};
    input.name.toUpperCase().split("").forEach((ch) => { const v = chaldeanMap[ch]; if (v) loShuNameCounts[v]++; });
    // Digits the everyday name lacks but the statutory string supplies: a
    // missing number echoed only by the legal name is far less critical, so the
    // severity scan reads both layers.
    const legalNameCounts = {};
    for (let i = 1; i <= 9; i++) legalNameCounts[i] = 0;
    if (identity.dual) legalName.toUpperCase().split("").forEach((ch) => { const v = chaldeanMap[ch]; if (v) legalNameCounts[v]++; });
    const loShuCombinedCounts = {};
    for (let i = 1; i <= 9; i++) loShuCombinedCounts[i] = loShuGrid.counts[i] + loShuNameCounts[i];

    // Mobile
    const mobCompound = digitSum(input.mobile);
    const mobNum = reduce(mobCompound);
    const mobRelD = relation(driver, mobNum);
    const mobRelC = relation(conductor, mobNum);

    // Vedic Tier
    const birthTimeRaw = String(input.birthTime || "").trim();
    const birthPlaceRaw = String(input.birthPlace || "").trim();
    const placeQuery = resolveAstroPlaceQuery(input);
    const hasTime = !!birthTimeRaw;
    const hasPlace = !!placeQuery;
    const vedicTier = (hasTime && hasPlace) ? 2 : (hasTime || hasPlace) ? "partial" : 1;

    const astro = (typeof window !== "undefined" && window.NVAstro)
      ? window.NVAstro.compute({ dob: input.dob, time: birthTimeRaw, place: placeQuery })
      : { ok: false, reason: "engine-missing" };

    const loShuMissingSeverity = loShuSignals.missing.map((n) => {
      const inBirth = loShuGrid.counts[n] > 0;
      const inName = loShuNameCounts[n] > 0;
      const inLegalName = legalNameCounts[n] > 0;
      const isDriverOrConductor = n === driver || n === conductor;
      const critical = !inBirth && !inName && !inLegalName && !isDriverOrConductor;
      const echoedBy = [];
      if (inName) echoedBy.push("Name");
      if (inLegalName) echoedBy.push("Legal Name");
      if (isDriverOrConductor) echoedBy.push(n === driver ? "Driver" : "Conductor");
      return { n, critical, echoedBy };
    });

    const kua = kuaNumber(input.gender, y);

    return {
      name: input.name,
      day: d, month: m, year: y,
      // Completed years of age at report time — safety signal only (minor
      // charts defer heavy gems); never alters numbers, grids or timing.
      ageYears: currentAgeYears(d, m, y),
      driver, conductor,
      loShuGrid,
      loShuCounts: loShuGrid.counts,
      loShuMissing: loShuSignals.missing,
      loShuRepeated: loShuSignals.repeated,
      loShuWeak: loShuSignals.weak,
      loShuMissingSeverity,
      loShuNameCounts,
      loShuCombinedCounts,
      vedicGrid,
      vedicCounts: vedicGrid.counts,
      vedicMissing: vedicSignals.missing,
      vedicRepeated: vedicSignals.repeated,
      vedicWeak: vedicSignals.weak,
      dobCompound, karmicDebts,
      // Authority boundary: these profiles receive only Driver/Conductor.
      doshaProfile: buildDoshaProfile({ driver, conductor }),
      deityProfile: buildDeityProfile({ driver, conductor }),
      nameCompound, nameNum, nameRelD, nameRelC,
      // Dual name layer — the everyday string above stays the primary reading;
      // these fields carry the statutory string and its own totals.
      legalName, legalNameCompound, legalNameNum, legalNameRelD, legalNameRelC,
      legalNameCounts,
      nameDual: identity.dual,
      nameIdentity: identity,
      patronymicTokens: identity.patronymicTokens,
      patronymicInitials: identity.patronymicInitials,
      authenticInitials: identity.authenticInitials,
      availableAuthenticInitials: identity.availableAuthenticInitials,
      usedAuthenticInitials: identity.usedAuthenticInitials,
      mobile: input.mobile, mobCompound, mobNum, mobRelD, mobRelC,
      vehicle: input.vehicle || "",
      /* Premises number (house / flat / plot / office / shop / desk /
         account). Optional and purely additive: an empty value renders no
         section and leaves every other engine output untouched. */
      premises: String(input.premises || "").trim(),
      premisesKind: String(input.premisesKind || "home"),
      // Degree readings survive onto the profile as plain strings; the
      // compass engine parses and validates them, so a typo degrades to
      // "no reading" rather than to a wrong zone.
      entranceDeg: String(input.entranceDeg || "").trim(),
      kitchenDeg: String(input.kitchenDeg || "").trim(),
      bedroomDeg: String(input.bedroomDeg || "").trim(),
      waterDeg: String(input.waterDeg || "").trim(),
      goals: input.goals || [],
      // Optional Health sub-tags from the intake form (respiratory / heat /
      // fatigue). "respiratory" drives the Moon-cold guardrail; all three
      // feed the Dosha x planet overlay (heat -> Ushna kits 1/7/9, fatigue ->
      // Guru/Chala kits 3/4/5/8, respiratory also flags Venus 6/Saturn 8).
      healthTags: Array.isArray(input.healthTags)
        ? [...new Set(input.healthTags.map((tag) => String(tag || "").trim().toLowerCase()).filter((tag) => HEALTH_TAG_VALUES.includes(tag)))]
        : [],
      entrance: input.entrance || "unsure",
      kitchen: input.kitchen || "unsure",
      bedroom: input.bedroom || "unsure",
      toilet: input.toilet || "unsure",
      study: input.study || "unsure",
      staircase: input.staircase || "unsure",
      plotShape: input.plotShape || "unsure",
      watchType: input.watchType || "none",
      gender: input.gender || "",
      birthTime: birthTimeRaw,
      birthTimeDisplay: formatBirthTime(birthTimeRaw),
      birthPlace: birthPlaceRaw,
      brand: input.brand || "",
      partnerName: input.partnerName || "",
      partnerDob: input.partnerDob || "",
      /* Partner Tier 2 inputs. Optional by design and never defaulted: an
         absent time or place keeps the Moon layer uncomputed rather than
         assuming a noon birth or a stand-in city. */
      partnerBirthTime: String(input.partnerBirthTime || "").trim(),
      partnerBirthTimeDisplay: formatBirthTime(String(input.partnerBirthTime || "").trim()),
      partnerBirthPlace: String(input.partnerBirthPlace || "").trim(),
      zodiac: zodiacSignSidereal(d, m),
      zodiacTropical: zodiacSign(d, m),
      /* Client-selected practice depth (Section 22 / intake). It sizes the
         daily practice only — it is never read by an engine that chooses a
         remedy target, a triage tier or a Dasha/Vastu result. */
      sadhana: normalizeSadhana(input.sadhana),
      vedicTier, astro, kua
    };
  }

  /* Localised label for dosha tags, so the constitution name reads naturally
     in English, Hindi and Gujarati while the data stays canonical. */
  function doshaLabel(type, lang) {
    const map = (lang === "hi"
      ? { pitta: "पित्त", vata: "वात", kapha: "कफ" }
      : lang === "gu"
        ? { pitta: "પિત્ત", vata: "વાત", kapha: "કફ" }
        : { pitta: "Pitta", vata: "Vata", kapha: "Kapha" });
    return String(type || "").split(/[\s\u2013\-/,]+/).map((w) => map[w.toLowerCase()] || w).filter(Boolean).join("–");
  }

  /* ---------------- spelling correction & name suggestions ---------------- */
  function spellingCandidates(name, baseCompound) {
    const up = name.toUpperCase();
    const S = (window.DB && window.DB.spelling) || { homophones: {}, vowelDoubles: {}, insertVowels: [] };
    const candidates = [];
    const seen = new Set([up.replace(/\s+/g, " ")]);
    const keepCase = (i, str) => str.split("").map((c, j) => {
      const orig = name[i + j];
      if (orig && orig === orig.toLowerCase()) return c.toLowerCase();
      return c;
    }).join("");
    const addCand = (text, change, kind, deltaV) => {
      const key = text.toUpperCase();
      if (seen.has(key)) return;
      seen.add(key);
      const compound = chaldeanValue(text);
      candidates.push({ text, change, compound, reduced: reduce(compound), kind, delta: Math.abs(compound - baseCompound) + (deltaV || 0) });
    };
    up.split("").forEach((ch, i) => {
      const v = (window.DB && window.DB.chaldean && window.DB.chaldean[ch]) || 0;
      if (!v) return;
      if ("BCDFGHJKLMNPQRSTVWXYZ".includes(ch) || (S.vowelDoubles && S.vowelDoubles[ch])) {
        const t = name.slice(0, i) + name[i] + name.slice(i);
        addCand(t, `double "${name[i]}"`, "double", 0);
      }
      ((S.homophones && S.homophones[ch]) || []).forEach((rep) => {
        const t = name.slice(0, i) + keepCase(i, rep) + name.slice(i + 1);
        addCand(t, `${name[i]} → ${rep}`, "swap", 1);
      });
      if (i > 0 && up[i - 1] !== " ") {
        (S.insertVowels || []).forEach((vowel) => {
          const t = name.slice(0, i + 1) + keepCase(i, vowel) + name.slice(i + 1);
          addCand(t, `insert "${vowel}" after "${name[i]}"`, "insert", 2);
        });
      }
    });
    return candidates;
  }

  /* Pronunciation & Practicality Rating (2026-09 audit; tiered in the polish
     pass). A spelling that fixes a number but wrecks a bank form is not a good
     remedy, so every candidate is scored 1–5 AND assigned to the strategy the
     client is actually choosing between:

       5 Excellent     — middle initial (the legal/banking-clean option: both
                         core names keep their existing spelling), a trailing
                         double, or an ending vowel insertion (Suniel pattern)
       4 Good          — a low-contrast double such as "Sambhhvani": visually
                         subtle, ideal for social media, digital profiles and
                         business cards, without touching legal documents
       3 Moderate      — doubling the consonant before the closing vowel
                         ("Sambhvanni") shifts the visible ending
       2 Use with care — doubling inside a hard consonant cluster, which reads
                         like a typo on legal formats

     Doubling a TRAILING consonant stays the safest letter change; the middle
     initial stays the safest overall. */
  const NAME_LOW_CONTRAST_DOUBLES = "H";
  /* Where a single inserted letter landed, and how many letters of that word
     follow it — the difference between an end-of-name vowel ("Amare", the
     Suniel pattern) and a vowel dropped into the middle ("Amear"). Returns -1
     when the candidate is not a clean single insertion. */
  function insertionGap(candidateText, originalName) {
    const a = String(candidateText || "").toUpperCase();
    const b = String(originalName || "").toUpperCase();
    if (!b || a.length !== b.length + 1) return -1;
    for (let i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) {
        if (a.slice(i + 1) !== b.slice(i)) return -1;
        const nextSpace = a.indexOf(" ", i);
        const tokenEnd = nextSpace === -1 ? a.length : nextSpace;
        return tokenEnd - i - 1;
      }
    }
    return -1;
  }
  function namePracticality(candidate, originalName) {
    const lang = getLang();
    const notes = [];
    let score = 5;
    const up = String(candidate.text || "").toUpperCase();
    const orig = String(originalName || "").toUpperCase();
    const VOWELS = "AEIOU";
    if (candidate.kind === "double") {
      const doubledAt = up.split("").findIndex((ch, i) => i > 0 && ch === up[i - 1] && !VOWELS.includes(ch));
      const doubledLetter = doubledAt > -1 ? up[doubledAt] : "";
      const nextChar = up[doubledAt + 1] || " ";
      const atWordEnd = doubledAt === up.length - 1 || nextChar === " ";
      /* A doubled VOWEL (Tripti -> Triptii) is the classic sound-preserving
         remedy and never penalised; `includes("")` is true, so the guard has
         to test the index as well as the letter. */
      const lowContrast = doubledAt > -1 && NAME_LOW_CONTRAST_DOUBLES.includes(doubledLetter);
      if (doubledAt === -1) {
        notes.push(lang === "hi" ? "स्वर दोहराव — उच्चारण और रूप दोनों सुरक्षित रहते हैं" : lang === "gu" ? "સ્વર પુનરાવર્તન — ઉચ્ચાર અને દેખાવ બંને સુરક્ષિત રહે છે" : "repeated vowel — sound and shape both stay safe");
      } else if (atWordEnd) {
        notes.push(lang === "hi" ? "अंत में दोहराव — सबसे सुरक्षित बदलाव" : lang === "gu" ? "અંતે પુનરાવર્તન — સૌથી સુરક્ષિત ફેરફાર" : "trailing double — the safest letter change");
      } else if (lowContrast) {
        score -= 1;
        notes.push(lang === "hi" ? "कम-दृश्यमान दोहराव — आँख को हल्का लगता है; सोशल मीडिया, डिजिटल प्रोफ़ाइल और कार्ड के लिए उपयुक्त, कानूनी दस्तावेज़ वैसे ही रखें" : lang === "gu" ? "ઓછું દૃશ્ય ડબલ — આંખને હળવું લાગે; સોશિયલ મીડિયા, ડિજિટલ પ્રોફાઇલ અને કાર્ડ માટે યોગ્ય, કાનૂની દસ્તાવેજ એવા જ રાખો" : "low-contrast double — visually subtle; ideal for social media, digital profiles and business cards without touching legal documents");
      } else if (VOWELS.includes(nextChar)) {
        score -= 2;
        notes.push(lang === "hi" ? "अंतिम स्वर से पहले का व्यंजन दोहराता है — दिखने वाला अंत बदल जाता है; गैर-कानूनी प्रोफ़ाइल तक रखें" : lang === "gu" ? "અંતિમ સ્વર પહેલાંનો વ્યંજન ડબલ થાય છે — દેખાતો અંત બદલાય છે; બિન-કાનૂની પ્રોફાઇલ સુધી રાખો" : "doubles the consonant before the closing vowel, so the visible ending shifts — best kept to non-legal profiles");
      } else {
        score -= 2;
        notes.push(lang === "hi" ? "भीतर का व्यंजन-समूह कानूनी/बैंक फॉर्म में टाइपो जैसा लग सकता है" : lang === "gu" ? "અંદરનો વ્યંજન-સમૂહ કાનૂની/બેંક ફોર્મમાં ટાઇપો જેવો લાગી શકે" : "internal consonant cluster can read like a typo on legal/banking forms");
      }
    }
    if (candidate.kind === "insert") {
      const gap = insertionGap(up, orig);
      if (gap === -1 || gap <= 1) {
        score -= 1;
        notes.push(lang === "hi" ? "नाम के अंत में स्वर-जोड़ (Suniel शैली) — उच्चारण समान रहता है" : lang === "gu" ? "નામના અંતે સ્વર-ઉમેરો (Suniel શૈલી) — ઉચ્ચાર એ જ રહે છે" : "ending vowel insertion (Suniel-style) — pronunciation stays identical");
      } else {
        score -= 2;
        notes.push(lang === "hi" ? "नाम के बीच स्वर जोड़ना — कानूनी फॉर्म में वर्तनी-दोष जैसा पढ़ा जाता है" : lang === "gu" ? "નામની વચ્ચે સ્વર ઉમેરવો — કાનૂની ફોર્મમાં જોડણી-દોષ જેવું વંચાય છે" : "vowel inserted inside the name — reads like a misspelling on legal forms");
      }
    }
    if (candidate.kind === "swap") {
      score -= 1;
      notes.push(lang === "hi" ? "समान-ध्वनि अदला-बदली — दस्तावेज़ों में पहचान बनी रहती है" : lang === "gu" ? "સમાન-ધ્વનિ અદલાબદલી — દસ્તાવેજોમાં ઓળખ જળવાય છે" : "same-sound swap — identity stays recognisable in documents");
    }
    if (candidate.kind === "initial") {
      score += 1;
      notes.push(lang === "hi" ? "मध्य-आद्यक्षर जोड़ना — कानूनी/बैंक रिकॉर्ड में सबसे व्यावहारिक विकल्प; मौजूदा नामों की वर्तनी वैसी ही रहती है" : lang === "gu" ? "મધ્ય-આદ્યાક્ષર ઉમેરવો — કાનૂની/બેંક રેકોર્ડમાં સૌથી વ્યવહારુ વિકલ્પ; હાલનાં નામોની જોડણી એવી જ રહે છે" : "middle-initial addition — the most practical option for legal/banking records; your existing names keep their spelling");
    }
    if (candidate.kind === "authentic-initial") {
      score += 1;
      notes.push(lang === "hi" ? "प्रामाणिक पारिवारिक आद्यक्षर — कुछ भी काल्पनिक नहीं; पहचान पत्र और चेक पर पहले से पढ़ा जाने वाला अक्षर" : lang === "gu" ? "અસલી કૌટુંબિક આદ્યાક્ષર — કંઈ પણ બનાવટી નહીં; ઓળખપત્ર અને ચેક પર પહેલેથી વંચાતો અક્ષર" : "authentic family initial — nothing invented, and it already reads naturally on identity cards and cheques");
    }
    if (candidate.kind === "compress" || candidate.kind === "drop") {
      notes.push(lang === "hi" ? "केवल दैनिक/सार्वजनिक उपयोग के लिए — कानूनी दस्तावेज़ की वर्तनी नहीं बदलती" : lang === "gu" ? "ફક્ત દૈનિક/જાહેર વપરાશ માટે — કાનૂની દસ્તાવેજની જોડણી બદલાતી નથી" : "everyday / public use only — the legal document spelling is never touched");
    }
    if (up.replace(/\s/g, "").length - orig.replace(/\s/g, "").length > 2) score -= 1;
    score = Math.max(1, Math.min(5, Math.round(score)));
    const label = score >= 5 ? (lang === "hi" ? "उत्कृष्ट" : lang === "gu" ? "ઉત્તમ" : "Excellent")
      : score === 4 ? (lang === "hi" ? "अच्छा" : lang === "gu" ? "સારું" : "Good")
      : score === 3 ? (lang === "hi" ? "मध्यम" : lang === "gu" ? "મધ્યમ" : "Moderate")
      : score === 2 ? (lang === "hi" ? "सोच-समझकर" : lang === "gu" ? "વિચારીને" : "Use with care")
      : (lang === "hi" ? "अव्यावहारिक" : lang === "gu" ? "અવ્યવહારુ" : "Awkward");
    return { score, label, notes: notes.slice(0, 2) };
  }

  /* The two strategies a client chooses between (2026-09 polish). Middle
     initials are listed first because they are the legal/banking-clean route;
     pronunciation-preserving letter alterations sit directly underneath as the
     digital/social route that needs no paperwork. */
  const NAME_STRATEGY = {
    "authentic-initial": {
      key: "authentic-middle-initial",
      en: { label: "Authentic Middle Initial", hint: "Uses the real first letter of your legal patronymic — the way identity cards, cheques and family records already read it. Nothing invented, nothing to explain." },
      hi: { label: "प्रामाणिक मध्य आद्यक्षर", hint: "आपके कानूनी पितृ-नाम का वास्तविक पहला अक्षर — जैसे पहचान पत्र, चेक और पारिवारिक रिकॉर्ड में पहले से है। कुछ भी काल्पनिक नहीं।" },
      gu: { label: "અસલી મધ્ય આદ્યાક્ષર", hint: "તમારા કાનૂની પિતૃ-નામનો સાચો પ્રથમ અક્ષર — ઓળખપત્ર, ચેક અને કૌટુંબિક રેકોર્ડમાં પહેલેથી જેમ છે તેમ. કંઈ પણ બનાવટી નહીં." }
    },
    initial: {
      key: "middle-initial",
      en: { label: "Middle Initial", hint: "Best for banking and legal records — both existing names keep their spelling." },
      hi: { label: "मध्य आद्यक्षर", hint: "बैंक और कानूनी रिकॉर्ड के लिए सर्वोत्तम — दोनों मौजूदा नामों की वर्तनी वैसी ही रहती है।" },
      gu: { label: "મધ્ય આદ્યાક્ષર", hint: "બેંક અને કાનૂની રેકોર્ડ માટે શ્રેષ્ઠ — હાલનાં બંને નામોની જોડણી એવી જ રહે છે." }
    },
    compress: {
      key: "patronymic-initial",
      en: { label: "Patronymic → Initial", hint: "Compresses the full patronymic into its own initial for daily use — the legal record keeps the full spelling untouched." },
      hi: { label: "पितृ-नाम → आद्यक्षर", hint: "पूरे पितृ-नाम को उसी के आद्यक्षर में बदलकर दैनिक उपयोग हेतु — कानूनी रिकॉर्ड में पूरी वर्तनी अपरिवर्तित रहती है।" },
      gu: { label: "પિતૃ-નામ → આદ્યાક્ષર", hint: "આખું પિતૃ-નામ તેના જ આદ્યાક્ષરમાં ઘટાડીને દૈનિક વપરાશ માટે — કાનૂની રેકોર્ડમાં આખી જોડણી અકબંધ રહે છે." }
    },
    drop: {
      key: "patronymic-omitted",
      en: { label: "Patronymic Omitted", hint: "Everyday / professional use only — the statutory string keeps the patronymic exactly as printed." },
      hi: { label: "पितृ-नाम हटाना", hint: "केवल दैनिक/व्यावसायिक उपयोग हेतु — कानूनी दस्तावेज़ में पितृ-नाम जैसा है वैसा ही रहता है।" },
      gu: { label: "પિતૃ-નામ છોડવું", hint: "ફક્ત દૈનિક/વ્યાવસાયિક વપરાશ માટે — કાનૂની દસ્તાવેજમાં પિતૃ-નામ જેમ છે તેમ રહે છે." }
    },
    double: {
      key: "spelling-alteration",
      en: { label: "Spelling Alteration", hint: "Same pronunciation; ideal for social media, digital profiles and business cards — no legal change needed." },
      hi: { label: "वर्तनी-परिवर्तन", hint: "उच्चारण वही; सोशल मीडिया, डिजिटल प्रोफ़ाइल और कार्ड के लिए उपयुक्त — कोई कानूनी बदलाव आवश्यक नहीं।" },
      gu: { label: "જોડણી-ફેરફાર", hint: "ઉચ્ચાર એ જ; સોશિયલ મીડિયા, ડિજિટલ પ્રોફાઇલ અને કાર્ડ માટે યોગ્ય — કોઈ કાનૂની ફેરફાર જરૂરી નથી." }
    },
    swap: {
      key: "spelling-alteration",
      en: { label: "Spelling Alteration", hint: "Same-sound letters only; the name stays recognisable on documents." },
      hi: { label: "वर्तनी-परिवर्तन", hint: "केवल समान-ध्वनि अक्षर; दस्तावेज़ों में नाम पहचाना जाता रहता है।" },
      gu: { label: "જોડણી-ફેરફાર", hint: "ફક્ત સમાન-ધ્વનિ અક્ષરો; દસ્તાવેજોમાં નામ ઓળખાય એવું રહે છે." }
    },
    insert: {
      key: "spelling-alteration",
      en: { label: "Spelling Alteration", hint: "A vowel is added (Suniel-style) — pronunciation stays identical." },
      hi: { label: "वर्तनी-परिवर्तन", hint: "स्वर जोड़ा जाता है (Suniel शैली) — उच्चारण बिलकुल वही रहता है।" },
      gu: { label: "જોડણી-ફેરફાર", hint: "સ્વર ઉમેરાય છે (Suniel શૈલી) — ઉચ્ચાર બિલકુલ એ જ રહે છે." }
    }
  };
  function nameStrategyOf(kind, langOverride) {
    const lang = langOverride || getLang();
    const entry = NAME_STRATEGY[kind] || NAME_STRATEGY.double;
    const copy = entry[lang] || entry.en;
    return { key: entry.key, label: copy.label, hint: copy.hint, kind: entry.key };
  }
  /* The two windows of name correction (2026-09 dual-name intake). Every
     suggestion states which identity it is meant for, because the paperwork
     consequence is completely different:

       Window 1 — Everyday / Public: business cards, LinkedIn, WhatsApp, email
       signature, letterheads. Immediate, no paperwork: drop the heavy
       patronymic token, or carry it as its authentic initial.
       Window 2 — Formal / Document: passport, banking KYC, Aadhaar,
       incorporation. The patronymic stays exactly as printed (no family
       lineage mismatch) and only the first name is tuned. */
  const NAME_WINDOW = {
    public: {
      key: "public",
      en: { label: "Window 1 — Everyday / Public", hint: "Business cards, LinkedIn, WhatsApp, email signature and letterheads. Live immediately — no paperwork required." },
      hi: { label: "विंडो 1 — दैनिक / सार्वजनिक", hint: "विज़िटिंग कार्ड, LinkedIn, WhatsApp, ईमेल हस्ताक्षर और लेटरहेड। तुरंत लागू — कोई कागज़ी कार्रवाई नहीं।" },
      gu: { label: "વિન્ડો 1 — દૈનિક / જાહેર", hint: "વિઝિટિંગ કાર્ડ, LinkedIn, WhatsApp, ઈમેલ સહી અને લેટરહેડ. તરત લાગુ — કોઈ કાગળકામ નહીં." }
    },
    legal: {
      key: "legal",
      en: { label: "Window 2 — Formal / Document", hint: "Passport, banking KYC, Aadhaar and incorporation papers. Your patronymic stays exactly as printed — only the first name is tuned." },
      hi: { label: "विंडो 2 — औपचारिक / दस्तावेज़", hint: "पासपोर्ट, बैंक KYC, आधार और कंपनी पंजीकरण। पितृ-नाम बिलकुल वैसा ही रहता है — केवल पहला नाम बदला जाता है।" },
      gu: { label: "વિન્ડો 2 — ઔપચારિક / દસ્તાવેજ", hint: "પાસપોર્ટ, બેંક KYC, આધાર અને કંપની નોંધણી. પિતૃ-નામ જેમ છે તેમ રહે છે — ફક્ત પ્રથમ નામ સુધારાય છે." }
    }
  };
  function nameWindowOf(window, langOverride) {
    const lang = langOverride || getLang();
    const entry = NAME_WINDOW[window] || NAME_WINDOW.public;
    const copy = entry[lang] || entry.en;
    return { key: entry.key, label: copy.label, hint: copy.hint };
  }
  /* One menu shape for both paths: the authentic family initial first, then the
     generic middle initials, then the pronunciation-preserving alterations,
     each tier capped so the table stays a short menu rather than a candidate
     dump. */
  const SPELLING_TIER_ORDER = ["authentic-initial", "initial", "compress", "double", "swap", "insert", "drop"];
  const SPELLING_TIER_CAP = { "authentic-initial": 2, initial: 2, compress: 1, double: 2, swap: 1, insert: 1, drop: 1 };
  /* Rank used whenever variants are ordered for display: window 1 before
     window 2, then the tier, then the best practice-safe rating, then how close
     the candidate sits to the client's own totals. */
  function spellingRowRank(v) {
    const windowRank = v.window === "legal" ? 1 : 0;
    const tier = SPELLING_TIER_ORDER.indexOf(v.kind);
    return windowRank * 100 + (tier === -1 ? 50 : tier) * 10 - (v.practicality ? v.practicality.score : 0);
  }
  function compareSpellingRows(a, b) {
    return spellingRowRank(a) - spellingRowRank(b)
      || (a.delta || 0) - (b.delta || 0)
      || String(a.text).localeCompare(String(b.text));
  }
  function tieredSpellingMenu(hits) {
    const out = [];
    SPELLING_TIER_ORDER.forEach((kind) => {
      hits.filter((h) => h.kind === kind)
        .sort((a, b) => compareSpellingRows(a, b))
        .slice(0, SPELLING_TIER_CAP[kind] || 0)
        .forEach((h) => out.push(h));
    });
    return out;
  }
  /* Correction path: keep the spread across target numbers, but give each
     target one legal-safe and one digital-safe option instead of two clones.
     When a real patronymic initial exists it takes the legal-safe slot, and the
     digital-safe alteration sits directly beside it — the client sees the
     zero-distortion option before the spelling change, never after it. */
  function pairedSpellingPick(hits) {
    const ranked = hits.slice().sort((a, b) => compareSpellingRows(a, b));
    const pick = [];
    const authentic = ranked.find((h) => h.kind === "authentic-initial");
    if (authentic) pick.push(authentic);
    const initial = ranked.find((h) => h.kind === "initial" && pick.indexOf(h) === -1);
    if (initial && !authentic) pick.push(initial);
    const alteration = ["double", "swap", "insert"]
      .map((kind) => ranked.find((h) => h.kind === kind && pick.indexOf(h) === -1))
      .filter(Boolean)
      .sort((a, b) => compareSpellingRows(a, b))[0];
    if (alteration) pick.push(alteration);
    ranked.forEach((h) => { if (pick.length < 2 && pick.indexOf(h) === -1) pick.push(h); });
    return pick.slice(0, 2);
  }

  /* Middle-initial candidates. Two sources, in strict order of preference:

       1. AUTHENTIC — the first letters of the patronymic tokens typed into the
          legal name ("Kishorbhai" → K, "Ravindra" → R). These are the only
          initials the engine is allowed to propose for a client whose family
          name is known, because the client already owns that letter on their
          own records.
       2. GENERIC — the A–Z scan, kept for clients who gave no legal name.
          Suppressed whenever an authentic letter exists, and also suppressed
          when the everyday name already carries a middle token: dropping an
          arbitrary letter next to an existing middle token ("Amarkumar U
          Kishorbhai") is exactly the invention this pass removes.

     A single letter carries its Chaldean value, so a scan can find the right
     total, but only the authentic letter is culturally free. */
  function initialCandidates(name, baseCompound, options) {
    const opts = options || {};
    const identity = opts.identity || null;
    const tokens = String(name).trim().split(/\s+/).filter(Boolean);
    const out = [];
    const seen = new Set();
    const push = (text, change, kind, delta, extra) => {
      const key = text.toUpperCase();
      if (seen.has(key)) return;
      seen.add(key);
      const compound = chaldeanValue(text);
      out.push(Object.assign({
        text, change, compound, reduced: reduce(compound), kind,
        window: "public", delta
      }, extra || {}));
    };
    const insertAt = (idx, letter) => tokens.slice(0, idx).concat(letter, tokens.slice(idx)).join(" ");
    /* The initial always lands after the first token: "Amar S Sambhvani" for a
       two-word name, "Amar S Kumar Sambhvani" for a longer one. */
    const slot = 1;
    const authentic = (identity && identity.availableAuthenticInitials) || [];
    authentic.forEach((a) => {
      const text = insertAt(slot, a.letter);
      push(text, `use the authentic patronymic initial "${a.letter}" (from "${a.token}")`,
        "authentic-initial", Math.abs(chaldeanValue(text) - baseCompound) - 1,
        { authentic: true, sourceToken: a.token, letter: a.letter });
    });
    /* Golden rule: never invent a letter beside a real middle token, and never
       invent one at all once the family letter is known. */
    const mayScan = !authentic.length && !opts.forbidArbitrary && !(identity && identity.hasOwnMiddleToken);
    if (mayScan) {
      for (const letter of "ABCDEFGHIJKLMNOPQRSTUVWXYZ") {
        const text = insertAt(slot, letter);
        push(text, `add middle initial "${letter}"`, "initial",
          Math.abs(chaldeanValue(text) - baseCompound) + 0.5);
      }
    }
    return out;
  }

  /* Patronymic compression — the everyday half of the dual-name lever.
     "Amarkumar Kishorbhai Sambhvani" reads as "Amarkumar K Sambhvani" on a
     business card without touching the statutory string. Emitted for the
     PUBLIC window only. */
  function compressionCandidates(name, baseCompound) {
    const tokens = String(name).trim().split(/\s+/).filter(Boolean);
    if (tokens.length < 3) return [];
    const first = tokens[0];
    const last = tokens[tokens.length - 1];
    const middles = tokens.slice(1, -1);
    const out = [];
    const seen = new Set();
    const push = (text, change, kind, delta) => {
      const key = text.toUpperCase();
      if (seen.has(key)) return;
      seen.add(key);
      const compound = chaldeanValue(text);
      out.push({ text, change, compound, reduced: reduce(compound), kind, window: "public", delta });
    };
    /* Only genuine patronymic tokens are compressed — never a middle token that
       is already an initial, and never a letter invented from nothing. */
    const compressible = middles.filter((token) => !isInitialToken(token));
    if (compressible.length && compressible.length === middles.length) {
      const initials = compressible.map((token) => firstLetterOf(token));
      if (initials.every((l) => chaldeanValue(l) > 0)) {
        push(`${first} ${initials.join(" ")} ${last}`,
          `compress the patronymic "${compressible.join(" ")}" to its own initial${initials.length > 1 ? "s" : ""} "${initials.join(" ")}"`,
          "compress", Math.abs(chaldeanValue(`${first} ${initials.join(" ")} ${last}`) - baseCompound) - 0.5);
      }
    }
    push(`${first} ${last}`, `drop the patronymic "${middles.join(" ")}" from the everyday name (the legal record keeps it)`,
      "drop", Math.abs(chaldeanValue(`${first} ${last}`) - baseCompound) + 1);
    return out;
  }

  /* Window 2 — Formal / Document Alignment.
     Tunes ONLY the first name of the legal string and re-appends every
     remaining token byte-for-byte, so the patronymic ("Kishorbhai") can never
     be altered, reordered or dropped by a suggestion. */
  function legalWindowCandidates(legalName, baseCompound) {
    const tokens = String(legalName).trim().split(/\s+/).filter(Boolean);
    if (tokens.length < 2) return [];
    const first = tokens[0];
    const rest = tokens.slice(1).join(" ");
    return spellingCandidates(first, chaldeanValue(first)).map((c) => {
      const text = `${c.text} ${rest}`;
      const compound = chaldeanValue(text);
      return {
        text,
        change: `${c.change} in the first name only — the remaining legal tokens "${rest}" stay exactly as printed`,
        compound, reduced: reduce(compound), kind: c.kind, window: "legal",
        scope: "first-name",
        delta: Math.abs(compound - baseCompound)
      };
    });
  }

  /* Optional grid-filling spellings for an ALREADY-harmonious name.
     These never "correct" anything — they consciously fill a number that is
     missing from the Lo Shu Foundation grid, stay non-enemy to both Driver and Conductor,
     and never add to a number the person already has in excess. */
  function buildOptionalSpellings(p) {
    const db = getActiveDB();
    const lang = getLang();
    const identity = p.nameIdentity || nameIdentity(p.name, p.legalName);
    const fillable = p.loShuMissing.filter((n) =>
      relation(p.driver, n) !== "enemy" &&
      relation(p.conductor, n) !== "enemy" &&
      !p.loShuRepeated.includes(n)
    );
    /* No early-out here: when every missing number is hostile to one of the
       birth numbers the spelling menu is empty, but the authentic family
       initial (below) is still admitted when its own total is harmonious —
       it is the one lever that must never be dropped. (2026-09 audit.) */
    const candidates = nameCandidatePool(p, identity);
    const variants = [];
    const seen = new Set();
    fillable.forEach((n) => {
      const planet = db.numbers[n].planet.split(" ")[0];
      const hits = candidates
        .filter((c) => c.reduced === n && c.window !== "legal")
        .map((c) => ({ ...c, practicality: namePracticality(c, p.name) }));
      /* The optional menu keeps BOTH strategies: the middle initials that are
         clean for legal/banking records first, then the pronunciation-
         preserving spelling alterations (doubles, same-sound swaps, ending
         vowels) directly underneath, so the client is never limited to one
         route and never pushed toward a spelling they would not want on a
         document. */
      const optWhy = lang === "hi"
        ? `वैकल्पिक: आपके अनुपस्थित अंक ${n} (${planet}) को भरता है — मूलांक ${p.driver} और भाग्यांक ${p.conductor} के अनुकूल रहता है`
        : lang === "gu"
          ? `વૈકલ્પિક: તમારો ખૂટતો અંક ${n} (${planet}) ભરે છે — મૂળાંક ${p.driver} અને ભાગ્યાંક ${p.conductor} સાથે અનુકૂળ રહે છે`
          : `optional: fills your missing number ${n} (${planet}) — stays harmonious with Driver ${p.driver} and Conductor ${p.conductor}`;
      tieredSpellingMenu(hits).forEach((c) => {
        const key = c.text.toUpperCase();
        if (seen.has(key)) return;
        seen.add(key);
        variants.push({ ...c, targetN: n, why: optWhy });
      });
    });
    /* An authentic family initial is admitted even when the grid is missing
       nothing, provided the total it produces is harmonious with both birth
       numbers. This is the lever the client asked for — the real letter from
       their own documents — and it is offered ahead of every spelling change. */
    authenticInitialAnalysis(p, identity).forEach((check) => {
      if (!check.harmonious) return;
      const key = check.text.toUpperCase();
      if (seen.has(key)) return;
      seen.add(key);
      const candidate = {
        text: check.text,
        change: `use the authentic patronymic initial "${check.letter}" (from "${check.token}")`,
        compound: check.compound, reduced: check.reduced,
        kind: "authentic-initial", window: "public", authentic: true,
        sourceToken: check.token, letter: check.letter, delta: -1
      };
      const why = lang === "hi"
        ? `वैकल्पिक: आपके असली पितृ-नाम "${check.token}" का अक्षर ${check.letter} दैनिक नाम में सक्रिय करता है — कुल ${check.compound} → ${check.reduced}, मूलांक ${p.driver} और भाग्यांक ${p.conductor} के अनुकूल; कोई अक्षर गढ़ा नहीं गया`
        : lang === "gu"
          ? `વૈકલ્પિક: તમારા સાચા પિતૃ-નામ "${check.token}" નો અક્ષર ${check.letter} દૈનિક નામમાં સક્રિય કરે છે — સરવાળો ${check.compound} → ${check.reduced}, મૂળાંક ${p.driver} અને ભાગ્યાંક ${p.conductor} સાથે અનુકૂળ; કોઈ અક્ષર બનાવટી નથી`
          : `optional: activates the authentic initial ${check.letter} of your patronymic "${check.token}" in the everyday name — total ${check.compound} → ${check.reduced}, harmonious with Driver ${p.driver} and Conductor ${p.conductor}, and nothing invented`;
      variants.push({ ...candidate, practicality: namePracticality(candidate, p.name), targetN: check.reduced, why });
    });
    variants.sort(compareSpellingRows);
    return {
      variants: variants.slice(0, 4),
      legalVariants: buildLegalWindowVariants(p, identity, fillable, "optional"),
      targets: fillable
    };
  }

  /* Every spelling candidate the engine is willing to offer for a chart, in one
     pool. Window 1 (everyday / public) carries the authentic family initial,
     the generic alphabetic initials, patronymic compression and the ordinary
     pronunciation-preserving alterations. Window 2 (legal) is generated from
     the legal string itself and only ever rewrites the first name. */
  function nameCandidatePool(p, identity) {
    const id = identity || nameIdentity(p.name, p.legalName || p.name);
    const pool = spellingCandidates(p.name, p.nameCompound)
      .concat(initialCandidates(p.name, p.nameCompound, { identity: id }))
      .concat(compressionCandidates(p.name, p.nameCompound));
    if (id.dual) {
      /* The legal string contributes its own compression option as a public
         spelling ("Amarkumar K Sambhvani"), because that is the form the
         client would print — and Window 2 rows for the statutory record. */
      pool.push(...compressionCandidates(id.legal, p.legalNameCompound != null ? p.legalNameCompound : chaldeanValue(id.legal)));
      pool.push(...legalWindowCandidates(id.legal, p.legalNameCompound != null ? p.legalNameCompound : chaldeanValue(id.legal)));
    }
    const seen = new Set();
    return pool.filter((c) => {
      const key = `${c.window}|${c.text.toUpperCase()}`;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    }).map((c) => Object.assign({ window: "public" }, c));
  }

  /* Window 2 rows: legal-name spellings that hit a target while the patronymic
     stays untouched. Kept deliberately short — the client who must change a
     statutory record gets a couple of well-explained options, not a menu. */
  function buildLegalWindowVariants(p, identity, targets, flavour) {
    const lang = getLang();
    const id = identity || p.nameIdentity || nameIdentity(p.name, p.legalName);
    if (!id.dual) return [];
    const legalCompound = p.legalNameCompound != null ? p.legalNameCompound : chaldeanValue(id.legal);
    const pool = legalWindowCandidates(id.legal, legalCompound)
      .map((c) => ({ ...c, practicality: namePracticality(c, id.legal) }));
    const patronymic = id.patronymicTokens.join(" ") || (id.legalTokens.length > 2 ? id.legalTokens.slice(1, -1).join(" ") : "");
    const out = [];
    const seen = new Set();
    targets.forEach((tgt) => {
      const n = typeof tgt === "number" ? tgt : tgt.n;
      const hits = pool.filter((c) => c.reduced === n).sort(compareSpellingRows);
      const best = hits[0];
      if (!best) return;
      const key = best.text.toUpperCase();
      if (seen.has(key)) return;
      seen.add(key);
      const why = flavour === "optional"
        ? (lang === "hi" ? `औपचारिक दस्तावेज़ के लिए वैकल्पिक: पहला नाम बदलकर कुल योग ${n} तक — पितृ-नाम "${patronymic}" ज्यों-का-त्यों सुरक्षित` : lang === "gu" ? `ઔપચારિક દસ્તાવેજ માટે વૈકલ્પિક: પ્રથમ નામ બદલીને સરવાળો ${n} સુધી — પિતૃ-નામ "${patronymic}" જેમ છે તેમ સુરક્ષિત` : `optional for the statutory record: first name tuned to reach total ${n} — the patronymic "${patronymic}" stays exactly as printed`)
        : (lang === "hi" ? `पहला नाम बदलकर कुल योग ${n} तक ले जाता है और पितृ-नाम "${patronymic}" को ज्यों-का-त्यों रखता है — कुल योग ${n} ${tgt.why}` : lang === "gu" ? `પ્રથમ નામ બદલીને સરવાળો ${n} સુધી લાવે છે અને પિતૃ-નામ "${patronymic}" જેમ છે તેમ રાખે છે — સરવાળો ${n} ${tgt.why}` : `takes the first name to total ${n} while keeping the patronymic "${patronymic}" untouched — total ${n} ${tgt.why}`);
      out.push({ ...best, why, targetN: n, window: "legal" });
    });
    out.sort(compareSpellingRows);
    return out.slice(0, 2);
  }

  function nameSuggestions(p) {
    const optional = buildOptionalSpellings(p);
    if (p.nameRelD !== "enemy" && p.nameRelC !== "enemy") {
      return { needed: false, verdict: p.nameRelD === "neutral" || p.nameRelC === "neutral" ? "neutral" : "friendly", optional };
    }

    const db = getActiveDB();
    const lang = getLang();
    const missingRanked = p.loShuMissing.slice().sort((a, b) => {
      const score = (n) => {
        const rd = relation(p.driver, n), rc = relation(p.conductor, n);
        if (rd === "friendly" && rc === "friendly") return 0;
        if (rd !== "enemy" || rc !== "enemy") return 1;
        return 2;
      };
      return score(a) - score(b);
    }).map((n) => ({
      n,
      why: lang === "hi" ? `आपके अनुपस्थित अंक ${n} (${db.numbers[n].planet}) की भरपाई करता है`
        : lang === "gu" ? `તમારા ખૂટતા અંક ${n} (${db.numbers[n].planet}) ની ભરપાઈ કરે છે`
          : `compensates your missing number ${n} (${db.numbers[n].planet})`
    }));

    const harm = [];
    for (let n = 1; n <= 9; n++) {
      const rd = relation(p.driver, n), rc = relation(p.conductor, n);
      if (rd !== "enemy" && rc !== "enemy" && !p.loShuMissing.includes(n)) {
        harm.push({
          n,
          why: rd === "friendly" && rc === "friendly"
            ? (lang === "hi" ? `मूलांक ${p.driver} और भाग्यांक ${p.conductor} दोनों के अनुकूल` : lang === "gu" ? `મૂળાંક ${p.driver} અને ભાગ્યાંક ${p.conductor} બંને સાથે અનુકૂળ` : `harmonious with both Driver ${p.driver} and Conductor ${p.conductor}`)
            : (lang === "hi" ? `मूलांक ${p.driver} और भाग्यांक ${p.conductor} के लिए स्वीकार्य` : lang === "gu" ? `મૂળાંક ${p.driver} અને ભાગ્યાંક ${p.conductor} માટે સ્વીકાર્ય` : `acceptable to Driver ${p.driver} and Conductor ${p.conductor}`)
        });
      }
    }
    const targets = missingRanked.concat(harm);
    if (!targets.length) return { needed: true, verdict: "enemy", variants: [], legalVariants: [], targets: [] };

    // Authentic patronymic initials, generic middle initials, patronymic
    // compression and the pronunciation-preserving alterations all join the
    // pool so a correction is never limited to doubling trailing consonants
    // (2026-09 audit; dual-name intake).
    const identity = p.nameIdentity || nameIdentity(p.name, p.legalName);
    const candidates = nameCandidatePool(p, identity);

    const variants = [];
    targets.forEach((tgt) => {
      const hits = candidates
        .filter((c) => c.reduced === tgt.n && c.window !== "legal")
        .map((c) => ({ ...c, practicality: namePracticality(c, p.name) }));
      /* One legal-safe + one digital-safe option per target number. */
      pairedSpellingPick(hits).forEach((c) => variants.push({ ...c, why: tgt.why, targetN: tgt.n }));
    });

    const finalSeen = new Set();
    const out = [];
    variants.sort(compareSpellingRows).forEach((v) => {
      const k = `${v.window}|${v.text.toUpperCase()}`;
      if (finalSeen.has(k)) return;
      finalSeen.add(k); out.push(v);
    });

    return {
      needed: true, verdict: "enemy",
      variants: out.slice(0, 6),
      legalVariants: buildLegalWindowVariants(p, identity, targets, "correction"),
      targets: targets.map((tgt) => tgt.n),
      optional
    };
  }

  function brandAnalysis(brand, p) {
    if (!brand || !brand.trim()) return null;
    const total = chaldeanValue(brand.trim());
    const root = reduce(total);
    const relD = relation(p.driver, root);
    const relC = relation(p.conductor, root);
    const conflicting = relD === "enemy" || relC === "enemy";

    const auspicious = [];
    for (let n = 1; n <= 9; n++) {
      if (relation(p.driver, n) !== "enemy" && relation(p.conductor, n) !== "enemy") auspicious.push(n);
    }

    let suggestions = [];
    if (conflicting) {
      const candidates = spellingCandidates(brand.trim(), total);
      const kindRank = { double: 0, swap: 1, insert: 2 };
      suggestions = candidates
        .filter((c) => auspicious.includes(c.reduced))
        .sort((a, b) => kindRank[a.kind] - kindRank[b.kind] || a.delta - b.delta)
        .slice(0, 6)
        .map((c) => ({ ...c, why: `brand number ${c.reduced} is friendly to your Driver ${p.driver} and Conductor ${p.conductor}` }));
    }

    return {
      brand: brand.trim(), total, root, relD, relC, conflicting, auspicious,
      suggestions,
      master: masterNumber(total),
      compound: compoundMeaning(total)
    };
  }

  /* A phone is the most-used device in the chart, so a hostile mobile total is
     the highest-impact remedy we offer — which makes an empty suggestion list
     worse than no suggestion at all. Requiring a total that is *friendly* to
     both birth numbers is impossible for 24 of the 81 Driver×Conductor pairs
     (Driver 6 × Conductor 1 among them: 6's friends {4,5,7,8} and 1's friends
     {2,3,9} never overlap), and the section used to render "pick one whose
     digits total ." with nothing in the gap. Fall back the same way
     vehicleAnalysis() already does — a total that is an outright enemy of
     neither number — then, as a last resort for a custom knowledge pack whose
     friendship rows leave even that empty, to totals friendly to the Driver.
     relation(n, n) is always "friendly", so that final tier cannot be empty. */
  /* The verdict and the recommendation deliberately use *different* thresholds,
     and that gap used to be invisible to the reader. "Change it" fires on an
     enemy; the ideal-total list is built from totals friendly to *both* birth
     numbers. A root that is friendly to one and merely neutral to the other
     (Driver 5 / Conductor 9 against Number 6 is exactly that: Mercury befriends
     Venus, Mars is neutral to her) therefore landed in neither branch — the
     report said "vibrates acceptably, no change required" while the same report
     had, one screen earlier, recommended 10/19/28/37/46/55 and then rendered no
     list at all. The reader was told their number was fine and was given no way
     to see it was off-target.

     So: keep `needed` on the enemy threshold (a neutral root is genuinely not
     hostile, and forcing a SIM change for it would be wrong), but classify the
     result into three honest verdicts and ALWAYS return the ideal totals.
       hostile    — an outright enemy of either birth number: change it
       off-target — not hostile, but outside the ideal set: keepable, upgradable
       optimal    — inside the ideal set: no change required
     Membership is tested on the reduced root, never on the sliced top-6, so a
     larger total such as 64 (also a 1) still reads as optimal. */
  function mobileSuggestion(p) {
    const bothGood = [], acceptable = [], driverGood = [];
    for (let t = 9; t <= 60; t++) {
      const r = reduce(t);
      const rd = relation(p.driver, r), rc = relation(p.conductor, r);
      if (rd === "friendly" && rc === "friendly") bothGood.push(t);
      else if (rd !== "enemy" && rc !== "enemy") acceptable.push(t);
      if (rd === "friendly") driverGood.push(t);
    }
    const tier = bothGood.length ? bothGood : acceptable.length ? acceptable : driverGood;
    const goodTotals = tier.slice(0, 6);
    const tierRoots = new Set(tier.map((t) => reduce(t)));

    const hostile = p.mobRelD === "enemy" || p.mobRelC === "enemy";
    if (hostile) return { needed: true, verdict: "hostile", goodTotals };

    // A caller that only passed relations (no compound total) cannot be judged
    // for membership; treat it as not hostile rather than guessing a verdict.
    const root = Number.isFinite(p.mobCompound) ? reduce(p.mobCompound) : null;
    const onTarget = root !== null && tierRoots.has(root);
    return { needed: false, verdict: onTarget ? "optimal" : "off-target", goodTotals };
  }

  function compatibility(a, b) {
    const pairs = [
      { a: `Your Driver ${a.driver}`, b: `their Driver ${b.driver}`, aNum: a.driver, bNum: b.driver, sideB: "their Driver", r: relation(a.driver, b.driver) },
      { a: `Your Driver ${a.driver}`, b: `their Conductor ${b.conductor}`, aNum: a.driver, bNum: b.conductor, sideB: "their Conductor", r: relation(a.driver, b.conductor) },
      { a: `Your Conductor ${a.conductor}`, b: `their Driver ${b.driver}`, aNum: a.conductor, bNum: b.driver, sideB: "their Driver", r: relation(a.conductor, b.driver) },
      { a: `Your Conductor ${a.conductor}`, b: `their Conductor ${b.conductor}`, aNum: a.conductor, bNum: b.conductor, sideB: "their Conductor", r: relation(a.conductor, b.conductor) }
    ];
    const score = pairs.reduce((s, p) => s + (p.r === "friendly" ? 2 : p.r === "neutral" ? 1 : 0), 0);
    const friendly = pairs.filter((p) => p.r === "friendly").length;
    const neutral = pairs.filter((p) => p.r === "neutral").length;
    const enemy = pairs.filter((p) => p.r === "enemy").length;
    const verdict = score >= 7 ? "Strong" : score >= 5 ? "Good" : score >= 3 ? "Workable" : "Challenging";
    return { pairs, score, max: 8, verdict, friendly, neutral, enemy };
  }

  /* ---- Chandra-bala: the mutual natal Moon relationship -------------------
     Progressive precision, applied to the partner exactly as it is applied to
     the primary chart.

     The Moon covers roughly 13°20′ of the zodiac a day — one whole Nakshatra —
     so a Moon Rashi, a Nakshatra or a pada simply cannot be derived from a date
     of birth. Any engine that "fills in" a noon birth or a default city is
     guessing, and a birth near a rashi or nakshatra boundary will be silently
     wrong. This module therefore computes nothing until BOTH charts carry an
     exact birth time and a birthplace the offline atlas can resolve; until then
     it returns tier 1 with `chandraBalaComputed: false` and names exactly which
     side is missing.

     Scope: this is the Rashi (Bhakoot / Chandra) axis between the two natal
     Moons. It is deliberately NOT a 36-point Ashtakoota score — Gana, Nadi,
     Yoni, Graha Maitri and the rest are not computed here and are not implied.
     It carries no remedy, no timing and no Vastu instruction. */
  const CHANDRA_AXIS = {
    "1/1": {
      key: "1/1", sanskrit: "Ekarashi",
      quality: "supportive",
      label: { en: "Same Moon sign (Ekarashi)", hi: "एक ही चंद्र राशि (एकराशि)", gu: "એક જ ચંદ્ર રાશિ (એકરાશિ)" },
      note: {
        en: "Both Moons occupy the same rashi, so the emotional idiom is shared — you read each other's moods quickly and recover from upsets in the same rhythm. The classical caution is sameness rather than friction: blind spots are shared too, so neither partner naturally supplies the missing perspective.",
        hi: "दोनों चंद्र एक ही राशि में हैं, इसलिए भावनात्मक भाषा साझा है — आप एक-दूसरे का मन जल्दी पढ़ लेते हैं और एक ही लय में सँभल जाते हैं। शास्त्रीय सावधानी घर्षण की नहीं, समानता की है: कमियाँ भी साझा होती हैं, इसलिए छूटा हुआ दृष्टिकोण कोई स्वाभाविक रूप से नहीं देता।",
        gu: "બંને ચંદ્ર એક જ રાશિમાં છે, તેથી ભાવનાત્મક ભાષા સહિયારી છે — તમે એકબીજાનું મન ઝડપથી વાંચો છો અને એક જ લયમાં સંભળાઈ જાઓ છો. શાસ્ત્રીય સાવચેતી ઘર્ષણની નહીં, સમાનતાની છે: ખામીઓ પણ સહિયારી હોય છે, તેથી ખૂટતો દૃષ્ટિકોણ કોઈ સ્વાભાવિક રીતે પૂરો પાડતું નથી."
      }
    },
    "2/12": {
      key: "2/12", sanskrit: "Dwidwadasha",
      quality: "challenging",
      label: { en: "Dwidwadasha axis (2/12)", hi: "द्विर्द्वादश अक्ष (2/12)", gu: "દ્વિર્દ્વાદશ અક્ષ (2/12)" },
      note: {
        en: "One Moon sits in the 2nd from the other and the second in the 12th — the classical give-and-spend axis. Tradition reads it as a persistent imbalance in resources, energy and attention: one partner tends to accumulate while the other tends to release. It describes an asymmetry to be managed explicitly, not a verdict on the relationship.",
        hi: "एक चंद्र दूसरे से द्वितीय में और दूसरा द्वादश में है — शास्त्रीय व्यय-संचय अक्ष। परंपरा इसे संसाधन, ऊर्जा और ध्यान के स्थायी असंतुलन के रूप में पढ़ती है: एक पक्ष संचय करता है, दूसरा व्यय। यह संबंध पर निर्णय नहीं, स्पष्ट रूप से सँभालने योग्य असमानता का संकेत है।",
        gu: "એક ચંદ્ર બીજાથી બીજા સ્થાનમાં અને બીજો બારમા સ્થાનમાં છે — શાસ્ત્રીય વ્યય-સંચય અક્ષ. પરંપરા તેને સંસાધન, ઊર્જા અને ધ્યાનના કાયમી અસંતુલન તરીકે વાંચે છે: એક પક્ષ સંચય કરે, બીજો ખર્ચે. આ સંબંધ પરનો ચુકાદો નથી, સ્પષ્ટપણે સંભાળવા જેવી અસમાનતા છે."
      }
    },
    "3/11": {
      key: "3/11", sanskrit: "Trikona-Labha",
      quality: "workable",
      label: { en: "3/11 axis — effort and gain", hi: "3/11 अक्ष — प्रयास और लाभ", gu: "3/11 અક્ષ — પ્રયાસ અને લાભ" },
      note: {
        en: "A one-directional flow: the partner whose Moon is 11th from the other receives gain and encouragement, while the partner in the 3rd position supplies the initiative and effort. Workable and often productive, provided the effort is acknowledged rather than assumed.",
        hi: "यह एकतरफा प्रवाह है: जिसका चंद्र दूसरे से एकादश है उसे लाभ और उत्साह मिलता है, जबकि तृतीय स्थान वाला पहल और परिश्रम देता है। यह साध्य और प्रायः फलदायी है, बशर्ते परिश्रम को स्वीकारा जाए, माना न जाए।",
        gu: "આ એકતરફી પ્રવાહ છે: જેનો ચંદ્ર બીજાથી અગિયારમો છે તેને લાભ અને ઉત્સાહ મળે છે, જ્યારે ત્રીજા સ્થાનવાળો પહેલ અને પરિશ્રમ આપે છે. તે સાધ્ય અને ઘણી વાર ફળદાયી છે, જો પરિશ્રમ સ્વીકારાય, ગૃહીત ન લેવાય."
      }
    },
    "4/10": {
      key: "4/10", sanskrit: "Kendra (Sukha-Karma)",
      quality: "workable",
      label: { en: "4/10 Kendra axis — home and duty", hi: "4/10 केंद्र अक्ष — गृह और कर्म", gu: "4/10 કેન્દ્ર અક્ષ — ગૃહ અને કર્મ" },
      note: {
        en: "The home-and-work angle. One Moon holds the domestic, emotional base (4th) while the other carries the outward, public and career-facing role (10th). Classically stable and complementary; the standing risk is that the partnership becomes a working arrangement, with duty crowding out affection.",
        hi: "गृह-कर्म कोण। एक चंद्र घरेलू, भावनात्मक आधार (चतुर्थ) सँभालता है और दूसरा बाहरी, सार्वजनिक व कर्मक्षेत्र की भूमिका (दशम)। शास्त्रीय रूप से स्थिर और पूरक; जोखिम यह कि संबंध कार्य-व्यवस्था बन जाए और कर्तव्य स्नेह को दबा दे।",
        gu: "ગૃહ-કર્મ કોણ. એક ચંદ્ર ઘરેલું, ભાવનાત્મક પાયો (ચતુર્થ) સંભાળે અને બીજો બાહ્ય, જાહેર અને કારકિર્દીની ભૂમિકા (દશમ). શાસ્ત્રીય રીતે સ્થિર અને પૂરક; જોખમ એ કે સંબંધ કાર્ય-વ્યવસ્થા બની જાય અને ફરજ સ્નેહને દબાવે."
      }
    },
    "5/9": {
      key: "5/9", sanskrit: "Navapanchama",
      quality: "supportive",
      label: { en: "Navapanchama axis (5/9)", hi: "नवपंचम अक्ष (5/9)", gu: "નવપંચમ અક્ષ (5/9)" },
      note: {
        en: "The trine most classical texts rate highest for marriage. One Moon falls in the 5th (affection, children, creativity) from the other and the other in the 9th (fortune, faith, mutual regard). Affection tends to be given rather than negotiated, and disagreements rarely turn cold.",
        hi: "विवाह के लिए अधिकांश शास्त्र इसी त्रिकोण को सर्वोत्तम मानते हैं। एक चंद्र दूसरे से पंचम (स्नेह, संतान, सृजन) में और दूसरा नवम (भाग्य, श्रद्धा, परस्पर आदर) में। स्नेह माँगना नहीं पड़ता, और मतभेद प्रायः ठंडे नहीं पड़ते।",
        gu: "લગ્ન માટે મોટા ભાગના શાસ્ત્રો આ ત્રિકોણને શ્રેષ્ઠ ગણે છે. એક ચંદ્ર બીજાથી પંચમ (સ્નેહ, સંતાન, સર્જન) માં અને બીજો નવમ (ભાગ્ય, શ્રદ્ધા, પરસ્પર આદર) માં. સ્નેહ માંગવો પડતો નથી, અને મતભેદ ભાગ્યે જ ઠંડા પડે છે."
      }
    },
    "6/8": {
      key: "6/8", sanskrit: "Shadashtaka",
      quality: "challenging",
      label: { en: "Shadashtaka axis (6/8)", hi: "षडाष्टक अक्ष (6/8)", gu: "ષડાષ્ટક અક્ષ (6/8)" },
      note: {
        en: "The most-cited caution in Moon-sign matching: one Moon stands 6th from the other and that one 8th in return. Classically associated with health strain, recurring friction and sudden reversals in the shared routine. It is a caution to be worked with consciously — many long marriages carry it — not a prohibition, and this app issues no remedy for it.",
        hi: "चंद्र-राशि मिलान की सर्वाधिक उद्धृत सावधानी: एक चंद्र दूसरे से षष्ठ और दूसरा अष्टम में। शास्त्रीय रूप से यह स्वास्थ्य-भार, बार-बार के घर्षण और साझा दिनचर्या में अचानक उलटफेर से जोड़ा जाता है। यह सजगता से सँभालने योग्य चेतावनी है — अनेक दीर्घ विवाह इसे धारण करते हैं — निषेध नहीं, और यह ऐप इसका कोई उपाय नहीं देता।",
        gu: "ચંદ્ર-રાશિ મિલનની સૌથી વધુ ટાંકાતી સાવચેતી: એક ચંદ્ર બીજાથી છઠ્ઠો અને બીજો આઠમો. શાસ્ત્રીય રીતે તે આરોગ્ય-ભાર, વારંવારના ઘર્ષણ અને સહિયારી દિનચર્યામાં અચાનક ઉથલપાથલ સાથે જોડાય છે. તે સજાગતાથી સંભાળવા જેવી ચેતવણી છે — ઘણાં લાંબાં લગ્ન તે ધરાવે છે — પ્રતિબંધ નહીં, અને આ ઍપ તેનો કોઈ ઉપાય આપતી નથી."
      }
    },
    "7/7": {
      key: "7/7", sanskrit: "Samasaptaka",
      quality: "supportive",
      label: { en: "Samasaptaka axis (7/7)", hi: "समसप्तक अक्ष (7/7)", gu: "સમસપ્તક અક્ષ (7/7)" },
      note: {
        en: "Mutual opposition: each Moon is exactly 7th from the other, the classical marriage axis. Attraction is strong and the two temperaments are complementary opposites, which is also the friction — the same polarity that draws you together produces the standoffs.",
        hi: "परस्पर सप्तम: प्रत्येक चंद्र दूसरे से ठीक सातवें में — शास्त्रीय विवाह-अक्ष। आकर्षण प्रबल है और दोनों स्वभाव पूरक विपरीत हैं, यही घर्षण भी है — जो ध्रुवता जोड़ती है वही गतिरोध बनाती है।",
        gu: "પરસ્પર સપ્તમ: દરેક ચંદ્ર બીજાથી બરાબર સાતમા સ્થાને — શાસ્ત્રીય લગ્ન-અક્ષ. આકર્ષણ પ્રબળ છે અને બંને સ્વભાવ પૂરક વિરોધી છે, એ જ ઘર્ષણ પણ છે — જે ધ્રુવતા જોડે છે તે જ અટકાવ સર્જે છે."
      }
    }
  };

  /* House-position ordinals. English needs 1st/2nd/3rd/4th; Hindi and Gujarati
     read naturally with a plain numeral plus their own positional word, which
     the caller supplies. */
  function houseOrdinal(n, lang) {
    if (lang === "hi" || lang === "gu") return String(n);
    const rem100 = n % 100;
    if (rem100 >= 11 && rem100 <= 13) return n + "th";
    return n + ({ 1: "st", 2: "nd", 3: "rd" }[n % 10] || "th");
  }

  function chandraAxisFor(selfIdx, partnerIdx) {
    const fwd = ((partnerIdx - selfIdx + 12) % 12) + 1;   // partner's Moon counted from yours
    const rev = ((selfIdx - partnerIdx + 12) % 12) + 1;   // yours counted from the partner's
    const key = Math.min(fwd, rev) + "/" + Math.max(fwd, rev);
    return { fwd, rev, key, entry: CHANDRA_AXIS[key] || null };
  }

  /* Missing-data contract for the partner Moon layer. Returns the degraded
     shape whenever either natal Moon is uncomputable, and never substitutes a
     default time, a default city or a noon chart. */
  function chandraBala(self, partner) {
    const selfAstro = self && self.astro;
    const partnerAstro = partner && partner.astro;
    const selfFull = !!(selfAstro && selfAstro.ok && selfAstro.tier === "full" && selfAstro.moon);
    const partnerFull = !!(partnerAstro && partnerAstro.ok && partnerAstro.tier === "full" && partnerAstro.moon);

    /* A computed profile carries day/month/year rather than a `dob` string, so
       validity is tested on what the profile actually exposes. */
    const partnerHasDob = !!(partner && (partner.dob || (partner.day && partner.month && partner.year)));
    if (!selfFull || !partnerFull) {
      const missing = [];
      if (!partnerHasDob) missing.push("partner-dob");
      else {
        if (!partner.birthTime) missing.push("partner-birth-time");
        if (!partner.birthPlace) missing.push("partner-birth-place");
        else if (!partnerFull && partnerAstro && partnerAstro.placeUnmatched) missing.push("partner-birth-place-unmatched");
      }
      if (!self || !self.birthTime) missing.push("self-birth-time");
      if (self && !self.birthPlace) missing.push("self-birth-place");
      else if (self && !selfFull && selfAstro && selfAstro.placeUnmatched) missing.push("self-birth-place-unmatched");
      const partnerSide = missing.some((m) => m.indexOf("partner") === 0);
      const selfSide = missing.some((m) => m.indexOf("self") === 0);
      const who = partnerSide && selfSide
        ? "add both charts' birth time and location"
        : partnerSide
          ? "add partner birth time and location"
          : "add your birth time and location";
      return {
        tier: 1,
        chandraBalaComputed: false,
        missing,
        partnerSide,
        selfSide,
        message: "Chandra-bala not computed — " + who
      };
    }

    const selfMoon = selfAstro.moon;
    const partnerMoon = partnerAstro.moon;
    const selfSign = window.NVAstro.signOf(selfMoon.lonSidereal);
    const partnerSign = window.NVAstro.signOf(partnerMoon.lonSidereal);
    const axis = chandraAxisFor(selfSign.index, partnerSign.index);
    /* Widely-cited classical relaxation of the Shadashtaka / Dwidwadasha
       caution: when both Moons share the same rashi lord the dosha is held to
       be cancelled. We report the objective fact (same lord or not) and leave
       the wider cancellation debate to the practitioner rather than inventing
       a score. */
    const sameLord = selfSign.lord === partnerSign.lord;
    const quality = (axis.entry && axis.entry.quality) || "workable";
    return {
      tier: 2,
      chandraBalaComputed: true,
      missing: [],
      axis: {
        key: axis.key,
        forward: axis.fwd,
        reverse: axis.rev,
        sanskrit: axis.entry ? axis.entry.sanskrit : "",
        label: axis.entry ? axis.entry.label : null,
        note: axis.entry ? axis.entry.note : null,
        quality
      },
      sameRashiLord: sameLord,
      doshaRelaxedBySharedLord: sameLord && quality === "challenging",
      self: {
        sign: selfSign.name, glyph: selfSign.glyph, lord: selfSign.lord, degStr: selfSign.degStr,
        lonSidereal: selfMoon.lonSidereal,
        nakshatra: selfMoon.nakshatra ? { name: selfMoon.nakshatra.name, pada: selfMoon.nakshatra.pada, lord: selfMoon.nakshatra.lord, glyph: selfMoon.nakshatra.glyph } : null
      },
      partner: {
        sign: partnerSign.name, glyph: partnerSign.glyph, lord: partnerSign.lord, degStr: partnerSign.degStr,
        lonSidereal: partnerMoon.lonSidereal,
        nakshatra: partnerMoon.nakshatra ? { name: partnerMoon.nakshatra.name, pada: partnerMoon.nakshatra.pada, lord: partnerMoon.nakshatra.lord, glyph: partnerMoon.nakshatra.glyph } : null
      },
      engine: partnerAstro.engine || (selfAstro && selfAstro.engine) || "",
      /* The Nakshatra-level layer under the Rashi axis: both natal Moons are
         known here, so both nakshatras are, and Tara can be counted. */
      tara: taraBala(self, partner),
      message: ""
    };
  }

  /* ---- Tara Bala: the Nakshatra-level Moon-pairing layer ------------------
     One level below the Rashi (Bhakoot) axis above: Tara is counted in
     NAKSHATRAS, so it needs both natal Moons (Tier 2 on each side). The
     working, as given in the standard Ashtakoota references:

       · count the nakshatras from the partner's Moon nakshatra to yours,
         INCLUSIVE of both ends — and the same count in the other direction;
       · divide each count by 9; remainders 3, 5 and 7 are traditionally
         inauspicious, every other remainder (1, 2, 4, 6, 8, 9 — with 0 read
         as 9) traditionally auspicious;
       · both directions auspicious = the favourable reading, one each way =
         mixed, both inauspicious = the caution reading.

     Source-verified example (the Anuradha / Rohini worked example in the
     references): Rohini → Anuradha counts 14 → remainder 5 → inauspicious;
     Anuradha → Rohini counts 15 → remainder 6 → auspicious.

     Moons that share one nakshatra give the count 1 in both directions
     (Janma Tara); schools differ on how they read that case, so it is flagged
     as a fact of the chart. This module reports the working and the
     traditional classification only: it folds nothing into any 36-point
     Ashtakoota score and prescribes nothing — no remedy, no muhurtha, no
     Vastu zone. */
  const TARA_INAUSPICIOUS_REMAINDERS = [3, 5, 7];

  function taraCount(fromIdx, toIdx) {
    /* Inclusive count from nakshatra fromIdx to nakshatra toIdx around the
       27-nakshatra circle (same nakshatra → 1, opposite extreme → 27). */
    return ((toIdx - fromIdx + 27) % 27) + 1;
  }

  function taraDirection(fromNak, toNak) {
    const count = taraCount(fromNak.index, toNak.index);
    const remainder = count % 9 === 0 ? 9 : count % 9;
    return {
      count,
      remainder,
      auspicious: TARA_INAUSPICIOUS_REMAINDERS.indexOf(remainder) === -1
    };
  }

  function taraBala(self, partner) {
    const selfAstro = self && self.astro;
    const partnerAstro = partner && partner.astro;
    const selfNak = selfAstro && selfAstro.ok && selfAstro.tier === "full" && selfAstro.moon && selfAstro.moon.nakshatra
      ? selfAstro.moon.nakshatra : null;
    const partnerNak = partnerAstro && partnerAstro.ok && partnerAstro.tier === "full" && partnerAstro.moon && partnerAstro.moon.nakshatra
      ? partnerAstro.moon.nakshatra : null;
    if (!selfNak || !partnerNak) {
      const missing = [];
      if (!selfNak) missing.push("self-nakshatra");
      if (!partnerNak) missing.push("partner-nakshatra");
      return {
        computed: false,
        missing,
        message: "Tara Bala not computed — " + missing.map((m) => m === "self-nakshatra" ? "your nakshatra (add your birth time and place)" : "the partner's nakshatra (add partner birth time and place)").join(", ")
      };
    }
    /* forward = counted from the partner's nakshatra to yours;
       reverse = counted from yours to the partner's. */
    const forward = taraDirection(partnerNak, selfNak);
    const reverse = taraDirection(selfNak, partnerNak);
    return {
      computed: true,
      missing: [],
      selfNak: { name: selfNak.name, index: selfNak.index, pada: selfNak.pada },
      partnerNak: { name: partnerNak.name, index: partnerNak.index, pada: partnerNak.pada },
      forward,
      reverse,
      sameNakshatra: selfNak.index === partnerNak.index,
      bothAuspicious: forward.auspicious && reverse.auspicious,
      bothInauspicious: !forward.auspicious && !reverse.auspicious,
      message: ""
    };
  }

  /* ---- compatibility reflection helpers -------------------------------
     Compatibility can describe pairwise friction and communication cues, but
     never creates a relationship remedy programme or timing prescription. */
  const PAIR_FRICTION = {
    "1-4": {
      friction: { en: "Sun's need for recognition meets Rahu's unconventional, restless style — clashes over authority, credit and \"who is right\".", hi: "सूर्य की पहचान की चाह और राहु की अपरंपरागत, चंचल शैली टकराती है — अधिकार, श्रेय और \"सही कौन\" पर विवाद।", gu: "સૂર્યની ઓળખની ચાહ અને રાહુની અપરંપરાગત, ચંચળ શૈલી અથડાય છે — સત્તા, શ્રેય અને \"સાચો કોણ\" પર વિવાદ." }
    },
    "1-6": {
      friction: { en: "Sun's authority vs Venus's comfort and sociability — one pushes status and discipline, the other beauty, leisure and spending.", hi: "सूर्य का अधिकार बनाम शुक्र का सुख-सामर्थ्य और मिलनसारिता — एक पद और अनुशासन का दबाव देता है, दूसरा सौंदर्य, विश्राम और खर्च की चाह।", gu: "સૂર્યનું વર્ચસ્વ વિરુદ્ધ શુક્રનો આરામ અને મિલનસારપણું — એક પ્રતિષ્ઠા અને શિસ્ત થોપે, બીજો સૌંદર્ય, વિશ્રાંતિ અને ખર્ચ ઇચ્છે." }
    },
    "1-7": {
      friction: { en: "Sun wants the stage, Ketu prefers silence and withdrawal — one feels ignored, the other feels exposed.", hi: "सूर्य मंच चाहता है, केतु मौन और एकांत — एक को अनदेखा लगता है, दूसरे को बहुत उजाला।", gu: "સૂર્યને સ્ટેજ જોઈએ, કેતુને મૌન અને એકાંત — એકને અવગણના લાગે, બીજાને વધુ પડતું પ્રકાશન." }
    },
    "1-8": {
      friction: { en: "Sun's quick authority meets Saturn's slow, tested methods — power struggles, delays read as defiance, discipline as insult.", hi: "सूर्य की तेज़ अधिकार-शैली और शनि की धीमी, परखी हुई पद्धति — सत्ता-संघर्ष, विलंब को विरोध और अनुशासन को अपमान समझा जाता है।", gu: "સૂર્યની ઝડપી સત્તા-શૈલી અને શનિની ધીમી, કસાયેલી પદ્ધતિ — સત્તા-સંઘર્ષ, વિલંબને વિરોધ અને શિસ્તને અપમાન ગણાય." }
    },
    "2-4": {
      friction: { en: "Moon's emotional sensitivity meets Rahu's restlessness — mood swings meet unpredictability, reassurance meets distraction.", hi: "चंद्र की भावुक संवेदनशीलता और राहु की बेचैनी — मन की लहरें अनिश्चितता से टकराती हैं, आश्वासन विचलित करने से।", gu: "ચંદ્રની ભાવુક સંવેદનશીલતા અને રાહુની બેચાની — મનની લહેરો અનિશ્ચિતતા સામે અથડાય, દિલાસો વિચલિત કરે." }
    },
    "2-7": {
      friction: { en: "Moon needs connection and words; Ketu withdraws into silence — distance feels like rejection, closeness feels like pressure.", hi: "चंद्र को जुड़ाव और वाणी चाहिए; केतु मौन में खो जाता है — दूरी अस्वीकृति और निकटता दबाव लगती है।", gu: "ચંદ્રને જોડાણ અને વાણી જોઈએ; કેતુ મૌનમાં ખોવાય — અંતરાલ અસ્વીકૃતિ અને નિકટતા દબાણ લાગે." }
    },
    "3-4": {
      friction: { en: "Jupiter's tradition and study vs Rahu's shortcuts — the 3-side preaches, the 4-side improvises; both feel unrespected.", hi: "गुरु की परंपरा और अध्ययन बनाम राहु के शॉर्टकट — 3 पक्ष उपदेश देता है, 4 पक्ष जुगाड़ करता है; दोनों को अनादर लगता है।", gu: "ગુરુની પરંપરા અને અભ્યાસ વિરુદ્ધ રાહુના ટૂંકા રસ્તા — 3 પક્ષ ઉપદેશ આપે, 4 પક્ષ જુગાડ કરે; બંનેને અનાદર લાગે." }
    },
    "3-5": {
      friction: { en: "Jupiter's depth vs Mercury's speed — advice sounds like criticism to the 5-side; the 3-side finds the 5-side scattered and superficial.", hi: "गुरु की गहराई बनाम बुध की गति — 5 पक्ष को सलाह आलोचना लगती है; 3 पक्ष 5 पक्ष को बिखरा हुआ और ऊपरी समझता है।", gu: "ગુરુની ઊંડાણ વિરુદ્ધ બુધની ઝડપ — 5 પક્ષને સલાહ ટીકા લાગે; 3 પક્ષ 5 પક્ષને બિખરાયેલો અને સપરી સમજે." }
    },
    "3-6": {
      friction: { en: "Jupiter's dharma and study vs Venus's comfort and luxury — spending vs saving, devotion vs enjoyment.", hi: "गुरु का धर्म और अध्ययन बनाम शुक्र का आराम और विलासिता — बचत बनाम खर्च, त्याग बनाम भोग।", gu: "ગુરુનો ધર્મ અને અભ્યાસ વિરુદ્ધ શુક્રનો આરામ અને વિલાસ — બચત વિરુદ્ધ ખર્ચ, ત્યાગ વિરુદ્ધ ભોગ." }
    },
    "3-7": {
      friction: { en: "Jupiter's outward teaching vs Ketu's inward detachment — one expands the world, the other renounces it; plans meet sudden withdrawal.", hi: "गुरु का बाहरमुखी उपदेश बनाम केतु का भीतरमुखी वैराग्य — एक जग का विस्तार करता है, दूसरा त्याग; योजनाएँ अचानक मौन से मिलती हैं।", gu: "ગુરુનું બહિર્મુખ શિક્ષણ વિરુદ્ધ કેતુનું અંતર્મુખ વૈરાગ્ય — એક જગતનો વિસ્તાર કરે, બીજો ત્યાગે; યોજનાઓ અચાનક મૌન પામે." }
    },
    "4-9": {
      friction: { en: "Rahu's risky shortcuts meet Mars's blunt force — impulsive decisions meet a short fuse; arguments escalate fast.", hi: "राहु के जोखिम भरे शॉर्टकट और मंगल की सीधी तेज़ शक्ति — आवेशी निर्णय और तपती ज़ुबान; बहस तेज़ी से बढ़ती है।", gu: "રાહુના જોખમી ટૂંકા રસ્તા અને મંગળની સીધી તેજ શક્તિ — આવેશી નિર્ણય અને ગરમ જીભ; વાદ-વિવાદ ઝડપથી વધે." }
    },
    "7-9": {
      friction: { en: "Ketu's detachment vs Mars's fiery drive — one renounces, one conquers; shared plans stall between mysticism and muscle.", hi: "केतु का वैराग्य बनाम मंगल की तेज़ चाह — एक त्यागता है, दूसरा जीतता है; रहस्यवाद और बल के बीच योजनाएँ अटकती हैं।", gu: "કેતુનો વૈરાગ્ય વિરુદ્ધ મંગળની તેજ ઇચ્છા — એક ત્યાગે, બીજો જીતે; રહસ્યવાદ અને બળ વચ્ચે યોજનાઓ અટકે." }
    }
  };

  function pairKey(x, y) { return Math.min(x, y) + "-" + Math.max(x, y); }

  const RELATIONSHIP_COMMUNICATION_GUIDANCE = {
    en: "Before the issue escalates, name your need with an ‘I’ statement, agree one clear next step, and review it together at a set time.",
    hi: "बात बढ़ने से पहले अपनी जरूरत को ‘मैं’ वाक्य में कहें, एक स्पष्ट अगला कदम तय करें और तय समय पर साथ उसकी समीक्षा करें।",
    gu: "વાત વધે તે પહેલાં તમારી જરૂરિયાત ‘હું’ વાક્યમાં કહો, એક સ્પષ્ટ આગલું પગલું નક્કી કરો અને નક્કી સમયે સાથે તેની સમીક્ષા કરો."
  };

  // Retained name for external compatibility; returns reflection inputs only.
  function compatRemedies(a, b, compat) {
    const db = getActiveDB();
    const conflicts = compat.pairs
      .filter((pr) => pr.r === "enemy")
      .map((pr) => {
        const g = PAIR_FRICTION[pairKey(pr.aNum, pr.bNum)] || null;
        return Object.assign({}, pr, {
          planetA: db.numbers[pr.aNum].planet,
          planetB: db.numbers[pr.bNum].planet,
          friction: g ? g.friction : null,
          bridge: RELATIONSHIP_COMMUNICATION_GUIDANCE
        });
      });
    /* Shared reference numbers: acceptable (never enemy) to both charts, ranked. */
    const four = [a.driver, a.conductor, b.driver, b.conductor].filter((n, i, arr) => arr.indexOf(n) === i);
    const bridges = [];
    for (let n = 1; n <= 9; n++) {
      const rels = four.map((m) => (m === n ? "friendly" : relation(m, n)));
      if (rels.indexOf("enemy") !== -1) continue;
      const score = rels.reduce((s, r) => s + (r === "friendly" ? 2 : 1), 0);
      bridges.push({ n, score, planet: db.numbers[n].planet.split(" ")[0] });
    }
    bridges.sort((x, y) => y.score - x.score || x.n - y.n);
    return {
      conflicts,
      bridges: bridges.slice(0, 3),
      bridgePool: bridges.length,
      neutralLinks: compat.pairs.filter((pr) => pr.r === "neutral").length
    };
  }


  function vehicleAnalysis(p) {
    const db = getActiveDB();
    const bothGood = [], okTotals = [];
    for (let t = 4; t <= 45; t++) {
      const r = reduce(t);
      const rd = relation(p.driver, r), rc = relation(p.conductor, r);
      if (rd === "friendly" && rc === "friendly") bothGood.push(t);
      else if (rd !== "enemy" && rc !== "enemy") okTotals.push(t);
    }
    const goodTotals = bothGood.length ? bothGood : okTotals;
    const luckyPlanetNums = [p.driver, p.conductor].filter((n, i, a) => a.indexOf(n) === i);
    const luckyColors = luckyPlanetNums.map((n) => db.numbers[n].color.split(",")[0] + " (" + db.numbers[n].planet.split(" ")[0] + ")");

    if (!p.vehicle || !p.vehicle.trim()) {
      return { provided: false, goodTotals: goodTotals.slice(0, 8), luckyColors };
    }

    const letters = p.vehicle.replace(/[^a-zA-Z]/g, "");
    const digits = p.vehicle.replace(/\D/g, "");
    const letterVal = chaldeanValue(letters);
    const digitVal = digitSum(digits);
    const total = letterVal + digitVal;
    const num = reduce(total);
    const relD = relation(p.driver, num);
    const relC = relation(p.conductor, num);
    return {
      provided: true, raw: p.vehicle.toUpperCase(),
      letters: letters.toUpperCase(), letterVal, digitVal, total, num,
      relD, relC,
      conflicting: relD === "enemy" || relC === "enemy",
      goodTotals: goodTotals.slice(0, 8), luckyColors
    };
  }

  /* Pinnacles & Challenges — the classical four life phases, derived purely
     from the birth date:
       P1 = day+month, P2 = day+year, P3 = P1+P2, P4 = month+year   (reduced 1–9)
       C1 = |day−month|, C2 = |day−year|, C3 = |C1−C2|, C4 = |month−year|
     Challenges use the single-digit components and are kept as-is (0–8,
     never reduced). Phase convention: the first pinnacle ends at age
     36 − Conductor, each following pinnacle spans 9 years, and the fourth
     runs to the end of life. */
  function pinnacleAnalysis(p) {
    const rd = reduce(p.day), rm = reduce(p.month), ry = reduce(p.year);
    const p1 = reduce(p.day + p.month);
    const p2 = reduce(p.day + p.year);
    const p3 = reduce(p1 + p2);
    const p4 = reduce(p.month + p.year);
    const c1 = Math.abs(rd - rm);
    const c2 = Math.abs(rd - ry);
    const c3 = Math.abs(c1 - c2);
    const c4 = Math.abs(rm - ry);
    const end1 = 36 - p.conductor;
    const end2 = end1 + 9;
    const end3 = end2 + 9;
    const phases = [
      { i: 1, pinnacle: p1, challenge: c1, from: 0, to: end1 },
      { i: 2, pinnacle: p2, challenge: c2, from: end1 + 1, to: end2 },
      { i: 3, pinnacle: p3, challenge: c3, from: end2 + 1, to: end3 },
      { i: 4, pinnacle: p4, challenge: c4, from: end3 + 1, to: null },
    ];
    return { phases, firstEnd: end1 };
  }

  function timingAnalysis(p) {
    const now = new Date();
    const cy = now.getFullYear();
    const personalYearNum = (yr) => reduce(p.day + p.month + reduce(yr));
    const db = getActiveDB();
    const pinnacles = pinnacleAnalysis(p);

    const years = [0, 1, 2, 3].map((off) => {
      const yr = cy + off;
      const n = personalYearNum(yr);
      return { yr, n, meaning: db.personalYear[n] || (window.DB && window.DB.personalYear && window.DB.personalYear[n]) || "", current: off === 0 };
    });

    const luckyYears = [];
    for (let off = 0; off <= 12 && luckyYears.length < 6; off++) {
      const yr = cy + off;
      const yv = reduce(yr);
      const py = personalYearNum(yr);
      const reasons = [];
      if (relation(p.driver, yv) === "friendly") reasons.push(`year vibration ${yv} supports Driver ${p.driver}`);
      if (py === p.driver) reasons.push(`personal year ${py} = your Driver — a personal-power year`);
      else if (py === p.conductor) reasons.push(`personal year ${py} = your Conductor — destiny doors open`);
      else if (relation(p.driver, py) === "friendly") reasons.push(`personal year ${py} is friendly to Driver ${p.driver}`);
      if (reasons.length) luckyYears.push({ yr, py, why: reasons.join("; ") });
    }

    const curAge = cy - p.year - (new Date(cy, p.month - 1, p.day) > now ? 1 : 0);
    const milestones = [];
    for (let age = curAge; age <= curAge + 25 && milestones.length < 6; age++) {
      const a = reduce(age);
      const rd = relation(p.driver, a), rc = relation(p.conductor, a);
      if (a === p.driver) milestones.push({ age, yr: p.year + age, why: `age reduces to ${a} = your Driver — peak personal-power year` });
      else if (a === p.conductor) milestones.push({ age, yr: p.year + age, why: `age reduces to ${a} = your Conductor — destiny-alignment year` });
      else if (rd === "friendly" && rc === "friendly") milestones.push({ age, yr: p.year + age, why: `age reduces to ${a} — harmonious with both your numbers` });
    }
    return { years, luckyYears, milestones, curAge, pinnacles };
  }

  /* ---------------- Numerology Dasha engine (Ank Jyotish) ----------------
     Classical proportional cycle on a 45-year base (1+2+…+9 = 45).
     · Mahadasha starts at birth with the Moolank and lasts N solar years;
       the sequence then advances cyclically 1→9 and repeats after 45 years.
     · Antardasha = MD years × AD number ÷ 45, sequence starting from the
       MD lord itself (nested mathematical continuity).
     · Pratyantar = AD span × PD number ÷ 45, sequence starting from the
       AD lord.
     Dates use the 365.2425-day solar year from the date of birth; when the
     user has provided an exact birth time (Vedic Tier 2) the cycle is
     anchored to that time for finer boundaries. */
  const DASHA_YEAR_MS = 365.2425 * 86400000;
  /* Average-lifespan horizon for every Dasha read-out. Wealth & business
     life-event windows are scanned across ages 21–75 (db.dasha.lifeEvents),
     and every other Dasha horizon — the Mahadasha ladder, the late-window
     scan once a classical band closes, and the Vimshottari ladder — is
     guaranteed inside an 80-year coverage window. The Mahadasha ladder is
     still computed to 100 years so sub-period boundaries stay exact past 80;
     the late scan reaches till age 80, or 15 years ahead of today, whichever
     reaches further, so a chart already near 80 still sees a useful horizon.
     Five detailed upcoming windows per event (three late windows once a band
     closes) keep the far end of a 75-year wealth band visible instead of
     collapsing it into the three strongest early peaks. */
  const DASHA_LIFESPAN_YEARS = 80;
  const DASHA_LATE_LOOKAHEAD_YEARS = 15;
  const DASHA_FUTURE_WINDOWS = 5;
  const DASHA_LATE_WINDOWS = 3;

  function dashaSequenceFrom(n) {
    return Array.from({ length: 9 }, (_, i) => ((n - 1 + i) % 9) + 1);
  }

  function dashaBirthDate(p) {
    let hh = 0, mm = 0;
    if (p.birthTime) {
      const parts = String(p.birthTime).split(":").map(Number);
      if (!isNaN(parts[0])) hh = parts[0];
      if (!isNaN(parts[1])) mm = parts[1];
    }
    return new Date(p.year, p.month - 1, p.day, hh, mm);
  }

  function buildAntardashas(mdNumber, mdStartMs) {
    let cur = mdStartMs;
    return dashaSequenceFrom(mdNumber).map((adN) => {
      const ms = (mdNumber * adN / 45) * DASHA_YEAR_MS;
      const seg = { n: adN, startMs: cur, endMs: cur + ms };
      cur += ms;
      return seg;
    });
  }

  function buildPratyantars(adSeg) {
    const span = adSeg.endMs - adSeg.startMs;
    let cur = adSeg.startMs;
    return dashaSequenceFrom(adSeg.n).map((pdN) => {
      const ms = span * pdN / 45;
      const seg = { n: pdN, startMs: cur, endMs: cur + ms };
      cur += ms;
      return seg;
    });
  }

  /* ---- Classical Vimshottari Dasha (true nakshatra-anchored layer) --------
     A SEPARATE, additive timing tradition from the Ank Jyotish proportional
     clock above. This one is the classical Jyotish stack:

       · anchor   – the natal Moon's nakshatra (astro.js already computes it)
       · total    – fixed 120-year cycle, lord durations never scaled
                    (Ketu 7, Venus 20, Sun 6, Moon 10, Mars 7, Rahu 18,
                     Jupiter 16, Saturn 19, Mercury 17)
       · balance  – the fraction of the birth nakshatra already traversed
                    removes exactly that fraction of the starting lord's MD
       · Antardasha / Pratyantar – proportional subdivision of the parent
                    span by the 120-year weights (AD = MDy × ADy ÷ 120)

     The two clocks are NOT reconciled anywhere: they answer different
     questions from different anchors and are deliberately allowed to
     disagree. Nothing here feeds the Lo Shu, Vastu or event-window
     authorities — it is a standalone Vedic read-out. Requires Vedic Tier 2
     (exact birth time + recognised birthplace); returns null otherwise. */
  const VIMSHOTTARI_LORDS = [
    /* [lord, years, number] — lord order is the canonical Vimshottari
       sequence; number maps the lord to its Ank Jyotish digit so the
       existing friendship matrix can grade the stack without a second
       relationship table. */
    ["Ketu", 7, 7], ["Venus", 20, 6], ["Sun", 6, 1], ["Moon", 10, 2],
    ["Mars", 7, 9], ["Rahu", 18, 4], ["Jupiter", 16, 3], ["Saturn", 19, 8],
    ["Mercury", 17, 5]
  ];
  const VIMSHOTTARI_TOTAL_YEARS = 120;
  const NAKSHATRA_SPAN_DEG = 360 / 27;

  function vimshottariLordIndex(name) {
    const target = String(name || "").trim().toLowerCase();
    return VIMSHOTTARI_LORDS.findIndex((row) => row[0].toLowerCase() === target);
  }

  function vimshottariTimeline(p, refDate) {
    const astro = p && p.astro && p.astro.ok && p.astro.moon && p.astro.moon.nakshatra ? p.astro : null;
    if (!astro || astro.tier !== "full") return null;
    const nak = astro.moon.nakshatra;
    const startIdx = vimshottariLordIndex(nak.lord);
    if (startIdx < 0) return null;

    const birth = dashaBirthDate(p);
    const birthMs = birth.getTime();
    const nowMs = (refDate ? new Date(refDate) : new Date()).getTime();

    // Balance of the birth lord: how much of that nakshatra was still unspent.
    const elapsed = Math.max(0, Math.min(1, (nak.within || 0) / NAKSHATRA_SPAN_DEG));
    const balanceYears = (1 - elapsed) * VIMSHOTTARI_LORDS[startIdx][1];

    // Lifetime Mahadasha ladder (72 of the 120-year cycles is plenty for a life)
    const mahadashas = [];
    let cur = birthMs, i = startIdx, years = balanceYears, guard = 0;
    while (cur < birthMs + 120 * DASHA_YEAR_MS && guard++ < 40) {
      const ms = years * DASHA_YEAR_MS;
      const row = VIMSHOTTARI_LORDS[i];
      mahadashas.push({
        lord: row[0], n: row[2], fullYears: row[1], years,
        startMs: cur, endMs: cur + ms,
        fromAge: +((cur - birthMs) / DASHA_YEAR_MS).toFixed(1),
        toAge: +((cur + ms - birthMs) / DASHA_YEAR_MS).toFixed(1),
        current: nowMs >= cur && nowMs < cur + ms,
        balance: mahadashas.length === 0
      });
      cur += ms;
      i = (i + 1) % VIMSHOTTARI_LORDS.length;
      years = VIMSHOTTARI_LORDS[i][1];
    }

    // Subdivide the running Mahadasha by the 120-year weights.
    const subdivide = (spanStartMs, spanYears, startLordIdx, depth) => {
      let c = spanStartMs, k = startLordIdx;
      const segs = [];
      for (let s = 0; s < VIMSHOTTARI_LORDS.length; s++) {
        const row = VIMSHOTTARI_LORDS[k];
        const ms = (spanYears * row[1] / VIMSHOTTARI_TOTAL_YEARS) * DASHA_YEAR_MS;
        segs.push({
          lord: row[0], n: row[2], years: spanYears * row[1] / VIMSHOTTARI_TOTAL_YEARS,
          startMs: c, endMs: c + ms, depth,
          // Each sub-period carries its OWN age window. Inheriting the
          // parent Mahadasha's ages would misreport a one-year Antardasha as
          // spanning the whole seven-year Mahadasha.
          fromAge: +((c - birthMs) / DASHA_YEAR_MS).toFixed(1),
          toAge: +((c + ms - birthMs) / DASHA_YEAR_MS).toFixed(1)
        });
        c += ms;
        k = (k + 1) % VIMSHOTTARI_LORDS.length;
      }
      return segs;
    };
    const pick = (segs) => segs.find((s) => nowMs >= s.startMs && nowMs < s.endMs) || segs[segs.length - 1];

    const md = mahadashas.find((m) => m.current) || mahadashas[mahadashas.length - 1];
    const mdStartIdx = vimshottariLordIndex(md.lord);
    const ads = subdivide(md.startMs, md.years, mdStartIdx, 2);
    const ad = pick(ads);
    const pds = subdivide(ad.startMs, ad.years, vimshottariLordIndex(ad.lord), 3);
    const pd = pick(pds);

    return {
      available: true,
      anchor: {
        nakshatra: nak.name, pada: nak.pada, lord: nak.lord, deity: nak.deity,
        moonSign: astro.moon.sign, moonDeg: astro.moon.degStr,
        span: nak.spanStr, elapsedPct: Math.round(elapsed * 1000) / 10
      },
      balanceYears: Math.round(balanceYears * 1000) / 1000,
      totalYears: VIMSHOTTARI_TOTAL_YEARS,
      mahadashas,
      current: { md, ad, pd },
      adProgress: Math.max(0, Math.min(100, Math.round(((nowMs - ad.startMs) / (ad.endMs - ad.startMs)) * 100))),
      // The single most useful professional read-out: does the classical
      // stack even agree with the Ank Jyotish stack on the active lord?
      agreementSignature: `${md.lord}/${ad.lord}`
    };
  }

  /* Dasha owns timing and life-event windows. Scores intentionally use only
     the active Mahadasha/Antardasha lords and the event's Dasha definition;
     neither Lo Shu nor Vedic-grid counts can strengthen, weaken or reroute a
     prediction window. */
  function scoreEventWindow(ev, mdN, adN) {
    // Timing score uses only the Dasha lords. Natal strength is NOT folded in
    // here: a missing significator must never delete a window (that produced
    // the all-or-nothing bug where Venus wealth/marriage windows vanished for
    // charts with 6 absent). Natal presence is reported separately as a
    // conversion-probability grade via natalConversion().
    let s = 0;
    if (ev.primary.includes(adN)) s += 3;
    if (ev.primary.includes(mdN)) s += 2;
    if (ev.support.includes(adN)) s += 1.5;
    if (ev.support.includes(mdN)) s += 1;
    return s;
  }

  /* Conversion-probability grade for an event window. The window itself is
     timing (Dasha authority); this grade only says how directly it is likely
     to convert, based on whether the significator lords that make the window
     are present in the VEDIC ANK KUNDALI grid.

     Strict grid tagging (2026-09 audit fix): the evaluation array and the
     printed label were allowed to drift in older builds — a window could be
     evaluated against one grid while the sentence called it the "Vedic birth
     grid", contradicting the Ank Kundali section pages earlier. The grade is
     now ALWAYS computed against p.vedicCounts (the Vedic array), carries an
     explicit `grid: "vedic"` tag for the renderer, and reports every
     significator whose presence differs between the Vedic and Lo Shu arrays
     so the renderer can disclose the divergence instead of hiding it. The
     renderer must print exactly this grid's name — never a generic "birth
     grid" label that could be read as either system.
       high        – the triggering AD lord is present natally (direct conversion)
       moderate    – AD lord absent but the MD lord (a significator) is present
       conditional – both triggering lords absent natally; needs the Vastu
                     sector of the AD lord activated before realisation */
  const NATAL_CONVERSION_GRID = "vedic";
  function natalConversion(ev, mdN, adN, p) {
    const counts = p && p.vedicCounts ? p.vedicCounts : {};
    const loShuCounts = p && p.loShuCounts ? p.loShuCounts : {};
    const present = (n) => (counts[n] || 0) > 0;
    const isSig = (n) => ev.primary.includes(n) || ev.support.includes(n);
    const adPresent = present(adN);
    const mdPresent = present(mdN) && isSig(mdN);
    const grade = adPresent ? "high" : mdPresent ? "moderate" : "conditional";
    const missing = [adN, mdN].filter((n, i, a) => a.indexOf(n) === i && isSig(n) && !present(n));
    // Cross-grid disclosure: numbers where the Vedic and Lo Shu arrays answer
    // differently (e.g. century digits plot in Lo Shu but not in the Vedic
    // Ank Kundali). Listed so the window text can say WHICH grid was judged.
    const divergence = [adN, mdN].filter((n, i, a) => a.indexOf(n) === i && isSig(n) &&
      (((counts[n] || 0) > 0) !== ((loShuCounts[n] || 0) > 0)));
    return { grade, adPresent, mdPresent, missing, grid: NATAL_CONVERSION_GRID, divergence };
  }

  function dashaTimeline(p, refDate) {
    const birth = dashaBirthDate(p);
    const birthMs = birth.getTime();
    const nowMs = (refDate ? new Date(refDate) : new Date()).getTime();

    // Lifetime Mahadasha ladder. Computed to 100 years so Antardasha and
    // Pratyantar boundaries stay exact past the 80-year average-lifespan
    // horizon (DASHA_LIFESPAN_YEARS); every Dasha read-out is guaranteed
    // inside that 80-year coverage window.
    const mahadashas = [];
    let cur = birthMs, n = p.driver;
    while (cur < birthMs + 100 * DASHA_YEAR_MS) {
      const ms = n * DASHA_YEAR_MS;
      mahadashas.push({
        n,
        startMs: cur, endMs: cur + ms,
        fromAge: Math.round((cur - birthMs) / DASHA_YEAR_MS),
        toAge: Math.round((cur + ms - birthMs) / DASHA_YEAR_MS),
        current: nowMs >= cur && nowMs < cur + ms
      });
      cur += ms;
      n = (n % 9) + 1;
    }

    // Current nested stack: MD → AD → PD
    const md = mahadashas.find((m) => m.current) || mahadashas[mahadashas.length - 1];
    const ads = buildAntardashas(md.n, md.startMs);
    const ad = ads.find((a) => nowMs >= a.startMs && nowMs < a.endMs) || ads[ads.length - 1];
    const pds = buildPratyantars(ad);
    const pd = pds.find((x) => nowMs >= x.startMs && nowMs < x.endMs) || pds[pds.length - 1];
    const adProgress = Math.max(0, Math.min(100, Math.round(((nowMs - ad.startMs) / (ad.endMs - ad.startMs)) * 100)));
    const pdDaysLeft = Math.max(0, Math.ceil((pd.endMs - nowMs) / 86400000));

    // Next-horizon roadmap: the current Pratyantar plus every Pratyantar that
    // starts inside the next ~90 days, crossing Antardasha (and, if needed,
    // Mahadasha) boundaries so the reader always sees what takes over next.
    const horizonMs = nowMs + 90 * 86400000;
    const mdIdx = mahadashas.indexOf(md);
    const adIdx = ads.indexOf(ad);
    // Flatten the Antardasha sequence from the current one forward, across
    // the Mahadasha boundary when needed, so the roadmap never dead-ends.
    const adRun = [];
    ads.slice(adIdx).forEach((a) => adRun.push({ seg: a, mdN: md.n, sameAd: a === ad }));
    if (mdIdx + 1 < mahadashas.length) {
      const nm = mahadashas[mdIdx + 1];
      buildAntardashas(nm.n, nm.startMs).forEach((a) => adRun.push({ seg: a, mdN: nm.n, sameAd: false }));
    }
    const upcoming = [];
    for (const { seg: adSeg, mdN, sameAd } of adRun) {
      if (adSeg.startMs > horizonMs) break;
      const list = buildPratyantars(adSeg);
      list.forEach((seg, i) => {
        if (seg.endMs <= nowMs || seg.startMs > horizonMs) return;
        upcoming.push({
          n: seg.n, startMs: seg.startMs, endMs: seg.endMs, mdN, adN: adSeg.n,
          adStartMs: adSeg.startMs, adEndMs: adSeg.endMs,
          current: nowMs >= seg.startMs && nowMs < seg.endMs,
          adChange: !sameAd && i === 0
        });
      });
    }
    const nextAdRun = adRun[1] || null;
    const nextAd = nextAdRun ? { n: nextAdRun.seg.n, startMs: nextAdRun.seg.startMs, endMs: nextAdRun.seg.endMs, mdN: nextAdRun.mdN } : null;

    // Life-event windows: scan every AD segment across life against the
    // classical Dasha lords, then keep the best upcoming windows (plus the
    // strongest past one for validation).
    const db = getActiveDB();
    const dashaDB = db.dasha || (window.DB && window.DB.dasha) || {};
    const eventDefs = dashaDB.lifeEvents || {};
    const events = Object.keys(eventDefs).map((key) => {
      const ev = eventDefs[key];
      const windows = [];
      mahadashas.forEach((m) => {
        buildAntardashas(m.n, m.startMs).forEach((a) => {
          const midAge = ((a.startMs + a.endMs) / 2 - birthMs) / DASHA_YEAR_MS;
          if (midAge < ev.band[0] || midAge > ev.band[1]) return;
          const score = scoreEventWindow(ev, m.n, a.n);
          if (score >= 3) windows.push({
            mdN: m.n, adN: a.n, score,
            conversion: natalConversion(ev, m.n, a.n, p),
            startMs: a.startMs, endMs: a.endMs,
            fromAge: Math.floor((a.startMs - birthMs) / DASHA_YEAR_MS),
            toAge: Math.ceil((a.endMs - birthMs) / DASHA_YEAR_MS),
            past: a.endMs < nowMs,
            active: nowMs >= a.startMs && nowMs < a.endMs
          });
        });
      });
      // Keep the strongest upcoming windows by Dasha score alone; a
      // conditional (natal-absent) window is still shown, only graded lower.
      // Five windows (not three) keep the far end of a 75-year wealth band
      // visible instead of collapsing it into the earliest peaks.
      let future = windows.filter((w) => !w.past).sort((x, y) => y.score - x.score || x.startMs - y.startMs).slice(0, DASHA_FUTURE_WINDOWS).sort((x, y) => x.startMs - y.startMs);
      const pastBest = windows.filter((w) => w.past).sort((x, y) => y.score - x.score)[0] || null;
      // Lifetime coverage for this event: how many significator windows the
      // band holds in total and where the furthest one lands. The renderer
      // prints this so a 21–75 wealth band reads as covered till 75 even
      // though only the next few windows are detailed above it.
      const lastInBand = windows.length ? windows[windows.length - 1] : null;
      const coverage = {
        total: windows.length,
        futureTotal: windows.filter((w) => !w.past).length,
        last: lastInBand ? { fromAge: lastInBand.fromAge, toAge: lastInBand.toAge, mdN: lastInBand.mdN, adN: lastInBand.adN, startMs: lastInBand.startMs, endMs: lastInBand.endMs } : null
      };
      // If the classical age band has already closed, do not leave the event
      // blank: surface the next significator windows beyond the band and flag
      // them as late windows so nothing is silently purged. The late scan
      // reaches till the 80-year average-lifespan horizon, or 15 years ahead
      // of today, whichever reaches further.
      const ageNow = (nowMs - birthMs) / DASHA_YEAR_MS;
      const lateHorizonMs = Math.max(birthMs + DASHA_LIFESPAN_YEARS * DASHA_YEAR_MS, nowMs + DASHA_LATE_LOOKAHEAD_YEARS * DASHA_YEAR_MS);
      let bandClosed = false;
      if (!future.length && ageNow > ev.band[1]) {
        bandClosed = true;
        const late = [];
        mahadashas.forEach((m) => {
          buildAntardashas(m.n, m.startMs).forEach((a) => {
            if (a.endMs < nowMs || a.startMs > lateHorizonMs) return;
            const score = scoreEventWindow(ev, m.n, a.n);
            if (score >= 3) late.push({
              mdN: m.n, adN: a.n, score, beyondBand: true,
              conversion: natalConversion(ev, m.n, a.n, p),
              startMs: a.startMs, endMs: a.endMs,
              fromAge: Math.floor((a.startMs - birthMs) / DASHA_YEAR_MS),
              toAge: Math.ceil((a.endMs - birthMs) / DASHA_YEAR_MS),
              past: false, active: nowMs >= a.startMs && nowMs < a.endMs
            });
          });
        });
        future = late.sort((x, y) => y.score - x.score || x.startMs - y.startMs).slice(0, DASHA_LATE_WINDOWS).sort((x, y) => x.startMs - y.startMs);
      }
      return { key, def: ev, future, pastBest, bandClosed, coverage, lateHorizonMs };
    });

    // Personal Year is the annual transit engine the Dasha operates through.
    // It is computed here (not in timingAnalysis) so the Dasha section can
    // synthesise it against the active MD/AD without touching timing dates.
    const nowDate = new Date(nowMs);
    const personalYear = reduce(p.day + p.month + reduce(nowDate.getFullYear()));

    return {
      birthMs,
      mahadashas,
      current: { md, ad, pd, adProgress, pdDaysLeft, nextAd, personalYear, year: nowDate.getFullYear() },
      upcoming,
      events
    };
  }

  /* ---- Real sunrise calculator (Meeus Ch.16 foundation) ----------------
     Replaces the hardcoded 6:30-8:30 window. Uses NVAstro.sunriseSunset
     (Meeus hour-angle) with DST and polar-day handling. Falls back to
     the old text only when no geo is available. */
  function getRealSunriseForProfile(p, Y, M, D) {
    try {
      if (!p) return null;
      var astro = (typeof window !== "undefined" && window.NVAstro) ? window.NVAstro : null;
      if (!astro || typeof astro.sunriseSunset !== "function") return null;
      var place = null;
      if (p.astro && p.astro.place) place = p.astro.place;
      if (!place || !isFinite(place.lat) || !isFinite(place.lon)) return null;
      var now = new Date();
      var y = Y || now.getFullYear();
      var m = M || (now.getMonth() + 1);
      var d = D || now.getDate();
      var tzEff = place.tz;
      if (typeof astro.effectiveTz === "function") {
        try { tzEff = astro.effectiveTz(place, y, m, d); } catch (e) { tzEff = place.tz; }
      } else if (place.dst) {
        try {
          if (typeof astro.isDSTActive === "function" && astro.isDSTActive(y, m, d, place.lat, place.lon)) tzEff = place.tz + 1;
        } catch (e) {}
      }
      if (!isFinite(tzEff)) tzEff = place.tz;
      var ss = astro.sunriseSunset(y, m, d, place.lat, place.lon, tzEff);
      if (!ss || !ss.ok) return null;
      return { place: place, tzEff: tzEff, ss: ss, y: y, m: m, d: d };
    } catch (e) { return null; }
  }

  function formatSunriseWindow(p, langOverride) {
    var lang = langOverride || getLang();
    var fallback = lang === "hi" ? "सुबह ६:३० से ८:३० के बीच (सूर्योदय काल)" : lang === "gu" ? "સવારે ૬:૩૦ થી ૮:૩૦ વચ્ચે (સૂર્યોદય સમય)" : "between 6:30 AM and 8:30 AM (sunrise hours)";
    var real = getRealSunriseForProfile(p);
    if (!real || !real.ss) return fallback;
    var ss = real.ss;
    var astro = window.NVAstro;
    var fmt = function(dec) {
      try {
        if (astro && typeof astro.formatSunTime === "function") return astro.formatSunTime(dec, lang);
      } catch (e) {}
      // fallback simple
      if (!isFinite(dec)) return "";
      var h = ((dec % 24) + 24) % 24;
      var hour24 = Math.floor(h);
      var minute = Math.floor((h - hour24) * 60 + 0.5);
      var hr = hour24, min = minute;
      if (min >= 60) { min -= 60; hr = (hr + 1) % 24; }
      var ampm = hr >= 12 ? "PM" : "AM";
      var h12 = hr % 12; if (h12 === 0) h12 = 12;
      var base = h12 + ":" + String(min).padStart(2, "0") + " " + ampm;
      return base;
    };
    if (ss.alwaysDay) {
      return lang === "hi" ? "सुबह सूर्योदय के आसपास (आपके स्थान पर ध्रुवीय दिन — सूर्य पूरे दिन ऊपर है, सुबह जल्दी पहनें)" : lang === "gu" ? "સવારે સૂર્યોદયની આસપાસ (તમારા સ્થાને ધ્રુવીય દિવસ — સૂર્ય આખો દિવસ ઉપર છે, વહેલી સવારે પહેરો)" : "around sunrise — polar day at your location (sun up all day, use early morning)";
    }
    if (ss.alwaysNight) {
      return lang === "hi" ? "सुबह ६ बजे के आसपास प्रतीकात्मक सूर्योदय (आपके स्थान पर ध्रुवीय रात)" : lang === "gu" ? "સવારે ૬ વાગ્યાની આસપાસ પ્રતીકાત્મક સૂર્યોદય (તમારા સ્થાને ધ્રુવીય રાત)" : "around symbolic sunrise 6:00 AM (polar night at your location)";
    }
    if (ss.sunrise == null || ss.sunset == null) return fallback;
    var sr = ss.sunrise;
    var srEnd = sr + 2;
    if (srEnd > ss.sunset) srEnd = ss.sunset;
    if (srEnd >= 24) srEnd -= 24;
    var srText = fmt(sr);
    var srEndText = fmt(srEnd);
    if (lang === "hi") {
      return "सुबह " + srText + " से " + srEndText + " के बीच (सूर्योदय " + srText + " पर, वास्तविक गणना)";
    } else if (lang === "gu") {
      return "સવારે " + srText + " થી " + srEndText + " વચ્ચે (સૂર્યોદય " + srText + " પર, વાસ્તવિક ગણતરી)";
    } else {
      return "between " + srText + " and " + srEndText + " (sunrise at " + srText + ", actual calculation for your location)";
    }
  }

  function watchSpec(p) {
    const d = p.driver, c = p.conductor;
    const db = getActiveDB();
    const lang = getLang();
    const rows = [
      [lang === "hi" ? "धातु / केस" : lang === "gu" ? "ધાતુ / કેસ" : "Metal / Case", db.watch.metal[d], lang === "hi" ? `मूलांक ${d} (${db.numbers[d].planet}) के अनुकूल` : lang === "gu" ? `મૂળાંક ${d} (${db.numbers[d].planet}) ના અનુકૂળ` : `Supports Driver ${d} (${db.numbers[d].planet})`],
      [lang === "hi" ? "डायल का रंग" : lang === "gu" ? "ડાયલનો રંગ" : "Dial Colour", db.watch.dial[d], lang === "hi" ? `मन को शांत और ${db.numbers[d].planet} को मजबूत करता है` : lang === "gu" ? `મનને શાંત અને ${db.numbers[d].planet} ને મજબૂત કરે છે` : `Calms and strengthens the ${db.numbers[d].planet} mind`],
      [lang === "hi" ? "डायल का आकार" : lang === "gu" ? "ડાયલનો આકાર" : "Case Geometry", db.watch.geometry[c], lang === "hi" ? `भाग्यांक ${c} (${db.numbers[c].planet}) की संरचना` : lang === "gu" ? `ભાગ્યાંક ${c} (${db.numbers[c].planet}) ની રચના` : `Mirrors Conductor ${c} (${db.numbers[c].planet}) structure`],
      [lang === "hi" ? "स्ट्रैप (पट्टा)" : lang === "gu" ? "સ્ટ્રેપ (પટ્ટો)" : "Strap", db.watch.strap[d], lang === "hi" ? "धातु ऊर्जा को स्थिर रखती है; रबर से बचें" : lang === "gu" ? "ધાતુ ઊર્જાને સ્થિર રાખે છે; રબરથી બચો" : "Metal grounds energy; avoid rubber/silicone"],
      [lang === "hi" ? "मुख्य विशेषताएं" : lang === "gu" ? "મુખ્ય વિશેષતાઓ" : "Key Features", db.watch.features[c], lang === "hi" ? `भाग्यांक ${c} कार्य निष्पादन सहायक` : lang === "gu" ? `ભાગ્યાંક ${c} કાર્ય પૂર્તિ સહાયક` : `Conductor ${c} execution support`],
    ];
    const avoids = [db.watch.avoid[d], db.watch.avoid[c]].filter(Boolean);
    const days = [...new Set([dayOf(d), dayOf(c)])];
    const timeText = formatSunriseWindow(p, lang);
    return {
      rows, avoids, days,
      time: timeText,
      currentVerdict: currentWatchVerdict(p)
    };
  }

  function currentWatchVerdict(p) {
    const t = p.watchType;
    if (!t || t === "none") return null;
    const db = getActiveDB();
    const lang = getLang();
    if (t === "smart") {
      const sensitive = [2, 7].includes(p.driver) || [2, 7].includes(p.conductor);
      if (lang === "hi") {
        return sensitive
          ? { tone: "warn", text: `आपकी स्मार्टवॉच राहु (४) की ऊर्जा पर काम करती है — कलाई पर बार-बार आने वाले नोटिफिकेशन आपके ${db.numbers[p.driver].planet} मूलांक को अशांत कर सकते हैं। यदि इसे पहनना जारी रखें: मेटल स्ट्रैप लगाएं, न्यूनतम डायल रखें और सोते समय 'डू नॉट डिस्टर्ब' चालू रखें।` }
          : { tone: "info", text: `स्मार्टवॉच आपके चार्ट के लिए ठीक है — नोटिफिकेशन सीमित रखें और राहु (४) की इलेक्ट्रॉनिक ऊर्जा को संतुलित करने के लिए मेटल स्ट्रैप को प्राथमिकता दें।` };
      }
      if (lang === "gu") {
        return sensitive
          ? { tone: "warn", text: `તમારી સ્માર્ટવોચ રાહુ (૪) ની ઊર્જા પર કામ કરે છે — કાંડા પર વારંવાર આવતા નોટિફિકેશન તમારા ${db.numbers[p.driver].planet} મૂળાંકને અશાંત કરી શકે છે. જો પહેરવાનું ચાલુ રાખો: મેટલ સ્ટ્રેપ લગાવો, સાદો ડાયલ રાખો અને ઊંઘતી વખતે 'ડુ નોટ ડિસ્ટર્બ' ચાલુ રાખો.` }
          : { tone: "info", text: `સ્માર્ટવોચ તમારા ચાર્ટ માટે યોગ્ય છે — નોટિફિકેશન મર્યાદિત રાખો અને રાહુ (૪) ની ઇલેક્ટ્રોનિક ઊર્જા સંતુલિત કરવા મેટલ સ્ટ્રેપને પ્રાથમિકતા આપો.` };
      }
      return sensitive
        ? { tone: "warn", text: `Your smartwatch runs on Rahu (4) energy — constant wrist notifications can disturb your ${db.numbers[p.driver].planet} driver. If you keep it: switch to a metallic strap, use a minimal ${p.driver === 2 ? "silver/white" : "calm"} watch-face, and enable Do-Not-Disturb during sleep and deep work.` }
        : { tone: "info", text: "A smartwatch is acceptable for your chart — keep notifications curated and prefer a metallic strap to ground the Rahu (4) electronic energy." };
    }
    if (t === "digital") {
      return {
        tone: "info",
        text: lang === "hi" ? "डिजिटल घड़ी सामान्य है। ऊपर दिए गए विवरण के अनुसार मेटल स्ट्रैप वाली एनालॉग घड़ी पहनने से अतिरिक्त ग्रहीय लाभ मिलेगा।"
          : lang === "gu" ? "ડિજિટલ ઘડિયાળ સામાન્ય છે. ઉપર દર્શાવેલ વિગત મુજબ મેટલ સ્ટ્રેપ વાળી એનાલોગ ઘડિયાળ પહેરવાથી વધારાનો ગ્રહીય લાભ મળશે."
          : "A digital watch is neutral. Upgrading to a metal-strap analog aligned with the spec above would add planetary support."
      };
    }
    return {
      tone: "good",
      text: lang === "hi" ? "क्लासिक एनालॉग घड़ी आपके चार्ट के लिए सर्वोत्तम है। पूर्ण लाभ के लिए ऊपर दिए गए धातु, डायल रंग और आकार का मिलान करें।"
        : lang === "gu" ? "ક્લાસિક એનાલોગ ઘડિયાળ તમારા ચાર્ટ માટે સર્વોત્તમ છે. સંપૂર્ણ લાભ માટે ઉપર દર્શાવેલ ધાતુ, ડાયલ રંગ અને આકાર પસંદ કરો."
        : "A classic analog watch suits your chart. Match the metal, dial colour and geometry to the spec above for full alignment."
    };
  }

  function vastuReport(p) {
    const findings = [];
    const db = getActiveDB();
    const lang = getLang();
    if (p.entrance && p.entrance !== "unsure" && db.vastu && db.vastu.entrance) {
      const e = db.vastu.entrance[p.entrance];
      if (e) {
        findings.push({
          item: lang === "hi" ? `मुख्य द्वार — ${dirLabel(p.entrance)}` : lang === "gu" ? `મુખ્ય પ્રવેશદ્વાર — ${dirLabel(p.entrance)}` : `Main entrance — ${dirLabel(p.entrance)}`,
          tone: e.score === "Excellent" || e.score === "Good" ? "good" : e.score === "Moderate" ? "warn" : "bad",
          label: e.score, note: e.note
        });
      }
    }
    const roomMap = {
      kitchen: lang === "hi" ? "रसोईघर (Kitchen)" : lang === "gu" ? "રસોડું (Kitchen)" : "Kitchen",
      bedroom: lang === "hi" ? "मास्टर बेडरूम (Master Bedroom)" : lang === "gu" ? "મુખ્ય બેડરૂમ (Master Bedroom)" : "Master Bedroom",
      toilet: lang === "hi" ? "शौचालय (Toilet)" : lang === "gu" ? "શૌચાલય (Toilet)" : "Toilet",
      study: lang === "hi" ? "अध्ययन कक्ष (Study Room)" : lang === "gu" ? "અભ્યાસ ખંડ (Study Room)" : "Study Room",
      staircase: lang === "hi" ? "सीढ़ियां (Staircase)" : lang === "gu" ? "દાદર / પગથિયાં (Staircase)" : "Staircase"
    };
    const engRoomNames = { kitchen: "Kitchen", bedroom: "Master Bedroom", toilet: "Toilet", study: "Study Room", staircase: "Staircase" };
    Object.entries(engRoomNames).forEach(([key, engName]) => {
      const dir = p[key];
      if (!dir || dir === "unsure" || !db.vastu || !db.vastu.roomRules) return;
      const rule = db.vastu.roomRules.find((r) => r.room === engName);
      if (!rule) return;
      const status = (rule.ideal && rule.ideal.includes(dir)) ? "ideal" : (rule.acceptable && rule.acceptable.includes(dir)) ? "ok" : "dosh";
      const roomLabel = roomMap[key] || engName;
      findings.push({
        item: `${roomLabel} — ${dirLabel(dir)}`,
        tone: status === "ideal" ? "good" : status === "ok" ? "warn" : "bad",
        label: status === "ideal" ? "Ideal" : status === "ok" ? "Acceptable" : "Dosh",
        note: status === "dosh" ? rule.doshText.replace("{dir}", dirLabel(dir)) + " " + rule.fix : status === "ok" ? (lang === "hi" ? "स्वीकार्य स्थिति। " + rule.fix : lang === "gu" ? "સ્વીકાર્ય સ્થિતિ. " + rule.fix : "Acceptable placement. " + rule.fix) : (lang === "hi" ? "उत्तम स्थिति — संतुलित ऊर्जा का संचार।" : lang === "gu" ? "ઉત્તમ સ્થિતિ — સંતુલિત ઊર્જાનો સંચાર." : "Well placed — supports balanced energy.")
      });
    });

    if (p.plotShape && p.plotShape !== "unsure" && db.vastu && db.vastu.plotShapes && db.vastu.plotShapes[p.plotShape]) {
      const ps = db.vastu.plotShapes[p.plotShape];
      findings.push({
        item: lang === "hi" ? `प्लॉट का आकार — ${p.plotShape.replace(/-/g, " ")}` : lang === "gu" ? `પ્લોટનો આકાર — ${p.plotShape.replace(/-/g, " ")}` : `Plot shape — ${p.plotShape.replace(/-/g, " ")}`,
        tone: ps.tone,
        label: ps.tone === "good" ? "Balanced" : ps.tone === "warn" ? "Caution" : "Dosh",
        note: ps.note
      });
    }
    return findings;
  }

  function goalPlan(p) {
    const db = getActiveDB();
    const goalsMap = (window.DB && window.DB.goals) || {};
    return p.goals.map((g) => {
      const nums = goalsMap[g] || [];
      const weak = nums.filter((n) => p.loShuMissing.includes(n));
      const strong = nums.filter((n) => !p.loShuMissing.includes(n));
      const focus = weak.length ? weak : nums.slice(0, 2);
      return { goal: g, weak, strong, focus: focus.map((n) => ({ n, ...db.numbers[n] })) };
    });
  }

  /* The Foundation practice engine intentionally reads one source only: the
     classic Lo Shu signal set. Driver/Conductor power days are rendered
     separately below as a scheduling reference, never as plan selectors. */
  function loShuPracticeTargets(p) {
    const critical = (p.loShuMissingSeverity || [])
      .filter((entry) => entry && entry.critical)
      .map((entry) => Number(entry.n));
    const missing = [...new Set(critical.concat((p.loShuMissing || []).map(Number)))];
    const repeated = [...new Set((p.loShuRepeated || []).map(Number))];
    const present = Object.keys(p.loShuCounts || {})
      .map(Number)
      .filter((n) => (p.loShuCounts[n] || 0) > 0)
      .sort((a, b) => (p.loShuCounts[b] - p.loShuCounts[a]) || a - b);
    const ordered = missing.concat(repeated.filter((n) => !missing.includes(n)), present.filter((n) => !missing.includes(n) && !repeated.includes(n)));
    return {
      missing,
      repeated,
      ordered,
      primary: ordered[0] || 5,
      secondary: ordered.find((n) => n !== (ordered[0] || 5)) || null
    };
  }

  /* Practice-target resolution — the 40-day plan must never chant against
     the Remedy Triage card on the same page. When the Dasha stack / Personal
     Year makes a Lo Shu missing number live, the acute Tier-1 number becomes
     the plan's practice target; the stack only RE-ORDERS Lo Shu missing
     numbers, it never imports a target from outside the grid. When no missing
     number is live, triage holds japa and the plan runs on non-invocation
     cues (colour, lifestyle, affirmation) with the mantra row held. */
  function resolvePracticeTargets(p, triagePre) {
    const targets = loShuPracticeTargets(p);
    const triage = triagePre || remedyTriage(p);
    const tier1 = (triage && triage.tier1) || { mode: "maintenance", n: targets.primary };
    const acute = tier1.mode === "acute";
    const holdJapa = tier1.mode === "environmental";
    const primary = acute ? tier1.n : targets.primary;
    /* Second signal: when an acute target leads, follow the triage queue
       (queued Tier-2 first — it is live but behind Tier-1); otherwise the
       classic Lo Shu ordering. Never echo the primary itself. */
    const queued = acute && triage && Array.isArray(triage.tier2)
      ? triage.tier2.map((t) => t.n)
      : [];
    const secondary = (queued.find((n) => n !== primary))
      || (targets.ordered || []).find((n) => n !== primary)
      || null;
    return { targets, triage, tier1, acute, holdJapa, primary, secondary };
  }

  function priorityPlan(p) {
    const db = getActiveDB();
    const lang = getLang();
    const targets = loShuPracticeTargets(p);
    const rows = [];
    targets.missing.slice(0, 5).forEach((n) => {
      const info = db.numbers[n];
      if (!info) return;
      if (lang === "hi") {
        rows.push({ cadence: "daily", source: "lo-shu", n, signal: "missing", text: `<strong>${esc(info.planet)}</strong> को बलवान बनाएं (लो शू में अनुपस्थित अंक ${n}): <span class="mantra">${esc(info.mantra)}</span> का जाप करें (${esc(info.mantraCount)}), ${esc(info.color.split(",")[0])} रंग अपनाएं और ${esc(info.lifestyle.split(";")[0])} का अभ्यास करें।` });
      } else if (lang === "gu") {
        rows.push({ cadence: "daily", source: "lo-shu", n, signal: "missing", text: `<strong>${esc(info.planet)}</strong> ને બળવાન બનાવો (લો શુમાં ખૂટતો અંક ${n}): <span class="mantra">${esc(info.mantra)}</span> નો જાપ કરો (${esc(info.mantraCount)}), ${esc(info.color.split(",")[0])} રંગ અપનાવો અને ${esc(info.lifestyle.split(";")[0])} નો અભ્યાસ કરો.` });
      } else {
        rows.push({ cadence: "daily", source: "lo-shu", n, signal: "missing", text: `Strengthen <strong>${esc(info.planet)}</strong> (missing ${n} in your Lo Shu grid): chant <span class="mantra">${esc(info.mantra)}</span> ${esc(info.mantraCount)}, use ${esc(info.color.split(",")[0])} and practise ${esc(info.lifestyle.split(";")[0])}.` });
      }
    });
    targets.repeated.slice(0, 3).forEach((n) => {
      const info = db.numbers[n];
      const excess = (db.excessEnergy && db.excessEnergy[n]) || {};
      const channel = loc(excess.channel, lang) || info.lifestyle;
      if (!info) return;
      if (lang === "hi") {
        rows.push({ cadence: "daily", source: "lo-shu", n, signal: "repeated", text: `<strong>${esc(info.planet)}</strong> की ${p.loShuCounts[n]}× दोहराई ऊर्जा को दिशा दें: ${esc(channel)}। इस अंक को और बढ़ाने वाला उपाय न जोड़ें।` });
      } else if (lang === "gu") {
        rows.push({ cadence: "daily", source: "lo-shu", n, signal: "repeated", text: `<strong>${esc(info.planet)}</strong> ની ${p.loShuCounts[n]}× પુનરાવર્તિત ઊર્જાને દિશા આપો: ${esc(channel)}. આ અંકને વધુ વધારતો ઉપાય ઉમેરશો નહીં.` });
      } else {
        rows.push({ cadence: "daily", source: "lo-shu", n, signal: "repeated", text: `Channel ${p.loShuCounts[n]}× repeated <strong>${esc(info.planet)}</strong> energy: ${esc(channel)}. Do not add another remedy that feeds this number.` });
      }
    });
    if (!rows.length) {
      const info = db.numbers[targets.primary];
      rows.push({ cadence: "daily", source: "lo-shu", text: lang === "hi"
        ? `आपकी लो शू जन्म-पट्टिका संतुलित है। अंक <strong>${targets.primary}</strong> (${esc(info.planet)}) की सकारात्मक आदत <strong>${esc(info.lifestyle.split(";")[0])}</strong> को स्थिरता के लिए रोज दोहराएं।`
        : lang === "gu"
          ? `તમારી લો શુ જન્મ-ગ્રિડ સંતુલિત છે. સ્થિરતા માટે અંક <strong>${targets.primary}</strong> (${esc(info.planet)}) ની સકારાત્મક ટેવ <strong>${esc(info.lifestyle.split(";")[0])}</strong> રોજ દોહરાવો.`
          : `Your Lo Shu Birth Grid is balanced. For maintenance, repeat number <strong>${targets.primary}</strong> (${esc(info.planet)})'s positive habit: <strong>${esc(info.lifestyle.split(";")[0])}</strong>.` });
    }
    return rows.slice(0, 8);
  }

  /* ---------------- Remedial triage (staged clinical protocol) ----------------
     A certified practitioner never prescribes every missing number at once.
     Three beej mantras (36,000+ japas), three weekly fasts, several gemstones
     and five lifestyle rules guarantee zero adherence — the "Christmas tree"
     prescription. This engine stages the same knowledge:

       Tier 1 (acute)  — only the missing number that is LIVE right now, i.e.
                         it is the Antardasha / Pratyantar / Mahadasha lord or
                         the Personal-Year number. One mantra, one dose, one
                         sector, one weekly discipline.
       Tier 2 (latent) — every other missing number. Held on environmental
                         cues only (colour, plant, sector hygiene) with the
                         exact date/period at which it becomes a Tier-1 target.

     Nothing is deleted: the full remedy library stays in the report. Triage
     only decides what the client is asked to DO this month. */
  function nextActivation(p, n, timeline, nowMs) {
    let antardasha = null;
    (timeline.mahadashas || []).forEach((m) => {
      if (m.endMs <= nowMs) return;
      buildAntardashas(m.n, m.startMs).forEach((a) => {
        if (a.n !== n || a.endMs <= nowMs) return;
        if (!antardasha || a.startMs < antardasha.startMs) {
          antardasha = { mdN: m.n, startMs: a.startMs, endMs: a.endMs, current: a.startMs <= nowMs };
        }
      });
    });
    const yearNow = new Date(nowMs).getFullYear();
    let personalYear = null;
    for (let off = 0; off <= 9; off++) {
      if (reduce(p.day + p.month + reduce(yearNow + off)) === n) { personalYear = yearNow + off; break; }
    }
    return { antardasha, personalYear };
  }

  function remedyTriage(p, dl, refDate) {
    const db = getActiveDB();
    const lang = getLang();
    const timeline = dl || dashaTimeline(p, refDate);
    const cur = timeline.current;
    const nowMs = (refDate ? new Date(refDate) : new Date()).getTime();
    const dashaDB = db.dasha || (window.DB && window.DB.dasha) || {};
    const shortMantra = db.mantraShort || (window.DB && window.DB.mantraShort) || {};
    const planetOf = (n) => String((db.numbers[n] || {}).planet || "").split(" ")[0];
    const targets = loShuPracticeTargets(p);
    const missing = (targets.missing || []).map(Number);
    const repeated = (targets.repeated || []).map(Number);

    // Which numbers are actually live in the client's current time-map.
    const layers = [
      { key: "antardasha", n: cur.ad.n, weight: 4, label: `Antardasha lord ${cur.ad.n} (${planetOf(cur.ad.n)}) — active until ${prettyDate(cur.ad.endMs)}` },
      { key: "personal-year", n: cur.personalYear, weight: 3, label: `Personal Year ${cur.personalYear} (${planetOf(cur.personalYear)}) — the ${cur.year} transit` },
      { key: "pratyantar", n: cur.pd.n, weight: 2, label: `Pratyantar lord ${cur.pd.n} (${planetOf(cur.pd.n)}) — micro period until ${prettyDate(cur.pd.endMs)}` },
      { key: "mahadasha", n: cur.md.n, weight: 1, label: `Mahadasha lord ${cur.md.n} (${planetOf(cur.md.n)}) — chapter until ${prettyDate(cur.md.endMs)}` }
    ];
    const activeNumbers = layers.map((l) => l.n).filter((n, i, a) => a.indexOf(n) === i);
    const acute = missing
      .map((n) => ({ n, layers: layers.filter((l) => l.n === n) }))
      .filter((c) => c.layers.length)
      .map((c) => ({ n: c.n, layers: c.layers, weight: Math.max.apply(null, c.layers.map((l) => l.weight)) }))
      .sort((a, b) => b.weight - a.weight || a.n - b.n);

    /* The client's Scaled Sadhana depth decides how the SAME acute target is
       dosed. Nothing else about the dose changes: the target number, the
       mantra, the day and the sector stay exactly as triaged. */
    const doseScale = sadhanaScaleOf(p);
    const doseLine = t(sadhanaI18n(doseScale.key).dose, "27× daily (quarter mala), same time each day");

    const doseFor = (n) => {
      const info = db.numbers[n] || {};
      const beej = shortMantra[n] || {};
      const zone = dashaDB[n] || {};
      return {
        n,
        planet: info.planet || "",
        mantra: beej.pron || info.mantra || "",
        mantraDev: beej.dev || "",
        // Adherence beats volume: a completed dose at the client's chosen
        // Scaled Sadhana depth is clinically worth more than an abandoned
        // 108×. The scale sizes the dose only — never the target.
        japa: doseLine,
        fullCycle: info.mantraCount || "",
        day: info.day || "",
        colour: String(info.color || "").split(",")[0].trim(),
        lifestyle: String(info.lifestyle || "").split(";")[0].trim(),
        zone: loc(zone.zone, lang),
        zoneRemedy: loc(zone.zoneRemedy, lang),
        crystal: info.crystal || ""
      };
    };

    let tier1;
    if (acute.length) {
      const pick = acute[0];
      tier1 = Object.assign({ mode: "acute", reasons: pick.layers.map((l) => l.label), trigger: pick.layers[0].key }, doseFor(pick.n));
    } else if (missing.length) {
      // Nothing missing is live: do not start japa. Work the active sector only.
      const adDose = doseFor(cur.ad.n);
      tier1 = {
        mode: "environmental", n: cur.ad.n, planet: adDose.planet,
        reasons: [`No missing number is live in the current stack — the active ${planetOf(cur.ad.n)} sub-period sets the only Tier-1 action`],
        trigger: "antardasha", mantra: "", mantraDev: "", japa: "Hold japa — no beej mantra is clinically indicated this period",
        fullCycle: "", day: "", colour: adDose.colour, lifestyle: adDose.lifestyle,
        zone: adDose.zone, zoneRemedy: adDose.zoneRemedy, crystal: ""
      };
    } else {
      const primary = targets.primary;
      tier1 = Object.assign({ mode: "maintenance", reasons: ["Balanced grid — maintenance dose only"], trigger: "maintenance" }, doseFor(primary));
    }

    const tier2 = missing
      .filter((n) => !(tier1.mode === "acute" && n === tier1.n))
      .map((n) => {
        const info = db.numbers[n] || {};
        const zone = dashaDB[n] || {};
        const unlock = nextActivation(p, n, timeline, nowMs);
        const liveLayers = layers.filter((l) => l.n === n);
        const queued = liveLayers.length > 0; // live, but out-ranked by the acute target
        const unlockLabel = queued
          ? `Live now via ${liveLayers.map((l) => l.key.replace("-", " ")).join(" + ")} — queued behind the Tier-1 target, review at the next consultation`
          : unlock.antardasha
            ? `${planetOf(n)} Antardasha ${prettyDate(unlock.antardasha.startMs)} → ${prettyDate(unlock.antardasha.endMs)}${unlock.personalYear ? ` · Personal Year ${n} in ${unlock.personalYear}` : ""}`
            : unlock.personalYear ? `Personal Year ${n} in ${unlock.personalYear}` : "No activation inside the scanned horizon";
        return {
          n,
          planet: info.planet || "",
          cue: String(info.lifestyle || "").split(";")[0].trim(),
          colour: String(info.color || "").split(",")[0].trim(),
          sector: loc(zone.zone, lang),
          status: queued ? "queued" : "latent",
          hold: queued
            ? "Environmental cue only this cycle — one acute japa target at a time."
            : "No japa, no fast, no gemstone yet — environmental cue only.",
          unlock,
          unlockLabel
        };
      })
      .sort((a, b) => {
        if ((a.status === "queued") !== (b.status === "queued")) return a.status === "queued" ? -1 : 1;
        const as = a.unlock.antardasha ? a.unlock.antardasha.startMs : Infinity;
        const bs = b.unlock.antardasha ? b.unlock.antardasha.startMs : Infinity;
        return as - bs || a.n - b.n;
      });

    const channel = repeated.map((n) => {
      const excess = (db.excessEnergy && db.excessEnergy[n]) || {};
      return { n, count: (p.loShuCounts || {})[n] || 0, planet: (db.numbers[n] || {}).planet || "", channel: loc(excess.channel, lang) || String((db.numbers[n] || {}).lifestyle || "").split(";")[0].trim() };
    });

    return {
      activeNumbers,
      layers,
      tier1,
      tier2,
      channel,
      // What the triage deliberately withholds, so the practitioner can say
      // why the client is not being handed the full 41-page prescription.
      withheld: tier2.length
        ? [
          `${tier2.length} additional beej mantra${tier2.length > 1 ? "s" : ""} (${tier2.map((x) => x.n).join(", ")}) — deferred to their own periods`,
          `${tier2.length} extra weekly fast${tier2.length > 1 ? "s" : ""} — a client cannot fast ${tier2.length + 1} days in 7`,
          "Additional gemstones — one activating stone at a time, never stacked"
        ]
        : []
    };
  }

  /* Natal-weighted qualification of a predictive event window. A missing
     significator never deletes a window — natal voids mean friction, delay and
     remedial effort, not the absence of the event. */
  function qualifyEventWindow(eventSignificators, natalCounts, dashaPair) {
    const sig = (eventSignificators || []).map(Number);
    const pair = dashaPair || [];
    const md = Number(pair[0]), ad = Number(pair[1]);
    if (!sig.includes(ad) && !sig.includes(md)) return null;
    const counts = natalCounts || {};
    const subLord = sig.includes(ad) ? ad : md;
    const isNatalPresent = (counts[subLord] || 0) > 0;
    const carriedByMd = !isNatalPresent && sig.includes(md) && (counts[md] || 0) > 0;
    return {
      subLord,
      natalStatus: isNatalPresent ? "Present" : "Absent",
      grade: isNatalPresent ? "high" : carriedByMd ? "moderate" : "conditional",
      probability: isNatalPresent
        ? "High (Direct Conversion)"
        : carriedByMd ? "Moderate (Carried by the Mahadasha significator)" : "Conditional (Remedy-Dependent)",
      clinicalNote: isNatalPresent
        ? "Natural window for conversion. Minimal external effort required."
        : carriedByMd
          ? "Results arrive, usually a beat later than the window opens — the Mahadasha significator carries them."
          : "Opportunity arrives with delays. Requires environmental Vastu activation in the active sector to manifest."
    };
  }

  /* ---------------- Practitioner Clinical Cockpit ----------------
     One printable A4 page a certified practitioner can work from during a
     30-minute consultation, instead of flipping through 40+ report pages.
     It consolidates identity, both grids, the live Dasha stack (judged by
     Sambhandha), the annual transit, the triaged prescription and the graded
     event windows. It computes nothing new — every value is read from the
     same engines the full report uses, so the two can never disagree. */
  function practitionerCockpit(p, refDate) {
    const db = getActiveDB();
    const lang = getLang();
    const dl = dashaTimeline(p, refDate);
    const cur = dl.current;
    const nowMs = (refDate ? new Date(refDate) : new Date()).getTime();
    const dashaDB = db.dasha || (window.DB && window.DB.dasha) || {};
    const planetOf = (n) => String((db.numbers[n] || {}).planet || "").split(" ")[0];
    const sambandha = getDashaRelationship(cur.md.n, cur.ad.n, p.driver);
    const triage = remedyTriage(p, dl, refDate);
    const countsOf = (counts) => Object.keys(counts || {}).map(Number).sort((a, b) => a - b);

    const loShuExcess = countsOf(p.loShuCounts)
      .filter((n) => (p.loShuCounts[n] || 0) >= 2)
      .map((n) => ({ n, count: p.loShuCounts[n] }))
      .sort((a, b) => b.count - a.count || a.n - b.n);
    // "Strong" in the Vedic birth grid means a repeated indicator (2+), which
    // is what a practitioner reads as a dominant energy; if nothing repeats we
    // fall back to whatever is simply present.
    const vedicPresent = countsOf(p.vedicCounts).filter((n) => (p.vedicCounts[n] || 0) > 0);
    const vedicRepeated = vedicPresent.filter((n) => (p.vedicCounts[n] || 0) >= 2);
    const vedicStrong = (vedicRepeated.length ? vedicRepeated : vedicPresent)
      .slice()
      .sort((a, b) => (p.vedicCounts[b] - p.vedicCounts[a]) || a - b);

    const astro = p.astro && p.astro.ok ? p.astro : null;
    const lagna = astro && astro.tier === "full" && astro.lagna ? `${astro.lagna.sign} ${astro.lagna.glyph}` : "";
    const place = astro && astro.place ? astro.place : null;
    const coords = place ? `${Math.abs(place.lat).toFixed(1)}°${place.lat >= 0 ? "N" : "S"}, ${Math.abs(place.lon).toFixed(1)}°${place.lon >= 0 ? "E" : "W"}` : "";

    // Graded event windows: nearest upcoming window per life event, never
    // scrubbed when a significator is natally absent — only qualified.
    const windows = (dl.events || []).map((e) => {
      const w = (e.future || []).find((x) => x.endMs > nowMs) || null;
      if (!w) return { key: e.key, label: loc(e.def.label, lang), icon: e.def.icon || "★", window: null, bandClosed: e.bandClosed };
      const significators = (e.def.primary || []).concat(e.def.support || []);
      const qualified = qualifyEventWindow(significators, p.vedicCounts, [w.mdN, w.adN]) || {};
      return {
        key: e.key, label: loc(e.def.label, lang), icon: e.def.icon || "★",
        bandClosed: e.bandClosed,
        window: {
          mdN: w.mdN, adN: w.adN, startMs: w.startMs, endMs: w.endMs,
          fromAge: w.fromAge, toAge: w.toAge, active: w.active, beyondBand: !!w.beyondBand,
          grade: qualified.grade || (w.conversion && w.conversion.grade) || "conditional",
          probability: qualified.probability || "",
          natalStatus: qualified.natalStatus || "",
          // Strict grid tagging: the cockpit passes p.vedicCounts into
          // qualifyEventWindow, so the grade is Vedic-grid-derived — say so.
          grid: NATAL_CONVERSION_GRID,
          clinicalNote: qualified.clinicalNote || ""
        }
      };
    }).sort((a, b) => {
      if (!a.window) return 1;
      if (!b.window) return -1;
      return a.window.startMs - b.window.startMs;
    });

    const adZone = dashaDB[cur.ad.n] || {};
    const mdZone = dashaDB[cur.md.n] || {};

    return {
      generatedMs: nowMs,
      header: {
        name: p.name,
        dob: `${String(p.day).padStart(2, "0")}-${String(p.month).padStart(2, "0")}-${p.year}`,
        birthTime: p.birthTimeDisplay || (p.birthTime ? formatBirthTime(p.birthTime) : ""),
        place: p.birthPlace || "",
        coords, lagna,
        sun: astro && astro.sun ? `${astro.sun.sign} ${astro.sun.glyph}` : p.zodiac || "",
        nakshatra: astro && astro.tier === "full" && astro.moon ? `${astro.moon.nakshatra.name} p${astro.moon.nakshatra.pada}` : ""
      },
      core: {
        driver: p.driver, conductor: p.conductor,
        driverPlanet: planetOf(p.driver), conductorPlanet: planetOf(p.conductor),
        nameCompound: p.nameCompound, nameNumber: p.nameNum,
        ageYears: p.ageYears,
        loShuMissing: p.loShuMissing, loShuExcess,
        vedicMissing: p.vedicMissing, vedicStrong,
        kua: p.kua || null
      },
      timing: {
        md: { n: cur.md.n, planet: planetOf(cur.md.n), startMs: cur.md.startMs, endMs: cur.md.endMs, fromAge: cur.md.fromAge, toAge: cur.md.toAge },
        ad: { n: cur.ad.n, planet: planetOf(cur.ad.n), startMs: cur.ad.startMs, endMs: cur.ad.endMs, progress: cur.adProgress },
        pd: { n: cur.pd.n, planet: planetOf(cur.pd.n), endMs: cur.pd.endMs, daysLeft: cur.pdDaysLeft },
        nextAd: cur.nextAd ? { n: cur.nextAd.n, planet: planetOf(cur.nextAd.n), startMs: cur.nextAd.startMs } : null,
        personalYear: { n: cur.personalYear, planet: planetOf(cur.personalYear), year: cur.year },
        sambandha
      },
      vastu: {
        primary: { n: cur.ad.n, zone: loc(adZone.zone, lang), remedy: loc(adZone.zoneRemedy, lang) },
        anchor: { n: cur.md.n, zone: loc(mdZone.zone, lang), remedy: loc(mdZone.zoneRemedy, lang) }
      },
      triage,
      windows
    };
  }

  function renderPractitionerCockpit(p, refDate) {
    const c = practitionerCockpit(p, refDate);
    const lang = getLang();
    const w = {
      en: {
        title: "Practitioner Clinical Cockpit", sub: "One-page consultation sheet — everything below is computed on this device from the same engines as the full report.",
        core: "Core", loshu: "Lo Shu (Foundation)", vedic: "Vedic (Ank Jyotish)", name: "Name", legalName: "Legal",
        missing: "Missing", excess: "Excess", absent: "Absent", strong: "Strong",
        timing: "Current timing", macro: "Macro", current: "Current", micro: "Micro", transit: "Transit",
        triage: "Clinical triage", conflict: "Active conflict", spatial: "Urgent spatial Rx", japa: "Single japa target",
        latent: "Tier 2 · latent leaks (hold)", unlocks: "Activates", withheld: "Deliberately withheld this cycle",
        windows: "Graded event windows", event: "Event", window: "Window", lords: "MD × AD", probability: "Conversion",
        notes: "Consultation notes", print: "Print this page", ends: "ends", elapsed: "elapsed", none: "None",
        disclaimer: "Traditional guidance for reflection and planning — not medical, legal or financial advice. Generated locally; no birth data left this device.",
        holdLine: "Held on environmental cues only — no japa, no fast, no gemstone until activation."
      },
      hi: {
        title: "प्रैक्टिशनर क्लिनिकल कॉकपिट", sub: "एक-पृष्ठ परामर्श शीट — सभी मान इसी डिवाइस पर, पूरी रिपोर्ट के समान इंजनों से गणना किए गए हैं।",
        core: "मुख्य", loshu: "लो शू (Foundation)", vedic: "वैदिक (अंक ज्योतिष)", name: "नाम", legalName: "कानूनी",
        missing: "अनुपस्थित", excess: "अधिक", absent: "अनुपस्थित", strong: "प्रबल",
        timing: "वर्तमान समय-चक्र", macro: "महा", current: "वर्तमान", micro: "सूक्ष्म", transit: "ट्रांज़िट",
        triage: "क्लिनिकल ट्राइएज", conflict: "सक्रिय टकराव", spatial: "तात्कालिक वास्तु उपाय", japa: "एकमात्र जप लक्ष्य",
        latent: "टियर २ · प्रतीक्षित रिसाव (रोकें)", unlocks: "सक्रिय होगा", withheld: "इस चक्र में जानबूझकर रोके गए",
        windows: "श्रेणीबद्ध घटना-विंडो", event: "घटना", window: "विंडो", lords: "महा × अंतर", probability: "फलन-संभावना",
        notes: "परामर्श नोट्स", print: "यह पृष्ठ प्रिंट करें", ends: "तक", elapsed: "पूर्ण", none: "कोई नहीं",
        disclaimer: "यह पारंपरिक मार्गदर्शन है — चिकित्सा, कानूनी या वित्तीय सलाह नहीं। सब कुछ स्थानीय रूप से बना; जन्म-डेटा कहीं नहीं भेजा गया।",
        holdLine: "केवल वातावरण-संकेत — सक्रिय होने तक न जप, न व्रत, न रत्न।"
      },
      gu: {
        title: "પ્રેક્ટિશનર ક્લિનિકલ કોકપિટ", sub: "એક-પાનાની પરામર્શ શીટ — બધા મૂલ્યો આ જ ડિવાઇસ પર, પૂરા રિપોર્ટના સમાન એન્જિનથી ગણાયા છે.",
        core: "મુખ્ય", loshu: "લો શુ (Foundation)", vedic: "વૈદિક (અંક જ્યોતિષ)", name: "નામ", legalName: "કાનૂની",
        missing: "ખૂટતા", excess: "વધુ", absent: "ગેરહાજર", strong: "પ્રબળ",
        timing: "વર્તમાન સમય-ચક્ર", macro: "મહા", current: "વર્તમાન", micro: "સૂક્ષ્મ", transit: "ટ્રાન્ઝિટ",
        triage: "ક્લિનિકલ ટ્રાયએજ", conflict: "સક્રિય ટકરાવ", spatial: "તાત્કાલિક વાસ્તુ ઉપાય", japa: "એકમાત્ર જાપ લક્ષ્ય",
        latent: "ટિયર ૨ · પ્રતીક્ષિત લીક (રોકો)", unlocks: "સક્રિય થશે", withheld: "આ ચક્રમાં ઇરાદાપૂર્વક રોકેલા",
        windows: "શ્રેણીબદ્ધ ઘટના-વિન્ડો", event: "ઘટના", window: "વિન્ડો", lords: "મહા × અંતર", probability: "ફલન-સંભાવના",
        notes: "પરામર્શ નોંધ", print: "આ પાનું પ્રિન્ટ કરો", ends: "સુધી", elapsed: "પૂર્ણ", none: "કોઈ નહીં",
        disclaimer: "આ પરંપરાગત માર્ગદર્શન છે — તબીબી, કાનૂની કે નાણાકીય સલાહ નથી. બધું સ્થાનિક રીતે બન્યું; જન્મ-ડેટા ક્યાંય મોકલાયો નથી.",
        holdLine: "ફક્ત પર્યાવરણીય સંકેત — સક્રિય થાય ત્યાં સુધી ન જાપ, ન ઉપવાસ, ન રત્ન."
      }
    }[lang] || null;
    const L = w || {};
    const t1 = c.triage.tier1;
    const numList = (arr) => (arr && arr.length ? arr.join(", ") : "—");
    const gradeBadge = (grade) => {
      const cls = grade === "high" ? "good" : grade === "moderate" ? "info" : "warn";
      const label = grade === "high" ? "High · direct" : grade === "moderate" ? "Moderate · carried" : "Conditional · remedy-led";
      return `<span class="badge ${cls}" data-cockpit-grade="${grade}">${label}</span>`;
    };
    const identity = [
      `<strong>${esc(c.header.name)}</strong>`,
      `DOB ${esc(c.header.dob)}${c.header.birthTime ? ` · ${esc(c.header.birthTime)}` : ""}`,
      c.header.place ? `${esc(c.header.place)}${c.header.coords ? ` (${esc(c.header.coords)})` : ""}` : "",
      c.header.lagna ? `Lagna ${esc(c.header.lagna)}` : `Sun ${esc(c.header.sun)}`,
      c.header.nakshatra ? `Nak ${esc(c.header.nakshatra)}` : ""
    ].filter(Boolean).join(" &nbsp;|&nbsp; ");

    const timingRows = [
      `<li><span class="cockpit-tag">${esc(L.macro)}</span> ${esc(c.timing.md.planet)} MD (${c.timing.md.n}) · ${prettyDate(c.timing.md.startMs)} → ${prettyDate(c.timing.md.endMs)} (ages ${c.timing.md.fromAge}–${c.timing.md.toAge})</li>`,
      `<li data-cockpit-ad-relation="${c.timing.sambandha.relation}"><span class="cockpit-tag">${esc(L.current)}</span> ${esc(c.timing.ad.planet)} AD (${c.timing.ad.n}) · ${prettyDate(c.timing.ad.startMs)} → ${prettyDate(c.timing.ad.endMs)} · ${c.timing.ad.progress}% ${esc(L.elapsed)} <span class="badge ${c.timing.sambandha.tone} ${c.timing.sambandha.cssClass}">${esc(c.timing.sambandha.status)}${c.timing.sambandha.grahan ? " · Grahan Yoga" : ""}</span></li>`,
      `<li><span class="cockpit-tag">${esc(L.micro)}</span> ${esc(c.timing.pd.planet)} PD (${c.timing.pd.n}) · ${esc(L.ends)} ${prettyDate(c.timing.pd.endMs)} (${c.timing.pd.daysLeft}d)${c.timing.nextAd ? ` · next AD ${esc(c.timing.nextAd.planet)} (${c.timing.nextAd.n}) ${prettyDate(c.timing.nextAd.startMs)}` : ""}</li>`,
      `<li><span class="cockpit-tag">${esc(L.transit)}</span> Personal Year ${c.timing.personalYear.n} (${esc(c.timing.personalYear.planet)}) · ${c.timing.personalYear.year}</li>`
    ].join("");

    const conflictLine = c.timing.sambandha.relation === "enemy"
      ? `${esc(c.timing.md.planet)} (${c.timing.md.n}) vs ${esc(c.timing.ad.planet)} (${c.timing.ad.n})${c.timing.sambandha.grahan ? " — Grahan Yoga" : ""} in the ${esc(c.vastu.primary.zone)} sector. ${esc(c.timing.sambandha.guidance)}`
      : `${esc(c.timing.md.planet)} (${c.timing.md.n}) × ${esc(c.timing.ad.planet)} (${c.timing.ad.n}) — ${esc(c.timing.sambandha.status)}. ${esc(c.timing.sambandha.guidance)}`;

    const japaLine = t1.mode === "acute"
      ? `<strong>${esc(t1.mantra)}</strong>${t1.mantraDev ? ` <span class="cockpit-dev">${esc(t1.mantraDev)}</span>` : ""} — ${esc(t1.japa)} · ${esc(t1.planet)} (${t1.n})${t1.day ? ` · one weekly discipline: ${esc(t1.day)}` : ""}`
      : t1.mode === "environmental"
        ? `${esc(t1.japa)} — work the ${esc(t1.zone)} sector instead.`
        : `<strong>${esc(t1.mantra)}</strong> — ${esc(t1.japa)} (maintenance).`;

    const tier2Rows = c.triage.tier2.length
      ? c.triage.tier2.map((item) => `<li data-cockpit-tier2="${item.n}"><strong>${item.n} · ${esc(item.planet)}</strong> — ${esc(item.colour)} accents, ${esc(item.cue)}. <span class="cockpit-hold">${esc(item.hold)}</span> <span class="cockpit-unlock">${esc(L.unlocks)}: ${esc(item.unlockLabel)}</span></li>`).join("")
      : `<li>${esc(L.none)} — the acute target is the only remedy load this cycle.</li>`;

    const windowRows = c.windows.map((ev) => {
      if (!ev.window) return `<tr data-cockpit-window="${esc(ev.key)}"><td>${ev.icon} ${esc(ev.label)}</td><td colspan="3">Watch the next Dasha transition — no significator window inside the scan horizon.</td></tr>`;
      return `<tr data-cockpit-window="${esc(ev.key)}" data-grade="${ev.window.grade}" data-natal-grid="${esc(ev.window.grid || NATAL_CONVERSION_GRID)}">
        <td>${ev.icon} ${esc(ev.label)}</td>
        <td>${prettyDate(ev.window.startMs)} → ${prettyDate(ev.window.endMs)}<div class="cockpit-mini">ages ${ev.window.fromAge}–${ev.window.toAge}${ev.window.beyondBand ? " · late window" : ""}</div></td>
        <td>${ev.window.mdN} × ${ev.window.adN}</td>
        <td>${gradeBadge(ev.window.grade)}<div class="cockpit-mini">${esc(ev.window.clinicalNote)}</div></td>
      </tr>`;
    }).join("");

    return `<section class="rsection cockpit-section" id="practitioner-cockpit" data-authority="clinical-cockpit">
      <div class="cockpit-toolbar">
        <button id="printCockpitBtn" class="btn btn-primary btn-32" type="button">${esc(L.print)}</button>
        <span class="cockpit-stamp">${esc(L.title)} · ${prettyDate(c.generatedMs)}</span>
      </div>
      <div class="cockpit-sheet" data-cockpit-sheet="true">
        <header class="cockpit-head">
          <div class="cockpit-sheet-title" data-cockpit-print-title="true">${esc(L.title)} · ${prettyDate(c.generatedMs)}</div>
          <div class="cockpit-identity">${identity}</div>
          <div class="cockpit-kicker">${esc(L.sub)}</div>
        </header>
        <div class="cockpit-grid three">
          <div class="cockpit-cell"><div class="cockpit-label">${esc(L.core)}</div>
            <div class="cockpit-fact">D-${c.core.driver} (${esc(c.core.driverPlanet)}) · C-${c.core.conductor} (${esc(c.core.conductorPlanet)})${Number.isFinite(c.core.ageYears) ? ` · ${lang === "hi" ? "आयु" : lang === "gu" ? "ઉંમર" : "age"} ${c.core.ageYears}` : ""}</div>
            <div class="cockpit-fact">${esc(L.name)}: ${c.core.nameCompound} → ${c.core.nameNumber}${c.core.kua ? ` · Kua ${c.core.kua}` : ""}</div>
            ${p.nameDual ? `<div class="cockpit-fact" data-cockpit-legal-total="${p.legalNameCompound}">${esc(L.legalName || "Legal")}: ${p.legalNameCompound} → ${p.legalNameNum}${p.patronymicInitials.length ? ` · ${esc(p.patronymicInitials.join("/"))}` : ""}</div>` : ""}
            ${isMinorProfile(p) ? `<div class="cockpit-fact" data-cockpit-guardrail="under-18">⚠ ${lang === "hi" ? "18 से कम — भारी रत्न स्थगित; खंड 4A तत्व आधार + हल्के पत्थर (Amethyst/Citrine)" : lang === "gu" ? "18 થી ઓછી — ભારે રત્ન મુલ્તવી; વિભાગ 4A તત્વ આધાર + હળવા પથ્થર (Amethyst/Citrine)" : "Under 18 — heavy gems deferred; 4A Tattva anchors + mild stones (Amethyst/Citrine)"}</div>` : ""}
            ${solarOverload(p) && pittaInBaseline(p) ? `<div class="cockpit-fact" data-cockpit-guardrail="solar">☀ ${lang === "hi" ? `सूर्य 1×${solarLoadOf(p)} + पित्त — अर्घ्य लघु रखें; चंद्र भेदन/शाम भूमि-संपर्क से ठंडा करें` : lang === "gu" ? `સૂર્ય 1×${solarLoadOf(p)} + પિત્ત — અર્ઘ્ય ટૂંકો રાખો; ચંદ્ર ભેદન/સાંજ ભૂમિ-સંપર્કથી ઠંડક આપો` : `Sun 1×${solarLoadOf(p)} + Pitta — keep arghya brief; cool via Chandra Bhedana / evening grounding`}</div>` : ""}
            ${moonColdCockpitFactHtml(p, lang)}
            ${doshaContraCockpitFactHtml(p, lang)}
          </div>
          <div class="cockpit-cell"><div class="cockpit-label">${esc(L.loshu)}</div>
            <div class="cockpit-fact" data-cockpit-loshu-missing="${c.core.loShuMissing.join(",")}">${esc(L.missing)}: <strong>${numList(c.core.loShuMissing)}</strong></div>
            <div class="cockpit-fact">${esc(L.excess)}: ${c.core.loShuExcess.length ? c.core.loShuExcess.map((x) => `${x.n} (${x.count}×)`).join(", ") : "—"}</div>
          </div>
          <div class="cockpit-cell"><div class="cockpit-label">${esc(L.vedic)}</div>
            <div class="cockpit-fact">${esc(L.absent)}: <strong>${numList(c.core.vedicMissing)}</strong></div>
            <div class="cockpit-fact">${esc(L.strong)}: ${numList(c.core.vedicStrong)}</div>
          </div>
        </div>
        <div class="cockpit-block" data-cockpit-block="timing">
          <div class="cockpit-label">${esc(L.timing)}</div>
          <ul class="cockpit-list">${timingRows}</ul>
        </div>
        <div class="cockpit-block cockpit-triage" data-cockpit-block="triage" data-tier1-mode="${esc(t1.mode)}" data-tier1-number="${t1.n}">
          <div class="cockpit-label">${esc(L.triage)}</div>
          <ol class="cockpit-list numbered">
            <li><span class="cockpit-tag warn">${esc(L.conflict)}</span> ${conflictLine}</li>
            <li><span class="cockpit-tag">${esc(L.spatial)}</span> ${esc(c.vastu.primary.zone)} (${esc(c.timing.ad.planet)} AD) — ${esc(c.vastu.primary.remedy)} ${esc(c.vastu.anchor.zone)} (${esc(c.timing.md.planet)} MD) — ${esc(c.vastu.anchor.remedy)}</li>
            <li data-cockpit-japa="${t1.mode === "acute" ? t1.n : ""}"><span class="cockpit-tag">${esc(L.japa)}</span> ${japaLine}</li>
          </ol>
          <div class="cockpit-why">${esc(t1.reasons.join(" · "))}</div>
        </div>
        <div class="cockpit-block" data-cockpit-block="tier2">
          <div class="cockpit-label">${esc(L.latent)}</div>
          <ul class="cockpit-list">${tier2Rows}</ul>
          ${c.triage.withheld.length ? `<div class="cockpit-why"><strong>${esc(L.withheld)}:</strong> ${c.triage.withheld.map(esc).join(" · ")}</div>` : ""}
        </div>
        <div class="cockpit-block" data-cockpit-block="windows">
          <div class="cockpit-label">${esc(L.windows)} <span class="cockpit-mini" data-natal-grid="${NATAL_CONVERSION_GRID}">${lang === "hi" ? "(उपस्थिति वैदिक अंक-कुंडली ग्रिड से जांची गई है)" : lang === "gu" ? "(હાજરી વૈદિક અંક-કુંડળી ગ્રિડ પર ચકાસાયેલ છે)" : "(presence graded against the Vedic Ank Kundali grid)"}</span></div>
          <table class="cockpit-table"><tr><th>${esc(L.event)}</th><th>${esc(L.window)}</th><th>${esc(L.lords)}</th><th>${esc(L.probability)}</th></tr>${windowRows}</table>
        </div>
        <footer class="cockpit-foot">
          <div class="cockpit-notes"><span class="cockpit-label">${esc(L.notes)}</span><span class="cockpit-rule"></span><span class="cockpit-rule"></span></div>
          <div class="cockpit-disclaimer">${esc(L.disclaimer)}</div>
        </footer>
      </div>
    </section>`;
  }

  /* Staged prescription card for the 40-Day Plan. The full remedy library
     stays in the report; this card decides what the client is asked to DO
     this cycle, so the plan stops reading like a Christmas tree. */
  function renderTriageCard(p, triage) {
    const lang = getLang();
    const tr = triage || remedyTriage(p);
    const t1 = tr.tier1;
    const head = lang === "hi" ? "उपाय ट्राइएज — इस चक्र में केवल यही करें" : lang === "gu" ? "ઉપાય ટ્રાયએજ — આ ચક્રમાં ફક્ત આટલું જ કરો" : "Remedy triage — do only this much this cycle";
    const intro = lang === "hi"
      ? "एक साथ हर अनुपस्थित अंक का उपाय न करें। नीचे दी गई पूरी सूची reference है; अभी केवल Tier 1 लक्ष्य साधें।"
      : lang === "gu"
        ? "એકસાથે દરેક ખૂટતા અંકનો ઉપાય ન કરો. નીચેની આખી યાદી reference છે; અત્યારે ફક્ત Tier 1 લક્ષ્ય સાધો."
        : "Do not run every missing number at once. Everything below stays as reference; this cycle you work one acute target — the number that is actually live in your Dasha stack or Personal Year.";
    const tier1Line = t1.mode === "acute"
      ? `<strong>${t1.n} · ${esc(t1.planet)}</strong> — <span class="mantra">${esc(t1.mantra)}</span> ${esc(t1.japa)}${t1.day ? ` · ${lang === "hi" ? "साप्ताहिक अनुशासन" : lang === "gu" ? "સાપ્તાહિક શિસ્ત" : "one weekly discipline"}: ${esc(t1.day)}` : ""} · ${esc(t1.colour)} · ${esc(t1.zone)}`
      : t1.mode === "environmental"
        ? `${esc(t1.japa)} — ${esc(t1.zone)}: ${esc(t1.zoneRemedy)}`
        : `<strong>${t1.n} · ${esc(t1.planet)}</strong> — ${esc(t1.japa)}`;
    // Latent Moon (Tier 2 · hold) prescribes no japa yet, but its future
    // activation must run warm — one short suffix, no extra triage row.
    const moonLatentSuffix = (item) => {
      if (item.n !== 2 || !moonColdSensitivity(p)) return "";
      return lang === "hi"
        ? " सक्रिय होने पर उष्ण रूप में चलाएं — शिव जप, गुनगुना चांदी-जल, नाड़ी शोधन।"
        : lang === "gu"
          ? " સક્રિય થાય ત્યારે ઉષ્ણ રૂપે ચલાવો — શિવ જાપ, ગુનગુનું ચાંદી-જળ, નાડી શોધન."
          : " When it activates, run it warm — Shiva japa, lukewarm silver water, Nadi Shodhana.";
    };
    const tier2Rows = tr.tier2.length
      ? tr.tier2.map((item) => `<div class="kit-row" data-triage-tier="2" data-triage-number="${item.n}"><div class="kit-ico"><strong>${item.n}</strong></div><div class="kit-body"><div class="kit-label">${esc(item.planet)} — ${lang === "hi" ? "प्रतीक्षित" : lang === "gu" ? "પ્રતીક્ષિત" : "latent"}</div><div class="kit-value">${esc(item.colour)} · ${esc(item.cue)}</div><div class="card-sub">${esc(item.hold)} ${lang === "hi" ? "सक्रिय होगा" : lang === "gu" ? "સક્રિય થશે" : "Activates"}: ${esc(item.unlockLabel)}${esc(moonLatentSuffix(item))}${esc(doshaContraLatentSuffix(item, p, lang))}</div></div></div>`).join("")
      : `<div class="kit-row"><div class="kit-ico">✓</div><div class="kit-body"><div class="kit-value">${lang === "hi" ? "कोई प्रतीक्षित लक्ष्य नहीं — केवल एक ही उपाय-भार है।" : lang === "gu" ? "કોઈ પ્રતીક્ષિત લક્ષ્ય નથી — ફક્ત એક જ ઉપાય-ભાર છે." : "No latent targets — the acute target is the only remedy load."}</div></div></div>`;
    // An acute/maintenance Tier-1 Moon target prescribes live japa, so the
    // Moon-cold guardrail rides the triage card itself. Environmental Tier-1
    // holds all japa and needs no mantra guardrail.
    const moonTier1Guardrail = (t1.n === 2 && t1.mode !== "environmental") ? moonColdKitGuardrailHtml(t1.n, p, lang) : "";
    // Other acute/maintenance Tier-1 targets ride the generic Dosha x planet
    // guardrail; environmental Tier-1 holds all japa and needs no mantra flag.
    const doshaTier1Guardrail = (t1.n !== 2 && t1.mode !== "environmental") ? doshaContraKitGuardrailHtml(t1.n, p, lang) : "";
    return `<div class="card triage-card" id="remedy-triage" data-remedy-authority="lo-shu" data-tier1-mode="${esc(t1.mode)}" data-tier1-number="${t1.n}">
      <div class="goal-head"><div class="card-title">${esc(head)}</div><span class="badge good">${lang === "hi" ? "टियर १ · अभी" : lang === "gu" ? "ટિયર ૧ · હમણાં" : "Tier 1 · now"}</span></div>
      <div class="card-sub">${esc(intro)}</div>
      <div class="kit">
        <div class="kit-row" data-triage-tier="1"><div class="kit-ico">🎯</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "टियर १ — तीव्र लक्ष्य" : lang === "gu" ? "ટિયર ૧ — તીવ્ર લક્ષ્ય" : "Tier 1 — acute target"}</div><div class="kit-value">${tier1Line}</div><div class="card-sub">${esc(t1.reasons.join(" · "))}</div></div></div>
        ${moonTier1Guardrail}
        ${doshaTier1Guardrail}
        ${tier2Rows}
      </div>
      ${tr.withheld.length ? `<div class="judge-note"><strong>${lang === "hi" ? "जानबूझकर रोका गया:" : lang === "gu" ? "ઇરાદાપૂર્વક રોકેલું:" : "Deliberately withheld this cycle:"}</strong> ${tr.withheld.map(esc).join(" · ")}</div>` : ""}
    </div>`;
  }

  function plainText(html) {
    return String(html || "")
      .replace(/<[^>]+>/g, "")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, " ")
      .trim();
  }

  function firstNameOf(name) {
    return String(name || "Friend").trim().split(/\s+/)[0] || "Friend";
  }

  /* Foundation summary is deliberately descriptive. Dasha, active Vastu and
     dated event windows are linked out to Timeline instead of being inferred
     from a Lo Shu grid or a static room scan. */
  function northstarSummary(p, triagePre) {
    const db = getActiveDB();
    const lang = getLang();
    /* The summary must point at the same practice target as the 40-day plan:
       when the triage marks a missing number acute (live in the Dasha stack),
       that number — not the raw first gap — is move #1. */
    const resolved = resolvePracticeTargets(p, triagePre);
    const targets = resolved.targets;
    const primary = resolved.primary;
    const acute = resolved.acute;
    const primaryInfo = db.numbers[primary];
    const goalNames = p.goals && p.goals.length ? p.goals : [lang === "hi" ? "समग्र विकास" : lang === "gu" ? "સર્વાંગી વિકાસ" : "overall growth"];
    const missingText = targets.missing.length ? targets.missing.join(", ") : "";
    const repeatedText = targets.repeated.length ? targets.repeated.join(", ") : "";
    let headline, story, moves, checks, cards;

    if (lang === "hi") {
      headline = `${esc(firstNameOf(p.name))}, आपका Foundation लो शू संकेतों के साथ ${esc(goalNames.join(" + "))} के लिए एक व्यावहारिक, निरंतर दिशा देता है।`;
      story = `आपका मूलांक ${p.driver} (${esc(db.numbers[p.driver].planet)}) आपकी दैनिक अभिव्यक्ति और भाग्यांक ${p.conductor} (${esc(db.numbers[p.conductor].planet)}) दीर्घकालिक दिशा बताते हैं। आपके remedy और lifestyle targets, हालांकि, केवल लो शू जन्म-ग्रिड से आते हैं: ${targets.missing.length ? `अनुपस्थित अंक <strong>${missingText}</strong>` : targets.repeated.length ? `दोहराए अंक <strong>${repeatedText}</strong> की channeling` : "संतुलित grid की maintenance"}।`;
      moves = [
        { title: acute ? `अभी का तीव्र gap — अंक ${primary} (Tier 1 · सक्रिय)` : targets.missing.length ? `लो शू का पहला gap — अंक ${primary}` : `लो शू की मुख्य ऊर्जा — अंक ${primary}`, detail: resolved.holdJapa ? `${esc(primaryInfo.planet)} के colour, affirmation और habit को 40-दिन के अभ्यास में रखें — इस चक्र जप होल्ड पर है (Remedy Triage देखें)।` : `${esc(primaryInfo.planet)} के mantra, affirmation, crystal/Rudraksha और habit को 40-दिन के अभ्यास में रखें।` },
        { title: targets.repeated.length ? `दोहराई ऊर्जा को दिशा दें — ${repeatedText}` : "जन्म, नाम और संयुक्त grid देखें", detail: targets.repeated.length ? "उसी अंक को और बढ़ाने के बजाय उसकी क्षमता को अनुशासित काम, सेवा या कला में लगाएं।" : "तीनों लो शू grids के coordinates और planes/arrows से अपने व्यवहारिक pattern पहचानें।" },
        { title: "अगली समय-सीमा Timeline में देखें", detail: "महादशा, अंतर्दशा, जीवन-घटना windows और Active Vastu Zone केवल Timeline · Ank Jyotish Dasha में देखें।" }
      ];
      checks = [
        "<strong>उपाय-अधिकार:</strong> missing/repeated remedy, crystal, Rudraksha, affirmation और habit केवल लो शू से आते हैं।",
        "<strong>मूलांक / भाग्यांक:</strong> आयुर्वेदिक baseline, इष्ट देवता और power days के अलग स्रोत हैं।",
        "<strong>समय और वास्तु:</strong> तारीखें, event windows और सक्रिय वास्तु क्षेत्र केवल दशा से आते हैं — Kua/Feng Shui अलग रहता है।"
      ];
      cards = [
        { label: "Foundation focus", value: `लो शू ${primary}`, note: acute ? `पहले अंक ${primary} — वर्तमान दशा-क्रम में सक्रिय (Tier 1); बाकी अंक टियर २ / होल्ड पर रहते हैं।` : targets.missing.length ? `पहले अनुपस्थित अंक ${missingText} को क्रम से साधें।` : targets.repeated.length ? `दोहराए अंक ${repeatedText} को अधिक fuel देने के बजाय channel करें।` : "संतुलित grid को सरल daily habit से बनाए रखें।" },
        { label: "आपके लक्ष्य", value: esc(goalNames.join(", ")), note: "यह दिशा तय करते हैं; remedy target केवल लो शू signal से आता है।" },
        { label: "Driver / Conductor", value: `${p.driver} / ${p.conductor}`, note: "व्यक्तित्व baseline, guardian deity, Ayurvedic baseline और power days के लिए।" },
        { label: "Timeline cue", value: "Ank Jyotish Dasha", note: "Active Vastu Zone, current/next period dates और life-event windows के लिए Timeline खोलें।" }
      ];
    } else if (lang === "gu") {
      headline = `${esc(firstNameOf(p.name))}, તમારું Foundation લો શુ સંકેતો સાથે ${esc(goalNames.join(" + "))} માટે વ્યવહારુ અને સતત દિશા આપે છે.`;
      story = `તમારો મૂળાંક ${p.driver} (${esc(db.numbers[p.driver].planet)}) દૈનિક અભિવ્યક્તિ અને ભાગ્યાંક ${p.conductor} (${esc(db.numbers[p.conductor].planet)}) લાંબી દિશા બતાવે છે. પરંતુ તમારા remedy અને lifestyle targets ફક્ત લો શુ જન્મ-ગ્રિડમાંથી આવે છે: ${targets.missing.length ? `ખૂટતા અંક <strong>${missingText}</strong>` : targets.repeated.length ? `પુનરાવર્તિત અંક <strong>${repeatedText}</strong> ની channeling` : "સંતુલિત grid ની maintenance"}.`;
      moves = [
        { title: acute ? `હમણાંનો તીવ્ર gap — અંક ${primary} (Tier 1 · સક્રિય)` : targets.missing.length ? `લો શુનો પ્રથમ gap — અંક ${primary}` : `લો શુની મુખ્ય ઊર્જા — અંક ${primary}`, detail: resolved.holdJapa ? `${esc(primaryInfo.planet)} ના colour, affirmation અને habit ૪૦-દિવસના અભ્યાસમાં રાખો — આ ચક્રે જાપ હોલ્ડ પર છે (Remedy Triage જુઓ).` : `${esc(primaryInfo.planet)} નો mantra, affirmation, crystal/Rudraksha અને habit ૪૦-દિવસના અભ્યાસમાં રાખો.` },
        { title: targets.repeated.length ? `પુનરાવર્તિત ઊર્જાને દિશા આપો — ${repeatedText}` : "જન્મ, નામ અને સંયુક્ત grid જુઓ", detail: targets.repeated.length ? "એ જ અંકને વધુ વધારવાને બદલે તેની ક્ષમતાને શિસ્તબદ્ધ કામ, સેવા કે કલામાં લગાવો." : "ત્રણેય લો શુ grids ના coordinates અને planes/arrows થી વર્તનના pattern ઓળખો." },
        { title: "આગલી સમય-રેખા Timeline માં જુઓ", detail: "મહાદશા, અંતર્દશા, જીવન-ઘટના windows અને Active Vastu Zone ફક્ત સમયરેખા · અંક-જ્યોતિષ દશામાં જુઓ." }
      ];
      checks = [
        "<strong>ઉપાય-અધિકાર:</strong> missing/repeated remedy, crystal, Rudraksha, affirmation અને habit ફક્ત લો શુમાંથી આવે છે.",
        "<strong>મૂળાંક / ભાગ્યાંક:</strong> Ayurvedic baseline, ઇષ્ટ દેવતા અને power days ના અલગ સ્ત્રોત છે.",
        "<strong>સમય અને વાસ્તુ:</strong> તારીખો, event windows અને સક્રિય વાસ્તુ ક્ષેત્ર ફક્ત દશાથી આવે છે — Kua/Feng Shui અલગ રહે છે."
      ];
      cards = [
        { label: "Foundation focus", value: `લો શુ ${primary}`, note: acute ? `પહેલાં અંક ${primary} — વર્તમાન દશા-ક્રમમાં સક્રિય (Tier 1); બાકીના અંક ટિયર ૨ / હોલ્ડ પર રહે છે.` : targets.missing.length ? `પહેલાં ખૂટતા અંક ${missingText} ને ક્રમથી સાધો.` : targets.repeated.length ? `પુનરાવર્તિત અંક ${repeatedText} ને વધુ fuel આપવાને બદલે channel કરો.` : "સંતુલિત grid ને સરળ daily habit થી જાળવો." },
        { label: "તમારા લક્ષ્યો", value: esc(goalNames.join(", ")), note: "તે દિશા નક્કી કરે છે; remedy target ફક્ત લો શુ signal પરથી આવે છે." },
        { label: "Driver / Conductor", value: `${p.driver} / ${p.conductor}`, note: "વ્યક્તિત્વ baseline, guardian deity, Ayurvedic baseline અને power days માટે." },
        { label: "Timeline cue", value: "અંક-જ્યોતિષ દશા", note: "Active Vastu Zone, current/next period dates અને life-event windows માટે Timeline ખોલો." }
      ];
    } else {
      headline = `${esc(firstNameOf(p.name))}, your Foundation turns Lo Shu signals into a practical, consistent direction for ${esc(goalNames.join(" + ").toLowerCase())}.`;
      story = `Your Driver ${p.driver} (${esc(db.numbers[p.driver].planet)}) describes day-to-day expression and Conductor ${p.conductor} (${esc(db.numbers[p.conductor].planet)}) describes longer direction. Your remedy and lifestyle targets, however, come only from the Lo Shu Birth Grid: ${targets.missing.length ? `missing number${targets.missing.length > 1 ? "s" : ""} <strong>${missingText}</strong>` : targets.repeated.length ? `channeling repeated number${targets.repeated.length > 1 ? "s" : ""} <strong>${repeatedText}</strong>` : "maintenance of a balanced grid"}.`;
      moves = [
        { title: acute ? `Acute Lo Shu gap — number ${primary} (Tier 1 · live now)` : targets.missing.length ? `First Lo Shu gap — number ${primary}` : `Primary Lo Shu energy — number ${primary}`, detail: resolved.holdJapa ? `Keep ${esc(primaryInfo.planet)}'s colour, affirmation and habit inside the 40-day practice — japa is held this cycle (see Remedy Triage).` : `Keep ${esc(primaryInfo.planet)}'s mantra, affirmation, crystal/Rudraksha and habit inside the 40-day practice.` },
        { title: targets.repeated.length ? `Channel surplus energy — ${repeatedText}` : "Read the Birth, Name and Combined grids", detail: targets.repeated.length ? "Put capacity into disciplined work, service or craft instead of feeding the same number again." : "Use the matching Lo Shu coordinates and planes/arrows to notice practical behaviour patterns." },
        { title: "Read the next time window in Timeline", detail: "Mahadasha, Antardasha, life-event windows and the Active Vastu Zone live only in Timeline · Ank Jyotish Dasha." }
      ];
      checks = [
        "<strong>Remedy authority:</strong> missing/repeated remedies, crystals, Rudraksha, affirmations and habits come only from Lo Shu.",
        "<strong>Driver / Conductor:</strong> these are the separate sources for the Ayurvedic baseline, guardian deities and power days.",
        "<strong>Timing and Vastu:</strong> dates, event windows and the active Vastu zone come only from Dasha — Kua/Feng Shui remains separate."
      ];
      cards = [
        { label: "Foundation focus", value: `Lo Shu ${primary}`, note: acute ? `Lead with ${primary} — live in the current Dasha stack (Tier 1); the other numbers stay Tier 2 / held.` : targets.missing.length ? `Work through missing number${targets.missing.length > 1 ? "s" : ""} ${missingText} in order.` : targets.repeated.length ? `Channel repeated number${targets.repeated.length > 1 ? "s" : ""} ${repeatedText}; do not add more fuel.` : "Maintain the balanced grid with one simple daily habit." },
        { label: "Your focus", value: esc(goalNames.join(", ")), note: "Goals set direction; only a Lo Shu signal sets a remedy target." },
        { label: "Driver / Conductor", value: `${p.driver} / ${p.conductor}`, note: "Personality baseline, guardian deity, Ayurvedic baseline and power days." },
        { label: "Timeline cue", value: "Ank Jyotish Dasha", note: "Open Timeline for the Active Vastu Zone, current/next period dates and life-event windows." }
      ];
    }
    /* Practice depth is a client choice, not a prescription: the card reports
       what the client selected so the summary and the 40-day plan agree. It
       never re-orders the remedy target above. */
    const summaryScale = sadhanaScaleOf(p);
    const summaryScaleCopy = sadhanaI18n(summaryScale.key);
    cards.push({
      label: t("sadhanaSummaryLabel", "Practice depth"),
      value: `${t(summaryScaleCopy.title, "Practitioner / Sadhak")} · ${localNumber(summaryScale.japa, lang)}×`,
      note: t(summaryScaleCopy.desc, "")
    });
    return { headline, story, cards, checks, moves };
  }

  /* ---- Layman Implementation Framework (2026-09 audit) --------------------
     A layman does not remember planetary planes; they remember what to do on
     Tuesday morning. These two builders turn the engines above into a
     plug-and-play 7-Day Micro-Routine table and explicit DO / DO-NOT cards,
     rendered at the very front of the report (Layer 1). Every row is derived
     from data already computed elsewhere — nothing new is invented, and the
     same clinical guardrails (solar overload, Moon-cold, under-18) mute
     conflicting rows instead of printing them side by side. */
  /* ---- Client-text hygiene (2026-09 polish) -------------------------------
     A printed cell composes three data sentences (colour, lifestyle, charity)
     and a label. Line-wrapping a PDF can leave a dangling hyphen in front of
     punctuation ("clutterfree-;"), which reads as a typo in a paid dossier.
     Every client-facing cell therefore passes one tidy pass: the known
     hyphenated compounds are repaired, a hyphen touching punctuation is
     dropped, spaced or doubled punctuation and repeated spaces collapse. */
  const TEXT_REPAIRS = [
    [/\bclutterfree\b/gi, "clutter-free"],
    [/\bclutter free\b/gi, "clutter-free"]
  ];
  function tidyText(value) {
    let out = String(value == null ? "" : value);
    if (!out) return "";
    TEXT_REPAIRS.forEach((pair) => { out = out.replace(pair[0], pair[1]); });
    out = out.replace(/\s+/g, " ")
      .replace(/\s+([,;:.!?])/g, "$1")
      .replace(/([,;:])(?:\s*\1)+/g, "$1")
      .replace(/-([,;.])/g, "$1")
      .replace(/\s*—\s*/g, " — ")
      .trim();
    return out;
  }

  /* A remedy sentence is often a "do this; then that" pair. Each clause prints
     as its own complete bullet sentence instead of running into the next. */
  function sentenceClause(value) {
    const text = tidyText(value);
    if (!text) return "";
    const capped = text.charAt(0).toUpperCase() + text.slice(1);
    return /[.!?]$/.test(capped) ? capped : `${capped}.`;
  }

  /* One labelled bullet per slot inside the Micro-Routine action cell. A
     layman must be able to run a weekday row without re-reading concatenated
     prose ("Wear white. Wear clean, fragrant clothes Donate: Donate white
     sweets…"), so each row renders fixed slots — Wear / Action / Donate —
     stacked vertically, and a "Donate" prefix is never doubled. */
  function microActionCell(lines, mutedNote) {
    const items = (lines || []).filter((line) => line && line.value)
      .map((line) => `<li data-action-kind="${line.key}"><span class="micro-action-label">${line.label}:</span> ${line.value}</li>`)
      .join("");
    return `<td class="micro-action-cell">
      <ul class="micro-action-list" data-micro-action="steps">${items}</ul>
      ${mutedNote ? `<div class="conflict-muted-note">${mutedNote}</div>` : ""}
    </td>`;
  }

  function renderMicroRoutine(p, activation, triage) {
    const db = getActiveDB();
    const lang = getLang();
    const solarHot = solarOverload(p) && pittaInBaseline(p);
    const rows = [];
    const L = {
      daily: lang === "hi" ? "दैनिक (सूर्योदय)" : lang === "gu" ? "દૈનિક (સૂર્યોદય)" : "Daily (Sunrise)",
      nightly: lang === "hi" ? "दैनिक (रात्रि)" : lang === "gu" ? "દૈનિક (રાત્રિ)" : "Daily (Night)",
      time: lang === "hi" ? "समय / दिन" : lang === "gu" ? "સમય / દિવસ" : "Time / Day",
      anchor: lang === "hi" ? "ग्रह-आधार" : lang === "gu" ? "ગ્રહ-આધાર" : "Planetary Anchor",
      action: lang === "hi" ? "क्रिया" : lang === "gu" ? "ક્રિયા" : "Action Item",
      /* Per-slot labels inside the action cell. */
      wearLabel: lang === "hi" ? "पहनें" : lang === "gu" ? "પહેરો" : "Wear",
      actionLabel: lang === "hi" ? "क्रिया" : lang === "gu" ? "ક્રિયા" : "Action",
      donateLabel: lang === "hi" ? "दान" : lang === "gu" ? "દાન" : "Donate",
      /* The one solar practice that survives the solar-overload guardrail. */
      briefArghya: lang === "hi"
        ? "केवल संक्षिप्त सूर्योदय अर्घ्य (30 सेकंड); दोपहर की धूप और सूर्य भेदन छोड़ें"
        : lang === "gu"
          ? "ફક્ત ટૂંકું સૂર્યોદય અર્ઘ્ય (30 સેકન્ડ); બપોરનો તડકો અને સૂર્ય ભેદન છોડો"
          : "Brief sunrise Arghya only (30 sec); avoid midday sun and skip Surya Bhedana",
      mutedNote: lang === "hi" ? "संयमित — सूर्य-ओवरलोड गार्डरेल के कारण हल्के रूप में" : lang === "gu" ? "સંયમિત — સૂર્ય-ઓવરલોડ ગાર્ડરેલને કારણે હળવા રૂપમાં" : "Muted — run gently due to your solar-overload guardrail"
    };
    // Row 1 — the one Tier-1 sunrise practice (same target as the 40-day plan).
    const tN = activation.targetN;
    const tInfo = db.numbers[tN];
    const tShort = db.mantraShort[tN];
    if (activation.holdJapa) {
      rows.push({
        when: L.daily, planet: `${esc(tInfo.planet)} (${tN})`, muted: false, tag: "Tier 1 target",
        cell: microActionCell([{
          key: "practice", label: L.actionLabel,
          value: lang === "hi" ? "जप इस चक्र होल्ड पर है — इसके बजाय सक्रिय क्षेत्र साधें (40-दिन योजना देखें)।" : lang === "gu" ? "જાપ આ ચક્રે હોલ્ડ પર છે — તેના બદલે સક્રિય ક્ષેત્ર સાધો (૪૦-દિવસ યોજના જુઓ)." : "Japa is on hold this cycle — work the active sector instead (see the 40-Day Plan)."
        }], "")
      });
    } else {
      const solarMuteSunrise = solarHot && tN === 1;
      rows.push({
        when: L.daily, planet: `${esc(tInfo.planet)} (${tN})`, muted: solarMuteSunrise, tag: "Tier 1 target",
        cell: microActionCell([{
          key: "practice", label: L.actionLabel,
          value: `${lang === "hi" ? "जापें" : lang === "gu" ? "જાપ કરો" : "Chant"} <span class="mantra">${esc(tShort.dev)}</span> <em>(${esc(tShort.pron)})</em> ${activation.sadhanaJapa}×`
        }], solarMuteSunrise ? L.mutedNote : "")
      });
    }
    // Row 2 — the nightly cooling / intention anchor.
    if (solarOverload(p)) {
      rows.push({
        when: L.nightly, planet: lang === "hi" ? "चंद्र (शीतलन)" : lang === "gu" ? "ચંદ્ર (ઠંડક)" : "Moon (Cooling)", muted: false, tag: "Cooling",
        cell: microActionCell([{
          key: "practice", label: L.actionLabel,
          value: lang === "hi" ? "5 मिनट बाईं-नासिका श्वास (चंद्र भेदन) और शाम का भूमि-संपर्क।" : lang === "gu" ? "5 મિનિટ ડાબી-નાસિકા શ્વાસ (ચંદ્ર ભેદન) અને સાંજનો ભૂમિ-સંપર્ક." : "5 minutes left-nostril breathing (Chandra Bhedana) plus evening grounding."
        }], "")
      });
    } else {
      rows.push({
        when: L.nightly, planet: `${esc(tInfo.planet)} (${tN})`, muted: false, tag: "Intention",
        cell: microActionCell([{
          key: "practice", label: L.actionLabel,
          value: lang === "hi" ? `संकल्प पत्र पर "${esc(tShort.affirmation)}" 11 बार लिखें।` : lang === "gu" ? `સંકલ્પ પત્ર પર "${esc(tShort.affirmation)}" 11 વખત લખો.` : `Write "${esc(tShort.affirmation)}" 11 times on your wish paper.`
        }], "")
      });
    }
    // Rows 3+ — weekday anchors: Driver/Conductor power days first, then the
    // missing goal numbers, de-duplicated by weekday.
    const dayRows = [];
    const pushDayRow = (n, tag) => {
      const info = db.numbers[n];
      if (!info) return;
      const day = dayOf(n);
      if (dayRows.some((r) => r.when === day)) return;
      const muted = solarHot && n === 1;
      /* A number may carry a complete dressing line (wearGuidance) instead of
         being reduced to the first token of its colour list. Sunday was the
         reported gap — "Wear: Gold" — while Friday read as full guidance;
         Sun now prints "Wear: Gold, saffron, or warm yellow" on the same
         labelled slot. Numbers without the field keep the old first-colour
         extraction byte-for-byte. */
      const colour = info.wearGuidance
        ? tidyText(String(info.wearGuidance))
        : tidyText(String(info.color || "").split(",")[0]);
      const lifestyle = tidyText(String(info.lifestyle || "").split(";")[0]);
      /* "Wear green on Wednesdays" beside the colour slot "Green" repeats
         itself, so a wear clause that opens with the colour word is dropped. */
      const colourHead = (colour.split(/\s+/)[0] || "").toLowerCase();
      const rawWearClause = /^wear\b/i.test(lifestyle) ? tidyText(lifestyle.replace(/^wear\b/i, "")) : "";
      const wearClause = rawWearClause && colourHead && !rawWearClause.toLowerCase().startsWith(colourHead) ? rawWearClause : "";
      const actionClause = /^wear\b/i.test(lifestyle) ? "" : lifestyle;
      const lines = [];
      const wearValue = [colour, wearClause].filter(Boolean).join(" · ");
      if (wearValue) lines.push({ key: "wear", label: L.wearLabel, value: esc(wearValue) });
      /* Solar guardrail: on a Sun-heavy chart the row is muted, and the one
         solar practice that survives is the brief sunrise arghya — the long
         "offer water daily" routine is exactly what must not print live. */
      if (muted) lines.push({ key: "action", label: L.actionLabel, value: esc(L.briefArghya) });
      else if (actionClause) lines.push({ key: "action", label: L.actionLabel, value: esc(actionClause) });
      if (info.charity) {
        const charity = tidyText(String(info.charity).replace(/^donate[d]?\s+/i, ""));
        if (charity) lines.push({ key: "donate", label: L.donateLabel, value: esc(charity) });
      }
      dayRows.push({
        when: day, planet: `${esc(info.planet)} (${n})`, tag, muted,
        cell: microActionCell(lines, muted ? L.mutedNote : "")
      });
    };
    pushDayRow(p.driver, lang === "hi" ? "मूलांक" : lang === "gu" ? "મૂળાંક" : "Driver");
    if (p.conductor !== p.driver) pushDayRow(p.conductor, lang === "hi" ? "भाग्यांक" : lang === "gu" ? "ભાગ્યાંક" : "Conductor");
    (activation.missingFocus || []).slice(0, 3).forEach((n) => pushDayRow(n, lang === "hi" ? "लो शू गैप" : lang === "gu" ? "લો શુ ગેપ" : "Lo Shu gap"));
    rows.push(...dayRows.slice(0, 5));

    /* A solar-muted row no longer carries the blanket strikethrough used
       elsewhere: the row now prints the ONE practice that survives (the brief
       sunrise arghya), so striking it through would read as "do not do this".
       It is tinted as a guardrail row and keeps `data-conflict-muted` for the
       automated safety audit. */
    const bodyRows = rows.map((r) => `<tr${r.muted ? ' class="solar-guardrail-row" data-conflict-muted="solar-overload"' : ""}>
      <td><strong>${r.when}</strong></td>
      <td>${r.planet}<div class="card-sub">${esc(r.tag)}</div></td>
      ${r.cell}
    </tr>`).join("");
    return `<div class="card micro-routine-card" data-micro-routine="7-day">
      <div class="goal-head">
        <div class="card-title">${lang === "hi" ? "आपकी 7-दिवसीय माइक्रो-रूटीन" : lang === "gu" ? "તમારી 7-દિવસીય માઇક્રો-રૂટિન" : "Your 7-Day Micro-Routine"}</div>
        <span class="badge good">${lang === "hi" ? "पहले करें यही" : lang === "gu" ? "પહેલાં આ જ કરો" : "Start here"}</span>
      </div>
      <div class="card-sub">${lang === "hi" ? "घने चेकलिस्ट की जगह एक साफ सप्ताहिक कार्यक्रम — यही इस सप्ताह का पूरा अभ्यास है।" : lang === "gu" ? "ગીચ ચેકલિસ્ટને બદલે એક સ્વચ્છ સાપ્તાહિક કાર્યક્રમ — આ જ આ અઠવાડિયાનો આખો અભ્યાસ છે." : "One clean weekly schedule instead of a dense checklist — this table is the whole practice for this week."}</div>
      <div class="table-scroll"><table class="rtable micro-routine-table">
        <tr><th>${L.time}</th><th>${L.anchor}</th><th>${L.action}</th></tr>
        ${bodyRows}
      </table></div>
    </div>`;
  }

  function renderDoAvoidCards(p, triage, vastuFindings) {
    const db = getActiveDB();
    const lang = getLang();
    const dos = [], donts = [];
    const solarHot = solarOverload(p) && pittaInBaseline(p);
    // DO: active Vastu sector from the Dasha triage.
    const t1 = (triage && triage.tier1) || {};
    if (t1.zone && t1.zoneRemedy) {
      const zoneRemedy = tidyText(t1.zoneRemedy);
      dos.push({ text: lang === "hi" ? `सक्रिय वास्तु क्षेत्र साधें — ${t1.zone}: ${zoneRemedy}` : lang === "gu" ? `સક્રિય વાસ્તુ ક્ષેત્ર સાધો — ${t1.zone}: ${zoneRemedy}` : `Activate the live Vastu sector — ${t1.zone}: ${zoneRemedy}`, src: "dasha" });
    }
    // DO: keep NE + centre clear (general upkeep from the Vastu section).
    dos.push({ text: lang === "hi" ? "घर के ईशान कोण और केंद्र (ब्रह्मस्थान) को भारी सामान से खाली रखें।" : lang === "gu" ? "ઘરના ઈશાન ખૂણા અને કેન્દ્ર (બ્રહ્મસ્થાન) ને ભારે સામાનથી ખાલી રાખો." : "Keep the North-East and the centre (Brahmasthan) of the home free of heavy clutter.", src: "vastu" });
    // DO: channel repeated energy instead of feeding it.
    if (p.loShuRepeated.length) {
      const n = p.loShuRepeated[0];
      const entry = (db.excessEnergy && db.excessEnergy[n]) || {};
      const channel = loc(entry.channel, lang) || db.numbers[n].lifestyle;
      dos.push({ text: lang === "hi" ? `अतिरिक्त ${db.numbers[n].planet} ऊर्जा (${p.loShuCounts[n]}× ${n}) को दिशा दें: ${channel}` : lang === "gu" ? `વધારાની ${db.numbers[n].planet} ઊર્જા (${p.loShuCounts[n]}× ${n}) ને દિશા આપો: ${channel}` : `Channel the excess ${db.numbers[n].planet} energy (${p.loShuCounts[n]}× ${n}): ${channel}`, src: "loshu" });
    }
    // DO NOT: never stack gemstones / dark stones.
    donts.push({ text: lang === "hi" ? "एक साथ कई गहरे रत्न न खरीदें / न पहनें — एक सक्रिय रत्न पर्याप्त है।" : lang === "gu" ? "એકસાથે અનેક ઘેરા રત્નો ન ખરીદો / ન પહેરો — એક સક્રિય રત્ન પૂરતું છે." : "Do not stack multiple dark stones or buy several gemstones at once — one activating stone is enough.", src: "triage" });
    /* Solar-overload pair. A guardrail that only prints bans leaves the client
       guessing whether the sunrise water offering they have always done is
       now forbidden, so the DO column names the one practice that survives
       (a brief 30-second arghya) and the DO-NOT column bans only the
       heat-building forms. */
    if (solarHot) {
      dos.push({ text: lang === "hi" ? "सूर्य-अभ्यास न्यूनतम रखें: सूर्योदय पर केवल 30-सेकंड का संक्षिप्त अर्घ्य, फिर चंद्र भेदन या शाम के भूमि-संपर्क से शीतलता।" : lang === "gu" ? "સૂર્ય-અભ્યાસ ન્યૂનતમ રાખો: સૂર્યોદયે ફક્ત 30-સેકન્ડનું ટૂંકું અર્ઘ્ય, પછી ચંદ્ર ભેદન કે સાંજના ભૂમિ-સંપર્કથી ઠંડક." : "Keep the sun practice minimal: a brief 30-second sunrise Arghya only, then cool down with Chandra Bhedana or evening grounding.", src: "solar" });
      donts.push({ text: lang === "hi" ? "दीर्घ सूर्य-अनुष्ठान, दोपहर का सूर्य सक्रियण और सूर्य भेदन छोड़ें — लंबा सूर्य-दर्शन भी नहीं।" : lang === "gu" ? "લાંબા સૂર્ય-અનુષ્ઠાન, બપોરનું સૂર્ય સક્રિયકરણ અને સૂર્ય ભેદન છોડો — લાંબું સૂર્ય-દર્શન પણ નહીં." : "Skip extended sun rituals, midday Solar Activation and Surya Bhedana; no prolonged sun-gazing.", src: "solar" });
    }
    // DO NOT: Moon-cold forms for cold-sensitive charts.
    if (moonColdSensitivity(p)) {
      donts.push({ text: lang === "hi" ? "ठंडे जल के अनुष्ठान / सोमवार के ठंडे व्रत न करें — उष्ण रूप अपनाएं।" : lang === "gu" ? "ઠંડા જળના અનુષ્ઠાન / સોમવારના ઠંડા વ્રત ન કરો — ઉષ્ણ રૂપ અપનાવો." : "Avoid cold-water rituals and cold Monday fasts — run the lunar forms warm.", src: "moon-cold" });
    }
    // DO NOT: heavy gems for minors.
    if (isMinorProfile(p)) {
      donts.push({ text: lang === "hi" ? "18 वर्ष से पहले भारी रत्न (नीलम, गोमेद, लहसुनिया) न पहनें।" : lang === "gu" ? "18 વર્ષ પહેલાં ભારે રત્નો (નીલમ, ગોમેદ, લહેસુનિયા) ન પહેરો." : "Do not wear heavy gems (Blue Sapphire, Hessonite, Cat's Eye) before adulthood.", src: "age" });
    }
    // DO NOT: dosh placements from the home scan (max 2, shortened).
    (vastuFindings || []).filter((f) => f.tone === "bad").slice(0, 2).forEach((f) => {
      donts.push({ text: `${f.item} — ${f.note.split(".")[0]}.`, src: "vastu" });
    });
    // DO NOT: everything at once.
    donts.push({ text: lang === "hi" ? "सारे उपाय एक साथ शुरू न करें — 40-दिन की योजना एक ही क्रम में चलती है।" : lang === "gu" ? "બધા ઉપાયો એકસાથે શરૂ ન કરો — ૪૦-દિવસની યોજના એક જ ક્રમમાં ચાલે છે." : "Do not start every remedy at once — the 40-day plan runs one tier at a time.", src: "triage" });

    const doRows = dos.slice(0, 5).map((d) => `<div class="ar-item do-item" data-do-src="${d.src}">✓ ${esc(d.text)}</div>`).join("");
    const dontRows = donts.slice(0, 5).map((d) => `<div class="ar-item dont-item" data-dont-src="${d.src}">✕ ${esc(d.text)}</div>`).join("");
    return `<div class="card-grid two do-avoid-grid">
      <div class="card do-card">
        <div class="card-title">${lang === "hi" ? "क्या करें" : lang === "gu" ? "શું કરવું" : "What to DO"}</div>
        <div class="adopt-release"><div class="adopt-col">${doRows}</div></div>
      </div>
      <div class="card avoid-card">
        <div class="card-title">${lang === "hi" ? "क्या न करें" : lang === "gu" ? "શું ન કરવું" : "What to AVOID"}</div>
        <div class="adopt-release"><div class="release-col">${dontRows}</div></div>
      </div>
    </div>`;
  }

  /* The 40-day mandala is a Lo Shu practice. It is deliberately isolated from
     Vedic grid indicators, Dasha timing, home-direction findings, dosha and
     deity baselines. Those systems keep their own cards/modules. */
  function activationPlan(p, triagePre) {
    const db = getActiveDB();
    const lang = getLang();
    /* Client-selected practice depth. It sizes the daily practice rows below
       and nothing else: the Lo Shu target, the triage tiers and every clinical
       guardrail are resolved exactly as before. */
    const sadhana = sadhanaScaleOf(p);
    const sadhanaCopy = sadhanaI18n(sadhana.key);
    const resolved = resolvePracticeTargets(p, triagePre);
    const targets = resolved.targets;
    const triage = resolved.triage;
    const tier1 = resolved.tier1;
    const acute = resolved.acute;
    const holdJapa = resolved.holdJapa;
    const targetN = resolved.primary;
    const target = db.numbers[targetN];
    const targetShort = db.mantraShort[targetN];
    const secondaryN = resolved.secondary;
    const secondary = secondaryN ? db.numbers[secondaryN] : null;
    const targetSignal = targets.missing.includes(targetN) ? "missing" : targets.repeated.includes(targetN) ? "repeated" : "present";
    const liveNote = acute && tier1.reasons && tier1.reasons.length ? tier1.reasons.join(" · ") : "";
    const targetDescriptor = (lang === "hi"
      ? (targetSignal === "missing" ? `लो शू में अनुपस्थित अंक ${targetN}` : targetSignal === "repeated" ? `लो शू में ${p.loShuCounts[targetN]}× दोहराया अंक ${targetN}` : `लो शू का सहायक अंक ${targetN}`)
      : lang === "gu"
        ? (targetSignal === "missing" ? `લો શુમાં ખૂટતો અંક ${targetN}` : targetSignal === "repeated" ? `લો શુંમાં ${p.loShuCounts[targetN]}× પુનરાવર્તિત અંક ${targetN}` : `લો શુનો સહાયક અંક ${targetN}`)
        : (targetSignal === "missing" ? `missing Lo Shu number ${targetN}` : targetSignal === "repeated" ? `${p.loShuCounts[targetN]}× repeated Lo Shu number ${targetN}` : `supportive Lo Shu number ${targetN}`))
      + (acute
        ? (lang === "hi" ? ` — अभी टियर १ तीव्र लक्ष्य (${liveNote})` : lang === "gu" ? ` — હમણાં ટિયર ૧ તીવ્ર લક્ષ્ય (${liveNote})` : ` — the live Tier 1 acute target (${liveNote})`)
        : "");

    /* Sync line rendered inside the ritual card so the plan is visibly bound
       to the triage verdict on the same page. */
    const triageNote = acute
      ? (lang === "hi" ? `नीचे का Remedy Triage से समन्वित: यही अंक ${targetN} (${esc(target.planet)}) इस चक्र का एकमात्र तीव्र जप लक्ष्य है — अन्य बीज मंत्र होल्ड पर हैं।` : lang === "gu" ? `નીચેના Remedy Triage સાથે સુસંગત: આ જ અંક ${targetN} (${esc(target.planet)}) આ ચક્રનો એકમાત્ર તીવ્ર જાપ લક્ષ્ય છે — બીજા બીજ મંત્ર હોલ્ડ પર છે.` : `Synced with the Remedy Triage below: number ${targetN} (${esc(target.planet)}) is the one acute japa target this cycle — other beej mantras stay on hold.`)
      : holdJapa
        ? (lang === "hi" ? `नीचे का Remedy Triage से समन्वित: इस चक्र जप होल्ड पर है — अभ्यास गैर-मंत्र संकेतों (रंग, आदत, संकल्प पत्र) पर चले और सक्रिय क्षेत्र साधें।` : lang === "gu" ? `નીચેના Remedy Triage સાથે સુસંગત: આ ચક્રે જાપ હોલ્ડ પર છે — અભ્યાસ બિન-મંત્ર સંકેતો (રંગ, ટેવ, સંકલ્પ પત્ર) પર ચાલે અને સક્રિય ક્ષેત્ર સાધો.` : `Synced with the Remedy Triage below: japa is held this cycle — the practice runs on non-mantra cues (colour, habit, wish paper) while you work the active sector.`)
        : (lang === "hi" ? "संतुलित grid — केवल रखरखाव अभ्यास।" : lang === "gu" ? "સંતુલિત grid — ફક્ત જાળવણી અભ્યાસ." : "Balanced grid — maintenance practice only.");

    /* ---- Real sunrise window for daily mantra (fixes hardcoded 8 AM) ---- */
    let _sunriseInfo = null;
    try { _sunriseInfo = getRealSunriseForProfile(p); } catch (e) { _sunriseInfo = null; }
    let _srText = "", _srEndText = "", _srLabel = "";
    if (_sunriseInfo && _sunriseInfo.ss && _sunriseInfo.ss.sunrise != null) {
      try {
        const astro = (typeof window !== "undefined" && window.NVAstro) ? window.NVAstro : null;
        const fmt = (dec) => {
          if (astro && typeof astro.formatSunTime === "function") return astro.formatSunTime(dec, lang);
          if (!isFinite(dec)) return "";
          let h = ((dec % 24) + 24) % 24;
          let hour24 = Math.floor(h);
          let minute = Math.floor((h - hour24) * 60 + 0.5);
          let hr = hour24, min = minute;
          if (min >= 60) { min -= 60; hr = (hr + 1) % 24; }
          let ampm = hr >= 12 ? "PM" : "AM";
          let h12 = hr % 12; if (h12 === 0) h12 = 12;
          return h12 + ":" + String(min).padStart(2, "0") + " " + ampm;
        };
        _srText = fmt(_sunriseInfo.ss.sunrise);
        let end = _sunriseInfo.ss.sunrise + 2;
        if (end > _sunriseInfo.ss.sunset) end = _sunriseInfo.ss.sunset;
        _srEndText = fmt(end);
        _srLabel = _sunriseInfo.ss.alwaysDay ? "polar-day" : _sunriseInfo.ss.alwaysNight ? "polar-night" : "ok";
      } catch (e) { _srText = ""; }
    }

    let daily;
    if (lang === "hi") {
      const timeHintHi = _srText ? `सूर्योदय ${_srText} पर — ${_srText} से ${_srEndText} आदर्श (वास्तविक गणना, ${esc(_sunriseInfo.place.name || _sunriseInfo.place.lat.toFixed(2)+","+_sunriseInfo.place.lon.toFixed(2))})` : "सूर्योदय के आसपास — सुबह ८ बजे से पहले (स्थान उपलब्ध होने पर वास्तविक सूर्योदय से गणना)";
      daily = [
        holdJapa
          ? { ico: "⏸", label: "सूर्योदय अभ्यास — जप होल्ड पर", value: esc(tier1.japa || "इस चक्र जप रोकें"), sub: `इसके बजाय सक्रिय ${esc(tier1.planet)} क्षेत्र साधें: ${esc(tier1.zone)} — ${esc(tier1.zoneRemedy)}` }
          : { ico: "🌅", label: "सूर्योदय मंत्र जाप", value: `<span class="mantra">${esc(targetShort.dev)}</span> <em>(${esc(targetShort.pron)})</em> — ${localNumber(sadhana.japa, "hi")} बार, ${timeHintHi}`, sub: `${esc(targetShort.meaning)} यह आपके ${esc(targetDescriptor)} के ${esc(target.planet)} संकेत को अभ्यास में लाता है।` },
        { ico: "📝", label: "संकल्प पत्र", value: `लिखें: “${esc(targetShort.affirmation)}” ११ बार`, sub: "कागज को पर्स या तकिए के नीचे रखें — लिखित संकल्प निरंतरता को सहारा देता है।" },
        { ico: "🎨", label: "लो शू रंग संकेत", value: `${esc(target.color.split(",")[0])} रंग को अपने दैनिक अभ्यास में शामिल करें।`, sub: `यह रंग केवल लो शू के अंक ${targetN} के अभ्यास के लिए चुना गया है।` },
        { ico: "🌬", label: t("sadhanaRowBreath", "श्वास अभ्यास"), value: t(sadhanaCopy.breath, ""), sub: t("sadhanaBreathSub", "अगर सांस रोकनी पड़े या चक्कर आए तो तुरंत रोक दें और सामान्य श्वास पर लौटें।") },
        { ico: "🌿", label: "जीवनशैली संकेत", value: esc(target.lifestyle.split(";")[0]), sub: `${esc(target.planet)} की ऊर्जा को संतुलित दिशा देने वाली छोटी, रोज़ की आदत।` }
      ];
    } else if (lang === "gu") {
      const timeHintGu = _srText ? `સૂર્યોદય ${_srText} પર — ${_srText} થી ${_srEndText} આદર્શ (વાસ્તવિક ગણતરી, ${esc(_sunriseInfo.place.name || _sunriseInfo.place.lat.toFixed(2)+","+_sunriseInfo.place.lon.toFixed(2))})` : "સૂર્યોદયની આસપાસ — સવારે ૮ વાગ્યા પહેલાં (સ્થાન મળે ત્યારે વાસ્તવિક સૂર્યોદયથી ગણતરી)";
      daily = [
        holdJapa
          ? { ico: "⏸", label: "સૂર્યોદય અભ્યાસ — જાપ હોલ્ડ પર", value: esc(tier1.japa || "આ ચક્રે જાપ રોકો"), sub: `તેના બદલે સક્રિય ${esc(tier1.planet)} ક્ષેત્ર સાધો: ${esc(tier1.zone)} — ${esc(tier1.zoneRemedy)}` }
          : { ico: "🌅", label: "સૂર્યોદય મંત્ર જાપ", value: `<span class="mantra">${esc(targetShort.dev)}</span> <em>(${esc(targetShort.pron)})</em> — ${localNumber(sadhana.japa, "gu")} વખત, ${timeHintGu}`, sub: `${esc(targetShort.meaning)} આ તમારા ${esc(targetDescriptor)} ના ${esc(target.planet)} સંકેતને અભ્યાસમાં લાવે છે.` },
        { ico: "📝", label: "સંકલ્પ પત્ર", value: `લખો: “${esc(targetShort.affirmation)}” ૧૧ વખત`, sub: "કાગળને પર્સમાં કે ઓશીકા નીચે રાખો — લખેલો સંકલ્પ સાતત્યને ટેકો આપે છે." },
        { ico: "🎨", label: "લો શુ રંગ સંકેત", value: `${esc(target.color.split(",")[0])} રંગને દૈનિક અભ્યાસમાં સામેલ કરો.`, sub: `આ રંગ માત્ર લો શુના અંક ${targetN} ના અભ્યાસ માટે પસંદ કરાયો છે.` },
        { ico: "🌬", label: t("sadhanaRowBreath", "શ્વાસ અભ્યાસ"), value: t(sadhanaCopy.breath, ""), sub: t("sadhanaBreathSub", "શ્વાસ રોકવો પડે કે ચક્કર આવે તો તરત અટકો અને સામાન્ય શ્વાસ પર પાછા ફરો.") },
        { ico: "🌿", label: "જીવનશૈલી સંકેત", value: esc(target.lifestyle.split(";")[0]), sub: `${esc(target.planet)} ની ઊર્જાને સંતુલિત દિશા આપતી નાની, રોજની ટેવ.` }
      ];
    } else {
      const timeHintEn = _srText ? `around sunrise at ${_srText} — ideal ${_srText} to ${_srEndText} (actual calculation for ${esc(_sunriseInfo.place.name || _sunriseInfo.place.lat.toFixed(2)+","+_sunriseInfo.place.lon.toFixed(2))})` : "around sunrise — ideally within 2 hours of sunrise (actual sunrise varies by location, e.g. 6:04 Trivandrum vs 6:47 Srinagar, 08:05 Birmingham GMT)";
      daily = [
        holdJapa
          ? { ico: "⏸", label: "Sunrise practice — japa on hold", value: esc(tier1.japa || "Hold japa this cycle"), sub: `Work the active ${esc(tier1.planet)} sector instead: ${esc(tier1.zone)} — ${esc(tier1.zoneRemedy)}` }
          : { ico: "🌅", label: "Sunrise mantra", value: `<span class="mantra">${esc(targetShort.dev)}</span> <em>(${esc(targetShort.pron)})</em> — ${localNumber(sadhana.japa, "en")} times, ${timeHintEn}`, sub: `${esc(targetShort.meaning)} This practises the ${esc(target.planet)} signal in your ${esc(targetDescriptor)}.` },
        { ico: "📝", label: "Wish paper", value: `Write “${esc(targetShort.affirmation)}” 11 times`, sub: "Keep the paper in your wallet or under your pillow — a written intention supports consistency." },
        { ico: "🎨", label: "Lo Shu colour cue", value: `Bring ${esc(target.color.split(",")[0].toLowerCase())} into your daily practice.`, sub: `This colour is selected only for the Lo Shu number ${targetN} practice.` },
        { ico: "🌬", label: t("sadhanaRowBreath", "Breathwork"), value: t(sadhanaCopy.breath, ""), sub: t("sadhanaBreathSub", "If a hold feels forced, or you feel dizzy, stop and return to normal breathing.") },
        { ico: "🌿", label: "Lifestyle cue", value: esc(target.lifestyle.split(";")[0]), sub: `A small daily habit that gives ${esc(target.planet)} energy a balanced direction.` }
      ];
    }

    /* Power days remain a Driver/Conductor-only reference. They can help a
       person choose a check-in day but never change the Lo Shu target above. */
    const powerDays = [];
    const appendPowerDay = (n, role) => {
      const info = db.numbers[n];
      if (!info) return;
      let sunriseSuffix = "";
      if (_srText) {
        if (lang === "hi") sunriseSuffix = ` — सूर्योदय ${_srText} पर, ${_srText} से ${_srEndText} शुभ`;
        else if (lang === "gu") sunriseSuffix = ` — સૂર્યોદય ${_srText} પર, ${_srText} થી ${_srEndText} શુભ`;
        else sunriseSuffix = ` — sunrise ${_srText}, ideal ${_srText} to ${_srEndText}`;
      }
      if (lang === "hi") {
        powerDays.push({ day: dayOf(n), planet: `${n} — ${esc(info.planet)}`, note: `${role} का power day — केवल check-in या शुरुआत चुनने का संदर्भ; यह लो शू अभ्यास-लक्ष्य नहीं बदलता।${sunriseSuffix}`, charity: info.charity, fast: info.fast });
      } else if (lang === "gu") {
        powerDays.push({ day: dayOf(n), planet: `${n} — ${esc(info.planet)}`, note: `${role} નો power day — ફક્ત check-in કે શરૂઆત પસંદ કરવાનો સંદર્ભ; આ લો શુ અભ્યાસ-લક્ષ્ય બદલતો નથી.${sunriseSuffix}`, charity: info.charity, fast: info.fast });
      } else {
        powerDays.push({ day: DAY_OF[n], planet: `${n} — ${esc(info.planet)}`, note: `Your ${role} power day — a check-in or start-day reference only; it never changes the Lo Shu practice target.${sunriseSuffix}`, charity: info.charity, fast: info.fast });
      }
    };
    appendPowerDay(p.driver, lang === "hi" ? "मूलांक" : lang === "gu" ? "મૂલાંક" : "Driver");
    if (p.conductor !== p.driver) appendPowerDay(p.conductor, lang === "hi" ? "भाग्यांक" : lang === "gu" ? "ભાગ્યાંક" : "Conductor");

    const repeatedChannel = targets.repeated.length
      ? (loc((db.excessEnergy && db.excessEnergy[targets.repeated[0]] || {}).channel, lang) || db.numbers[targets.repeated[0]].lifestyle)
      : "";
    const phases = [];
    if (lang === "hi") {
      const firstRows = [`ऊपर दी गई <strong>दैनिक मुख्य साधना</strong> शुरू करें — एक ही समय और स्थान पर, प्रतिदिन। यह योजना केवल आपके ${esc(targetDescriptor)} से चुनी गई है।`];
      if (targetSignal === "repeated") firstRows.push(`ऊर्जा को बढ़ाने के बजाय दिशा दें: ${esc(repeatedChannel)}।`);
      phases.push({ badge: "दिन १–७", title: "आधार — संकेत को देखें", rows: firstRows });
      phases.push({ badge: "दिन ८–२१", title: "लय — आदत को स्थिर करें", rows: [`${esc(target.lifestyle.split(";")[0])} को हर दिन दर्ज करें और नीचे के <strong>४०-दिवसीय ट्रैकर</strong> में निशान लगाएं।`, `किसी भी अनुपस्थित अंक को अतिरिक्त सूची से न चुनें — पहले अंक ${targetN} की निरंतरता बनाएं।`] });
      const thirdRows = secondary ? [`दूसरा लो शू संकेत जोड़ें: <strong>${esc(secondary.planet)} (${secondaryN})</strong> के लिए <span class="mantra">${esc(db.mantraShort[secondaryN].dev)}</span> ११ बार और ${esc(secondary.color.split(",")[0])} रंग शामिल करें।`] : [t(sadhanaCopy.deepen, "साधना को गहरा करें: सूर्योदय मंत्र जाप बढ़ाकर १०८ बार करें और अपने अनुभव लिखें।")];
      if (targets.repeated.length && targetSignal !== "repeated") thirdRows.push(`दोहराए अंक ${targets.repeated.join(", ")} को और बढ़ाने के बजाय उनकी ऊर्जा को काम, सेवा या अनुशासन में दिशा दें।`);
      phases.push({ badge: "दिन २२–४०", title: "समन्वय — लो शू संकेत", rows: thirdRows });
      phases.push({ badge: "दिन ४०+", title: "अवलोकन एवं निरंतरता", rows: [`<strong>४०वें दिन</strong> ट्रैकर और जर्नल में देखें कि ${esc(targetDescriptor)} के साथ क्या बदला।`, `केवल लो शू के अनुपस्थित/दोहराए संकेत के अनुसार हल्का अभ्यास जारी रखें। तिथियों, जीवन-घटना विंडो और सक्रिय वास्तु क्षेत्र के लिए <strong>Timeline · Ank Jyotish Dasha</strong> देखें।`] });
    } else if (lang === "gu") {
      const firstRows = [`ઉપરની <strong>દૈનિક મુખ્ય સાધના</strong> શરૂ કરો — રોજ એક જ સમયે અને એક જ સ્થળે. આ યોજના ફક્ત તમારા ${esc(targetDescriptor)} પરથી પસંદ કરાઈ છે.`];
      if (targetSignal === "repeated") firstRows.push(`ઊર્જાને વધારવાને બદલે દિશા આપો: ${esc(repeatedChannel)}.`);
      phases.push({ badge: "દિવસ ૧–૭", title: "પાયો — સંકેત જુઓ", rows: firstRows });
      phases.push({ badge: "દિવસ ૮–૨૧", title: "લય — ટેવ સ્થિર કરો", rows: [`${esc(target.lifestyle.split(";")[0])} ને રોજ નોંધો અને નીચેના <strong>૪૦-દિવસીય ટ્રેકર</strong> માં નિશાની કરો.`, `કોઈ ખૂટતો અંક વધારાની યાદીમાંથી ન પસંદ કરો — પહેલાં અંક ${targetN} ની સાતત્ય બનાવો.`] });
      const thirdRows = secondary ? [`બીજો લો શુ સંકેત ઉમેરો: <strong>${esc(secondary.planet)} (${secondaryN})</strong> માટે <span class="mantra">${esc(db.mantraShort[secondaryN].dev)}</span> ૧૧ વખત અને ${esc(secondary.color.split(",")[0])} રંગ સામેલ કરો.`] : [t(sadhanaCopy.deepen, "અભ્યાસ ઊંડો કરો: સૂર્યોદય મંત્ર જાપ ૧૦૮ વખત કરો અને અનુભવ લખો.")];
      if (targets.repeated.length && targetSignal !== "repeated") thirdRows.push(`પુનરાવર્તિત અંક ${targets.repeated.join(", ")} ને વધુ વધારવાને બદલે તેની ઊર્જાને કામ, સેવા કે શિસ્તમાં દિશા આપો.`);
      phases.push({ badge: "દિવસ ૨૨–૪૦", title: "સમન્વય — લો શુ સંકેત", rows: thirdRows });
      phases.push({ badge: "દિવસ ૪૦+", title: "અવલોકન અને સાતત્ય", rows: [`<strong>૪૦મા દિવસે</strong> ટ્રેકર અને જર્નલમાં જુઓ કે ${esc(targetDescriptor)} સાથે શું બદલાયું.`, `ફક્ત લો શુના ખૂટતા/પુનરાવર્તિત સંકેત મુજબ હળવો અભ્યાસ ચાલુ રાખો. તારીખો, જીવન-ઘટના વિન્ડો અને સક્રિય વાસ્તુ ક્ષેત્ર માટે <strong>સમયરેખા · અંક-જ્યોતિષ દશા</strong> જુઓ.`] });
    } else {
      const firstRows = [`Begin the <strong>daily core ritual</strong> above at the same time and place each day. This plan is selected only from your ${esc(targetDescriptor)}.`];
      if (targetSignal === "repeated") firstRows.push(`Give the surplus direction rather than more fuel: ${esc(repeatedChannel)}.`);
      phases.push({ badge: "Days 1–7", title: "Foundation — notice the signal", rows: firstRows });
      phases.push({ badge: "Days 8–21", title: "Rhythm — stabilize the habit", rows: [`Log <strong>${esc(target.lifestyle.split(";")[0])}</strong> each day and mark the <strong>40-Day Tracker</strong> below.`, `Do not add a new missing-number target yet — first build consistency with number ${targetN}.`] });
      const thirdRows = secondary ? [`Add a second Lo Shu signal: use <strong>${esc(secondary.planet)} (${secondaryN})</strong>'s short mantra <span class="mantra">${esc(db.mantraShort[secondaryN].dev)}</span> ×${localNumber(sadhana.japa, "en")} and its ${esc(secondary.color.split(",")[0].toLowerCase())} colour.`] : [t(sadhanaCopy.deepen, "Deepen the practice: raise the sunrise mantra to 108 times and write down what you notice.")];
      if (targets.repeated.length && targetSignal !== "repeated") thirdRows.push(`Channel repeated number${targets.repeated.length > 1 ? "s" : ""} ${targets.repeated.join(", ")} through work, service or disciplined craft rather than adding more fuel.`);
      phases.push({ badge: "Days 22–40", title: "Integrate — Lo Shu signals", rows: thirdRows });
      phases.push({ badge: "Day 40+", title: "Review & reset", rows: [`On <strong>Day 40</strong>, use your tracker and journal to review what changed around this ${esc(targetDescriptor)}.`, `Continue only the light practice your Lo Shu missing/repeated signals call for. For dates, life-event windows and the active Vastu zone, open <strong>Timeline · Ank Jyotish Dasha</strong>.`] });
    }

    return { targetN, target: { ...target, short: targetShort }, missingFocus: targets.missing, repeatedFocus: targets.repeated, daily, powerDays, phases, acute, holdJapa, tier1N: tier1.n, tier1Mode: tier1.mode, triageNote, sadhana: sadhana.key, sadhanaJapa: sadhana.japa };
  }


  /* ---------------- Export to calendar (.ics) ----------------------
     A client who wants the 40-day container to sit beside their work
     and family commitments has two possible mechanisms, and only one
     of them belongs in a consultation dossier.

     The rejected one is a push notification daemon: a service-worker
     subscription, an OS permission prompt, a vendor push endpoint and
     a server that necessarily learns when each client practises. That
     is daily-active-user machinery borrowed from ad-funded portals,
     and pointing it at someone's spiritual practice would quietly
     convert a self-directed sadhana into an app that nags.

     This is the other one. The browser serialises a static text file
     on the device; the client imports it wherever they already keep
     their life; the app is then completely out of the loop. Nothing
     is subscribed, nothing runs in the background, nothing phones
     home, and the client can delete any entry without asking us.

     Doctrinal rule, identical to the one the 16-zone compass follows:
     this exports text the report already rendered and resolves no new
     prescription of its own. Every description below is assembled from
     `activation.*`, which the practitioner-gated knowledge pack
     produced, so the calendar cannot drift from the page. The only
     new computation is per-day sunrise — arithmetic, not doctrine. */
  const PLAN_WEEKDAY_INDEX = { 1: 0, 2: 1, 9: 2, 7: 2, 5: 3, 3: 4, 6: 5, 8: 6, 4: 6 };

  function planCalendarAnchor(planState) {
    const raw = planState && planState.startedAt ? new Date(planState.startedAt) : new Date();
    const d = isNaN(raw.getTime()) ? new Date() : raw;
    return { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() };
  }

  /* Returns language-neutral *structure* with language-specific text
     already resolved, plus the counts the export card needs to tell the
     client exactly how many entries each option will add. */
  function practiceCalendarPlan(p, activation, planState, options) {
    const ICS = (typeof window !== "undefined" && window.NVCalendar) ? window.NVCalendar : null;
    const empty = { ok: false, events: [], counts: { practice: 0, phases: 0, power: 0, dates: 0, windows: 0 }, sunrise: false };
    if (!ICS || !p || !activation) return empty;

    const opts = options || {};
    const lang = getLang();
    const T = (en, hi, gu) => triText(lang, en, hi, gu);
    const plain = (html) => ICS.htmlToPlain(html);
    const DAYS = 40;
    const include = opts.include || { practice: true, phases: true, power: true, dates: false, windows: false };
    const alarmMinutes = Number(opts.alarmMinutes) > 0 ? Math.trunc(Number(opts.alarmMinutes)) : 0;
    const key = opts.profileKey || state.activeProfileKey || profileKeyOf(p) || "anonymous";
    const uid = (slot) => ICS.uidFor(key, slot);
    const anchor = planCalendarAnchor(planState);

    const scale = SADHANA_SCALE[activation.sadhana] || SADHANA_SCALE[SADHANA_DEFAULT];
    /* Length of the sitting, derived from the practice depth the client
       already chose — never a number invented here. */
    const practiceMinutes = Math.max(15, (scale.breathMinutes || 10) + 10);

    /* The one line that keeps the file honest about what it is. */
    const cordon = T(
      "Timing aid only. This entry repeats text from your NumeroVastu 360 report and changes no remedy, dose or guardrail in it. Open the report for the full reasoning.",
      "केवल समय-सहायक। यह प्रविष्टि आपकी NumeroVastu 360 रिपोर्ट का पाठ दोहराती है और उसमें किसी उपाय, मात्रा या सुरक्षा-नियम को नहीं बदलती। पूरा तर्क रिपोर्ट में देखें।",
      "ફક્ત સમય-સહાયક. આ એન્ટ્રી તમારા NumeroVastu 360 રિપોર્ટનો લખાણ દોહરાવે છે અને તેમાં કોઈ ઉપાય, માત્રા કે સુરક્ષા-નિયમ બદલતી નથી. પૂરું તર્ક રિપોર્ટમાં જુઓ."
    );

    /* Per-day solar solve. getRealSunriseForProfile already handles the
       daylight-saving offset for the date it is asked about, so a cycle
       that crosses a DST boundary stays correct instead of drifting an
       hour mid-practice. */
    let sunriseInfo = null;
    try { sunriseInfo = getRealSunriseForProfile(p); } catch (e) { sunriseInfo = null; }
    const place = sunriseInfo && sunriseInfo.place ? sunriseInfo.place : null;
    const placeName = place ? (place.name || `${Number(place.lat).toFixed(2)}, ${Number(place.lon).toFixed(2)}`) : "";
    const sunriseFor = (parts) => {
      if (!place) return null;
      let info = null;
      try { info = getRealSunriseForProfile(p, parts.y, parts.m, parts.d); } catch (e) { info = null; }
      if (!info || !info.ss || info.ss.sunrise == null || !isFinite(info.ss.sunrise)) return null;
      return info;
    };

    const events = [];
    const counts = { practice: 0, phases: 0, power: 0, dates: 0, windows: 0 };

    /* ---- 1 · the daily container -------------------------------
       Forty discrete entries rather than one RRULE, because sunrise
       moves by roughly twenty-five minutes over forty days at Indian
       latitudes. A single repeating 06:14 event would be wrong for most
       of the cycle, and a sunrise practice that is wrong about sunrise
       is worse than no entry at all. */
    const dailyText = (activation.daily || [])
      .map((row) => `• ${plain(row.label)}: ${plain(row.value)}`)
      .join("\n");
    const targetLine = T(
      `Lo Shu practice target: number ${activation.targetN}.`,
      `लो शू अभ्यास लक्ष्य: अंक ${activation.targetN}।`,
      `લો શુ અભ્યાસ લક્ષ્ય: અંક ${activation.targetN}.`
    );
    if (include.practice) {
      for (let i = 0; i < DAYS; i++) {
        const day = ICS.addDays(anchor, i);
        const info = sunriseFor(day);
        const start = info
          ? ICS.fromDecimalHours(day, info.ss.sunrise)
          : { y: day.y, m: day.m, d: day.d, h: 6, mi: 30, s: 0 };
        const horizon = info
          ? T(`Sunrise ${placeName}: computed for this date.`,
              `सूर्योदय ${placeName}: इसी तिथि के लिए गणना।`,
              `સૂર્યોદય ${placeName}: આ જ તારીખ માટે ગણતરી.`)
          : T("No birthplace on file, so this is a nominal 6:30 AM slot — move it to your own sunrise.",
              "फ़ाइल में जन्मस्थान नहीं है, अतः यह नाममात्र ६:३० AM का समय है — इसे अपने सूर्योदय पर ले जाएँ।",
              "ફાઇલમાં જન્મસ્થળ નથી, તેથી આ નામમાત્ર ૬:૩૦ AM નો સમય છે — તેને તમારા સૂર્યોદય પર ખસેડો.");
        events.push({
          uid: uid(`practice-${i + 1}`),
          summary: T(`Lo Shu practice — Day ${i + 1} of ${DAYS}`,
            `लो शू अभ्यास — दिन ${i + 1} / ${DAYS}`,
            `લો શુ અભ્યાસ — દિવસ ${i + 1} / ${DAYS}`),
          start,
          end: ICS.addMinutes(start, practiceMinutes),
          description: [targetLine, dailyText, horizon, cordon].filter(Boolean).join("\n\n"),
          categories: ["NumeroVastu 360"],
          alarmMinutes
        });
        counts.practice++;
      }
    }

    /* ---- 2 · phase milestones ---------------------------------- */
    if (include.phases) {
      (activation.phases || []).forEach((phase, idx) => {
        /* "Days 8-21" / "Day 40+" — take the first integer as the offset. */
        const match = /(\d+)/.exec(String(phase.badge || ""));
        const dayNo = match ? Math.max(1, Math.min(DAYS, Number(match[1]))) : idx * 10 + 1;
        const at = ICS.addDays(anchor, dayNo - 1);
        events.push({
          uid: uid(`phase-${idx + 1}`),
          summary: `${plain(phase.badge)} — ${plain(phase.title)}`,
          allDay: true,
          start: at,
          description: [(phase.rows || []).map((r) => `• ${plain(r)}`).join("\n"), cordon].filter(Boolean).join("\n\n"),
          categories: ["NumeroVastu 360"],
          transparent: true
        });
        counts.phases++;
      });
    }

    /* ---- 3 · power-day check-ins -------------------------------
       Driver and Conductor weekdays only, and the description repeats
       the report's own caveat that these schedule a check-in and never
       move the Lo Shu target. */
    if (include.power) {
      const dayNumbers = [p.driver, p.conductor].filter((n, i, arr) => isFinite(n) && arr.indexOf(n) === i);
      dayNumbers.forEach((n, slot) => {
        const target = PLAN_WEEKDAY_INDEX[n];
        if (target === undefined) return;
        const info = (activation.powerDays || [])[slot] || null;
        for (let i = 0; i < DAYS; i++) {
          const day = ICS.addDays(anchor, i);
          if (new Date(day.y, day.m - 1, day.d).getDay() !== target) continue;
          events.push({
            uid: uid(`power-${n}-${i + 1}`),
            summary: T(`Power-day check-in — ${DAY_NAMES.en[n]} (${n})`,
              `पावर-डे चेक-इन — ${DAY_NAMES.hi[n]} (${n})`,
              `પાવર-ડે ચેક-ઇન — ${DAY_NAMES.gu[n]} (${n})`),
            allDay: true,
            start: day,
            description: [info ? plain(info.note) : "", info ? `${T("Charity", "दान", "દાન")}: ${plain(info.charity)}` : "", cordon].filter(Boolean).join("\n\n"),
            categories: ["NumeroVastu 360"],
            transparent: true
          });
          counts.power++;
        }
      });
    }

    /* ---- 4 · favourable dates ----------------------------------
       Deliberately the same engine call as Section 13a — same horizon,
       same limit, same purpose keys — so an exported date can never
       disagree with the date printed in the report. */
    if (include.dates) {
      const NI = insightsEngine();
      const db = getActiveDB();
      const lifeEvents = (db.dasha && db.dasha.lifeEvents) || {};
      const chart = { driver: p.driver, conductor: p.conductor, day: p.day, month: p.month };
      Object.keys(lifeEvents).forEach((purpose) => {
        const row = lifeEvents[purpose] || {};
        const label = (row.label && (row.label[lang] || row.label.en)) || purpose;
        let found = null;
        try { found = NI.favourableDates(chart, { purpose, fromMs: Date.now(), days: 90, limit: 4 }); } catch (e) { found = null; }
        if (!found) return;
        found.best.filter((b) => b.grade !== "avoid").forEach((b) => {
          const parts = { y: b.date.getFullYear(), m: b.date.getMonth() + 1, d: b.date.getDate() };
          events.push({
            uid: uid(`date-${purpose}-${b.iso.replace(/-/g, "")}`),
            summary: T(`Favourable for ${label} — ${b.grade}`,
              `${label} हेतु अनुकूल — ${b.grade}`,
              `${label} માટે અનુકૂળ — ${b.grade}`),
            allDay: true,
            start: parts,
            description: [
              `${T("Personal Day", "व्यक्तिगत दिन", "વ્યક્તિગત દિવસ")} ${b.cycles.personalDay} · ${T("score", "अंक", "ગુણ")} ${b.score} (${b.grade})`,
              T("Scored from your Personal Day against Driver and Conductor, the date root and the weekday lord. Section 13a prints the full trail.",
                "व्यक्तिगत दिन की मूलांक-भाग्यांक, तिथि-मूल और वार-स्वामी से तुलना करके अंक दिए गए। पूरा विवरण खंड 13a में है।",
                "વ્યક્તિગત દિવસની મૂળાંક-ભાગ્યાંક, તિથિ-મૂળ અને વાર-સ્વામી સાથે તુલના કરીને ગુણ અપાયા. પૂરી વિગત વિભાગ 13a માં છે."),
              cordon
            ].join("\n\n"),
            categories: ["NumeroVastu 360"],
            transparent: true
          });
          counts.dates++;
        });
      });
    }

    /* ---- 5 · inauspicious day-division windows -----------------
       Rahu, Yamaganda and Gulika for each day of the container. Marked
       TRANSPARENT on purpose: these are advisory, and a window that
       blocked the client's calendar would stop colleagues booking over
       it and turn an almanac note into a scheduling obstruction. */
    if (include.windows && place && typeof window !== "undefined" && window.NVMuhurtha
      && typeof window.NVMuhurtha.inauspiciousWindows === "function") {
      const labels = {
        rahu: T("Rahu Kaal", "राहु काल", "રાહુ કાળ"),
        yamaganda: T("Yamaganda Kaal", "यमगंड काल", "યમગંડ કાળ"),
        gulika: T("Gulika Kaal", "गुलिक काल", "ગુલિક કાળ")
      };
      for (let i = 0; i < DAYS; i++) {
        const day = ICS.addDays(anchor, i);
        let tzEff = place.tz;
        try {
          const info = getRealSunriseForProfile(p, day.y, day.m, day.d);
          if (info && isFinite(info.tzEff)) tzEff = info.tzEff;
        } catch (e) { /* fall back to the stored offset */ }
        let solved = null;
        try { solved = window.NVMuhurtha.inauspiciousWindows(day.y, day.m, day.d, place.lat, place.lon, tzEff); } catch (e) { solved = null; }
        if (!solved || !solved.ok) continue;
        solved.windows.forEach((w) => {
          const start = ICS.fromDecimalHours(day, w.start);
          const end = ICS.fromDecimalHours(day, w.end);
          if (!start || !end) return;
          events.push({
            uid: uid(`window-${w.kind}-${day.y}${String(day.m).padStart(2, "0")}${String(day.d).padStart(2, "0")}`),
            summary: `${labels[w.kind] || w.kind} — ${T("avoid new beginnings", "नए आरंभ से बचें", "નવી શરૂઆત ટાળો")}`,
            start,
            end,
            transparent: true,
            description: [
              T(`Part ${w.part} of 8 of the measured daylight at ${placeName}.`,
                `${placeName} पर मापे गए दिनमान के ८ भागों में से भाग ${w.part}।`,
                `${placeName} પર માપેલા દિનમાનના ૮ ભાગોમાંથી ભાગ ${w.part}.`),
              T("Shown as free time, not busy — this is an almanac note, not an appointment.",
                "यह व्यस्त नहीं, मुक्त समय दिखेगा — यह पंचांग की टिप्पणी है, कोई अपॉइंटमेंट नहीं।",
                "આ વ્યસ્ત નહીં, મુક્ત સમય દેખાશે — આ પંચાંગની નોંધ છે, કોઈ એપોઇન્ટમેન્ટ નથી."),
              cordon
            ].join("\n\n"),
            categories: ["NumeroVastu 360"]
          });
          counts.windows++;
        });
      }
    }

    return {
      ok: events.length > 0,
      events,
      counts,
      anchor,
      sunrise: !!place,
      placeName,
      practiceMinutes,
      filename: `numerovastu-360-practice-${anchor.y}-${String(anchor.m).padStart(2, "0")}-${String(anchor.d).padStart(2, "0")}.ics`,
      calendarName: T("NumeroVastu 360 — 40-day practice", "NumeroVastu 360 — ४०-दिवसीय अभ्यास", "NumeroVastu 360 — ૪૦-દિવસનો અભ્યાસ")
    };
  }

  /* Serialise and hand the file to the browser. Blob + object URL keeps
     the bytes on the device; there is no endpoint to post them to. */
  function downloadPracticeCalendar(p, activation, planState, options) {
    const ICS = (typeof window !== "undefined" && window.NVCalendar) ? window.NVCalendar : null;
    const built = practiceCalendarPlan(p, activation, planState, options);
    if (!ICS || !built.ok) return built;
    const text = ICS.calendar(built.events, { name: built.calendarName });
    try {
      const blob = new Blob([text], { type: "text/calendar;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = built.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      /* Revoked on the next tick so Safari has finished reading it. */
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch (e) {
      return Object.assign({}, built, { ok: false, reason: "download-failed" });
    }
    return Object.assign({}, built, { text });
  }

  function saveSnapshot(input, profile, timing) {
    const snapshot = {
      id: `${profileKeyOf(input)}|${Date.now()}`,
      key: profileKeyOf(input),
      name: input.name,
      dob: input.dob,
      savedAt: isoDate(),
      packVersion: activePack().packVersion,
      driver: profile.driver,
      conductor: profile.conductor,
      loShuMissing: profile.loShuMissing,
      goals: profile.goals,
      luckyYears: timing.luckyYears.map((y) => y.yr),
      input: Object.assign({}, input)
    };
    state.activeProfileKey = snapshot.key;
    const history = state.history.filter((item) => item.key !== snapshot.key);
    history.unshift(snapshot);
    state.history = history.slice(0, 15);
    writeStore(STORAGE_KEYS.history, state.history);
    updateMemoryUI();
  }

  function readPlanStore() { return readStore(STORAGE_KEYS.plan, {}); }
  function writePlanStore(store) { return writeStore(STORAGE_KEYS.plan, store); }
  function readPlan(profileKey) {
    const store = readPlanStore();
    const cur = store[profileKey] || { startedAt: null, days: [] };
    return { startedAt: cur.startedAt || null, days: Array.isArray(cur.days) ? cur.days : [] };
  }
  function writePlan(profileKey, plan) {
    const store = readPlanStore();
    store[profileKey] = { startedAt: plan.startedAt || null, days: plan.days || [] };
    writePlanStore(store);
  }

  function readPracticeStore() { return readStore(STORAGE_KEYS.practice, {}); }
  function writePracticeStore(store) { return writeStore(STORAGE_KEYS.practice, store); }
  function readJournalStore() { return readStore(STORAGE_KEYS.journal, {}); }
  function writeJournalStore(store) { return writeStore(STORAGE_KEYS.journal, store); }

  function logPractice(profileKey, number) {
    const store = readPracticeStore();
    const list = store[profileKey] || [];
    list.unshift({ number, at: isoDate() });
    store[profileKey] = list.slice(0, 100);
    writePracticeStore(store);
  }
  function addJournalEntry(profileKey, text) {
    const store = readJournalStore();
    const list = store[profileKey] || [];
    list.unshift({ text, at: isoDate() });
    store[profileKey] = list.slice(0, 50);
    writeJournalStore(store);
  }

  function contributionPayload(profile, timing) {
    return {
      schemaVersion: 1,
      packVersion: activePack().packVersion,
      createdAt: isoDate(),
      driver: profile.driver,
      conductor: profile.conductor,
      loShuMissingCount: profile.loShuMissing.length,
      loShuRepeatedCount: profile.loShuRepeated.length,
      goals: profile.goals,
      luckyYearActive: timing.luckyYears.some((item) => item.yr === new Date().getFullYear()),
      kua: profile.kua,
      vedicTier: profile.vedicTier
    };
  }

  function queueAnonymousContribution(profile, timing) {
    if (!state.contributionEnabled) return null;
    const payload = contributionPayload(profile, timing);
    const outbox = readStore(STORAGE_KEYS.contributionOutbox, []);
    outbox.unshift(payload);
    writeStore(STORAGE_KEYS.contributionOutbox, outbox.slice(0, 25));
    return payload;
  }

  function evolvingChartData(profile, timing) {
    const key = state.activeProfileKey || profileKeyOf(profile);
    const practices = (readPracticeStore()[key] || []);
    const journal = (readJournalStore()[key] || []);
    const snapshots = state.history.filter((s) => s.key === key);
    const now = new Date();
    const curMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const movesThisYear = journal.filter((j) => String(j.at || "").startsWith(String(now.getFullYear()))).length;

    const focusNumbers = Array.from(new Set([profile.driver, profile.conductor, ...profile.loShuMissing])).slice(0, 4);
    const practiceSummary = focusNumbers.map((n) => {
      const allForNum = practices.filter((p) => p.number === n);
      const thisMonth = allForNum.filter((p) => String(p.at || "").startsWith(curMonth)).length;
      return { n, total: allForNum.length, month: thisMonth };
    });

    const currentYearLucky = timing.luckyYears.some((entry) => entry.yr === now.getFullYear());
    const previewPayload = contributionPayload(profile, timing);

    return { snapshots, movesThisYear, currentYearLucky, practiceSummary, journal, previewPayload };
  }

  function zodiacHarmonyNote(p, z) {
    const db = getActiveDB();
    const ruler = z.ruler;
    const planet = db.numbers[ruler] ? db.numbers[ruler].planet : String(ruler);
    const aligns = p.driver === ruler || p.conductor === ruler;
    const lang = getLang();
    const statement = lang === "hi"
      ? `${aligns ? `आपकी सूर्य-राशि का स्वामी ${esc(planet)} आपके ${p.driver === ruler ? "मूलांक" : "भाग्यांक"} से भी जुड़ता है।` : `आपकी सूर्य-राशि का स्वामी ${esc(planet)} (अंक ${ruler}) एक अलग राशिगत संदर्भ देता है।`} यह राशिगत परत लो शू remedy checklist, इष्ट देवता, आयुर्वेदिक baseline, power days या दशा-वास्तु समय को नहीं बदलती।`
      : lang === "gu"
        ? `${aligns ? `તમારા સૂર્ય-રાશિના સ્વામી ${esc(planet)} તમારા ${p.driver === ruler ? "મૂલાંક" : "ભાગ્યાંક"} સાથે પણ જોડાય છે.` : `તમારા સૂર્ય-રાશિના સ્વામી ${esc(planet)} (અંક ${ruler}) અલગ રાશિ-સંદર્ભ આપે છે.`} આ રાશિ-સ્તર લો શુ remedy checklist, ઇષ્ટ દેવતા, આયુર્વેદિક baseline, power days અથવા દશા-વાસ્તુ સમયને બદલતું નથી.`
        : `${aligns ? `Your Sun-sign ruler, ${esc(planet)}, also aligns with your ${p.driver === ruler ? "Driver" : "Conductor"}.` : `Your Sun-sign ruler, ${esc(planet)} (number ${ruler}), provides a separate zodiac reference.`} This zodiac layer does not alter the Lo Shu remedy checklist, guardian deities, Ayurvedic baseline, power days or Dasha/Vastu timing.`;
    return `<div class="harmony-note judge-note"><strong>${lang === "hi" ? "राशि का स्थान:" : lang === "gu" ? "રાશિનું સ્થાન:" : "Where the zodiac layer fits:"}</strong> ${statement}</div>`;
  }

  function fmtAy(deg) {
    if (deg == null) return "24°00′";
    const d = Math.floor(deg);
    const m = Math.round((deg - d) * 60);
    return `${d}°${String(m).padStart(2, "0")}′`;
  }
  function fmtTz(tz) {
    const sign = tz < 0 ? "-" : "+";
    const abs = Math.abs(tz);
    return `UTC${sign}${Math.floor(abs)}:${String(Math.round((abs % 1) * 60)).padStart(2, "0")}`;
  }
  function astroCell(cls, glyph, label, degLine, sub, ref) {
    return `<div class="astro-cell ${cls}">
      <div class="astro-glyph">${glyph}</div>
      <div class="astro-name">${label}</div>
      <div class="astro-deg">${degLine}</div>
      <div class="astro-sub">${sub}</div>
      <div class="astro-ref">${ref}</div>
    </div>`;
  }

  function vedicSnapshotCard(p) {
    const a = p.astro;
    if (!a || !a.ok) return "";
    const db = getActiveDB();
    const boundaryNote = a.boundary
      ? `<p class="astro-note astro-boundary">Your Sun sits on the <strong>${esc(a.daySpan[0])} / ${esc(a.daySpan[1])}</strong> boundary on your birth date — the exact hour can tip the final sign. Add your birth time to pin it precisely.</p>`
      : "";
    if (a.tier === "full") {
      const pl = a.place, nak = a.moon.nakshatra;
      const placeLine = pl.fromCoords
        ? `${esc(pl.displayName)}`
        : `${esc(pl.name)}${pl.state ? ", " + esc(pl.state) : ""}, ${esc(pl.country)}`;
      const caveat = pl.dst
        ? ` · standard-time offset (${fmtTz(pl.tz)}) — if daylight saving applied on the birth date, shift the time accordingly`
        : ` · ${fmtTz(pl.tz)}`;
      const driverPlanet = db.numbers[p.driver] ? db.numbers[p.driver].planet : "";
      const nakDriverLink = driverPlanet && driverPlanet.startsWith(nak.lord)
        ? `<div class="astro-nak-driver">⭐ Star–Driver resonance: <strong>${esc(nak.name)}</strong>'s Vimshottari lord is <strong>${esc(driverPlanet)}</strong> — the same planet behind your Driver <strong>${p.driver}</strong>. A descriptive echo between the Vedic sky and your root number: it adds no remedy and changes no timing.</div>`
        : "";
      /* The Midheaven is the ecliptic's highest point — it is NOT the Vedic
         10th-house cusp. Whole-sign Dasham Bhava is counted from the Lagna,
         and the two land in different signs for roughly a third of charts
         (measured: 28,800 sample charts across 16 places, MC sign equals the
         10th-from-Lagna sign in only ~67% of them). So the cell keeps the MC's
         true identity and states the real Dasham Bhava sign beside it. */
      const lagnaCusp = Math.floor(a.lagna.lonSidereal / 30) * 30;
      const tenthSign = window.NVAstro.signOf((lagnaCusp + 270) % 360);
      /* Card copy stays English exactly like every other string in this card
         on main; localising the whole Astro-Identity Snapshot is its own task. */
      const mcVedicNote = `Whole-sign Vedic 10th house (Dasham Bhava) from your Lagna: <strong>${esc(tenthSign.glyph)} ${esc(tenthSign.name)}</strong>`;
      return `<div class="card astro-snapshot-card" id="vedic-snapshot">
      <div class="goal-head">
        <div class="card-title">🪐 Astro-Identity Snapshot — your Vedic sky at birth</div>
        <span class="badge info">Computed on this device<span class="practitioner-only"> · ${esc(a.engine)}</span></span>
      </div>
      <div class="astro-grid">
        ${astroCell("astro-sun", esc(a.sun.glyph), "Sun · Surya Rashi", `${esc(a.sun.sign)} ${esc(a.sun.degStr)}`, `${esc(a.sun.element)} · ruled by ${esc(a.sun.lord)}`, `Western tropical reference: ${esc(a.sun.tropicalGlyph)} ${esc(a.sun.tropicalSign)} ${esc(a.sun.tropicalDegStr)}`)}
        ${astroCell("astro-moon", esc(a.moon.glyph), "Moon · Chandra Rashi", `${esc(a.moon.sign)} ${esc(a.moon.degStr)}`, `${esc(a.moon.element)} · ruled by ${esc(a.moon.lord)}`, `<span class="astro-nak-badge">${esc(nak.glyph)} ${esc(nak.name)} · Pada ${nak.pada} · lord ${esc(nak.lord)}</span>`)}
        ${astroCell("astro-lagna", esc(a.lagna.glyph), "Lagna (Ascendant)", `${esc(a.lagna.sign)} ${esc(a.lagna.degStr)}`, `${esc(a.lagna.element)} · ruled by ${esc(a.lagna.lord)}`, "The sign rising on the eastern horizon at your birth minute")}
        ${astroCell("astro-mc", esc(a.mc.glyph), "Midheaven (MC)", `${esc(a.mc.sign)} ${esc(a.mc.degStr)}`, `${esc(a.mc.element)} · ruled by ${esc(a.mc.lord)}`, `Highest point of the ecliptic — career &amp; public life · ${mcVedicNote}`)}
      </div>
      <div class="astro-nak-strip">
        <div class="astro-nak-head">Nakshatra of the Moon — <strong>${esc(nak.name)}</strong> ${esc(nak.glyph)} · <strong>Pada ${nak.pada} of 4</strong> · ${esc(nak.spanStr)} of the sidereal zodiac</div>
        <div class="astro-nak-body">Vimshottari lord <strong>${esc(nak.lord)}</strong> · Deity <strong>${esc(nak.deity)}</strong> — ${esc(nak.trait)}.</div>
        ${nakDriverLink}
      </div>
      <div class="astro-foot">
        Lahiri (Chitrapaksha) ayanamsa <strong>${fmtAy(a.ayanamsa)}</strong> · Birth moment <strong>${esc(a.moment.localIso)}</strong> local, ${placeLine} (${esc(pl.lat.toFixed(2))}°N, ${esc(Math.abs(pl.lon).toFixed(2))}°${pl.lon >= 0 ? "E" : "W"})${caveat} · Positions are sidereal (Nirayana). Everything is computed locally in your browser — nothing is sent anywhere.
      </div>
    </div>`;
    }

    const need = [];
    if (!p.birthTime) need.push("<strong>exact birth time</strong>");
    if (!p.birthPlace) need.push("<strong>birth city / place</strong>");
    let unlockText;
    if (a.placeUnmatched) {
      unlockText = `We couldn't match <strong>“${esc(p.birthPlace)}”</strong> to the built-in atlas (${(window.NVAstro && window.NVAstro.cityNames().length) || 630}+ cities, fully offline). Try “City, State” — e.g. <strong>Faridabad, India</strong> — or enter coordinates like <strong>“28.41, 77.32”</strong> (add a third number to override the time zone, e.g. “40.71, -74.01, -5”).`;
    } else if (need.length === 1) {
      unlockText = `Almost unlocked — add your ${need[0]} (Edit Details → Vedic Precision) to reveal your <strong>Moon Sign (Chandra Rashi)</strong>, <strong>Nakshatra</strong> with its pada, <strong>Lagna</strong> and <strong>Midheaven</strong>, computed instantly on this device.`;
    } else {
      unlockText = `Add your <strong>exact birth time</strong> and <strong>birth city / place</strong> (Edit Details → Vedic Precision) to unlock your <strong>Moon Sign (Chandra Rashi)</strong>, <strong>Nakshatra</strong> with its pada, <strong>Lagna</strong> and <strong>Midheaven</strong> — computed instantly on your device, never sent anywhere.`;
    }
    return `<div class="card astro-snapshot-card astro-snapshot-reduced" id="vedic-snapshot">
      <div class="goal-head">
        <div class="card-title">🪐 Astro-Identity Snapshot — your Vedic Sun</div>
        <span class="badge info">Tier 1 · from your date of birth</span>
      </div>
      <div class="astro-grid">
        ${astroCell("astro-sun", esc(a.sun.glyph), "Sun · Surya Rashi", `${esc(a.sun.sign)} ${esc(a.sun.degStr)}`, `${esc(a.sun.element)} · ruled by ${esc(a.sun.lord)}`, `Western tropical reference: ${esc(a.sun.tropicalGlyph)} ${esc(a.sun.tropicalSign)} ${esc(a.sun.tropicalDegStr)}`)}
        <div class="astro-unlock">
          <div class="astro-unlock-title">🔓 Unlock the full snapshot</div>
          <p>${unlockText}</p>
          ${boundaryNote}
        </div>
      </div>
      <div class="astro-foot">
        Lahiri (Chitrapaksha) ayanamsa <strong>${fmtAy(a.ayanamsa)}</strong> · Sun position computed for your birth date (sidereal / Nirayana) <span class="practitioner-only"> · ${esc(a.engine)}</span> · Everything runs locally in your browser — nothing is sent anywhere.
      </div>
    </div>`;
  }

  /* ---- Partner Astro-Identity Snapshot (Section 18 companion) -------------
     A side-by-side positional read of both charts, so a practitioner can
     verify the Chandra-bala verdict above against the actual Moon longitudes
     rather than trusting it. Rendered only when the partner's chart is Tier 2
     (birth time + atlas-resolvable place); there is no Tier 1 variant, because
     a Sun-only partner column would invite exactly the eyeball comparison of
     Moon positions that cannot be made from a date.

     The primary column degrades independently: if your own chart is Tier 1,
     your Moon/Nakshatra/Lagna cells say so instead of showing blanks, which
     would read as "no planet there" rather than "not computed".

     Positions only. The verdict lives in the Chandra-bala card; this card adds
     no second interpretation, no Ashtakoota points and no remedy. */
  function partnerAstroSnapshotCard(p, partnerProfile, partnerFirst, lang) {
    const pa = partnerProfile && partnerProfile.astro;
    if (!pa || !pa.ok || pa.tier !== "full") return "";
    const sa = p.astro;
    const selfFull = !!(sa && sa.ok && sa.tier === "full");
    const LT = (en, hi, gu) => (lang === "hi" ? hi : lang === "gu" ? gu : en);
    const selfFirst = String(p.name || "").trim().split(/\s+/)[0] || LT("You", "आप", "તમે");

    const pending = `<span class="astro-pending">${LT("not computed — add your birth time &amp; place", "अगणित — अपना जन्म समय व स्थान जोड़ें", "અગણિત — તમારો જન્મ સમય અને સ્થળ ઉમેરો")}</span>`;
    const pos = (body) => `${esc(body.glyph)} ${esc(body.sign)} <strong>${esc(body.degStr)}</strong>`;
    const nak = (moon) => moon.nakshatra
      ? `<span class="astro-nak-badge">${esc(moon.nakshatra.glyph)} ${esc(moon.nakshatra.name)} · ${LT("Pada", "पद", "પાદ")} ${moon.nakshatra.pada}</span> <span class="astro-pair-lord">${LT("lord", "स्वामी", "સ્વામી")} ${esc(moon.nakshatra.lord)}</span>`
      : pending;

    const rows = [
      { label: LT("Sun · Surya Rashi", "सूर्य · सूर्य राशि", "સૂર્ય · સૂર્ય રાશિ"), self: pos(sa.sun), partner: pos(pa.sun) },
      { label: LT("Moon · Chandra Rashi", "चंद्र · चंद्र राशि", "ચંદ્ર · ચંદ્ર રાશિ"), self: selfFull ? pos(sa.moon) : pending, partner: pos(pa.moon), key: true },
      { label: LT("Nakshatra · Pada", "नक्षत्र · पद", "નક્ષત્ર · પાદ"), self: selfFull ? nak(sa.moon) : pending, partner: nak(pa.moon), key: true },
      { label: LT("Lagna (Ascendant)", "लग्न", "લગ્ન"), self: selfFull ? pos(sa.lagna) : pending, partner: pos(pa.lagna) }
    ];

    const pl = pa.place;
    /* A coordinate-entered place already carries its lat/lon (and any assumed
       offset) inside displayName, so the explicit pair is appended only for
       atlas matches — otherwise the same numbers print twice. */
    const placeLine = pl.fromCoords
      ? esc(pl.displayName)
      : `${esc(pl.name)}${pl.state ? ", " + esc(pl.state) : ""}, ${esc(pl.country)} (${esc(pl.lat.toFixed(2))}°, ${esc(Math.abs(pl.lon).toFixed(2))}°${pl.lon >= 0 ? "E" : "W"})`;
    const dstCaveat = pl.dst
      ? ` · ${LT("standard-time offset", "मानक समय", "પ્રમાણભૂત સમય")} (${fmtTz(pl.tz)}) — ${LT("if daylight saving applied on that date, shift the time accordingly", "यदि उस तिथि पर डेलाइट सेविंग लागू थी तो समय तदनुसार बदलें", "જો તે તારીખે ડેલાઇટ સેવિંગ લાગુ હતું તો સમય તે મુજબ બદલો")}`
      : ` · ${fmtTz(pl.tz)}`;

    return `<div class="card astro-pair-card" id="partner-astro-snapshot" data-authority="chandra-bala" data-partner-astro="full">
      <div class="goal-head">
        <div class="card-title">🪐 ${LT("Astro-Identity Snapshot", "ज्योतिष-पहचान झलक", "જ્યોતિષ-ઓળખ ઝલક")} — ${esc(selfFirst)} &amp; ${esc(partnerFirst)}</div>
        <span class="badge info">${LT("Computed on this device", "इसी डिवाइस पर गणित", "આ જ ડિવાઇસ પર ગણિત")}<span class="practitioner-only"> · ${esc(pa.engine)}</span></span>
      </div>
      <div class="table-scroll"><table class="rtable astro-pair-table">
        <tr><th>${LT("Factor", "घटक", "ઘટક")}</th><th>${esc(selfFirst)}</th><th>${esc(partnerFirst)}</th></tr>
        ${rows.map((r) => `<tr${r.key ? ' class="astro-pair-key"' : ""}><td>${esc(r.label)}</td><td>${r.self}</td><td>${r.partner}</td></tr>`).join("")}
      </table></div>
      <div class="astro-foot">
        ${LT("Partner's birth moment", "साथी का जन्म क्षण", "સાથીદારનો જન્મ ક્ષણ")} <strong>${esc(pa.moment.localIso)}</strong> ${LT("local", "स्थानीय", "સ્થાનિક")}, ${placeLine}${dstCaveat} · ${LT("Lahiri (Chitrapaksha) ayanamsa", "लाहिड़ी (चित्रपक्ष) अयनांश", "લાહિડી (ચિત્રપક્ષ) અયનાંશ")} <strong>${fmtAy(pa.ayanamsa)}</strong> · ${LT("Sidereal (Nirayana). Both charts are computed in your browser and never leave this device.", "निरयण (सायन नहीं)। दोनों कुंडलियाँ आपके ब्राउज़र में गणित होती हैं और यह डिवाइस कभी नहीं छोड़तीं।", "નિરયણ (સાયન નહીં). બંને કુંડળીઓ તમારા બ્રાઉઝરમાં ગણાય છે અને આ ડિવાઇસ ક્યારેય છોડતી નથી.")}
      </div>
      <div class="judge-note"><strong>${LT("Scope:", "सीमा:", "મર્યાદા:")}</strong> ${LT("Positions only, shown so the Chandra-bala verdict above can be checked against the actual longitudes. This card adds no second verdict, no Ashtakoota points and no remedy.", "केवल स्थितियाँ, ताकि ऊपर के चंद्र-बल निर्णय को वास्तविक अंशों से जाँचा जा सके। यह कार्ड कोई दूसरा निर्णय, अष्टकूट गुण या उपाय नहीं जोड़ता।", "ફક્ત સ્થિતિઓ, જેથી ઉપરના ચંદ્ર-બલ નિર્ણયને વાસ્તવિક અંશો સામે ચકાસી શકાય. આ કાર્ડ કોઈ બીજો નિર્ણય, અષ્ટકૂટ ગુણ કે ઉપાય ઉમેરતું નથી.")}</div>
    </div>`;
  }

  /* ---- Partner Vimshottari anchor (Section 18 companion) ------------------
     The partner's OWN classical Vimshottari stack, computed from the partner's
     natal Moon by the same engine and with the same fixed 120-year lord
     durations as the primary chart's card. The partner profile is a full
     computeProfile() result (day/month/year, birthTime, astro), so
     vimshottariTimeline() applies to it unchanged — no second engine, no
     rescaled lords.

     Rendered only when the partner chart reached Tier 2: there is no Tier 1
     variant, because without a natal Moon there is no anchor, no balance and
     no stack to show — and the Chandra-bala Tier 1 banner above already asks
     for exactly that data. The primary chart degrades independently: if YOUR
     chart is Tier 1 the card still shows the partner's stack (it is a fact of
     the partner's chart), only the comparison line is withheld rather than
     half-computed.

     A timing read-out of the partner's chart only: it never feeds the
     Chandra-bala verdict, Lo Shu remedies, Vastu zones or the Ank Jyotish
     roadmap, and it prescribes nothing. */
  function partnerVimshottariCard(p, partnerProfile, partnerFirst, lang) {
    const pa = partnerProfile && partnerProfile.astro;
    if (!pa || !pa.ok || pa.tier !== "full") return "";
    const pv = vimshottariTimeline(partnerProfile);
    if (!pv) return "";
    const LT = (en, hi, gu) => (lang === "hi" ? hi : lang === "gu" ? gu : en);
    const fmtD = (ms) => new Date(ms).toLocaleDateString(lang === "hi" ? "hi-IN" : lang === "gu" ? "gu-IN" : "en-GB", { day: "2-digit", month: "short", year: "numeric" });
    const vmd = pv.current.md, vad = pv.current.ad, vpd = pv.current.pd;
    const stackRow = (label, seg) => `<tr>
      <td><strong>${label}</strong></td>
      <td>${esc(seg.lord)} <span class="card-sub">(${seg.n})</span></td>
      <td>${fmtD(seg.startMs)} → ${fmtD(seg.endMs)}</td>
      <td>${LT("Ages", "आयु", "ઉંમર")} ${seg.fromAge}–${seg.toAge}</td>
    </tr>`;
    /* Factual comparison with the primary chart's active stack — the same
       "report the fact, do not score it" idiom as the shared-rashi-lord line
       in the Chandra-bala card. Withheld (not half-computed) when the primary
       chart is Tier 1 and its own stack does not exist. */
    const sv = vimshottariTimeline(p);
    let compareHtml;
    if (sv) {
      const sameMd = sv.current.md.lord === vmd.lord;
      compareHtml = `<div class="kit-value partner-vim-compare" data-partner-vim-compare="${sameMd ? "same" : "differ"}">
        <strong>${LT("How the two active stacks line up:", "दोनों सक्रिय स्टैक कैसे मेल खाते हैं:", "બંને સક્રિય સ્ટેક કેવી રીતે બંધબેસે છે:")}</strong> ${LT("you", "आप", "તમે")} ${esc(sv.current.md.lord)} ${LT("Mahadasha /", "महादशा /", "મહાદશા /")} ${esc(sv.current.ad.lord)} · ${esc(partnerFirst)} ${esc(vmd.lord)} ${LT("Mahadasha /", "महादशा /", "મહાદશા /")} ${esc(vad.lord)}.
        ${sameMd
          ? LT(`Both charts are currently under ${vmd.lord} Mahadasha — a coincidence of these particular anchors, not a rule; each stack is anchored on its own natal Moon nakshatra and the two remain independent.`,
               `दोनों कुंडलियाँ अभी ${vmd.lord} महादशा में हैं — यह इन खास आधारों का संयोग है, नियम नहीं; प्रत्येक स्टैक अपनी जन्म-चंद्र नक्षत्र पर आधारित है और दोनों स्वतंत्र रहते हैं।`,
               `બંને કુંડળી હજુ ${vmd.lord} મહાદશામાં છે — આ આ ખાસ ધરાઓનો સંયોગ છે, નિયમ નહીં; દરેક સ્ટેક પોતાના જન્મ-ચંદ્ર નક્ષત્ર પર આધારિત છે અને બંને સ્વતંત્ર રહે છે.`)
          : LT(`The two charts are in different Mahadashas right now — that is expected, not an error: each stack is anchored on its own natal Moon nakshatra and the two are independent read-outs.`,
               `दोनों कुंडलियाँ अभी अलग-अलग महादशा में हैं — यह अपेक्षित है, त्रुटि नहीं: प्रत्येक स्टैक अपनी जन्म-चंद्र नक्षत्र पर आधारित है और दोनों स्वतंत्र पठन हैं।`,
               `બંને કુંડળી હજુ અલગ-અલગ મહાદશામાં છે — આ અપેક્ષિત છે, ભૂલ નહીં: દરેક સ્ટેક પોતાના જન્મ-ચંદ્ર નક્ષત્ર પર આધારિત છે અને બંને સ્વતંત્ર વાંચન છે.`)}
      </div>`;
    } else {
      compareHtml = `<div class="kit-value partner-vim-compare" data-partner-vim-compare="not-comparable">${LT("Your own classical stack is not computed (add your birth time and place in Edit Details), so the two charts are not compared here — only the partner's stack is shown.",
        "आपकी अपनी शास्त्रीय दशा गणित नहीं हुई है (विवरण बदलें में अपना जन्म समय व स्थान जोड़ें), इसलिए यहाँ दोनों कुंडलियों की तुलना नहीं की गई है — केवल साथी की दशा दिखाई गई है।",
        "તમારી પોતાની શાસ્ત્રીય દશા ગણાઈ નથી (વિગત બદલોમાં તમારો જન્મ સમય અને સ્થળ ઉમેરો), તેથી અહીં બંને કુંડળીઓની સરખામણી નથી કરવામાં આવી — ફક્ત સાથીદારની દશા બતાવવામાં આવી છે.")}</div>`;
    }
    return `<div class="card partner-vimshottari-card" id="partner-vimshottari" data-authority="vimshottari" data-partner-vimshottari="available" data-partner-vimshottari-md="${esc(vmd.lord)}" data-partner-vimshottari-ad="${esc(vad.lord)}" data-partner-vimshottari-agrees="${sv ? (sv.current.md.lord === vmd.lord ? "yes" : "no") : "n/a"}">
      <div class="goal-head">
        <div class="card-title">🕰 ${LT("Partner's Classical Vimshottari Dasha", "साथी की शास्त्रीय विम्शोत्तरी दशा", "સાથીદારની શાસ્ત્રીય વિમ્શોત્તરી દશા")} — ${esc(partnerFirst)}</div>
        <span class="badge info">${LT("Vedic · nakshatra-anchored · fixed 120-year cycle", "वैदिक · नक्षत्र-आधारित · निश्चित १२०-वर्षीय चक्र", "વૈદિક · નક્ષત્ર-આધારિત · નિશ્ચિત ૧૨૦-વર્ષીય ચક્ર")}</span>
      </div>
      <div class="kit-value">${LT("This is the partner's own classical Vimshottari stack: it is anchored on their birth Moon's nakshatra with the same fixed lord durations as your card (Ketu 7, Venus 20, Sun 6, Moon 10, Mars 7, Rahu 18, Jupiter 16, Saturn 19, Mercury 17 years) and is computed from their birth time and place — never from the date of birth alone. It is a read-out of their chart; it changes nothing in your report.",
        "यह साथी की अपनी शास्त्रीय विम्शोत्तरी दशा है: यह उनके जन्म-चंद्र की नक्षत्र पर आधारित है, आपके कार्ड जैसी निश्चित स्वामी-अवधियों के साथ (केतु ७, शुक्र २०, सूर्य ६, चंद्र १०, मंगल ७, राहु १८, बृहस्पति १६, शनि १९, बुध १७ वर्ष) और उनके जन्म समय व स्थान से गणित होती है — केवल जन्मतिथि से नहीं। यह उनकी कुंडली का पठन है; यह आपके रिपोर्ट में कुछ भी नहीं बदलती।",
        "આ સાથીદારની પોતાની શાસ્ત્રીય વિમ્શોત્તરી દશા છે: તે તેમના જન્મ-ચંદ્રના નક્ષત્ર પર આધારિત છે, તમારા કાર્ડ જેવી નિશ્ચિત સ્વામી-અવધિઓ સાથે (કેતુ ૭, શુક્ર ૨૦, સૂર્ય ૬, ચંદ્ર ૧૦, મંગલ ૭, રાહુ ૧૮, બ્રહ્મગુ ૧૬, શનિ ૧૯, બુધ ૧૭ વર્ષ) અને તેમના જન્મ સમય અને સ્થળથી ગણાય છે — ફક્ત જન્મ તારીખથી નહીં. તે તેમની કુંડળીનું વાંચન છે; તે તમારા રિપોર્ટમાં કંઈ પણ બદલતું નથી.")}</div>
      <div class="kit-value partner-vim-anchor">
        <strong>${LT("Anchor", "आधार", "ધરા")}:</strong> ${esc(pv.anchor.nakshatra)} · ${LT("pada", "पद", "પાદ")} ${pv.anchor.pada} · ${esc(pv.anchor.lord)} ·
        ${esc(pv.anchor.moonSign)} ${esc(pv.anchor.moonDeg)} (${esc(pv.anchor.span)}) · ${pv.anchor.elapsedPct}% ${LT("elapsed", "गुज़रा", "ગત")}
      </div>
      <div class="kit-value">
        <strong>${LT("Balance of the birth lord at birth", "जन्म-समय पर जन्म-स्वामी का शेष", "જન્મ સમયે જન્મ-સ્વામીનું શેષ")}:</strong> ${pv.balanceYears} ${LT("years", "वर्ष", "વર્ષ")} ${esc(pv.anchor.lord)}
        <div class="card-sub">${LT("Each nakshatra spans 13°20′. They were born part-way through it, so the unspent fraction is deducted from the starting lord's period and the remaining years carry over.",
          "प्रत्येक नक्षत्र १३°२०′ फैला है। वे उसके बीच में जन्मे, इसलिए बचा हुआ अंश प्रारंभिक स्वामी की अवधि से घटाया जाता है और शेष वर्ष आगे बहाल होते हैं।",
          "દરેક નક્ષત્ર ૧૩°૨૦′ વિસ્તરે છે. તેઓ તેની મધ્યમાં જન્મેલા છે, તેથી બાકીનો ભાગ પ્રારંભિક સ્વામીની અવધિમાંથી બાદ કરાય છે અને બાકીના વર્ષ આગળ વહાય છે.")}</div>
      </div>
      <div class="card-title partner-vim-subhead">${LT("Active Vimshottari stack", "सक्रिय विम्शोत्तरी स्टैक", "સક્રિય વિમ્શોત્તરી સ્ટેક")}</div>
      <div class="table-scroll"><table class="rtable">
        <tr><th>${LT("Level", "स्तर", "સ્તર")}</th><th>${LT("Lord", "ग्रह", "ગ્રહ")}</th><th>${LT("Period", "अवधि", "અવધિ")}</th><th>${LT("Ages", "आयु", "ઉંમર")}</th></tr>
        ${stackRow(LT("Mahadasha", "महादशा", "મહાદશા"), vmd)}
        ${stackRow(LT("Antardasha", "अंतर्दशा", "અંતર્દશા"), vad)}
        ${stackRow(LT("Pratyantar", "प्रत्यांतर", "પ્રત્યાંતર"), vpd)}
      </table></div>
      ${compareHtml}
      <div class="judge-note"><strong>${LT("Scope:", "सीमा:", "મર્યાદા:")}</strong> ${LT("This is the partner's own classical read-out, computed on this device from their birth time and place. It is a timing read-out only: it never feeds the Chandra-bala verdict, Lo Shu remedies, Vastu zones or the Ank Jyotish event windows, and it prescribes nothing — no remedy, no muhurtha, no timing for events.",
        "यह साथी की अपनी शास्त्रीय पठन है, जो उनके जन्म समय व स्थान से इसी डिवाइस पर गणित होती है। यह केवल समय-पठन है: यह चंद्र-बल निर्णय, लो शू उपाय, वास्तु क्षेत्र या अंकज्योतिष event windows में कभी जाती नहीं, और यह कुछ भी निर्धारित नहीं करती — न उपाय, न मुहूर्त, न किसी घटना का समय।",
        "આ સાથીદારની પોતાની શાસ્ત્રીય વાંચન છે, જે તેમના જન્મ સમય અને સ્થળથી આ જ ડિવાઇસ પર ગણાય છે. તે ફક્ત સમય-વાંચન છે: તે ચંદ્ર-બલ નિર્ણય, લો શુ ઉપાય, વાસ્તુ પ્રદેશ કે અંકજ્યોતિષ event windows માં ક્યારેય જતી નથી, અને તે કશું પણ નિર્ધારિત કરતી નથી — ન ઉપાય, ન મુહૂર્ત, ન કોઈ ઘટનાનો સમય.")}</div>
    </div>`;
  }

  function vedicTierDisclosure(p) {
    let stateLine, badge;
    if (p.vedicTier === 2) {
      const full = p.astro && p.astro.tier === "full";
      badge = full ? "Tier 2 · Unlocked" : "Tier 2 · Add a recognised birthplace";
      stateLine = full
        ? `Your birth time (<strong>${esc(p.birthTimeDisplay)}</strong>) and birthplace (<strong>${esc(p.birthPlace)}</strong>) unlock the full snapshot above — Moon Sign (Chandra Rashi), Nakshatra, Lagna and Midheaven are computed on this device and never leave your browser.`
        : `Your birth time (<strong>${esc(p.birthTimeDisplay)}</strong>) and birthplace (<strong>${esc(p.birthPlace)}</strong>) are saved — enter your place as “City, State” (e.g. Faridabad, India) or coordinates (“28.41, 77.32”) to complete the snapshot.`;
    } else if (p.vedicTier === "partial") {
      badge = "Tier 2 · Almost unlocked";
      stateLine = `Almost there — add the missing <strong>${p.birthTime && !p.birthPlace ? "birth city / place" : "exact birth time"}</strong> (Edit Details) to complete your Astro-Identity Snapshot.`;
    } else {
      badge = "Tier 2 · Unlock now";
      stateLine = "Add your <strong>exact birth time</strong> and <strong>birth city / place</strong> (Edit Details) to unlock Moon Sign (Chandra Rashi), Nakshatra, Lagna and Midheaven — computed on this device, never sent anywhere.";
    }
    return `<div class="card vedic-tier-card">
      <div class="card-title">Deepen your Vedic chart — progressive precision</div>
      <div class="tier-list">
        <div class="tier tier-ready">
          <span class="tier-badge tier-badge-ready">Tier 1 · Ready now</span>
          <div class="tier-body">
            <strong>Vedic Sun Sign (Surya Rashi)</strong> — sidereal / Nirayana, Lahiri ayanamsa (~24° behind the Western tropical zodiac). Computed instantly from your date of birth; this is the layer this report uses today.
          </div>
        </div>
        <div class="tier ${p.vedicTier === 2 ? "tier-ready" : "tier-upcoming"}">
          <span class="tier-badge ${p.vedicTier === 2 ? "tier-badge-ready" : "tier-badge-upcoming"}">${badge}</span>
          <div class="tier-body">
            <strong>Moon Sign (Chandra Rashi) · Nakshatra · Lagna · Midheaven</strong> — ${stateLine}
          </div>
        </div>
      </div>
    </div>`;
  }

  /* Shared spelling table (used by both correction-required and optional-enhancement rows). */
  /* Did the authentic family initial actually help THIS chart? The engine tests
     it like any other candidate — the real letter is preferred, but it is never
     pushed when it lands on a number that fights the Driver or Conductor. The
     evaluation is reported either way, so the client sees the check happen. */
  function authenticInitialAnalysis(p, identity) {
    const id = identity || p.nameIdentity || nameIdentity(p.name, p.legalName);
    const tokens = id.everydayTokens;
    if (!tokens.length) return [];
    return id.authenticInitials.map((a) => {
      const inUse = id.everydayInitials.includes(a.letter);
      const inFull = !!a.inEverydayFull;
      const settled = inUse || inFull;
      const text = settled ? id.everyday : tokens.slice(0, 1).concat(a.letter, tokens.slice(1)).join(" ");
      const compound = settled && p.nameCompound != null ? p.nameCompound : chaldeanValue(text);
      const n = reduce(compound);
      const relD = relation(p.driver, n);
      const relC = relation(p.conductor, n);
      return {
        letter: a.letter, token: a.token, text, compound, reduced: n, relD, relC, inUse, inFull,
        harmonious: relD !== "enemy" && relC !== "enemy"
      };
    });
  }

  /* ---------------- dual name layer: report cards ----------------
     Two layers, two totals, one honest picture. The everyday / professional
     string is the reading the rest of the report runs on; the statutory string
     is scored beside it so nobody discovers years later that the name on their
     passport vibrates to an enemy number. */
  function legalNameCard(p) {
    const db = getActiveDB();
    const lang = getLang();
    const identity = p.nameIdentity || nameIdentity(p.name, p.legalName);
    const master = masterNumber(p.legalNameCompound);
    const compound = compoundMeaning(p.legalNameCompound);
    const debt = (p.karmicDebts || []).find((k) => k.source === "legalName");
    const hostile = p.legalNameRelD === "enemy" || p.legalNameRelC === "enemy";
    const friendly = !hostile && p.legalNameRelD !== "neutral" && p.legalNameRelC !== "neutral";
    /* The patronymic line is the bridge between the two layers: it names the
       family token, its authentic initial and — because the engine actually
       tests it — the total that initial would produce on the everyday name,
       with the verdict. A real letter that lands on an enemy number is shown
       and rejected explicitly rather than silently dropped. */
    const patronymics = identity.patronymics || [];
    const authenticChecks = authenticInitialAnalysis(p, identity);
    const initialLine = (() => {
      if (!patronymics.length) {
        return lang === "hi" ? "इस नाम में पितृ-नाम (मध्य नाम) दर्ज नहीं है, इसलिए कोई प्रामाणिक आद्यक्षर उपलब्ध नहीं — सुझाव केवल वर्तनी-सुधार तक सीमित रहेंगे।"
          : lang === "gu" ? "આ નામમાં પિતૃ-નામ (મધ્ય નામ) નથી, તેથી કોઈ અસલી આદ્યાક્ષર ઉપલબ્ધ નથી — સૂચનો ફક્ત જોડણી-સુધારા સુધી મર્યાદિત રહેશે."
            : "No patronymic (middle name) is present in this string, so there is no authentic initial to draw on — suggestions stay limited to spelling adjustments.";
      }
      return patronymics.map((pt) => {
        const check = authenticChecks.find((c) => c.letter === pt.initial) || {};
        const status = check.inFull
          ? (lang === "hi" ? `आपके दैनिक नाम में <strong>पूरा पितृ-नाम पहले से मौजूद</strong> है — इसलिए इंजन उसके बग़ल में दूसरा अक्षर जोड़ने के बजाय उसे ही आद्यक्षर में बदलने का विकल्प देता है (“${esc(check.text || "")}” = ${check.compound} → ${check.reduced}).` : lang === "gu" ? `તમારા દૈનિક નામમાં <strong>આખું પિતૃ-નામ પહેલેથી હાજર</strong> છે — તેથી એન્જિન તેની બાજુમાં બીજો અક્ષર ઉમેરવાને બદલે તેને જ આદ્યાક્ષરમાં ઘટાડવાનો વિકલ્પ આપે છે (“${esc(check.text || "")}” = ${check.compound} → ${check.reduced}).` : `<strong>already present in full in your everyday name</strong> — so the engine compresses it to its initial instead of adding a second letter beside it (“${esc(check.text || "")}” = ${check.compound} → ${check.reduced}).`)
          : check.inUse
          ? (lang === "hi" ? `<strong>आपके दैनिक नाम में पहले से सक्रिय</strong> — “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}.` : lang === "gu" ? `<strong>તમારા દૈનિક નામમાં પહેલેથી સક્રિય</strong> — “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}.` : `<strong>already active in your everyday name</strong> — “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}.`)
          : check.harmonious
            ? (lang === "hi" ? `जोड़ने पर “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}, जो मूलांक ${p.driver} और भाग्यांक ${p.conductor} दोनों के अनुकूल है — <strong>सुझाव तालिका में सर्वप्रथम</strong>।` : lang === "gu" ? `ઉમેરતાં “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}, જે મૂળાંક ${p.driver} અને ભાગ્યાંક ${p.conductor} બંને સાથે અનુકૂળ છે — <strong>સૂચન કોષ્ટકમાં સૌથી પહેલાં</strong>.` : `adding it gives “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}, harmonious with both Driver ${p.driver} and Conductor ${p.conductor} — <strong>offered first in the table below</strong>.`)
            : (lang === "hi" ? `जोड़ने पर “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}, जो आपके जन्म अंकों से टकराता है — इसलिए इंजन इसे सुझाव तालिका में नहीं रखता (कोई हानिकारक सिफ़ारिश नहीं), परन्तु यह आपका असली पारिवारिक अक्षर बना रहता है।` : lang === "gu" ? `ઉમેરતાં “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}, જે તમારા જન્મ અંકો સાથે અથડાય છે — તેથી એન્જિન તેને સૂચન કોષ્ટકમાં મૂકતું નથી (કોઈ નુકસાનકારક સૂચન નહીં), પણ તે તમારો સાચો કૌટુંબિક અક્ષર રહે છે.` : `adding it gives “${esc(check.text || "")}” = ${check.compound} → ${check.reduced}, which fights your birth numbers — so the engine deliberately keeps it out of the remedy table (no harmful recommendation), while it stays your authentic family letter.`);
        return `<li><strong>${esc(pt.token)}</strong> → ${lang === "hi" ? "प्रामाणिक आद्यक्षर" : lang === "gu" ? "અસલી આદ્યાક્ષર" : "authentic initial"} <strong>${esc(pt.initial)}</strong> (${lang === "hi" ? "चाल्डियन" : lang === "gu" ? "કાલ્ડિયન" : "Chaldean"} ${chaldeanValue(pt.initial)}) — ${status}</li>`;
      }).join("");
    })();
    const divergence = (() => {
      if (!p.nameDual) return "";
      const everydayHostile = p.nameRelD === "enemy" || p.nameRelC === "enemy";
      if (!hostile && !everydayHostile) {
        return lang === "hi" ? "दोनों नाम आपके जन्म अंकों के अनुकूल हैं — कोई छिपी हुई प्रतिकूलता नहीं मिली।"
          : lang === "gu" ? "બંને નામ તમારા જન્મ અંકો સાથે અનુકૂળ છે — કોઈ છુપાયેલી પ્રતિકૂળતા મળી નથી."
            : "Both layers sit well with your birth numbers — no hidden contrary vibration.";
      }
      if (hostile && !everydayHostile) {
        return lang === "hi" ? `आपका दैनिक नाम अनुकूल है, परन्तु दस्तावेज़ी नाम <strong>${p.legalNameCompound} → ${p.legalNameNum}</strong> आपके जन्म अंकों से टकराता है — यही वह छिपी हुई ऊर्जा है जो केवल दोहरी गणना से दिखती है। पासपोर्ट/KYC जैसे दस्तावेज़ों पर विंडो 2 के सुझाव अपनाएँ।`
          : lang === "gu" ? `તમારું દૈનિક નામ અનુકૂળ છે, પણ દસ્તાવેજી નામ <strong>${p.legalNameCompound} → ${p.legalNameNum}</strong> તમારા જન્મ અંકો સાથે અથડાય છે — આ જ એ છુપાયેલી ઊર્જા છે જે ફક્ત બેવડી ગણતરીથી દેખાય છે. પાસપોર્ટ/KYC જેવા દસ્તાવેજો પર વિન્ડો 2 નાં સૂચનો અપનાવો.`
            : `Your everyday name is friendly, but the statutory string <strong>${p.legalNameCompound} → ${p.legalNameNum}</strong> clashes with your birth numbers — exactly the hidden vibration a single-field intake cannot see. Use the Window 2 suggestions for documents such as a passport or KYC.`;
      }
      if (everydayHostile && !hostile) {
        return lang === "hi" ? `आपका दस्तावेज़ी नाम अनुकूल है, परन्तु दैनिक नाम <strong>${p.nameCompound} → ${p.nameNum}</strong> टकराता है — विंडो 1 के सुझाव बिना किसी कागज़ी कार्रवाई के दैनिक नाम सुधार देते हैं।`
          : lang === "gu" ? `તમારું દસ્તાવેજી નામ અનુકૂળ છે, પણ દૈનિક નામ <strong>${p.nameCompound} → ${p.nameNum}</strong> અથડાય છે — વિન્ડો 1 નાં સૂચનો કોઈ કાગળકામ વગર દૈનિક નામ સુધારે છે.`
            : `Your statutory name is friendly, yet the everyday name <strong>${p.nameCompound} → ${p.nameNum}</strong> clashes — the Window 1 suggestions fix the daily identity with no paperwork at all.`;
      }
      return lang === "hi" ? "दोनों नाम आपके जन्म अंकों से टकराते हैं — दोनों विंडो के सुझाव देखें।"
        : lang === "gu" ? "બંને નામ તમારા જન્મ અંકો સાથે અથડાય છે — બંને વિન્ડોનાં સૂચનો જુઓ."
          : "Both layers clash with your birth numbers — review the suggestions in both windows.";
    })();
    return `<div class="card" id="legal-name-layer" data-legal-total="${p.legalNameCompound}">
      <div class="goal-head">
        <div>
          <div class="card-sub">${lang === "hi" ? "दस्तावेज़ / कानूनी नाम" : lang === "gu" ? "દસ્તાવેજ / કાનૂની નામ" : "Document / Legal Name"}</div>
          <div class="card-title">${esc(p.legalName)}</div>
        </div>
        <span class="badge info">${lang === "hi" ? "चाल्डियन कुल" : lang === "gu" ? "કાલ્ડિયન સરવાળો" : "Chaldean total"} ${p.legalNameCompound}${master ? " (Master Number)" : ""} → ${lang === "hi" ? "नामांक" : lang === "gu" ? "નામાંક" : "Name Number"} ${p.legalNameNum}</span>
        ${relBadge(hostile ? "enemy" : (p.legalNameRelD === "neutral" || p.legalNameRelC === "neutral") ? "neutral" : "friendly")}
      </div>
      <table class="rtable">
        <tr><th>${lang === "hi" ? `नामांक बनाम मूलांक ${p.driver}` : lang === "gu" ? `નામાંક વિરુદ્ધ મૂળાંક ${p.driver}` : `Name number vs Driver ${p.driver}`}</th><td>${relBadge(p.legalNameRelD)}</td></tr>
        <tr><th>${lang === "hi" ? `नामांक बनाम भाग्यांक ${p.conductor}` : lang === "gu" ? `નામાંક વિરુદ્ધ ભાગ્યાંક ${p.conductor}` : `Name number vs Conductor ${p.conductor}`}</th><td>${relBadge(p.legalNameRelC)}</td></tr>
      </table>
      ${master ? `<div class="judge-note"><strong>${esc(master.name)}:</strong> ${esc(master.meaning)}</div>` : (compound ? `<div class="judge-note"><strong>Compound Number ${p.legalNameCompound}:</strong> ${esc(compound)}</div>` : "")}
      ${debt ? `<div class="judge-note" data-legal-karmic="${debt.n}"><strong>${lang === "hi" ? "कर्मऋण" : lang === "gu" ? "કર્મઋણ" : "Karmic debt"} ${debt.n}:</strong> ${lang === "hi" ? "दस्तावेज़ी नाम का कुल योग कर्मऋण अंक पर पड़ता है — यह केवल दोहरी गणना से दिखता है।" : lang === "gu" ? "દસ્તાવેજી નામનો સરવાળો કર્મઋણ અંક પર પડે છે — આ ફક્ત બેવડી ગણતરીથી દેખાય છે." : "the statutory total lands on a karmic debt number — visible only because both layers are scored."}</div>` : ""}
      <div class="kit-value"><strong>${lang === "hi" ? "पितृ-नाम का विश्लेषण:" : lang === "gu" ? "પિતૃ-નામ વિશ્લેષણ:" : "Patronymic analysis:"}</strong> <ul class="name-layer-list">${initialLine}</ul></div>
      <div class="judge-note" data-name-divergence="${hostile ? (p.nameRelD === "enemy" || p.nameRelC === "enemy" ? "both" : "legal") : "public"}">${divergence}</div>
    </div>`;
  }

  /* The two windows of name correction, stated once in the client's own terms.
     Window 1 can be lived from today; Window 2 is the paperwork decision. */
  function nameWindowsCard(p) {
    const lang = getLang();
    const identity = p.nameIdentity || nameIdentity(p.name, p.legalName);
    const publicExample = identity.dual || identity.patronymics.length
      ? (() => {
        const tokens = identity.legalTokens;
        if (tokens.length >= 3) {
          const initials = identity.patronymics.map((pt) => pt.initial).join(" ");
          return `${tokens[0]}${initials ? " " + initials : ""} ${tokens[tokens.length - 1]}`;
        }
        return identity.everyday;
      })()
      : identity.everyday;
    const rows = [
      { w: nameWindowOf("public", lang), example: publicExample, usage: lang === "hi" ? "विज़िटिंग कार्ड, LinkedIn, WhatsApp, ईमेल हस्ताक्षर, लेटरहेड।" : lang === "gu" ? "વિઝિટિંગ કાર્ડ, LinkedIn, WhatsApp, ઈમેલ સહી, લેટરહેડ." : "Business cards, LinkedIn, WhatsApp, email signature, letterheads." },
      { w: nameWindowOf("legal", lang), example: identity.legal, usage: lang === "hi" ? "पासपोर्ट, बैंक KYC, आधार, कंपनी पंजीकरण।" : lang === "gu" ? "પાસપોર્ટ, બેંક KYC, આધાર, કંપની નોંધણી." : "Passport, banking KYC, Aadhaar, company incorporation." }
    ];
    return `<div class="card" id="name-windows">
      <div class="goal-head">
        <div class="card-title">${lang === "hi" ? "नाम-सुधार की दो विंडो" : lang === "gu" ? "નામ-સુધારાની બે વિન્ડો" : "The Two Windows of Name Correction"}</div>
        <span class="badge info">${lang === "hi" ? "एक ही व्यक्ति, दो पहचान" : lang === "gu" ? "એક જ વ્યક્તિ, બે ઓળખ" : "One person, two identities"}</span>
      </div>
      <table class="rtable">
        <tr><th>${lang === "hi" ? "विंडो" : lang === "gu" ? "વિન્ડો" : "Window"}</th><th>${lang === "hi" ? "कहाँ प्रयोग होता है" : lang === "gu" ? "ક્યાં વપરાય છે" : "Where it lives"}</th><th>${lang === "hi" ? "आपका उदाहरण" : lang === "gu" ? "તમારું ઉદાહરણ" : "Your example"}</th></tr>
        ${rows.map((r) => `<tr data-window-row="${esc(r.w.key)}"><td><strong>${esc(r.w.label)}</strong><div class="card-sub">${esc(r.w.hint)}</div></td><td>${esc(r.usage)}</td><td><strong>${esc(r.example || "—")}</strong></td></tr>`).join("")}
      </table>
      <div class="card-sub">${lang === "hi" ? "विंडो 1 तुरंत लागू होती है और व्यावसायिक प्रोफ़ाइल पर बिना किसी कागज़ी कार्रवाई के चलती है। विंडो 2 पहला नाम सुधारती है और पितृ-नाम को ज्यों-का-त्यों रखती है, ताकि वंश/पारिवारिक पहचान में कोई अंतर न आए।" : lang === "gu" ? "વિન્ડો 1 તરત લાગુ થાય છે અને વ્યાવસાયિક પ્રોફાઇલ પર કોઈ કાગળકામ વગર ચાલે છે. વિન્ડો 2 પ્રથમ નામ સુધારે છે અને પિતૃ-નામ જેમ છે તેમ રાખે છે, જેથી વંશ/કૌટુંબિક ઓળખમાં કોઈ ફરક ન પડે." : "Window 1 takes effect immediately on your professional profile and needs no paperwork. Window 2 tunes the first name while holding the patronymic exactly as printed, so no lineage or family mismatch can ever arise."}</div>
      <div class="judge-note">${lang === "hi" ? "ना कभी पहले नाम के साथ कोई काल्पनिक दूसरा आद्यक्षर जोड़ा जाता है (जैसे <em>Amarkumar U Kishorbhai</em> अस्वीकार्य), ना ही मध्य नाम के बिना कोई अक्षर गढ़ा जाता है। पहले नाम की वर्तनी सुधारें, या पूरे पितृ-नाम को उसके आद्यक्षर में बदलें।" : lang === "gu" ? "પ્રથમ નામ સાથે ક્યારેય બનાવટી બીજો આદ્યાક્ષર ઉમેરાતો નથી (જેમ કે <em>Amarkumar U Kishorbhai</em> નામંજૂર), અને મધ્ય નામ વગર કોઈ અક્ષર ઘડાતો નથી. પ્રથમ નામની જોડણી સુધારો, અથવા આખું પિતૃ-નામ તેના આદ્યાક્ષરમાં ઘટાડો." : `No arbitrary second initial is ever injected beside an existing middle token (<em>Amarkumar U Kishorbhai</em> is rejected), and no letter is invented where a real patronymic is known. Tune the first name's spelling, or compress the full patronymic into its own initial.`}</div>
    </div>`;
  }

  function spellingTableHtml(rows) {
    const lang = getLang();
    if (!rows || !rows.length) return "";
    // Candidates without a computed practicality (legacy callers) are rated on
    // the fly so the column is never blank.
    const rated = rows.map((v) => v.practicality ? v : { ...v, practicality: namePracticality(v, "") });
    const stars = (score) => "★".repeat(score) + "☆".repeat(Math.max(0, 5 - score));
    const H = {
      spelling: lang === "hi" ? "सुझाई गई स्पेलिंग" : lang === "gu" ? "સૂચવેલી સ્પેલિંગ" : "Suggested spelling",
      strategy: lang === "hi" ? "रणनीति" : lang === "gu" ? "વ્યૂહરચના" : "Strategy",
      window: lang === "hi" ? "कहाँ लागू होगी" : lang === "gu" ? "ક્યાં લાગુ પડશે" : "Applies to",
      total: lang === "hi" ? "नया कुल योग" : lang === "gu" ? "નવો સરવાળો" : "New total",
      practicality: lang === "hi" ? "व्यावहारिकता" : lang === "gu" ? "વ્યવહારુતા" : "Pronunciation & practicality",
      why: lang === "hi" ? "यह कैसे मदद करता है" : lang === "gu" ? "આ કેવી રીતે મદદ કરે છે" : "Why it helps"
    };
    /* Window 1 then Window 2 — the everyday identity first because it is the
       one the client can change today without a single form. Inside a window:
       the authentic family initial, the generic middle initials, the
       patronymic compressions, and finally the pronunciation-preserving
       alterations. Each row states its window and strategy, each group
       explains itself once, and the literal letter change stays on the row as
       a data attribute so audits and smoke assertions can still see exactly
       what was doubled, added or compressed. */
    const source = rated.slice().sort(compareSpellingRows);
    return `<div class="table-scroll"><table class="rtable spelling-table">
      <tr><th>${H.spelling}</th><th>${H.strategy}</th><th>${H.window}</th><th>${H.total}</th><th>${H.practicality}</th><th>${H.why}</th></tr>
      ${source.map((v, i) => {
        const strategy = nameStrategyOf(v.kind, lang);
        const win = nameWindowOf(v.window, lang);
        /* The strategy and window explanations belong to their group, not to
           every row: each prints once, on the first row that uses it. */
        const prevStrategy = i > 0 ? nameStrategyOf(source[i - 1].kind, lang) : null;
        const prevWindow = i > 0 ? nameWindowOf(source[i - 1].window, lang) : null;
        const showStrategyHint = !prevStrategy || prevStrategy.key !== strategy.key;
        const showWindowHint = !prevWindow || prevWindow.key !== win.key;
        const legalSafe = strategy.key === "middle-initial" || strategy.key === "authentic-middle-initial";
        return `<tr data-spelling-strategy="${esc(strategy.key)}" data-window="${esc(win.key)}" data-change="${esc(v.change || "")}"${v.authentic ? ' data-authentic-initial="true"' : ""}>
          <td><strong>${esc(v.text)}</strong></td>
          <td><div class="spelling-cell-title"><span class="badge ${legalSafe ? "good" : "info"}" data-strategy="${esc(strategy.key)}">${esc(strategy.label)}</span></div>${showStrategyHint ? `<div class="card-sub" data-strategy-hint="${esc(strategy.key)}">${esc(strategy.hint)}</div>` : ""}</td>
          <td><div class="spelling-cell-title"><span class="badge ${win.key === "public" ? "info" : "warn"}" data-window-badge="${esc(win.key)}">${esc(win.label)}</span></div>${showWindowHint ? `<div class="card-sub" data-window-hint="${esc(win.key)}">${esc(win.hint)}</div>` : ""}</td>
          <td><strong>${v.compound}</strong> <span class="card-sub" data-new-number="${v.reduced}">(${v.reduced})</span></td>
          <td data-practicality="${v.practicality.score}"><span class="practicality-stars" aria-hidden="true">${stars(v.practicality.score)}</span> ${esc(v.practicality.label)}${v.practicality.notes.length ? `<div class="card-sub">${v.practicality.notes.map(esc).join(" · ")}</div>` : ""}</td>
          <td>${esc(v.why)}</td>
        </tr>`;
      }).join("")}
    </table></div>`;
  }

  /* Excess-energy channeling card — numbers repeated 3+ times get a full,
     prescriptive "overshoot / channel it" card instead of one generic line. */
  function renderExcessEnergyCard(p) {
    const db = getActiveDB();
    const lang = getLang();
    const rows = p.loShuRepeated.map((n) => {
      const entry = (db.excessEnergy && db.excessEnergy[n]) || {};
      const overshoot = loc(entry.overshoot, lang);
      const channel = loc(entry.channel, lang);
      const count = p.loShuCounts[n] || 0;
      return `<div class="kit-row"><div class="kit-ico"><strong>${n}</strong></div><div class="kit-body">
        <div class="kit-label">${esc(db.numbers[n].planet)} — ${lang === "hi" ? `${count}× दोहराया` : lang === "gu" ? `${count}× પુનરાવર્તિત` : `repeated ${count}×`}</div>
        <div class="kit-value"><strong>${lang === "hi" ? "जब यह बढ़ता है:" : lang === "gu" ? "જ્યારે તે વધુ થાય:" : "When it overshoots:"}</strong> ${esc(overshoot)}</div>
        <div class="kit-value"><strong>${lang === "hi" ? "इसे दिशा दें:" : lang === "gu" ? "તેને દિશા આપો:" : "Channel it:"}</strong> ${esc(channel)}</div>
        ${n === 1 ? solarModerationNote(p, lang, { context: "excess" }) : ""}
      </div></div>`;
    }).join("");
    const guidance = lang === "hi"
      ? "यह लो शू का repeated-number signal है: प्रतिभा को दिशा दें, अधिक ईंधन नहीं। उसी अंक को बढ़ाने वाले नाम, मोबाइल या वाहन कुल से बचें और ऊपर की आदतों में ऊर्जा लगाएं।"
      : lang === "gu"
        ? "આ લો શુનો repeated-number signal છે: પ્રતિભાને દિશા આપો, વધુ બળતણ નહીં. એ જ અંક વધારતા નામ, મોબાઇલ અથવા વાહન ટોટલ ટાળો અને ઊર્જા ઉપરની આદતોમાં લગાવો."
        : "This is a Lo Shu repeated-number signal: give the talent direction, not more fuel. Avoid name, mobile or vehicle totals that pile onto the same number; put the surplus into the habits above.";
    return `<div class="card" data-remedy-authority="lo-shu"><div class="card-title">${lang === "hi" ? "अधिक ऊर्जा — सही दिशा में" : lang === "gu" ? "વધુ ઊર્જા — યોગ્ય દિશામાં" : "Excess Energy — Channel It"}</div><div class="kit">${rows}</div><div class="card-sub">${guidance}</div></div>`;
  }

  /* Karmic Debt card — scans the three classical unreduced totals
     (birth day, full birth-date sum, Chaldean name total) for 13/14/16/19.
     A clean slate is stated explicitly so users trust the check ran.
     Remedies route through the remedy kit of the debt's reduced root. */
  function karmicDebtCard(p) {
    const db = getActiveDB();
    const lang = getLang();
    const debts = p.karmicDebts || [];
    const srcLabel = (src) => src === "driver"
      ? (lang === "hi" ? "जन्म तिथि" : lang === "gu" ? "જન્મ તિથિ" : "Birth day")
      : src === "conductor"
        ? (lang === "hi" ? "पूर्ण जन्मतिथि का योग" : lang === "gu" ? "સંપૂર્ણ જન્મતારીખનો સરવાળો" : "Full birth-date total")
        : src === "legalName"
          ? (lang === "hi" ? "कानूनी नाम का चाल्डियन योग" : lang === "gu" ? "કાનૂની નામનો કાલ્ડિયન સરવાળો" : "Legal-name Chaldean total")
          : (lang === "hi" ? "नाम का चाल्डियन योग" : lang === "gu" ? "નામનો કાલ્ડિયન સરવાળો" : "Name Chaldean total");
    const rows = debts.map((kd) => {
      const e = (db.karmicDebt && db.karmicDebt[kd.n]) || {};
      const rootInfo = db.numbers[reduce(kd.n)] || {};
      return `<div class="kit-row">
        <div class="kit-ico bad-ico"><strong>${kd.n}</strong></div>
        <div class="kit-body">
          <div class="kit-label">${esc(srcLabel(kd.source))} — ${esc(loc(e.title, lang) || `Karmic Debt ${kd.n}`)}</div>
          <div class="kit-value"><strong>${lang === "hi" ? "दोहराती सीख:" : lang === "gu" ? "વારંવાર આવતી સીખ:" : "Repeating lesson:"}</strong> ${esc(loc(e.lesson, lang))}</div>
          <div class="kit-value"><strong>${lang === "hi" ? "निवारण:" : lang === "gu" ? "નિવારણ:" : "Settling remedy:"}</strong> ${esc(loc(e.remedy, lang))}</div>
          <div class="card-sub">${lang === "hi" ? `यह अंक ${kd.n} → ${reduce(kd.n)} में सिमटता है — पूर्ण सहायता के लिए ${esc(rootInfo.planet || "")} उपाय-किट भी अपनाएं।` : lang === "gu" ? `આ અંક ${kd.n} → ${reduce(kd.n)} માં સંયોજાય છે — સંપૂર્ણ સહાય માટે ${esc(rootInfo.planet || "")} ઉપાય-કિટ પણ અપનાવો.` : `This debt reduces to ${kd.n} → ${reduce(kd.n)} — pair it with the ${esc(rootInfo.planet || "")} remedy kit for full support.`}</div>
        </div>
      </div>`;
    }).join("");
    const clean = lang === "hi"
      ? "जन्म तिथि, पूर्ण जन्मतिथि के योग और नाम के चाल्डियन योग में कर्मऋण अंक (13, 14, 16, 19) में से कोई नहीं है — जन्म-पट्टिका का कर्म पट्ट साफ है।"
      : lang === "gu"
        ? "જન્મ તિથિ, સંપૂર્ણ જન્મતારીખના સરવાળા અને નામના કાલ્ડિયન સરવાળામાં કર્મઋણ અંકો (13, 14, 16, 19) પૈકી કોઈ નથી — જન્મ-પત્રિકાનો કર્મ હિસાબ સ્વચ્છ છે."
        : "None of the karmic debt numbers (13, 14, 16, 19) appear in your birth day, full birth-date total or name total — a clean karmic slate.";
    const judgeNote = lang === "hi"
      ? "कर्मऋण हमेशा <strong>सीमांत (गैर-संक्षिप्त) योग</strong> पर जांचा जाता है — जन्म तिथि जैसी है, पूरी जन्मतिथि के अंकों का कुल योग, और नाम का पूरा चाल्डियन योग। केवल अंतिम अंक (मूलांक/भाग्यांक/नामांक) देखने से ये सीख छूट जाती हैं।"
      : lang === "gu"
        ? "કર્મઋણ હંમેશાં <strong>અઘટિત (બિન-ઘટાડેલા) સરવાળા</strong> પર તપાસાય છે — જન્મ તિથિ જેમ છે તેમ, સંપૂર્ણ જન્મતારીખના અંકોનો કુલ સરવાળો, અને નામનો સંપૂર્ણ કાલ્ડિયન સરવાળો. ફક્ત અંતિમ અંક (મૂળાંક/ભાગ્યાંક/નામાંક) જોવાથી આ સીખ છૂટી જાય છે."
        : "Karmic debt is always checked at the <strong>unreduced subtotal</strong> — the birth day as it falls, the digit sum of the entire birth date, and the full Chaldean name total. Reading only the final Driver/Conductor/Name digit would miss these lessons.";
    return `<div class="card" id="karmic-debt-card">
      <div class="goal-head">
        <div class="card-title">${t("karmicDebtTitle", "Karmic Debt Check — 13 · 14 · 16 · 19")}</div>
        <span class="badge ${debts.length ? "warn" : "good"}">${debts.length ? (lang === "hi" ? `${debts.length} मिले` : lang === "gu" ? `${debts.length} મળ્યા` : `${debts.length} found`) : (lang === "hi" ? "कोई कर्मऋण नहीं" : lang === "gu" ? "કોઈ કર્મઋણ નહીં" : "Clean slate")}</span>
      </div>
      ${debts.length ? `<div class="kit">${rows}</div>` : `<div class="kit-value">${clean}</div>`}
      <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${judgeNote}</div>
    </div>`;
  }

  /* Ayurvedic dosha card — a Driver/Conductor-only constitution baseline.
     Lo Shu and advanced Vedic grid signals do not modify this layer. */
  function doshaCard(p) {
    const db = getActiveDB();
    const lang = getLang();
    const d = p.doshaProfile || {};
    const labels = lang === "hi" ? { pitta: "पित्त", vata: "वात", kapha: "कफ" }
      : lang === "gu" ? { pitta: "પિત્ત", vata: "વાત", kapha: "કફ" }
        : { pitta: "Pitta", vata: "Vata", kapha: "Kapha" };
    const doshaName = (value) => String(value || "").split(/[\s\u2013\-/,]+/).map((word) => labels[word.toLowerCase()] || word).filter(Boolean).join("–");
    const row = (n, entry, role) => `<div class="kit-row"><div class="kit-ico"><strong>${n}</strong></div><div class="kit-body"><div class="kit-label">${esc(db.numbers[n].planet)} · ${esc(role)} → ${doshaName(entry.dominant)}</div><div class="kit-value">${esc(loc(entry.nature, lang))}</div><div class="card-sub">${lang === "hi" ? "संतुलन:" : lang === "gu" ? "સંતુલન:" : "Balance:"} ${esc(loc(entry.routine, lang))}</div></div></div>`;
    const blend = ["pitta", "vata", "kapha"].map((key) => `${labels[key]} ${d.counts && d.counts[key] || 0}`).join(" · ");
    const foods = [loc(d.driverDosha && d.driverDosha.balancingFoods, lang), loc(d.conductorDosha && d.conductorDosha.balancingFoods, lang)].filter(Boolean).join(" ");
    return `<div class="card" id="dosha-card" data-authority="driver-conductor"><div class="goal-head"><div class="card-title">${lang === "hi" ? "आयुर्वेदिक दोष स्तर — आपकी प्रकृति" : lang === "gu" ? "આયુર્વેદિક દોષ સ્તર — તમારી પ્રકૃતિ" : "Ayurvedic Dosha Layer — Your Constitution"}</div><span class="badge warn">${doshaName(d.primary) || (lang === "hi" ? "संतुलित" : lang === "gu" ? "સંતુલિત" : "Balanced")}</span></div>
      <div class="card-sub">${lang === "hi" ? "यह baseline केवल मूलांक और भाग्यांक से आता है — लो शू या वैदिक-grid की missing/repeated cells इसे नहीं बदलतीं।" : lang === "gu" ? "આ baseline ફક્ત મૂળાંક અને ભાગ્યાંકથી આવે છે — લો શુ અથવા વૈદિક-grid ની missing/repeated cells તેને બદલતી નથી." : "This baseline comes only from your Driver and Conductor — Lo Shu or Vedic-grid missing/repeated cells do not change it."}</div>
      <div class="kit">${row(d.driverNumber, d.driverDosha || {}, lang === "hi" ? "मूलांक" : lang === "gu" ? "મૂલાંક" : "Driver")}${row(d.conductorNumber, d.conductorDosha || {}, lang === "hi" ? "भाग्यांक" : lang === "gu" ? "ભાગ્યાંક" : "Conductor")}</div>
      <div class="kit"><div class="kit-label">${lang === "hi" ? "मिश्रित प्रकृति" : lang === "gu" ? "મિશ્ર પ્રકૃતિ" : "Blended constitution"}</div><div class="kit-value"><strong>${doshaName(d.primary)}</strong> — ${blend}</div><div class="kit-value"><strong>${lang === "hi" ? "संतुलन-पोषण:" : lang === "gu" ? "સંતુલન-પોષણ:" : "Balancing foods:"}</strong> ${esc(foods)}</div></div>
      ${solarModerationNote(p, lang, { context: "dosha" })}
      <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${lang === "hi" ? "यह पारंपरिक wellness guidance है, निदान नहीं; चिकित्सा सलाह के लिए योग्य पेशेवर से बात करें।" : lang === "gu" ? "આ પરંપરાગત wellness guidance છે, નિદાન નથી; તબીબી સલાહ માટે લાયક વ્યાવસાયિક સાથે વાત કરો." : "This is traditional wellness guidance, not a diagnosis; speak with a qualified professional for medical advice."}</div></div>`;
  }

  /* Deity Protection Layer — Ishta Devta card. Names the guardian deity
     (ishta devta) behind the Driver and Conductor numbers, with the
     guiding archetypes, short mantra, cadence & day, offerings and
     presentation copy. Framed as traditional spiritual guidance: the
     reader's own family tradition and guru's instruction take priority. */
  function deityCard(p) {
    const dp = p.deityProfile || {};
    const db = getActiveDB();
    const lang = getLang();
    const L = (obj) => {
      if (!obj) return "";
      if (typeof obj === "string") return obj;
      return obj[lang] || obj.en || "";
    };
    const guardians = [];
    if (dp.driverDeity) {
      guardians.push({
        n: dp.driverNumber,
        role: dp.sameDeity && dp.driverNumber === dp.conductorNumber
          ? (lang === "hi" ? "ड्राइवर व कंडक्टर / मूलांक व भाग्यांक" : lang === "gu" ? "ડ્રાઈવર અને કન્ડક્ટર / મૂળાંક અને ભાગ્યાંક" : "Driver & Conductor / Moolank & Bhagyank")
          : (lang === "hi" ? "ड्राइवर / मूलांक" : lang === "gu" ? "ડ્રાઈવર / મૂળાંક" : "Driver / Moolank"),
        deity: dp.driverDeity
      });
    }
    if (dp.conductorDeity && !dp.sameDeity) {
      guardians.push({
        n: dp.conductorNumber,
        role: lang === "hi" ? "कंडक्टर / भाग्यांक" : lang === "gu" ? "કન્ડક્ટર / ભાગ્યાંક" : "Conductor / Bhagyank",
        deity: dp.conductorDeity
      });
    }

    const rows = guardians.map((guard) => {
      const numInfo = (db.numbers && db.numbers[guard.n]) || {};
      const planetName = numInfo.planet || "";
      const archetypes = L(guard.deity.archetypes || guard.deity.god);
      const mantra = guard.deity.mantra || "";
      const cadence = L(guard.deity.cadence) || [L(guard.deity.primaryChant), L(guard.deity.weeklyChant)].filter(Boolean).join(" · ");
      const offerings = L(guard.deity.offerings);
      const presCopy = L(guard.deity.presentationCopy || guard.deity.protectionNote);

      const archetypesLabel = lang === "hi" ? "मार्गदर्शक स्वरूप:" : lang === "gu" ? "માર્ગદર્શક સ્વરૂપ:" : "Guiding Archetypes:";
      const mantraLabel = lang === "hi" ? "लघु मंत्र:" : lang === "gu" ? "લઘુ મંત્ર:" : "Short Mantra:";
      const cadenceLabel = lang === "hi" ? "जाप क्रम व वार:" : lang === "gu" ? "જાપ ક્રમ અને વાર:" : "Cadence & Day:";
      const offeringsLabel = lang === "hi" ? "भोग व अर्पण:" : lang === "gu" ? "ભોગ અને અર્પણ:" : "Offerings:";
      const presLabel = lang === "hi" ? "स्वरूप मार्गदर्शन:" : lang === "gu" ? "સ્વરૂપ માર્ગદર્શન:" : "Archetype Guidance:";

      return `<div class="kit-row">
        <div class="kit-ico"><strong>${guard.n}</strong></div>
        <div class="kit-body">
          <div class="kit-label">${esc(guard.role)} · Number ${guard.n} — ${esc(planetName)}</div>
          <div class="kit-value"><strong>${archetypesLabel}</strong> <strong>${esc(archetypes)}</strong></div>
          <div class="kit-value"><strong>${mantraLabel}</strong> <span class="mantra">${esc(mantra)}</span></div>
          <div class="card-sub"><strong>${cadenceLabel}</strong> ${esc(cadence)}</div>
          <div class="card-sub"><strong>${offeringsLabel}</strong> ${esc(offerings)}</div>
          ${presCopy ? `<div class="card-sub" style="margin-top:4px;"><strong>${presLabel}</strong> <em>${esc(presCopy)}</em></div>` : ""}
        </div>
      </div>`;
    }).join("");

    const badge = dp.sameDeity
      ? L(dp.driverDeity && (dp.driverDeity.archetypes || dp.driverDeity.god))
      : guardians.map((g) => L(g.deity.archetypes || g.deity.god)).join(" · ");

    return `<div class="card" id="deity-card" data-authority="driver-conductor">
      <div class="goal-head">
        <div class="card-title">${lang === "hi" ? "देव-संरक्षण स्तर — आपका इष्ट देवता" : lang === "gu" ? "દેવ-સંરક્ષણ સ્તર — તમારો ઈષ્ટ દેવતા" : "Deity Protection Layer — Your Ishta Devta"}</div>
        <span class="badge">${esc(badge)}</span>
      </div>
      <div class="card-sub">${lang === "hi" ? "रक्षक देव केवल आपके मूलांक और भाग्यांक से चुने जाते हैं। लो शू और उन्नत वैदिक तुलना इस चयन को नहीं बदलते।" : lang === "gu" ? "રક્ષક દેવ ફક્ત તમારા મૂળાંક અને ભાગ્યાંકથી પસંદ થાય છે. લો શુ અને ઉન્નત વૈદિક તુલના આ પસંદગી બદલતી નથી." : "Guardian deities are selected only from your Driver and Conductor. Lo Shu and the advanced Vedic comparison never change this selection."}</div>
      <div class="kit">${rows}</div>
      ${dp.sameDeity ? `<div class="kit-value">${lang === "hi" ? "एक ही इष्ट देव दोनों मुख्य अंकों का सहारा हैं।" : lang === "gu" ? "એક જ ઇષ્ટ દેવ બંને મુખ્ય અંકોનો સહારો છે." : "One ishta devta supports both of your key numbers."}</div>` : ""}
      <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${lang === "hi" ? "यह पारंपरिक आध्यात्मिक मार्गदर्शन है; अपनी कुल-परंपरा और गुरु की शिक्षा को प्राथमिकता दें।" : lang === "gu" ? "આ પરંપરાગત આધ્યાત્મિક માર્ગદર્શન છે; તમારી કુળ-પરંપરા અને ગુરુની શિક્ષાને પ્રાથમિકતા આપો." : "This is traditional spiritual guidance; give priority to your family tradition and guru's instruction."}</div>
    </div>`;
  }

  function gridConfigIsCanonical(layout, canonical) {
    return Array.isArray(layout) && layout.length === 3 &&
      layout.every((row) => Array.isArray(row) && row.length === 3) &&
      layout.flat().join(",") === canonical.flat().join(",");
  }

  function loShuGridConfig(db) {
    const configured = (db && db.loShuGrid) || {};
    const fallback = (window.DB && window.DB.loShuGrid) || {};
    const layout = gridConfigIsCanonical(configured.layout, LO_SHU_GRID_LAYOUT)
      ? configured.layout : LO_SHU_GRID_LAYOUT;
    const isPlaneSet = (planes) => Array.isArray(planes) && planes.length === LO_SHU_PLANE_CELLS.length &&
      planes.every((plane, i) => plane && Array.isArray(plane.cells) && plane.cells.join(",") === LO_SHU_PLANE_CELLS[i].join(","));
    const isArrowSet = (arrows) => Array.isArray(arrows) && arrows.length === LO_SHU_ARROW_LINES.length &&
      arrows.every((arrow, i) => arrow && Array.isArray(arrow.line) && arrow.line.join(",") === LO_SHU_ARROW_LINES[i].join(","));
    return {
      layout,
      planes: isPlaneSet(configured.planes) ? configured.planes : (isPlaneSet(fallback.planes) ? fallback.planes : []),
      arrows: isArrowSet(configured.arrows) ? configured.arrows : (isArrowSet(fallback.arrows) ? fallback.arrows : []),
      plotting: configured.plotting || fallback.plotting || {}
    };
  }

  function vedicGridConfig(db) {
    const configured = (db && db.vedicGrid) || {};
    const layout = gridConfigIsCanonical(configured.layout, VEDIC_GRID_LAYOUT)
      ? configured.layout : VEDIC_GRID_LAYOUT;
    const planes = Array.isArray(configured.planes) && configured.planes.length === DEFAULT_VEDIC_PLANES.length &&
      configured.planes.every((plane, i) => plane && plane.key === DEFAULT_VEDIC_PLANES[i].key &&
        Array.isArray(plane.cells) && plane.cells.join(",") === DEFAULT_VEDIC_PLANES[i].cells.join(","))
      ? configured.planes : DEFAULT_VEDIC_PLANES;
    return { layout, planes, filtering: configured.filtering || {} };
  }

  function gridCopy(lang) {
    const copies = {
      en: {
        present: "Present", repeated: "Repeated", missing: "Missing", weak: "Single occurrence",
        birth: "Birth Grid", name: "Name Grid", combined: "Combined Grid", source: "Source",
        plotted: "Plotted digits", treatment: "Treatment", day: "Birth day", month: "Birth month", year: "Birth year",
        driver: "Driver / Moolank", conductor: "Conductor / Bhagyank", complete: "Complete", partial: "Partial",
        needsSupport: "Needs conscious support", strengths: "Strengths", gaps: "Growth cues"
      },
      hi: {
        present: "उपस्थित", repeated: "दोहराया", missing: "अनुपस्थित", weak: "एक बार उपस्थित",
        birth: "जन्म ग्रिड", name: "नाम ग्रिड", combined: "संयुक्त ग्रिड", source: "स्रोत",
        plotted: "रखे गए अंक", treatment: "नियम", day: "जन्म दिन", month: "जन्म माह", year: "जन्म वर्ष",
        driver: "मूलांक", conductor: "भाग्यांक", complete: "पूर्ण", partial: "आंशिक",
        needsSupport: "सजग सहारा चाहिए", strengths: "शक्तियां", gaps: "विकास संकेत"
      },
      gu: {
        present: "હાજર", repeated: "પુનરાવર્તિત", missing: "ખૂટતો", weak: "એક વાર હાજર",
        birth: "જન્મ ગ્રિડ", name: "નામ ગ્રિડ", combined: "સંયુક્ત ગ્રિડ", source: "સ્ત્રોત",
        plotted: "મૂકેલા અંકો", treatment: "નિયમ", day: "જન્મ દિવસ", month: "જન્મ મહિનો", year: "જન્મ વર્ષ",
        driver: "મૂલાંક", conductor: "ભાગ્યાંક", complete: "સંપૂર્ણ", partial: "આંશિક",
        needsSupport: "સભાન સહારો જોઈએ", strengths: "શક્તિઓ", gaps: "વિકાસ સંકેતો"
      }
    };
    return copies[lang] || copies.en;
  }

  function renderLoShuGridCells(counts, label) {
    const db = getActiveDB();
    const copy = gridCopy(getLang());
    const layout = loShuGridConfig(db).layout;
    return layout.flat().map((n) => {
      const c = counts[n] || 0;
      const cls = c === 0 ? "missing" : c >= 3 ? "present multi" : "present";
      const digits = c ? Array(c).fill(n).map((x) => `<span>${x}</span>`).join("") : `<span>${n}</span>`;
      return `<div class="loshu-cell ${cls}" data-grid-engine="lo-shu" data-grid-number="${n}" data-missing-label="${esc(copy.missing)}" title="${esc(label || "Lo Shu")} · ${n}: ${c} occurrence${c === 1 ? "" : "s"}">
        <div class="digits">${digits}</div>
        ${c ? `<div class="cnt">${esc(db.numbers[n].planet.split(" ")[0])}</div>` : ""}
      </div>`;
    }).join("");
  }

  function renderLoShuGrid(p) {
    const db = getActiveDB();
    const lang = getLang();
    const copy = gridCopy(lang);
    const config = loShuGridConfig(db);
    const grid = p.loShuGrid || generateLoShuGrid(p.day, p.month, p.year);
    const numberList = (numbers) => numbers && numbers.length ? numbers.join(", ") : "—";
    const planeCards = config.planes.map((plane) => {
      const present = plane.cells.filter((n) => p.loShuCounts[n] > 0);
      const absent = plane.cells.filter((n) => p.loShuCounts[n] === 0);
      const chips = plane.cells.map((n) => `<span class="plane-chip ${p.loShuCounts[n] > 0 ? "on" : "off"}">${n}</span>`).join("");
      const missingRoles = absent.map((n) => {
        const role = plane.roles && plane.roles[n] ? plane.roles[n] : {};
        return `${n} — ${role.label || role.short || "support"}${role.fix ? `: ${role.fix}` : ""}`;
      });
      const complete = present.length === plane.cells.length;
      const reading = complete ? (plane.complete || "This Lo Shu line is fully represented.")
        : missingRoles.length ? missingRoles.join(" · ") : (plane.about || "");
      return `<article class="card plane-card loshu-plane-card">
        <div class="goal-head"><div class="card-title">${esc(plane.name || "Lo Shu Plane")}</div><span class="badge ${complete ? "good" : "warn"}">${complete ? copy.complete : copy.partial}</span></div>
        <div class="card-sub">${esc(plane.zone || "")} · ${plane.cells.join(" – ")}</div>
        <div class="plane-chips">${chips}</div>
        <div class="kit-value plane-about">${esc(plane.about || "")}</div>
        <div class="kit-value"><strong>${complete ? copy.strengths : copy.gaps}:</strong> ${esc(reading)}</div>
      </article>`;
    }).join("");
    const arrowCards = config.arrows.map((arrow) => {
      const formed = arrow.line.every((n) => p.loShuCounts[n] > 0);
      const state = formed ? copy.present : copy.missing;
      return `<article class="card arrow-card ${formed ? "arrow-formed" : "arrow-open"}">
        <div class="goal-head"><div class="card-title">${esc(arrow.name || "Lo Shu Arrow")}</div><span class="badge ${formed ? "good" : "warn"}">${state}</span></div>
        <div class="card-sub">${esc(arrow.axis || "")} · ${arrow.line.join(" – ")}</div>
        <div class="kit-value">${esc(formed ? arrow.present : arrow.missing)}</div>
      </article>`;
    }).join("");
    const severityByNumber = {};
    p.loShuMissingSeverity.forEach((entry) => { severityByNumber[entry.n] = entry; });
    const missingFixes = p.loShuMissing.map((n) => {
      const severity = severityByNumber[n];
      const badge = severity && severity.critical
        ? `<span class="badge bad">${t("critical", "Critical")}</span>`
        : severity && severity.echoedBy.length
          ? `<span class="badge warn">${esc(severity.echoedBy.join(" / "))}</span>` : "";
      return `<div class="kit-row"><div class="kit-ico bad-ico"><strong>${n}</strong></div><div class="kit-body">
        <div class="kit-label">${esc(db.numbers[n].planet)} — ${copy.missing} ${badge}</div>
        <div class="kit-value">${esc(db.missingFix[n] || "Build a steady, practical habit around this quality.")}</div>
      </div></div>`;
    }).join("");
    // Render the two root calculations as grouped, labelled equations rather
    // than a single monospace digit string. Monospace zero glyphs (dotted /
    // slashed) print poorly in PDF and OCR as 8, and a wrapped "3 +" was read
    // as "$" — see the 31/01/1978 report bug. Grouping by day / month / year
    // also makes the day–month boundary unambiguous.
    const conductorFormula = rootFormulaMarkup([
      { label: copy.day, digits: grid.raw.day },
      { label: copy.month, digits: grid.raw.month },
      { label: copy.year, digits: grid.raw.year }
    ], grid.calculations.destinyDigitSum, p.conductor, lang);
    const driverFormula = rootFormulaMarkup([{ label: copy.day, digits: grid.raw.day }], grid.calculations.rulingDigitSum, p.driver, lang);
    const calendarCheck = `${Number(grid.raw.day)} + ${Number(grid.raw.month)} + ${Number(grid.raw.year)} = ${grid.calculations.destinyCalendarSum} → ${reductionChain(grid.calculations.destinyCalendarSum).slice(1).join(" → ") || grid.calculations.destinyCalendarSum}`;
    const sourceRows = [
      [copy.day, numberList(grid.sourceDigits.day), "All non-zero day digits"],
      [copy.month, numberList(grid.sourceDigits.month), "All non-zero month digits"],
      [copy.year, numberList(grid.sourceDigits.year), "Full year, including century digits"],
      [copy.driver, String(p.driver), "Added after raw DOB digits"],
      [copy.conductor, String(p.conductor), "Added after raw DOB digits"]
    ].map(([source, digits, treatment]) => `<tr><td><strong>${esc(source)}</strong></td><td>${esc(digits)}</td><td>${esc(treatment)}</td></tr>`).join("");

    return `<section class="rsection" id="loshu-grid-section" data-remedy-authority="lo-shu">
      <h2 class="rsection-title"><span class="idx">${SECTION.grid}</span>${t("secLoShuGrid", "Lo Shu Blueprint — Your Foundation")}</h2>
      <div class="card loshu-grid-intro">
        <div class="card-title">${lang === "hi" ? "क्लासिक लो शू जन्म-पट्टिका" : lang === "gu" ? "ક્લાસિક લો શુ જન્મ-પટ્ટિકા" : "Classic Lo Shu Birth Blueprint"}</div>
        <div class="kit-value">${lang === "hi" ? "यह आपका प्राथमिक Foundation grid है: ४–९–२ / ३–५–७ / ८–१–६। जन्म, नाम और संयुक्त ग्रिड के संकेत यहां व्यक्तित्व, आदतों और ४०-दिवसीय अभ्यास को चलाते हैं।" : lang === "gu" ? "આ તમારું મુખ્ય Foundation grid છે: ૪–૯–૨ / ૩–૫–૭ / ૮–૧–૬. જન્મ, નામ અને સંયુક્ત ગ્રિડના સંકેતો અહીં વ્યક્તિત્વ, આદતો અને ૪૦-દિવસના અભ્યાસને માર્ગદર્શન આપે છે." : "This is your primary Foundation grid: 4–9–2 / 3–5–7 / 8–1–6. Its Birth, Name and Combined signals guide personality patterns, habits and the 40-day practice."}</div>
        <div class="judge-note">${lang === "hi" ? "उपाय-अधिकार: अनुपस्थित और दोहराए अंक केवल लो शू से आते हैं। आयुर्वेद, इष्ट देव और power days केवल मूलांक/भाग्यांक से आते हैं; समय और सक्रिय वास्तु क्षेत्र केवल दशा से आते हैं।" : lang === "gu" ? "ઉપાય-અધિકાર: ખૂટતા અને પુનરાવર્તિત અંકો ફક્ત લો શુમાંથી આવે છે. આયુર્વેદ, ઇષ્ટ દેવ અને power days ફક્ત મૂળાંક/ભાગ્યાંકથી આવે છે; સમય અને સક્રિય વાસ્તુ ક્ષેત્ર ફક્ત દશાથી આવે છે." : "Authority boundary: missing and repeated-number remedies come only from Lo Shu. Ayurveda, guardian deities and power days come only from Driver/Conductor; timing and active Vastu zones come only from Dasha."}</div>
      </div>
      <div class="loshu-grid-wrap">
        <div><div class="loshu-grid" role="img" aria-label="Classic Lo Shu Birth Grid">${renderLoShuGridCells(p.loShuCounts, copy.birth)}</div>
          <div class="vedic-legend" style="margin-top:8px"><span><i class="dot g"></i>${copy.present}</span><span><i class="dot y"></i>${copy.repeated}</span><span><i class="dot w"></i>${copy.missing}</span></div></div>
        <div class="card"><div class="card-title">${copy.birth}</div>
          <div class="kit-value"><span class="badge good">${copy.present}</span> ${Object.keys(p.loShuCounts).filter((k) => p.loShuCounts[k] > 0).join(", ") || "—"}</div>
          ${p.loShuWeak.length ? `<div class="kit-value"><span class="badge warn">${copy.weak}</span> ${p.loShuWeak.join(", ")}</div>` : ""}
          <div class="kit-value"><span class="badge bad">${copy.missing}</span> ${p.loShuMissing.length ? p.loShuMissing.join(", ") : copy.complete}</div>
        </div>
      </div>
      <div class="card"><div class="card-title">${lang === "hi" ? "लो शू प्लॉटिंग नियम" : lang === "gu" ? "લો શુ પ્લોટિંગ નિયમો" : "Lo Shu plotting rules"}</div>
        <div class="kit-value"><strong>1.</strong> ${esc(config.plotting.zeros || "Remove every 0 before plotting.")}<br><strong>2.</strong> ${esc(config.plotting.year || "Plot all non-zero digits of the full birth date, including century digits.")}<br><strong>3.</strong> ${esc(config.plotting.calculations || "Add Driver and Conductor after the raw DOB digits.")}</div>
        <div class="vedic-calculation-grid"><div><span class="kit-label">${copy.driver}</span>${driverFormula}</div><div><span class="kit-label">${copy.conductor}</span>${conductorFormula}<div class="card-sub root-formula-check">${lang === "hi" ? "कैलेंडर जांच" : lang === "gu" ? "કેલેન્ડર ચકાસણી" : "Calendar check"}: ${calendarCheck}</div></div></div>
      </div>
      <div class="card"><div class="card-title">${lang === "hi" ? "आपकी जन्म-पट्टिका कैसे बनी" : lang === "gu" ? "તમારી જન્મ-પટ્ટિકા કેવી રીતે બની" : "How your Lo Shu Birth Grid was plotted"}</div><div class="table-scroll"><table class="rtable"><tr><th>${copy.source}</th><th>${copy.plotted}</th><th>${copy.treatment}</th></tr>${sourceRows}</table></div></div>
      <div class="card-grid two loshu-secondary-grids">
        <div class="card"><div class="card-title">${copy.name}</div><div class="loshu-grid compact" role="img" aria-label="Lo Shu Name Grid">${renderLoShuGridCells(p.loShuNameCounts, copy.name)}</div><div class="card-sub">${lang === "hi" ? "आपके दैनिक नाम के चाल्डियन अक्षर-मूल्य उसी लो शू निर्देशांकों पर।" : lang === "gu" ? "તમારા દૈનિક નામના ચાલ્ડિયન અક્ષર-મૂલ્યો એ જ લો શુ નિર્દેશાંકો પર." : "The Chaldean values in your everyday name, mapped onto the same Lo Shu coordinates."}</div></div>
        <div class="card"><div class="card-title">${copy.combined}</div><div class="loshu-grid compact" role="img" aria-label="Lo Shu Combined Grid">${renderLoShuGridCells(p.loShuCombinedCounts, copy.combined)}</div><div class="card-sub">${lang === "hi" ? "जन्म और नाम का संयुक्त संकेत — आप दुनिया में किस ऊर्जा को मजबूत करते हैं।" : lang === "gu" ? "જન્મ અને નામનો સંયુક્ત સંકેત — તમે વિશ્વમાં કઈ ઊર્જા મજબૂત કરો છો." : "Your Birth and Name signals together — the energy you reinforce in the world."}</div></div>
      </div>
      <div class="plane-cards">${planeCards}</div>
      <div class="card"><div class="card-title">${lang === "hi" ? "लो शू तीर — बने हुए पैटर्न" : lang === "gu" ? "લો શુ તીર — બનેલા પેટર્ન" : "Lo Shu Arrows — formed patterns"}</div><div class="arrow-grid">${arrowCards}</div></div>
      ${p.loShuMissing.length ? `<div class="card" id="loshu-remedies"><div class="card-title">${lang === "hi" ? "अनुपस्थित अंक — लो शू उपाय" : lang === "gu" ? "ખૂટતા અંકો — લો શુ ઉપાયો" : "Missing Numbers — Lo Shu Remedies"}</div><div class="card-sub">${lang === "hi" ? "यही एकमात्र missing-number remedy checklist है।" : lang === "gu" ? "આ એકમાત્ર missing-number remedy checklist છે." : "This is the one and only missing-number remedy checklist."}</div><div class="kit">${missingFixes}</div></div>` : `<div class="card"><div class="kit-value"><span class="badge good">${copy.complete}</span> ${lang === "hi" ? "सभी लो शू अंक उपस्थित हैं — अभ्यास सुधार और स्थिरता के लिए रखें।" : lang === "gu" ? "બધા લો શુ અંકો હાજર છે — અભ્યાસ સુધારણા અને સાતત્ય માટે રાખો." : "All Lo Shu numbers are present — keep the practice for refinement and consistency."}</div></div>`}
      ${p.loShuRepeated.length ? `<div class="rsection-desc">${lang === "hi" ? "दोहराए गए ३+ अंक:" : lang === "gu" ? "૩+ વાર પુનરાવર્તિત અંકો:" : "Repeated 3+ times:"} <strong>${p.loShuRepeated.join(", ")}</strong></div>${renderExcessEnergyCard(p)}` : ""}
    </section>`;
  }

  function vedicGridCopy(lang) {
    const copy = {
      en: { title: "Vedic Birth Grid — Planetary Strength Indicators", intro: "An advanced comparison only. This birth-only Ank Kundali uses filtered DOB plotting and the Vedic layout 3–1–9 / 6–7–5 / 2–8–4.", present: "Present indicator", repeated: "Concentrated indicator", weak: "Single indicator", missing: "Absent indicator", note: "These indicators describe a separate Vedic lens. An absent or repeated indicator is not a missing-number remedy obligation and does not create another checklist.", source: "Source", plotted: "Plotted digits", treatment: "Vedic treatment", day: "Birth day", month: "Birth month", year: "Birth year", ruling: "Ruling Number", destiny: "Destiny Number", planesTitle: "What the three Vedic planes say", planesIntro: "Each horizontal row of the Ank Kundali is a plane. Read it by which planetary indicators are present — this is interpretation of natal strength, not a remedy list.", planeComplete: "Fully active", planePartial: "Partly active", planeEmpty: "Empty plane", planeActive: "Active indicators", planeAbsent: "Absent indicators" },
      hi: { title: "वैदिक जन्म ग्रिड — ग्रह-शक्ति संकेतक", intro: "केवल उन्नत तुलना। यह जन्म-अंक कुंडली छाने हुए DOB नियमों और ३–१–९ / ६–७–५ / २–८–४ वैदिक क्रम का उपयोग करती है।", present: "उपस्थित संकेतक", repeated: "सघन संकेतक", weak: "एकल संकेतक", missing: "अनुपस्थित संकेतक", note: "ये अलग वैदिक दृष्टि के संकेतक हैं। अनुपस्थित या दोहराया संकेतक missing-number remedy obligation नहीं बनाता और दूसरी checklist नहीं देता।", source: "स्रोत", plotted: "रखे गए अंक", treatment: "वैदिक नियम", day: "जन्म दिन", month: "जन्म माह", year: "जन्म वर्ष", ruling: "मूलांक", destiny: "भाग्यांक", planesTitle: "तीन वैदिक तल क्या कहते हैं", planesIntro: "अंक कुंडली की हर क्षैतिज पंक्ति एक तल है। इसे उपस्थित ग्रह-संकेतकों से पढ़ें — यह जन्म-बल की व्याख्या है, उपाय-सूची नहीं।", planeComplete: "पूर्ण सक्रिय", planePartial: "आंशिक सक्रिय", planeEmpty: "रिक्त तल", planeActive: "सक्रिय संकेतक", planeAbsent: "अनुपस्थित संकेतक" },
      gu: { title: "વૈદિક જન્મ ગ્રિડ — ગ્રહ-શક્તિ સંકેતકો", intro: "માત્ર ઉન્નત તુલના. આ જન્મ-અંક કુંડળી છાનેલા DOB નિયમો અને ૩–૧–૯ / ૬–૭–૫ / ૨–૮–૪ વૈદિક ક્રમ વાપરે છે.", present: "હાજર સંકેતક", repeated: "સઘન સંકેતક", weak: "એકલ સંકેતક", missing: "ગેરહાજર સંકેતક", note: "આ અલગ વૈદિક દૃષ્ટિના સંકેતકો છે. ગેરહાજર અથવા પુનરાવર્તિત સંકેતક missing-number remedy obligation બનતો નથી અને બીજી checklist આપતો નથી.", source: "સ્ત્રોત", plotted: "મૂકેલા અંકો", treatment: "વૈદિક નિયમ", day: "જન્મ દિવસ", month: "જન્મ મહિનો", year: "જન્મ વર્ષ", ruling: "મૂલાંક", destiny: "ભાગ્યાંક", planesTitle: "ત્રણ વૈદિક તલ શું કહે છે", planesIntro: "અંક કુંડળીની દરેક આડી હરોળ એક તલ છે. તેને હાજર ગ્રહ-સંકેતકોથી વાંચો — આ જન્મ-બળનું અર્થઘટન છે, ઉપાય-યાદી નહીં.", planeComplete: "પૂર્ણ સક્રિય", planePartial: "આંશિક સક્રિય", planeEmpty: "ખાલી તલ", planeActive: "સક્રિય સંકેતકો", planeAbsent: "ગેરહાજર સંકેતકો" }
    };
    return copy[lang] || copy.en;
  }

  /* Qualitative reading of the three Vedic planes (Practical/Fire 3-1-9,
     Materialistic/Air 6-7-5, Emotional/Water 2-8-4). Produces 1–2 sentences
     per plane from the present/absent indicator pattern. This is a strength
     lens only — it never mints remedy obligations (Lo Shu owns those). */
  const VEDIC_PLANE_READINGS = {
    practical: {
      complete: { en: "Vision (3), initiative (1) and courage (9) are all present — you can conceive a goal, take the first step and push it through. Execution is a natural strength; guard against doing everything yourself.", hi: "दृष्टि (3), पहल (1) और साहस (9) तीनों उपस्थित — लक्ष्य सोचना, पहला कदम और पूरा करना सहज है। सब कुछ स्वयं करने की प्रवृत्ति से बचें।", gu: "દૃષ્ટિ (3), પહેલ (1) અને હિંમત (9) ત્રણેય હાજર — લક્ષ્ય વિચારવું, પહેલું પગલું અને પૂર્ણ કરવું સહજ છે. બધું જાતે કરવાની વૃત્તિથી બચો." },
      empty: { en: "No Fire indicators — direction, initiative and follow-through all have to be borrowed from structure, mentors or partners rather than felt from within. Decide slowly, then commit to written plans.", hi: "कोई अग्नि-संकेतक नहीं — दिशा, पहल और निष्पादन ढांचे, गुरु या साथी से लेने पड़ते हैं। धीरे निर्णय लें, फिर लिखित योजना पर टिकें।", gu: "કોઈ અગ્નિ-સંકેતક નથી — દિશા, પહેલ અને અમલ માળખા, ગુરુ કે ભાગીદાર પાસેથી લેવા પડે છે. ધીમે નિર્ણય લો, પછી લેખિત યોજનાને વળગી રહો." },
      partial: {
        en: {
          3: "Jupiter (3) present gives you the vision and the wisdom to choose the right direction",
          1: "Sun (1) present gives you executive drive — you naturally take charge and initiate",
          9: "Mars (9) present gives you the courage to act and the stamina to finish"
        },
        absent: {
          3: "without Jupiter (3) the plane acts before it has a philosophy — seek an adviser before big pivots",
          1: "without Sun (1) the plane lacks a self-starter — momentum depends on external deadlines",
          9: "without Mars (9) energy fades before completion — break goals into short sprints"
        }
      }
    },
    materialistic: {
      complete: { en: "Venus (6), Ketu (7) and Mercury (5) are all present — value-sense, discernment and commercial communication work together. Wealth tends to compound through networks and negotiation.", hi: "शुक्र (6), केतु (7) और बुध (5) तीनों उपस्थित — मूल्य-बोध, विवेक और व्यापारिक संवाद साथ चलते हैं। धन नेटवर्क और मोल-भाव से बढ़ता है।", gu: "શુક્ર (6), કેતુ (7) અને બુધ (5) ત્રણેય હાજર — મૂલ્ય-બોધ, વિવેક અને વ્યાપારિક સંવાદ સાથે ચાલે છે. ધન નેટવર્ક અને વાટાઘાટથી વધે છે." },
      empty: { en: "An empty Material Plane: money, luxury and deal-making are not instinctive — wealth comes through the Practical or Emotional planes (effort, discipline, timing) rather than through charm or trading. Expect Venus and Mercury Dasha windows to convert conditionally, after remedy activation.", hi: "रिक्त भौतिक तल: धन, विलास और सौदेबाज़ी सहज नहीं — संपत्ति व्यावहारिक या भावनात्मक तल (श्रम, अनुशासन, समय) से आती है। शुक्र-बुध दशा-विंडो उपाय-सक्रियण के बाद सशर्त फलित होती हैं।", gu: "ખાલી ભૌતિક તલ: ધન, વૈભવ અને સોદાબાજી સહજ નથી — સંપત્તિ વ્યવહારુ કે ભાવનાત્મક તલ (શ્રમ, શિસ્ત, સમય) થી આવે છે. શુક્ર-બુધ દશા-વિન્ડો ઉપાય-સક્રિયકરણ પછી શરતી ફળે છે." },
      partial: {
        en: {
          6: "Venus (6) present gives an eye for value, comfort and relationships that pay",
          7: "Ketu (7) present gives analytical detachment — you can research and evaluate before spending",
          5: "Mercury (5) present gives commercial fluency — deals, contracts and networks come naturally"
        },
        absent: {
          6: "without Venus (6) wealth is earned but not easily enjoyed or attracted — relationship-led income needs deliberate cultivation",
          7: "without Ketu (7) financial decisions can lack scrutiny — always sleep on large commitments",
          5: "without Mercury (5) negotiation and salesmanship are learned skills, not reflexes — use written terms"
        }
      }
    },
    emotional: {
      complete: { en: "Moon (2), Saturn (8) and Rahu (4) are all present — intuition, perseverance and systematic planning reinforce each other. You feel deeply and still build patiently.", hi: "चंद्र (2), शनि (8) और राहु (4) तीनों उपस्थित — अंतर्ज्ञान, धैर्य और व्यवस्थित योजना एक-दूसरे को बल देते हैं।", gu: "ચંદ્ર (2), શનિ (8) અને રાહુ (4) ત્રણેય હાજર — અંતઃસ્ફુરણા, ધીરજ અને વ્યવસ્થિત આયોજન એકબીજાને બળ આપે છે." },
      empty: { en: "No Water indicators — emotional regulation, patience and long-range planning are the growth edge. Decisions arrive fast and are felt later; build routines that slow the reaction.", hi: "कोई जल-संकेतक नहीं — भावनात्मक संतुलन, धैर्य और दीर्घ योजना विकास-क्षेत्र हैं। निर्णय जल्दी होते हैं, अनुभूति बाद में; प्रतिक्रिया धीमी करने वाली दिनचर्या बनाएं।", gu: "કોઈ જળ-સંકેતક નથી — ભાવનાત્મક સંતુલન, ધીરજ અને લાંબા ગાળાનું આયોજન વિકાસ-ક્ષેત્ર છે. નિર્ણયો ઝડપી થાય છે, અનુભૂતિ પછી; પ્રતિક્રિયા ધીમી કરે તેવી દિનચર્યા બનાવો." },
      partial: {
        en: {
          2: "Moon (2) present gives intuition and the ability to read people and rooms",
          8: "Saturn (8) present gives perseverance — you outlast obstacles others abandon",
          4: "Rahu (4) present gives systematic, unconventional planning and a tolerance for disruption"
        },
        absent: {
          2: "without Moon (2) feelings are processed slowly or rationalised — nurture the sensitive side deliberately, especially in Moon sub-periods",
          8: "without Saturn (8) discipline is situational — external accountability keeps long projects alive",
          4: "without Rahu (4) you prefer the known path — sudden change unsettles more than it should"
        }
      }
    }
  };

  function vedicPlaneReadings(p, lang) {
    const db = getActiveDB();
    const config = vedicGridConfig(db);
    const counts = p.vedicCounts || {};
    return config.planes.map((plane) => {
      const key = plane.key;
      const text = VEDIC_PLANE_READINGS[key] || {};
      const cells = plane.cells.slice();
      const present = cells.filter((n) => counts[n] > 0);
      const absent = cells.filter((n) => !(counts[n] > 0));
      const roles = plane.roles || {};
      const roleOf = (n) => (typeof roles[n] === "string" ? roles[n] : (roles[n] && (roles[n].label || roles[n].short)) || `${db.numbers[n].planet.split(" ")[0]} (${n})`);
      const state = present.length === cells.length ? "complete" : present.length === 0 ? "empty" : "partial";
      let reading;
      if (state === "complete") reading = loc(text.complete, lang) || (text.complete && text.complete.en) || "";
      else if (state === "empty") reading = loc(text.empty, lang) || (text.empty && text.empty.en) || "";
      else {
        // Partial planes are composed sentence-by-sentence so the wording
        // always matches the exact present/absent pattern of this chart.
        const partial = text.partial || { en: {}, absent: {} };
        const strong = present.filter((n) => counts[n] > 1);
        const presentClauses = present.map((n) => partial.en[n]).filter(Boolean);
        const absentClauses = absent.map((n) => partial.absent[n]).filter(Boolean);
        const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
        const strongNote = strong.length ? ` ${strong.map((n) => `${db.numbers[n].planet.split(" ")[0]} (${n})`).join(" and ")} appear${strong.length === 1 ? "s" : ""} more than once, so th${strong.length === 1 ? "at quality is concentrated" : "ose qualities are concentrated"} — lean on ${strong.length === 1 ? "it" : "them"}.` : "";
        const planetList = (list) => list.map((n) => `${db.numbers[n].planet.split(" ")[0]} (${n})`).join(", ");
        reading = lang === "hi"
          ? `${planetList(present)} उपस्थित — इस तल की ये शक्तियां सहज हैं। ${planetList(absent)} अनुपस्थित — इन गुणों को सचेत अभ्यास और सहयोग से विकसित करना होगा।`
          : lang === "gu"
            ? `${planetList(present)} હાજર — આ તલની આ શક્તિઓ સહજ છે. ${planetList(absent)} ગેરહાજર — આ ગુણો સભાન અભ્યાસ અને સહયોગથી વિકસાવવા પડશે.`
            : `${cap(presentClauses.join("; "))}.${strongNote} ${cap(absentClauses.join("; "))}.`.replace(/\s+/g, " ").trim();
      }
      return {
        key, name: plane.name || key, element: plane.element || "", governs: plane.governs || "", cells, state,
        present, absent, reading,
        presentRoles: present.map((n) => `${roleOf(n)}${counts[n] > 1 ? ` ×${counts[n]}` : ""}`),
        absentRoles: absent.map(roleOf)
      };
    });
  }

  function renderVedicGridCells(counts) {
    const db = getActiveDB();
    const copy = vedicGridCopy(getLang());
    const layout = vedicGridConfig(db).layout;
    return layout.flat().map((n) => {
      const c = counts[n] || 0;
      const cls = c === 0 ? "missing" : c >= 3 ? "present multi" : "present";
      const digits = c ? Array(c).fill(n).map((x) => `<span>${x}</span>`).join("") : `<span>${n}</span>`;
      return `<div class="vedic-cell ${cls}" data-grid-engine="vedic" data-grid-number="${n}" data-missing-label="${esc(copy.missing)}" title="Vedic birth indicator · ${n}: ${c} occurrence${c === 1 ? "" : "s"}"><div class="digits">${digits}</div>${c ? `<div class="cnt">${esc(db.numbers[n].planet.split(" ")[0])}</div>` : ""}</div>`;
    }).join("");
  }

  function renderVedicBirthComparison(p) {
    const lang = getLang();
    const copy = vedicGridCopy(lang);
    const grid = p.vedicGrid || generateVedicGrid(p.day, p.month, p.year);
    const numberList = (numbers) => numbers && numbers.length ? numbers.join(", ") : "—";
    const sourceRows = [
      [copy.day, grid.excluded.dayDeduplicated ? "—" : numberList(grid.sourceDigits.day), grid.excluded.dayDeduplicated ? (lang === "hi" ? "मूलांक के रूप में एक बार दर्ज" : lang === "gu" ? "મૂલાંક તરીકે એક વખત દાખલ" : "Entered once as the Ruling Number") : (lang === "hi" ? "संयुक्त तारीख के अंक" : lang === "gu" ? "સંયુક્ત તારીખના અંકો" : "Compound-day digits")],
      [copy.month, numberList(grid.sourceDigits.month), lang === "hi" ? "शून्य हटाए गए" : lang === "gu" ? "શૂન્ય દૂર કરાયા" : "Zeros removed"],
      [copy.year, numberList(grid.sourceDigits.year), lang === "hi" ? "केवल वर्ष के अंतिम दो अंक; शताब्दी हटाई" : lang === "gu" ? "માત્ર વર્ષના છેલ્લા બે અંકો; સદી દૂર" : "Final two year digits only; century excluded"],
      [copy.ruling, String(p.driver), lang === "hi" ? "फ़िल्टरिंग के बाद जोड़ा" : lang === "gu" ? "છટણી પછી ઉમેર્યો" : "Added after filtering"],
      [copy.destiny, String(p.conductor), lang === "hi" ? "पूर्ण DOB से निकाला और जोड़ा" : lang === "gu" ? "પૂર્ણ DOBથી ગણીને ઉમેર્યો" : "Calculated from complete DOB and added"]
    ].map(([source, digits, treatment]) => `<tr><td><strong>${esc(source)}</strong></td><td>${esc(digits)}</td><td>${esc(treatment)}</td></tr>`).join("");
    const present = Object.keys(p.vedicCounts).filter((n) => p.vedicCounts[n] > 0).join(", ") || "—";
    const planeReadings = vedicPlaneReadings(p, lang);
    const planeCards = planeReadings.map((plane) => {
      const chips = plane.cells.map((n) => `<span class="plane-chip ${p.vedicCounts[n] > 0 ? "on" : "off"}">${n}</span>`).join("");
      const badge = plane.state === "complete" ? `<span class="badge good">${copy.planeComplete}</span>`
        : plane.state === "empty" ? `<span class="badge warn">${copy.planeEmpty}</span>`
        : `<span class="badge info">${copy.planePartial}</span>`;
      return `<article class="card plane-card vedic-plane-reading" data-vedic-plane="${plane.key}" data-plane-state="${plane.state}">
        <div class="goal-head"><div class="card-title">${esc(plane.name)}</div>${badge}</div>
        <div class="card-sub">${esc(plane.element)} · ${plane.cells.join(" – ")} · ${esc(plane.governs)}</div>
        <div class="plane-chips">${chips}</div>
        <div class="kit-value">${esc(plane.reading)}</div>
        ${plane.presentRoles.length ? `<div class="card-sub"><strong>${copy.planeActive}:</strong> ${esc(plane.presentRoles.join(" · "))}</div>` : ""}
        ${plane.absentRoles.length ? `<div class="card-sub"><strong>${copy.planeAbsent}:</strong> ${esc(plane.absentRoles.join(" · "))}</div>` : ""}
      </article>`;
    }).join("");
    return `<section class="rsection vedic-comparison-section" id="vedic-comparison-section">
      <details class="advanced-vedic-comparison">
        <summary><span>${t("secVedicCompare", "Advanced Vedic Comparison")}</span><span class="details-hint">${lang === "hi" ? "वैकल्पिक जन्म-ग्रिड" : lang === "gu" ? "વૈકલ્પિક જન્મ-ગ્રિડ" : "Optional birth-grid view"}</span></summary>
        <div class="details-body">
          <h2 class="rsection-title"><span class="idx">+</span>${copy.title}</h2>
          <div class="card vedic-grid-intro"><div class="kit-value">${copy.intro}</div><div class="judge-note">${copy.note}</div></div>
          <div class="vedic-grid-wrap"><div><div class="vedic-grid" role="img" aria-label="Vedic Birth Grid planetary strength indicators">${renderVedicGridCells(p.vedicCounts)}</div><div class="vedic-legend" style="margin-top:8px"><span><i class="dot g"></i>${copy.present}</span><span><i class="dot y"></i>${copy.repeated}</span><span><i class="dot w"></i>${copy.missing}</span></div></div>
            <div class="card"><div class="card-title">${lang === "hi" ? "जन्म संकेतक एक नजर में" : lang === "gu" ? "જન્મ સંકેતકો એક નજરે" : "Birth indicators at a glance"}</div><div class="kit-value"><span class="badge good">${copy.present}</span> ${present}</div>${p.vedicWeak.length ? `<div class="kit-value"><span class="badge warn">${copy.weak}</span> ${p.vedicWeak.join(", ")}</div>` : ""}<div class="kit-value"><span class="badge info">${copy.missing}</span> ${p.vedicMissing.length ? p.vedicMissing.join(", ") : (lang === "hi" ? "कोई नहीं" : lang === "gu" ? "કોઈ નહીં" : "none")}</div></div>
          </div>
          <div class="card"><div class="card-title">${lang === "hi" ? "वैदिक जन्म ग्रिड कैसे बना" : lang === "gu" ? "વૈદિક જન્મ ગ્રિડ કેવી રીતે બન્યો" : "How the Vedic Birth Grid was plotted"}</div><div class="table-scroll"><table class="rtable"><tr><th>${copy.source}</th><th>${copy.plotted}</th><th>${copy.treatment}</th></tr>${sourceRows}</table></div></div>
          <div class="card vedic-plane-intro"><div class="card-title">${copy.planesTitle}</div><div class="card-sub">${copy.planesIntro}</div></div>
          <div class="plane-cards vedic-plane-cards">${planeCards}</div>
        </div>
      </details>
    </section>`;
  }

  // Retained as a public compatibility alias for integrations/tests. It is now
  // explicitly a birth-only advanced comparison, never a remedy renderer.
  function renderVedicGrid(p) { return renderVedicBirthComparison(p); }

  /* Bio-energetic Tattva anchors for Vedic planes that are Partly Active
     or Deficient. Complete planes are omitted. This is Dinacharya /
     Aushadhi / Pranayama only — Lo Shu keeps mantras, minerals and the
     40-day mandala; Dasha keeps spatial timing. Copy lives here (same
     pattern as VEDIC_PLANE_READINGS) so pack 2.9.0 stays in lockstep. */
  const VEDIC_TATTVA_KIT = {
    practical: {
      tattva: { en: "Agni / Fire Tattva", hi: "अग्नि तत्व", gu: "અગ્નિ તત્વ" },
      cells: [3, 1, 9],
      signature: {
        en: "Low digestive fire, morning sluggishness, cold extremities, delayed decision-making. The body needs heat, not more cooling.",
        hi: "पाचन-अग्नि मंद, सुबह सुस्ती, ठंडे हाथ-पैर, निर्णय में देरी। शरीर को ऊष्मा चाहिए, और ठंडक नहीं।",
        gu: "પાચન-અગ્નિ મંદ, સવારે સુસ્તી, ઠંડા હાથ-પગ, નિર્ણયમાં વિલંબ. શરીરને ગરમી જોઈએ, વધુ ઠંડક નહીં."
      },
      rows: [
        { ico: "🌬", label: { en: "Breathwork (Pranayama)", hi: "श्वास-अभ्यास (प्राणायाम)", gu: "શ્વાસ-અભ્યાસ (પ્રાણાયામ)" }, value: { en: "Surya Bhedana (right-nostril breathing): inhale 4 counts through the right nostril, hold 2, exhale 4 through the left. 5–9 rounds after sunrise.", hi: "सूर्य भेदन (दाईं नासिका श्वास): दाहिनी नासिका से 4 गिनती खींचें, 2 रोकें, बाईं से 4 छोड़ें। सूर्योदय के बाद 5–9 चक्र।", gu: "સૂર્ય ભેદન (જમણી નાસિકા શ્વાસ): જમણી નાસિકાથી 4 ગણતરી ખેંચો, 2 રોકો, ડાબીથી 4 છોડો. સૂર્યોદય પછી 5–9 ચક્ર." } },
        { ico: "🛁", label: { en: "Aushadhi Snan & Aroma", hi: "औषधि स्नान और सुगंध", gu: "ઔષધિ સ્નાન અને સુગંધ" }, value: { en: "Warm (not hot) baths; a pinch of turmeric or fresh ginger in the bath water; light camphor or cinnamon aroma in the room — never overpowering.", hi: "गुनगुना (बहुत गरम नहीं) स्नान; पानी में हल्दी या ताज़ा अदरक की चुटकी; कमरे में कपूर या दालचीनी की हल्की सुगंध — तेज़ नहीं।", gu: "ગુનગુનું (ખૂબ ગરમ નહીં) સ્નાન; પાણીમાં હળદર કે તાજી આદુની ચુટકી; રૂમમાં કપૂર કે તજની હળવી સુગંધ — તીવ્ર નહીં." } },
        { ico: "💧", label: { en: "Water & Ingestion Anchor", hi: "जल और सेवन आधार", gu: "જળ અને સેવન આધાર" }, value: { en: "Room-temperature or warm water through the day; warm lemon-honey water on waking. Skip iced drinks.", hi: "दिन भर कमरे के तापमान या गुनगुना पानी; जागने पर नींबू-शहद का गुनगुना पानी। बर्फ वाले पेय न लें।", gu: "દિવસભર રૂમ-તાપમાન કે ગુનગુનું પાણી; ઊઠતાં લીંબુ-મધનું ગુનગુનું પાણી. બરફવાળા પીણાં ટાળો." } },
        { ico: "☀", label: { en: "Solar Activation", hi: "सूर्य सक्रियण", gu: "સૂર્ય સક્રિયકરણ" }, value: { en: "10–20 minutes of morning sunlight facing East — face and upper chest uncovered.", hi: "सुबह 10–20 मिनट पूर्व दिशा में धूप — चेहरा और ऊपरी छाती खुली रखें।", gu: "સવારે 10–20 મિનિટ પૂર્વ દિશામાં ધૂપ — ચહેરો અને ઉપરની છાતી ખુલ્લા રાખો." } },
        { ico: "✦", label: { en: "Behavioral Micro-Habit", hi: "व्यवहार की छोटी आदत", gu: "વ્યવહારની નાની ટેવ" }, value: { en: "Make the first work block of the day a 25-minute focused sprint — a small, warm start to light the fire.", hi: "दिन का पहला काम 25 मिनट का केंद्रित स्प्रिंट रखें — अग्नि जलाने के लिए छोटा, गर्म प्रारंभ।", gu: "દિવસનું પહેલું કામ 25 મિનિટનું કેન્દ્રિત સ્પ્રિન્ટ રાખો — અગ્નિ પ્રગટાવવા નાની, ગરમ શરૂઆત." } }
      ]
    },
    materialistic: {
      tattva: { en: "Vayu / Air Tattva", hi: "वायु तत्व", gu: "વાયુ તત્વ" },
      cells: [6, 7, 5],
      signature: {
        en: "Restlessness, unfinished conversations, scattered attention, stalled money-cycles. Move air with rhythm, not more stimulation.",
        hi: "बेचैनी, अधूरी बातचीत, बिखरा ध्यान, धन-चक्र में अटकन। वायु को लय से चलाएं, और उत्तेजना से नहीं।",
        gu: "બેચેની, અધૂરી વાતચીત, વેરાયેલું ધ્યાન, ધન-ચક્રમાં અટકાણ. વાયુને લયથી ચલાવો, વધુ ઉત્તેજનાથી નહીં."
      },
      rows: [
        { ico: "🌬", label: { en: "Breathwork (Pranayama)", hi: "श्वास-अभ्यास (प्राणायाम)", gu: "શ્વાસ-અભ્યાસ (પ્રાણાયામ)" }, value: { en: "Nadi Shodhana (alternate-nostril): inhale left, exhale right; inhale right, exhale left. 9–12 rounds, mid-morning or before a negotiation.", hi: "नाड़ी शोधन (एकांतर नासिका): बाईं से खींचें, दाईं से छोड़ें; दाईं से खींचें, बाईं से छोड़ें। 9–12 चक्र, सुबह देर से या बातचीत से पहले।", gu: "નાડી શોધન (એકાંતર નાસિકા): ડાબીથી ખેંચો, જમણીથી છોડો; જમણીથી ખેંચો, ડાબીથી છોડો. 9–12 ચક્ર, સવારે મોડે કે વાટાઘાટ પહેલાં." } },
        { ico: "🛁", label: { en: "Aushadhi Snan & Aroma", hi: "औषधि स्नान और सुगंध", gu: "ઔષધિ સ્નાન અને સુગંધ" }, value: { en: "A handful of tulsi or mint in the bath; a light eucalyptus or mint aroma; keep one window cracked for a cross-breeze.", hi: "स्नान में तुलसी या पुदीने की मुट्ठी; यूकेलिप्टस या पुदीने की हल्की सुगंध; हवा के लिए एक खिड़की थोड़ी खुली रखें।", gu: "સ્નાનમાં તુલસી કે ફુદીનાની મુઠ્ઠી; યુકેલિપ્ટસ કે ફુદીનાની હળવી સુગંધ; હવા માટે એક બારી થોડી ખુલ્લી રાખો." } },
        { ico: "💧", label: { en: "Water & Ingestion Anchor", hi: "जल और सेवन आधार", gu: "જળ અને સેવન આધાર" }, value: { en: "Small sips through the day; tulsi or mint infusion; lighter, less fried meals at the main sitting.", hi: "दिन भर छोटे घूंट; तुलसी या पुदीने का काढ़ा; मुख्य भोजन हलका रखें, तली चीज़ें कम।", gu: "દિવસભર નાના ઘૂંટ; તુલસી કે ફુદીનાનો કાઢો; મુખ્ય ભોજન હળવું રાખો, તળેલું ઓછું." } },
        { ico: "🌬", label: { en: "Space & Sensory Reset", hi: "स्थान और इंद्रिय रीसेट", gu: "સ્થાન અને ઇન્દ્રિય રીસેટ" }, value: { en: "Open a window every 90 minutes; stand and roll the shoulders for two minutes between deep-work blocks.", hi: "हर 90 मिनट खिड़की खोलें; गहरे काम के बीच दो मिनट खड़े होकर कंधे घुमाएँ।", gu: "દર 90 મિનિટે બારી ખોલો; ઊંડા કામ વચ્ચે બે મિનિટ ઊભા રહીને ખભા ફેરવો." } },
        { ico: "✦", label: { en: "Behavioral Micro-Habit", hi: "व्यवहार की छोटी आदत", gu: "વ્યવહારની નાની ટેવ" }, value: { en: "After every conversation, write the next step in one line — give Air a direction instead of letting it scatter.", hi: "हर बातचीत के बाद अगला कदम एक पंक्ति में लिखें — वायु को दिशा दें, बिखराव नहीं।", gu: "દરેક વાતચીત પછી આગલું પગલું એક લીટીમાં લખો — વાયુને દિશા આપો, વેરવિખેર નહીં." } }
      ]
    },
    emotional: {
      tattva: { en: "Jala / Water + Earth Tattva", hi: "जल + पृथ्वी तत्व", gu: "જળ + પૃથ્વી તત્વ" },
      cells: [2, 8, 4],
      signature: {
        en: "Mood waves, uneven sleep, feeling ungrounded, plans that fade. Stability comes from water and earth, not more intensity.",
        hi: "भाव-लहरें, अस्थिर नींद, ज़मीन से कटाव, योजनाएँ जो फीकी पड़ जाती हैं। स्थिरता जल और मिट्टी से आती है, और तीव्रता से नहीं।",
        gu: "ભાવ-લહેરો, અસ્થિર ઊંઘ, જમીનથી કટાવ, યોજનાઓ જે ઝાંખી પડે. સ્થિરતા જળ અને માટીથી આવે છે, વધુ તીવ્રતાથી નહીં."
      },
      rows: [
        { ico: "🌬", label: { en: "Breathwork (Pranayama)", hi: "श्वास-अभ्यास (प्राणायाम)", gu: "શ્વાસ-અભ્યાસ (પ્રાણાયામ)" }, value: { en: "Chandra Bhedana (left-nostril) or a 4–6 calming breath: inhale left 4, hold 2, exhale right 6. 5–8 rounds before sleep.", hi: "चंद्र भेदन (बाईं नासिका) या 4–6 शांत श्वास: बाईं से 4 खींचें, 2 रोकें, दाईं से 6 छोड़ें। सोने से पहले 5–8 चक्र।", gu: "ચંદ્ર ભેદન (ડાબી નાસિકા) અથવા 4–6 શાંત શ્વાસ: ડાબીથી 4 ખેંચો, 2 રોકો, જમણીથી 6 છોડો. સૂતા પહેલાં 5–8 ચક્ર." } },
        { ico: "🛁", label: { en: "Aushadhi Snan & Aroma", hi: "औषधि स्नान और सुगंध", gu: "ઔષધિ સ્નાન અને સુગંધ" }, value: { en: "Warm bath with a drop of rose or sandalwood hydrosol; a light lavender or sandalwood aroma at night.", hi: "गुलाब या चंदन जल की बूंद के साथ गुनगुना स्नान; रात को लैवेंडर या चंदन की हल्की सुगंध।", gu: "ગુલાબ કે ચંદન જળના ટીપા સાથે ગુનગુનું સ્નાન; રાત્રે લેવેન્ડર કે ચંદનની હળવી સુગંધ." } },
        { ico: "💧", label: { en: "Water & Ingestion Anchor", hi: "जल और सेवन आधार", gu: "જળ અને સેવન આધાર" }, value: { en: "Regular sips of room-temperature or lukewarm water (ideally stored in a pure silver vessel); cumin-coriander warm infusion in the afternoon; strictly avoid refrigerated drinks, ice, or late-night cooling fluids if prone to morning nasal allergies; ease caffeine after dusk.", hi: "कमरे के तापमान या गुनगुने पानी के नियमित घूंट (शुद्ध चांदी के बर्तन में रखा जल उत्तम); दोपहर में जीरा-धनिया का गुनगुना काढ़ा; सुबह की नाक-एलर्जी हो तो फ्रिज के पेय, बर्फ या रात के ठंडे तरल से सख्त परहेज करें; शाम के बाद कैफीन कम करें।", gu: "રૂમ-તાપમાન કે ગુનગુના પાણીના નિયમિત ઘૂંટ (શુદ્ધ ચાંદીના વાસણમાં રાખેલું જળ ઉત્તમ); બપોરે જીરું-ધાણાનો ગરમ ઉકાળો; સવારની નાક-એલર્જી હોય તો ફ્રિજના પીણાં, બરફ કે રાત્રિના ઠંડા પ્રવાહીનો સખત પરહેજ કરો; સાંજ પછી કેફીન ઓછું." } },
        { ico: "🌱", label: { en: "Grounding Anchor", hi: "भूमि-संपर्क", gu: "ભૂમિ-સંપર્ક" }, value: { en: "Bare feet on soil or grass 5–10 minutes; a warm foot-soak in the evening.", hi: "नंगे पाँव मिट्टी या घास पर 5–10 मिनट; शाम को गुनगुना पैर-स्नान।", gu: "નંગા પગે માટી કે ઘાસ પર 5–10 મિનિટ; સાંજે ગુનગુનું પગ-સ્નાન." } },
        { ico: "✦", label: { en: "Behavioral Micro-Habit", hi: "व्यवहार की छोटी आदत", gu: "વ્યવહારની નાની ટેવ" }, value: { en: "Three lines at night — what you felt, what you finished, one small step for tomorrow.", hi: "रात को तीन पंक्तियाँ — क्या महसूस किया, क्या पूरा किया, कल का एक छोटा कदम।", gu: "રાત્રે ત્રણ લીટીઓ — શું અનુભવ્યું, શું પૂરું કર્યું, કાલનું એક નાનું પગલું." } }
      ]
    }
  };

  function vedicTattvaAnchors(p, lang) {
    const l = lang || getLang();
    return vedicPlaneReadings(p, l)
      .filter((plane) => plane.state === "partial" || plane.state === "empty")
      .map((plane) => {
        const kit = VEDIC_TATTVA_KIT[plane.key] || { tattva: {}, signature: {}, rows: [], cells: plane.cells };
        return {
          key: plane.key,
          name: plane.name,
          element: plane.element,
          cells: kit.cells || plane.cells,
          state: plane.state,
          present: plane.present,
          absent: plane.absent,
          tattva: loc(kit.tattva, l),
          signature: loc(kit.signature, l),
          rows: (kit.rows || []).map((row) => ({
            ico: row.ico,
            label: loc(row.label, l),
            value: loc(row.value, l)
          }))
        };
      });
  }

  function renderVedicTattvaSection(p) {
    const lang = getLang();
    const copy = vedicGridCopy(lang);
    const anchors = vedicTattvaAnchors(p, lang);
    if (!anchors.length) return "";
    const deficientLabel = lang === "hi" ? "न्यून" : lang === "gu" ? "ઊણપ" : "Deficient";
    /* Automated conflict resolution (2026-09 audit): when the solar-overload
       guardrail is live (3+ Sun against a Pitta baseline), the Agni plane's
       heating anchors — Surya Bhedana and the midday Solar Activation — are
       visually MUTED in place instead of being printed live right next to the
       moderation warning. The reader can still see what was withheld and why. */
    const solarMuteActive = solarOverload(p) && pittaInBaseline(p);
    const mutedHint = lang === "hi" ? "संयमित — सूर्य-ओवरलोड गार्डरेल सक्रिय है; इसे छोड़ें।" : lang === "gu" ? "સંયમિત — સૂર્ય-ઓવરલોડ ગાર્ડરેલ સક્રિય છે; આ છોડી દો." : "Muted — the solar-overload guardrail is active; skip this anchor.";
    const isHeatingRow = (row) => /surya bhedana|solar activation|सूर्य भेदन|सूर्य सक्रियण|સૂર્ય ભેદન|સૂર્ય સક્રિયકરણ/i.test(`${row.label} ${row.value}`);
    const cards = anchors.map((plane) => {
      const chips = plane.cells.map((n) => `<span class="plane-chip ${p.vedicCounts[n] > 0 ? "on" : "off"}">${n}</span>`).join("");
      const badge = plane.state === "empty"
        ? `<span class="badge warn">${esc(deficientLabel)}</span>`
        : `<span class="badge info">${esc(copy.planePartial)}</span>`;
      const rows = plane.rows.map((row) => {
        const muted = solarMuteActive && plane.key === "practical" && isHeatingRow(row);
        return `<div class="kit-row${muted ? " conflict-muted" : ""}"${muted ? ' data-conflict-muted="solar-overload"' : ""}><div class="kit-ico">${row.ico}</div><div class="kit-body"><div class="kit-label">${esc(row.label)}${muted ? ` <span class="conflict-muted-note">${mutedHint}</span>` : ""}</div><div class="kit-value">${esc(row.value)}</div></div></div>`;
      }).join("");
      return `<article class="card plane-card tattva-card" data-vedic-plane="${plane.key}" data-plane-state="${plane.state}" data-tattva="${esc(plane.tattva)}">
        <div class="goal-head"><div class="card-title">${esc(plane.name)} — ${esc(plane.tattva)}</div>${badge}</div>
        <div class="card-sub">${esc(plane.element)} · ${plane.cells.join(" – ")}</div>
        <div class="plane-chips">${chips}</div>
        <div class="kit">
          <div class="kit-row"><div class="kit-ico">◎</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "न्यूनता संकेत" : lang === "gu" ? "ઊણપનું ચિહ્ન" : "Deficiency Signature"}</div><div class="kit-value">${esc(plane.signature)}</div></div></div>
          ${rows}
          ${plane.key === "practical" ? solarModerationNote(p, lang, { context: "agni" }) : ""}
          ${plane.key === "emotional" ? moonColdTattvaOverlayHtml(p, lang) : ""}
        </div>
      </article>`;
    }).join("");
    const note = lang === "hi"
      ? "ये दैनिक जैविक आधार हैं — श्वास, औषधि स्नान, सुगंध, धूप, जल और छोटी आदतें। ये आपकी 40-दिवसीय लो शू साधना के साथ चलते हैं; खनिज साथी और दिशा-समय अपनी-अपनी धाराओं में रहते हैं।"
      : lang === "gu"
        ? "આ દૈનિક જૈવિક આધાર છે — શ્વાસ, ઔષધિ સ્નાન, સુગંધ, ધૂપ, જળ અને નાની ટેવો. તે તમારી ૪૦-દિવસીય લો શુ સાધના સાથે ચાલે છે; ખનિજ સાથી અને દિશા-સમય પોતપોતાની ધારામાં રહે છે."
        : "These are everyday biological anchors — breath, herbal baths, aroma, sunlight, water and small habits. They run alongside your 40-day Lo Shu practice. Mineral companions and spatial timing stay in their own streams.";
    return `<section class="rsection tattva-section" id="tattva-section" data-authority="vedic-tattva">
      <h2 class="rsection-title"><span class="idx idx-wide">${SECTION.tattva}</span>${t("secTattva", "Vedic Plane Harmonization — Elemental Tattva Balancing")}</h2>
      <p class="rsection-desc">${t("secTattvaDesc", "Physical, breathwork, and herbal anchors to stabilize deficient natal planes. These run alongside your 40-day Lo Shu practice without adding ritual fatigue.")}</p>
      <div class="plane-cards tattva-cards">${cards}</div>
      <div class="judge-note">${note}</div>
    </section>`;
  }


  /* Crystal row for one remedy kit. Adult charts quote the canonical kit
     string; under-18 charts lead with the gentle substitute and explicitly
     defer the heavy Saturn/Rahu/Ketu gem until adulthood. */
  function crystalRowValue(db, n, p, lang) {
    const canonical = String(((db && db.numbers) || {})[n] ? db.numbers[n].crystal : "");
    if (!isMinorProfile(p)) return canonical;
    const heavy = HEAVY_GEM_BY_NUMBER[n];
    if (!heavy) return canonical;
    return lang === "hi"
      ? `${heavy.gentle} — 18 से कम आयु में यही हल्का विकल्प प्रथम है। ${heavy.heavy} वयस्कता तक स्थगित रहे — तब भी केवल विशेषज्ञ परीक्षण के बाद पहनें।`
      : lang === "gu"
        ? `${heavy.gentle} — 18 થી ઓછી ઉંમરમાં આ હળવો વિકલ્પ જ પ્રથમ. ${heavy.heavy} પુખ્ત ઉંમર સુધી મુલ્તવી રહે — ત્યારે પણ ફક્ત નિષ્ણાત પરીક્ષણ પછી જ પહેરવું.`
        : `${heavy.gentle} — the gentle substitute is the first choice under 18. ${heavy.heavy} stays deferred until adulthood — and even then, worn only after an expert trial.`;
  }

  function kitCard(n, heading, p) {
    const db = getActiveDB();
    const i = db.numbers[n];
    const sm = db.mantraShort[n];
    const yantraName = (db.yantra && db.yantra[n]) || (window.DB && window.DB.yantra && window.DB.yantra[n]) || `Yantra ${n}`;
    const lang = getLang();

    return `<div class="card">
      <div class="goal-head">
        <div class="num-value" style="width:40px;height:40px;font-size:18px;line-height:40px">${n}</div>
        <div>
          <div class="card-title">${esc(i.planet)}</div>
          <div class="card-sub">${esc(heading || i.traits)}</div>
        </div>
      </div>
      <div class="kit">
        ${moonColdKitGuardrailHtml(n, p, lang)}
        ${doshaContraKitGuardrailHtml(n, p, lang)}
        <div class="kit-row"><div class="kit-ico">🕉</div><div class="kit-body"><div class="kit-label">${t("beejMantra", "Beej Mantra")}</div><div class="kit-value"><span class="mantra">${esc(i.mantra)}</span><br>${esc(i.mantraCount)}</div></div></div>
        <div class="kit-row"><div class="kit-ico">🙏</div><div class="kit-body"><div class="kit-label">${t("dailyShortMantra", "Daily Short Mantra")}</div><div class="kit-value"><span class="mantra">${esc(sm.dev)}</span> <em>(${esc(sm.pron)})</em><br><span class="card-sub">${esc(sm.meaning)}</span></div></div></div>
        <div class="kit-row"><div class="kit-ico">📝</div><div class="kit-body"><div class="kit-label">${t("wishPaperAffirmation", "Wish-Paper Affirmation")}</div><div class="kit-value">“${esc(sm.affirmation)}”<br><span class="card-sub">${lang === "hi" ? "इसे अपने संकल्प पत्र पर रोज ११ बार लिखें और पर्स या तकिए के नीचे रखें।" : lang === "gu" ? "આને તમારા સંકલ્પ પત્ર પર રોજ ૧૧ વખત લખો અને પર્સમાં કે ઓશીકા નીચે રાખો." : "Write this on your wish paper 11 times daily, then keep the paper in your wallet or under your pillow."}</span></div></div></div>
        <div class="kit-row"><div class="kit-ico">💎</div><div class="kit-body"><div class="kit-label">${t("crystal", "Crystal")}</div><div class="kit-value">${esc(crystalRowValue(db, n, p, lang))}</div></div></div>
        ${isMinorProfile(p) && HEAVY_GEM_BY_NUMBER[n] ? `<div class="kit-row" data-age-guardrail="under-18"><div class="kit-ico">🛡</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "आयु सुरक्षा (18 से कम)" : lang === "gu" ? "ઉંમર સુરક્ષા (18 થી ઓછી)" : "Age guardrail (under 18)"}</div><div class="kit-value">${lang === "hi" ? `अभिभावक ध्यान दें: विद्यार्थी-आयु में यह किट जीवनशैली, रंग और दान पंक्तियों तथा खंड 4A के तत्व आधारों से चले; रत्न वैकल्पिक और हल्का ही रहे।` : lang === "gu" ? `વાલી નોંધ: વિદ્યાર્થી-ઉંમરે આ કિટ જીવનશૈલી, રંગ અને દાન હરોળ તથા વિભાગ 4A ના તત્વ આધારથી ચાલે; રત્ન વૈકલ્પિક અને હળવું જ રહે.` : `For parents: at school age this kit runs on its lifestyle, colour and charity rows plus the Section 4A Tattva anchors; the stone stays optional and mild.`}</div></div></div>` : ""}
        <div class="kit-row"><div class="kit-ico">📿</div><div class="kit-body"><div class="kit-label">${t("rudraksha", "Rudraksha")}</div><div class="kit-value">${esc(i.rudraksha)}</div></div></div>
        <div class="kit-row"><div class="kit-ico">🔱</div><div class="kit-body"><div class="kit-label">${t("yantra", "Yantra")}</div><div class="kit-value">${esc(yantraName)}</div></div></div>
        <div class="kit-row"><div class="kit-ico">🎨</div><div class="kit-body"><div class="kit-label">${t("colorDayMetal", "Colour / Metal") }</div><div class="kit-value">${esc(i.color)} · ${esc(i.metal)}</div></div></div>
        <div class="kit-row"><div class="kit-ico">🎁</div><div class="kit-body"><div class="kit-label">${t("charity", "Charity")}</div><div class="kit-value">${esc(i.charity)}</div></div></div>
        <div class="kit-row"><div class="kit-ico">🌿</div><div class="kit-body"><div class="kit-label">${t("lifestyle", "Lifestyle")}</div><div class="kit-value">${esc(i.lifestyle)}</div></div></div>
        <div class="kit-row"><div class="kit-ico">🍽</div><div class="kit-body"><div class="kit-label">${t("fast", "Fast")}</div><div class="kit-value">${esc(i.fast)}</div></div></div>
      </div>
    </div>`;
  }

  /* Crystal and Rudraksha remedy picks are intentionally Lo Shu-only. The
     Driver/Conductor baseline, zodiac reference and Vedic comparison do not
     add competing remedial stones. */
  function crystalGuide(p) {
    const db = getActiveDB();
    const remedyNumbers = [...new Set((p.loShuMissing || []).map(Number))];
    const sources = remedyNumbers.map((n) => db.numbers[n] && db.numbers[n].crystal).filter(Boolean);
    const keys = Object.keys(db.crystals || {}).filter((k) => k !== "Selenite" && k !== "5 Mukhi Rudraksha");
    const seen = new Set();
    const picks = [];
    for (const src of sources) {
      const s = String(src || "").toLowerCase();
      for (const k of keys) {
        if (!seen.has(k) && s.includes(k.toLowerCase())) { seen.add(k); picks.push(k); }
      }
    }

    const rudrakshaPool = remedyNumbers.map((n) => db.numbers[n] && db.numbers[n].rudraksha).filter(Boolean).join(" ").toLowerCase();
    const rudrakshaNote = rudrakshaPool.includes("5 mukhi") ? db.crystals["5 Mukhi Rudraksha"] : null;

    return { remedyNumbers, picks: picks.slice(0, 5), rudrakshaNote };
  }

  /* ================================================================
     2026-10 parity layers
     ================================================================
     A competitive review (docs/competitive-gap-analysis-2026.md) found
     four capabilities that comparable products ship and this one did
     not. They are rendered here, each inside its own authority scope
     and each carrying NO remedy obligation — the remedy layer stays
     exactly where it was, under Lo Shu.

       6A  Name Architecture       vowel / consonant split
       8A  Premises numerology     house / flat / plot / office number
       13a Personal cycles         month, day, calendar, date finder
       17A Western cross-reference optional Pythagorean chart

     The calculations live in insights.js as pure functions so they are
     independently testable; this file only decides what the client is
     shown and in which language.
     ================================================================ */
  function insightsEngine() {
    try { return (typeof window !== "undefined" && window.NVInsights) ? window.NVInsights : null; }
    catch (e) { return null; }
  }

  /* Tri-lingual inline literal, matching the convention used by the
     Muhurtha section: section copy that is unique to one card stays
     beside the card rather than inflating the shared i18n pack. */
  function triText(lang, en, hi, gu) {
    return lang === "hi" ? hi : lang === "gu" ? gu : en;
  }

  /* --- 6A · Name Architecture ------------------------------------
     The app scored one Chaldean total for the whole name. Every
     competing product splits the name into its vowels and its
     consonants, because the three numbers answer three different
     questions:

       Expression  (all letters) — what you do; already the app's
                   existing Name Number, so the two can never disagree
       Soul Urge   (vowels)      — what you privately want
       Personality (consonants)  — what the room meets first

     The genuinely differentiated part is the last table: because this
     app already generates spelling corrections, it can show what each
     correction does to the Soul Urge and the Personality, not just to
     the total. No competitor does that, because none of them generate
     the corrections in the first place. */
  function nameArchitecture(p) {
    const NI = insightsEngine();
    if (!NI) return null;
    const everyday = NI.nameArchitecture(p.name, { system: "chaldean" });
    const legal = p.nameDual && p.legalName ? NI.nameArchitecture(p.legalName, { system: "chaldean" }) : null;
    return { everyday, legal };
  }

  function renderNameArchitecture(p, nameSug) {
    const arch = nameArchitecture(p);
    if (!arch) return "";
    const NI = insightsEngine();
    const lang = getLang();
    const db = getActiveDB();
    const L = (en, hi, gu) => triText(lang, en, hi, gu);
    const e = arch.everyday;
    const planetOf = (n) => esc(String(((db.numbers || {})[n] || {}).planet || n).split(" ")[0]);

    const strip = e.letters.map((l) =>
      `<span class="letter-chip${l.vowel ? " letter-vowel" : " letter-consonant"}" data-letter="${esc(l.ch)}" data-letter-vowel="${l.vowel ? "1" : "0"}">${esc(l.ch)}<em>${l.value}</em></span>`
    ).join("");

    const card = (label, layer, total, note) => `<div class="card num-card" data-name-layer="${layer}">
      <div class="num-value">${total.reduced}</div>
      <div class="num-label">${label}</div>
      <div class="num-planet">${planetOf(total.reduced)} · ${L("Chaldean total", "कैल्डियन योग", "કૅલ્ડિયન સરવાળો")} ${total.compound}</div>
      <div class="num-traits">${note}</div>
    </div>`;

    const variants = (nameSug && (nameSug.variants || (nameSug.optional && nameSug.optional.variants))) || [];
    const shortlist = variants.slice(0, 4).map((v) => {
      const next = NI.nameArchitecture(v.text, { system: "chaldean" });
      const move = (before, after) => before === after
        ? `<span class="arch-same">${after}</span>`
        : `<span class="arch-move">${before} → <strong>${after}</strong></span>`;
      return `<tr data-arch-variant="${esc(v.text)}">
        <td><strong>${esc(v.text)}</strong><div class="card-sub">${esc(v.change || "")}</div></td>
        <td>${move(e.expression.reduced, next.expression.reduced)}</td>
        <td>${move(e.soulUrge.reduced, next.soulUrge.reduced)}</td>
        <td>${move(e.personality.reduced, next.personality.reduced)}</td>
      </tr>`;
    }).join("");

    const legalRow = arch.legal ? `<div class="card" data-name-layer="legal-architecture">
      <div class="card-title">${L("Statutory record — same split", "कानूनी रिकॉर्ड — वही विभाजन", "કાનૂની રેકોર્ડ — એ જ વિભાજન")}</div>
      <div class="kit-value">${esc(p.legalName)} — ${L("Expression", "अभिव्यक्ति", "અભિવ્યક્તિ")} <strong>${arch.legal.expression.reduced}</strong> ·
        ${L("Soul Urge", "आत्मा-इच्छा", "આત્મા-ઇચ્છા")} <strong>${arch.legal.soulUrge.reduced}</strong> ·
        ${L("Personality", "व्यक्तित्व", "વ્યક્તિત્વ")} <strong>${arch.legal.personality.reduced}</strong></div>
      <div class="card-sub">${L(
      "The statutory string usually splits differently from the everyday one. That is not an error: the document carries your formal identity and the business card carries your working one.",
      "कानूनी नाम का विभाजन प्रायः दैनिक नाम से अलग होता है। यह त्रुटि नहीं है — दस्तावेज़ आपकी औपचारिक पहचान रखता है और विज़िटिंग कार्ड आपकी कार्यशील पहचान।",
      "કાનૂની નામનું વિભાજન ઘણીવાર દૈનિક નામથી અલગ હોય છે. આ ભૂલ નથી — દસ્તાવેજ તમારી ઔપચારિક ઓળખ ધરાવે છે અને વિઝિટિંગ કાર્ડ તમારી કાર્યકારી ઓળખ."
    )}</div>
    </div>` : "";

    return `<section class="rsection" id="name-architecture-section" data-authority="name-architecture" data-name-architecture="chaldean">
      <h2 class="rsection-title"><span class="idx idx-wide">${SECTION.nameArch}</span>${L("Name Architecture — Soul Urge, Personality & Expression", "नाम-संरचना — आत्मा-इच्छा, व्यक्तित्व एवं अभिव्यक्ति", "નામ-સંરચના — આત્મા-ઇચ્છા, વ્યક્તિત્વ અને અભિવ્યક્તિ")}</h2>
      <p class="rsection-desc">${L(
      "Your name does not carry one number, it carries three. The vowels you cannot see when the name is spoken carry what you privately want; the consonants carry the impression the room forms before you speak; together they are the Expression that Section " + SECTION.name + " already reported.",
      "आपका नाम एक नहीं, तीन अंक रखता है। स्वर वह रखते हैं जो आप भीतर चाहते हैं; व्यंजन वह प्रभाव रखते हैं जो कमरा आपके बोलने से पहले बना लेता है; दोनों मिलकर वही अभिव्यक्ति बनाते हैं जो खंड " + SECTION.name + " में पहले ही दी गई है।",
      "તમારું નામ એક નહીં, ત્રણ અંક ધરાવે છે. સ્વરો તમારી અંદરની ઇચ્છા ધરાવે છે; વ્યંજનો તમે બોલો તે પહેલાંની છાપ ધરાવે છે; બંને મળીને એ જ અભિવ્યક્તિ બને છે જે વિભાગ " + SECTION.name + " માં પહેલેથી આપી છે."
    )}</p>
      <div class="card-grid three">
        ${card(L("Soul Urge (vowels)", "आत्मा-इच्छा (स्वर)", "આત્મા-ઇચ્છા (સ્વરો)"), "soul-urge", e.soulUrge,
      L("What genuinely motivates you, before anyone is watching.", "वह जो वास्तव में आपको प्रेरित करता है — किसी के देखने से पहले।", "જે ખરેખર તમને પ્રેરે છે — કોઈ જુએ તે પહેલાં."))}
        ${card(L("Personality (consonants)", "व्यक्तित्व (व्यंजन)", "વ્યક્તિત્વ (વ્યંજનો)"), "personality", e.personality,
      L("The first impression your name makes on a stranger.", "अपरिचित व्यक्ति पर आपके नाम की पहली छाप।", "અજાણ્યા પર તમારા નામની પહેલી છાપ."))}
        ${card(L("Expression (all letters)", "अभिव्यक्ति (सभी अक्षर)", "અભિવ્યક્તિ (બધા અક્ષરો)"), "expression", e.expression,
      L("Identical to your Name Number in Section " + SECTION.name + " — the two can never disagree.", "खंड " + SECTION.name + " के नाम-अंक के समान — दोनों कभी भिन्न नहीं हो सकते।", "વિભાગ " + SECTION.name + " ના નામ-અંક સમાન — બંને ક્યારેય અલગ ન પડે."))}
      </div>
      <div class="card">
        <div class="card-title">${L("Letter by letter", "अक्षर दर अक्षर", "અક્ષર દર અક્ષર")}</div>
        <div class="letter-strip">${strip}</div>
        <div class="card-sub">${L(
      "Gold = vowel (Soul Urge), slate = consonant (Personality). Y is read as a vowel only when it carries the syllable alone — Mary and Lynn yes, Maya and Yolanda no. W is always read as a consonant, because the diphthong cases cannot be decided from spelling and a guess would silently move your Soul Urge.",
      "सुनहरा = स्वर (आत्मा-इच्छा), स्लेट = व्यंजन (व्यक्तित्व)। Y केवल तब स्वर गिना जाता है जब वह अकेले अक्षर-ध्वनि संभालता है — Mary और Lynn में हाँ, Maya और Yolanda में नहीं। W सदैव व्यंजन है, क्योंकि संयुक्त-स्वर के मामले वर्तनी से तय नहीं हो सकते और अनुमान आपकी आत्मा-इच्छा को चुपचाप बदल देता।",
      "સોનેરી = સ્વર (આત્મા-ઇચ્છા), સ્લેટ = વ્યંજન (વ્યક્તિત્વ). Y ત્યારે જ સ્વર ગણાય જ્યારે તે એકલો ઉચ્ચાર સંભાળે — Mary અને Lynn માં હા, Maya અને Yolanda માં ના. W હંમેશા વ્યંજન છે, કારણ કે સંયુક્ત-સ્વરના કિસ્સા જોડણીથી નક્કી ન થાય અને અનુમાન તમારી આત્મા-ઇચ્છા ચૂપચાપ બદલી નાખે."
    )}</div>
      </div>
      ${(e.cornerstone || e.capstone) ? `<div class="card-grid two">
        ${e.cornerstone ? `<div class="card"><div class="card-title">${L("Cornerstone", "आधार-अक्षर", "આધાર-અક્ષર")} — ${esc(e.cornerstone.ch)}</div><div class="kit-value">${L("The first letter of your first name sets how you meet a new situation.", "आपके प्रथम नाम का पहला अक्षर बताता है कि आप नई परिस्थिति से कैसे मिलते हैं।", "તમારા પ્રથમ નામનો પહેલો અક્ષર બતાવે છે કે તમે નવી પરિસ્થિતિને કેવી રીતે મળો છો.")} ${L("Value", "मान", "મૂલ્ય")} ${e.cornerstone.value} · ${planetOf(reduce(e.cornerstone.value))}</div></div>` : ""}
        ${e.capstone ? `<div class="card"><div class="card-title">${L("Capstone", "शिखर-अक्षर", "શિખર-અક્ષર")} — ${esc(e.capstone.ch)}</div><div class="kit-value">${L("The last letter of your first name shows how you finish what you start.", "आपके प्रथम नाम का अंतिम अक्षर बताता है कि आप आरंभ किए काम को कैसे पूरा करते हैं।", "તમારા પ્રથમ નામનો છેલ્લો અક્ષર બતાવે છે કે તમે શરૂ કરેલું કામ કેવી રીતે પૂરું કરો છો.")} ${L("Value", "मान", "મૂલ્ય")} ${e.capstone.value} · ${planetOf(reduce(e.capstone.value))}</div></div>` : ""}
      </div>` : ""}
      ${shortlist ? `<div class="card" data-arch-variants>
        <div class="card-title">${L("What each suggested spelling actually moves", "प्रत्येक सुझाई वर्तनी वास्तव में क्या बदलती है", "દરેક સૂચવેલી જોડણી ખરેખર શું બદલે છે")}</div>
        <div class="table-scroll"><table class="rtable arch-table">
          <thead><tr>
            <th>${L("Spelling", "वर्तनी", "જોડણી")}</th>
            <th>${L("Expression", "अभिव्यक्ति", "અભિવ્યક્તિ")}</th>
            <th>${L("Soul Urge", "आत्मा-इच्छा", "આત્મા-ઇચ્છા")}</th>
            <th>${L("Personality", "व्यक्तित्व", "વ્યક્તિત્વ")}</th>
          </tr></thead>
          <tbody>${shortlist}</tbody>
        </table></div>
        <div class="card-sub">${L(
      "A correction that lifts the Expression but leaves the Soul Urge untouched changes how you are received without changing what you want — usually the safer change. One that moves all three is a bigger shift and should be lived with for a month before any paperwork.",
      "जो सुधार अभिव्यक्ति बदले पर आत्मा-इच्छा को न छुए, वह आपके स्वीकार किए जाने का ढंग बदलता है, आपकी चाह नहीं — प्रायः यही सुरक्षित परिवर्तन है। जो तीनों बदल दे वह बड़ा परिवर्तन है; कागज़ी कार्रवाई से पहले एक माह उसके साथ जिएँ।",
      "જે સુધારો અભિવ્યક્તિ બદલે પણ આત્મા-ઇચ્છાને ન અડે, તે તમે કેવી રીતે સ્વીકારાઓ છો તે બદલે છે, તમારી ઇચ્છા નહીં — સામાન્ય રીતે એ જ સલામત ફેરફાર. જે ત્રણેય બદલે તે મોટો ફેરફાર છે; કાગળકામ પહેલાં એક મહિનો તેની સાથે જીવો."
    )}</div>
      </div>` : ""}
      ${legalRow}
    </section>`;
  }

  /* --- 8A · Premises numerology ----------------------------------
     Conspicuously absent from a product whose other half is Vastu:
     the number on the door. Two totals are reported because practice
     genuinely uses two, and the actionable half is the nameplate
     tuning — a suffix letter changes the full token without anyone
     having to move house. */
  function premisesReport(p) {
    const NI = insightsEngine();
    if (!NI || !p.premises) return null;
    return NI.premisesNumerology(p.premises, { driver: p.driver, conductor: p.conductor }, { kind: p.premisesKind });
  }

  function renderPremises(p) {
    const data = premisesReport(p);
    if (!data || !data.ok) return "";
    const lang = getLang();
    const db = getActiveDB();
    const L = (en, hi, gu) => triText(lang, en, hi, gu);
    const planetOf = (n) => esc(String(((db.numbers || {})[n] || {}).planet || n).split(" ")[0]);
    const kindLabel = {
      home: L("Home", "घर", "ઘર"), flat: L("Flat", "फ्लैट", "ફ્લેટ"), plot: L("Plot", "भूखंड", "પ્લોટ"),
      office: L("Office", "कार्यालय", "ઓફિસ"), shop: L("Shop", "दुकान", "દુકાન"),
      desk: L("Desk", "डेस्क", "ડેસ્ક"), account: L("Account", "खाता", "ખાતું")
    }[data.kind] || L("Premises", "परिसर", "પરિસર");

    const verdictText = {
      excellent: L("Excellent — harmonious with both your Driver and your Conductor.", "उत्तम — आपके मूलांक और भाग्यांक दोनों के अनुकूल।", "ઉત્તમ — તમારા મૂળાંક અને ભાગ્યાંક બંને સાથે અનુકૂળ."),
      supportive: L("Supportive — harmonious with one of your two birth numbers, neutral to the other.", "सहायक — आपके दो जन्म-अंकों में से एक के अनुकूल, दूसरे के प्रति तटस्थ।", "સહાયક — તમારા બે જન્મ-અંકોમાંથી એક સાથે અનુકૂળ, બીજા પ્રત્યે તટસ્થ."),
      neutral: L("Neutral — it neither helps nor hinders; the nameplate tuning below can lift it.", "तटस्थ — न सहायक, न बाधक; नीचे दी नामपट्टिका-ट्यूनिंग इसे ऊपर उठा सकती है।", "તટસ્થ — ન મદદરૂપ, ન અવરોધક; નીચેની નામપટ્ટી-ટ્યુનિંગ તેને ઊંચું લાવી શકે."),
      hostile: L("Conflicting — this total opposes one of your birth numbers. Tune the plate rather than panicking: the number you live behind is a daily input, not a verdict on your life.", "विरोधी — यह योग आपके एक जन्म-अंक के विरुद्ध है। घबराएँ नहीं, नामपट्टिका को ट्यून करें: जिस अंक के पीछे आप रहते हैं वह एक दैनिक प्रभाव है, जीवन का निर्णय नहीं।", "વિરોધી — આ સરવાળો તમારા એક જન્મ-અંકની વિરુદ્ધ છે. ગભરાશો નહીં, નામપટ્ટી ટ્યુન કરો: જે અંક પાછળ તમે રહો છો તે દૈનિક અસર છે, જીવનનો ચુકાદો નહીં.")
    }[data.operative.verdict];

    const tuningRows = data.tuning.map((t) => `<tr data-premises-tuning="${esc(t.letter)}">
      <td><strong>${esc(data.raw)}-${esc(t.letter)}</strong></td>
      <td>${t.compound} → <strong>${t.reduced}</strong> · ${planetOf(t.reduced)}</td>
      <td>${t.verdict === "excellent" ? L("Excellent", "उत्तम", "ઉત્તમ") : L("Supportive", "सहायक", "સહાયક")}</td>
    </tr>`).join("");

    return `<section class="rsection" id="premises-section" data-authority="premises-numerology" data-premises-kind="${esc(data.kind)}" data-premises-verdict="${esc(data.operative.verdict)}">
      <h2 class="rsection-title"><span class="idx idx-wide">${SECTION.premises}</span>${L("Premises Number — ", "परिसर अंक — ", "પરિસર અંક — ")}${esc(kindLabel)}</h2>
      <p class="rsection-desc">${L(
      "The number you walk past every single day is read the same way your mobile and vehicle numbers are. This is the one reading where numerology and Vastu meet on the same object, so it is reported as context for Section " + SECTION.vastu + " rather than as a reason to move.",
      "जिस अंक के पास से आप प्रतिदिन गुज़रते हैं, उसे वैसे ही पढ़ा जाता है जैसे आपका मोबाइल और वाहन अंक। यही एक पाठ है जहाँ अंकशास्त्र और वास्तु एक ही वस्तु पर मिलते हैं — इसे खंड " + SECTION.vastu + " के संदर्भ के रूप में लें, स्थान बदलने के कारण के रूप में नहीं।",
      "જે અંક પાસેથી તમે રોજ પસાર થાઓ છો, તેને એ જ રીતે વાંચવામાં આવે છે જેમ તમારો મોબાઇલ અને વાહન અંક. આ એક જ વાચન છે જ્યાં અંકશાસ્ત્ર અને વાસ્તુ એક જ વસ્તુ પર મળે છે — તેને વિભાગ " + SECTION.vastu + " ના સંદર્ભ તરીકે લો, સ્થાન બદલવાના કારણ તરીકે નહીં."
    )}</p>
      <div class="card-grid ${data.hasLetters ? "two" : ""}">
        <div class="card num-card" data-premises-layer="door">
          <div class="num-value">${data.door.reduced}</div>
          <div class="num-label">${L("Door digits", "द्वार अंक", "દ્વાર અંક")} · ${esc(data.digits)}</div>
          <div class="num-planet">${planetOf(data.door.reduced)} · ${L("total", "योग", "સરવાળો")} ${data.door.compound}</div>
          <div class="num-traits">${L("The digits alone — the number you live inside.", "केवल अंक — जिसके भीतर आप रहते हैं।", "માત્ર અંકો — જેની અંદર તમે રહો છો.")}</div>
        </div>
        ${data.hasLetters ? `<div class="card num-card" data-premises-layer="full">
          <div class="num-value">${data.full.reduced}</div>
          <div class="num-label">${L("Full token", "पूर्ण पता", "પૂર્ણ સરનામું")} · ${esc(data.raw)}</div>
          <div class="num-planet">${planetOf(data.full.reduced)} · ${L("total", "योग", "સરવાળો")} ${data.full.compound}</div>
          <div class="num-traits">${L("Digits plus the block / wing letter — your full postal identity.", "अंक + ब्लॉक/विंग अक्षर — आपकी पूर्ण डाक पहचान।", "અંકો + બ્લોક/વિંગ અક્ષર — તમારી પૂર્ણ ટપાલ ઓળખ.")}</div>
        </div>` : ""}
      </div>
      <div class="card">
        <div class="card-title">${L("Verdict", "निर्णय", "ચુકાદો")}</div>
        <div class="kit-value">${verdictText}</div>
        <div class="card-sub">${L("Operative reading", "प्रभावी पाठ", "અસરકારક વાચન")}: <strong>${data.operative.reduced}</strong> ·
          ${L("Driver", "मूलांक", "મૂળાંક")} ${p.driver} → ${esc(relBadgeText(data.operative.relD))} ·
          ${L("Conductor", "भाग्यांक", "ભાગ્યાંક")} ${p.conductor} → ${esc(relBadgeText(data.operative.relC))}</div>
      </div>
      ${tuningRows ? `<div class="card" data-premises-tuning-card>
        <div class="card-title">${L("Nameplate tuning — change the plate, not the address", "नामपट्टिका ट्यूनिंग — पता नहीं, पट्टिका बदलें", "નામપટ્ટી ટ્યુનિંગ — સરનામું નહીં, પટ્ટી બદલો")}</div>
        <div class="table-scroll"><table class="rtable">
          <thead><tr><th>${L("Plate reads", "पट्टिका पर", "પટ્ટી પર")}</th><th>${L("New total", "नया योग", "નવો સરવાળો")}</th><th>${L("Becomes", "बन जाता है", "બની જાય છે")}</th></tr></thead>
          <tbody>${tuningRows}</tbody>
        </table></div>
        <div class="card-sub">${L(
      "Adding a single letter to the plate is the classical adjustment — it changes nothing legal, nothing postal and nothing structural. Pick one and keep it consistent across the door, the letterbox and the utility records.",
      "पट्टिका पर एक अक्षर जोड़ना शास्त्रीय समायोजन है — इससे कानूनी, डाक या संरचनात्मक कुछ नहीं बदलता। एक चुनें और उसे दरवाज़े, लेटरबॉक्स तथा उपयोगिता रिकॉर्ड में समान रखें।",
      "પટ્ટી પર એક અક્ષર ઉમેરવો એ શાસ્ત્રીય સમાયોજન છે — તેનાથી કાનૂની, ટપાલ કે માળખાકીય કશું બદલાતું નથી. એક પસંદ કરો અને તેને દરવાજા, લેટરબોક્સ અને યુટિલિટી રેકોર્ડમાં સમાન રાખો."
    )}</div>
      </div>` : ""}
      <div class="card">
        <div class="card-title">${L("If you are choosing rather than rationalising", "यदि आप चुन रहे हैं, न कि समझौता कर रहे हैं", "જો તમે પસંદ કરી રહ્યા છો, સમાધાન નહીં")}</div>
        <div class="kit-value">${L("Door totals that suit this chart", "इस कुंडली के अनुकूल द्वार-योग", "આ કુંડળીને અનુકૂળ દ્વાર-સરવાળા")}: <strong>${data.harmonious.length ? data.harmonious.join(", ") : L("none clearly favourable — prefer a neutral total", "कोई स्पष्ट अनुकूल नहीं — तटस्थ योग चुनें", "કોઈ સ્પષ્ટ અનુકૂળ નથી — તટસ્થ સરવાળો પસંદ કરો")}</strong></div>
        <div class="card-sub">${L("Use this when shortlisting a flat, a shop unit or a locker — before the paperwork, not after.", "फ्लैट, दुकान या लॉकर चुनते समय इसका उपयोग करें — कागज़ी कार्रवाई से पहले, बाद में नहीं।", "ફ્લેટ, દુકાન કે લોકર પસંદ કરતી વખતે આનો ઉપયોગ કરો — કાગળકામ પહેલાં, પછી નહીં.")}</div>
      </div>
    </section>`;
  }

  /* Plain-language relation label, reused by the new sections. */
  function relBadgeText(r) {
    const lang = getLang();
    const labels = {
      en: { friendly: "Harmonious", neutral: "Neutral", enemy: "Conflicting" },
      hi: { friendly: "अनुकूल", neutral: "तटस्थ", enemy: "विरोधी" },
      gu: { friendly: "અનુકૂળ", neutral: "તટસ્થ", enemy: "વિરોધી" }
    };
    return (labels[lang] || labels.en)[r] || r;
  }

  /* --- 13a · Personal cycles & the favourable-date finder ---------
     The app could tell a client what this YEAR means and what this
     MAHADASHA means, and nothing in between — while every competing
     product ships a personal day, a personal month and a calendar.
     This closes the gap on the app's own calendar-year convention, so
     the Personal Year printed here is always the one Section 13
     already printed. */
  function renderPersonalCycles(p, nowMs) {
    const NI = insightsEngine();
    if (!NI) return "";
    const lang = getLang();
    const db = getActiveDB();
    const L = (en, hi, gu) => triText(lang, en, hi, gu);
    const now = new Date(nowMs === undefined || nowMs === null ? Date.now() : nowMs);
    const cyc = NI.personalCycles({ day: p.day, month: p.month }, now);
    const planetOf = (n) => esc(String(((db.numbers || {})[n] || {}).planet || n).split(" ")[0]);
    const py = (db.personalYear && db.personalYear[cyc.personalYear]) || "";

    const monthNames = {
      en: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      hi: ["जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्तूबर", "नवंबर", "दिसंबर"],
      gu: ["જાન્યુઆરી", "ફેબ્રુઆરી", "માર્ચ", "એપ્રિલ", "મે", "જૂન", "જુલાઈ", "ઓગસ્ટ", "સપ્ટેમ્બર", "ઓક્ટોબર", "નવેમ્બર", "ડિસેમ્બર"]
    }[lang] || null;
    const monthName = (monthNames || ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"])[cyc.month - 1];

    /* The month grid. Grades come from the same scorer the date finder
       uses, so a day can never be green in one card and red in the
       other. */
    const cal = NI.personalCalendar({ driver: p.driver, conductor: p.conductor, day: p.day, month: p.month }, cyc.year, cyc.month);
    const firstWeekday = new Date(cyc.year, cyc.month - 1, 1).getDay();
    const blanks = Array.from({ length: firstWeekday }, () => `<div class="cal-cell cal-blank" aria-hidden="true"></div>`).join("");
    const cells = cal.days.map((d) => `<div class="cal-cell cal-${d.grade}${d.cycles.day === cyc.day ? " cal-today" : ""}" data-cal-day="${d.cycles.day}" data-cal-grade="${d.grade}" data-cal-pd="${d.cycles.personalDay}" title="${esc(String(d.iso))} · PD ${d.cycles.personalDay}">
      <span class="cal-date">${d.cycles.day}</span><span class="cal-pd">${d.cycles.personalDay}</span>
    </div>`).join("");
    const weekdayShort = {
      en: ["S", "M", "T", "W", "T", "F", "S"],
      hi: ["र", "सो", "मं", "बु", "गु", "शु", "श"],
      gu: ["ર", "સો", "મં", "બુ", "ગુ", "શુ", "શ"]
    }[lang] || ["S", "M", "T", "W", "T", "F", "S"];

    /* A date offered without its reasoning is an oracle, not a reading.
       Every pill therefore carries the scoring trail that produced it,
       phrased in the client's language, as its tooltip. */
    const reasonText = {
      "pd-driver": (d) => L(`Personal Day ${d.pd} is ${d.relation} to Driver ${d.driver}`, `व्यक्तिगत दिन ${d.pd} मूलांक ${d.driver} के प्रति ${relBadgeText(d.relation)}`, `વ્યક્તિગત દિવસ ${d.pd} મૂળાંક ${d.driver} પ્રત્યે ${relBadgeText(d.relation)}`),
      "pd-conductor": (d) => L(`Personal Day ${d.pd} is ${d.relation} to Conductor ${d.conductor}`, `व्यक्तिगत दिन ${d.pd} भाग्यांक ${d.conductor} के प्रति ${relBadgeText(d.relation)}`, `વ્યક્તિગત દિવસ ${d.pd} ભાગ્યાંક ${d.conductor} પ્રત્યે ${relBadgeText(d.relation)}`),
      "pd-is-driver": (d) => L(`Personal Day equals your Driver ${d.pd}`, `व्यक्तिगत दिन आपके मूलांक ${d.pd} के बराबर`, `વ્યક્તિગત દિવસ તમારા મૂળાંક ${d.pd} બરાબર`),
      "pd-is-conductor": (d) => L(`Personal Day equals your Conductor ${d.pd}`, `व्यक्तिगत दिन आपके भाग्यांक ${d.pd} के बराबर`, `વ્યક્તિગત દિવસ તમારા ભાગ્યાંક ${d.pd} બરાબર`),
      "date-root": (d) => L(`Date root ${d.root} is ${d.relation} to your Driver`, `तिथि-मूल ${d.root} आपके मूलांक के प्रति ${relBadgeText(d.relation)}`, `તારીખ-મૂળ ${d.root} તમારા મૂળાંક પ્રત્યે ${relBadgeText(d.relation)}`),
      "weekday-lord": (d) => L(`${dayOf(d.lord)} rules this weekday and is ${d.relation} to your Driver`, `${dayOf(d.lord)} इस वार का स्वामी है और आपके मूलांक के प्रति ${relBadgeText(d.relation)}`, `${dayOf(d.lord)} આ વારનો સ્વામી છે અને તમારા મૂળાંક પ્રત્યે ${relBadgeText(d.relation)}`),
      "purpose-primary": (d) => L(`Personal Day ${d.pd} is a primary significator for this purpose`, `व्यक्तिगत दिन ${d.pd} इस कार्य का मुख्य कारक है`, `વ્યક્તિગત દિવસ ${d.pd} આ કાર્યનો મુખ્ય કારક છે`),
      "purpose-support": (d) => L(`Personal Day ${d.pd} supports this purpose`, `व्यक्तिगत दिन ${d.pd} इस कार्य का सहायक है`, `વ્યક્તિગત દિવસ ${d.pd} આ કાર્યને સહાય કરે છે`),
      "purpose-enemy": (d) => L(`Personal Day ${d.pd} opposes the significators of this purpose`, `व्यक्तिगत दिन ${d.pd} इस कार्य के कारकों का विरोधी है`, `વ્યક્તિગત દિવસ ${d.pd} આ કાર્યના કારકોનો વિરોધી છે`)
    };
    const whyDate = (b) => {
      const lines = (b.reasons || []).map((r) => {
        const fn = reasonText[r.code];
        const text = fn ? fn(r.detail || {}) : r.code;
        return `${r.points > 0 ? "+" : ""}${r.points}  ${text}`;
      });
      return `${L("Score", "अंक", "ગુણ")} ${b.score} · ${b.grade}\n${lines.join("\n")}`;
    };

    /* Favourable-date finder, one block per life area the knowledge
       pack already defines, so the dates and the Dasha event windows
       in Section 14 cannot contradict each other on doctrine. */
    const events = (db.dasha && db.dasha.lifeEvents) || {};
    const finderBlocks = Object.keys(events).map((key) => {
      const row = events[key] || {};
      const label = (row.label && (row.label[lang] || row.label.en)) || key;
      const found = NI.favourableDates({ driver: p.driver, conductor: p.conductor, day: p.day, month: p.month },
        { purpose: key, fromMs: now.getTime(), days: 90, limit: 4 });
      const best = found.best.filter((b) => b.grade !== "avoid");
      if (!best.length) return "";
      return `<tr data-finder-purpose="${esc(key)}">
        <td>${esc(row.icon || "")} ${esc(label)}</td>
        <td>${best.map((b) => `<span class="date-pill date-${b.grade}" data-finder-date="${esc(b.iso)}" data-finder-grade="${esc(b.grade)}" title="${esc(whyDate(b))}">${formatStampDate(b.date)}<em>PD ${b.cycles.personalDay} · ${esc(b.grade)}</em></span>`).join(" ")}</td>
      </tr>`;
    }).filter(Boolean).join("");

    const todayGrade = NI.gradeDate({ driver: p.driver, conductor: p.conductor, day: p.day, month: p.month }, now);

    return `<section class="rsection" id="personal-cycles-section" data-authority="personal-cycles" data-personal-day="${cyc.personalDay}" data-personal-month="${cyc.personalMonth}" data-personal-year="${cyc.personalYear}">
      <h2 class="rsection-title"><span class="idx idx-wide">${SECTION.cycles}</span>${L("Personal Cycles — Year, Month and Day", "व्यक्तिगत चक्र — वर्ष, मास एवं दिन", "વ્યક્તિગત ચક્રો — વર્ષ, માસ અને દિવસ")}</h2>
      <p class="rsection-desc">${L(
      "Section " + SECTION.timing + " reads the year and Section " + SECTION.dasha + " reads the Dasha. Between them sits the layer you actually plan a week around. Same calendar-year convention as Section " + SECTION.timing + ", so the Personal Year below is the one you have already read.",
      "खंड " + SECTION.timing + " वर्ष पढ़ता है और खंड " + SECTION.dasha + " दशा। इनके बीच वही परत है जिस पर आप सप्ताह की योजना बनाते हैं। वही कैलेंडर-वर्ष परंपरा जो खंड " + SECTION.timing + " में है — अतः नीचे का व्यक्तिगत वर्ष वही है जो आपने पहले पढ़ा।",
      "વિભાગ " + SECTION.timing + " વર્ષ વાંચે છે અને વિભાગ " + SECTION.dasha + " દશા. તેમની વચ્ચે એ જ સ્તર છે જેના પર તમે અઠવાડિયાનું આયોજન કરો છો. એ જ કેલેન્ડર-વર્ષ પરંપરા જે વિભાગ " + SECTION.timing + " માં છે — તેથી નીચેનું વ્યક્તિગત વર્ષ એ જ છે જે તમે વાંચી ચૂક્યા છો."
    )}</p>
      <div class="card-grid three">
        <div class="card num-card" data-cycle-layer="year">
          <div class="num-value">${cyc.personalYear}</div>
          <div class="num-label">${L("Personal Year", "व्यक्तिगत वर्ष", "વ્યક્તિગત વર્ષ")} ${cyc.year}</div>
          <div class="num-planet">${planetOf(cyc.personalYear)}</div>
          <div class="num-traits">${esc(String(py).slice(0, 160))}</div>
        </div>
        <div class="card num-card" data-cycle-layer="month">
          <div class="num-value alt">${cyc.personalMonth}</div>
          <div class="num-label">${L("Personal Month", "व्यक्तिगत मास", "વ્યક્તિગત માસ")} · ${esc(monthName)}</div>
          <div class="num-planet">${planetOf(cyc.personalMonth)}</div>
          <div class="num-traits">${esc(cyc.formula.pm)}</div>
        </div>
        <div class="card num-card" data-cycle-layer="day">
          <div class="num-value">${cyc.personalDay}</div>
          <div class="num-label">${L("Personal Day", "व्यक्तिगत दिन", "વ્યક્તિગત દિવસ")} · ${formatStampDate(now)}</div>
          <div class="num-planet">${planetOf(cyc.personalDay)}</div>
          <div class="num-traits">${esc(cyc.formula.pd)} · ${L("today grades", "आज का श्रेणी", "આજની શ્રેણી")} <strong>${esc(todayGrade.grade)}</strong></div>
        </div>
      </div>
      <div class="card" data-personal-calendar>
        <div class="card-title">${L("Your month at a glance", "आपका मास एक नज़र में", "તમારો માસ એક નજરે")} — ${esc(monthName)} ${cyc.year}</div>
        <div class="cal-grid" role="table" aria-label="${L("Personal day calendar", "व्यक्तिगत दिन कैलेंडर", "વ્યક્તિગત દિવસ કૅલેન્ડર")}">
          ${weekdayShort.map((w) => `<div class="cal-head" role="columnheader">${esc(w)}</div>`).join("")}
          ${blanks}${cells}
        </div>
        <div class="cal-legend">
          <span class="cal-key cal-excellent"></span>${L("Excellent", "उत्तम", "ઉત્તમ")}
          <span class="cal-key cal-good"></span>${L("Good", "अच्छा", "સારું")}
          <span class="cal-key cal-workable"></span>${L("Workable", "चलने योग्य", "ચાલે તેવું")}
          <span class="cal-key cal-avoid"></span>${L("Hold back", "रोकें", "રોકો")}
        </div>
        <div class="card-sub">${L(
      "The small number in each cell is that day's Personal Day. The colour grades it against your Driver, your Conductor, the date root and the weekday's planetary lord — the full scoring is printed under the date finder below.",
      "प्रत्येक खाने का छोटा अंक उस दिन का व्यक्तिगत दिन है। रंग उसे आपके मूलांक, भाग्यांक, तिथि-मूल और वार-स्वामी के विरुद्ध श्रेणीबद्ध करता है — पूरा अंकन नीचे दिनांक-खोजक के साथ दिया है।",
      "દરેક ખાનામાંનો નાનો અંક તે દિવસનો વ્યક્તિગત દિવસ છે. રંગ તેને તમારા મૂળાંક, ભાગ્યાંક, તારીખ-મૂળ અને વાર-સ્વામી સામે શ્રેણીબદ્ધ કરે છે — પૂરું ગુણાંકન નીચે તારીખ-શોધક સાથે આપ્યું છે."
    )}</div>
      </div>
      ${finderBlocks ? `<div class="card" data-date-finder>
        <div class="card-title">${L("Favourable dates in the next 90 days", "अगले ९० दिनों की शुभ तिथियाँ", "આગામી ૯૦ દિવસની શુભ તારીખો")}</div>
        <div class="table-scroll"><table class="rtable">
          <thead><tr><th>${L("For", "किसके लिए", "કોના માટે")}</th><th>${L("Best dates", "श्रेष्ठ तिथियाँ", "શ્રેષ્ઠ તારીખો")}</th></tr></thead>
          <tbody>${finderBlocks}</tbody>
        </table></div>
        <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${L(
      "each date is scored on five independent inputs — Personal Day against your Driver (±3) and Conductor (±2), the date root against your Driver (±2), the weekday's planetary lord against your Driver (±2), and the life-area significators the knowledge pack already uses for the Dasha event windows (+3 primary, +1 supporting). A good date is not yet a good hour, and this layer does not outrank the classical Muhurtha: once you have picked a date here, open the Muhurtha section (" + SECTION.timing + "b) for that day and place the act inside Abhijit or a Shubh / Amrit / Labh Choghadiya, outside Rahu Kaal and outside Vishti.",
      "प्रत्येक तिथि पाँच स्वतंत्र आधारों पर अंकित है — व्यक्तिगत दिन बनाम मूलांक (±३) और भाग्यांक (±२), तिथि-मूल बनाम मूलांक (±२), वार-स्वामी बनाम मूलांक (±२), तथा वही जीवन-क्षेत्र कारक जो ज्ञान-पैक दशा-खिड़कियों में प्रयोग करता है (+३ प्रमुख, +१ सहायक)। शुभ तिथि अभी शुभ मुहूर्त नहीं है, और यह परत शास्त्रीय मुहूर्त से ऊपर नहीं है: तिथि चुनने के बाद उसी दिन का मुहूर्त खंड (" + SECTION.timing + "b) खोलें और कार्य को अभिजित अथवा शुभ / अमृत / लाभ चौघड़िया में रखें — राहु काल और विष्टि से बाहर।",
      "દરેક તારીખ પાંચ સ્વતંત્ર આધારો પર ગુણાંકિત છે — વ્યક્તિગત દિવસ વિરુદ્ધ મૂળાંક (±૩) અને ભાગ્યાંક (±૨), તારીખ-મૂળ વિરુદ્ધ મૂળાંક (±૨), વાર-સ્વામી વિરુદ્ધ મૂળાંક (±૨), અને એ જ જીવન-ક્ષેત્ર કારકો જે જ્ઞાન-પૅક દશા-વિન્ડોમાં વાપરે છે (+૩ મુખ્ય, +૧ સહાયક). શુભ તારીખ હજી શુભ મુહૂર્ત નથી, અને આ સ્તર શાસ્ત્રીય મુહૂર્તથી ઉપર નથી: તારીખ પસંદ કર્યા પછી એ જ દિવસનો મુહૂર્ત વિભાગ (" + SECTION.timing + "b) ખોલો અને કાર્યને અભિજિત અથવા શુભ / અમૃત / લાભ ચોઘડિયામાં મૂકો — રાહુ કાળ અને વિષ્ટિની બહાર."
    )}</div>
      </div>` : ""}
    </section>`;
  }

  /* --- 17A · Western (Pythagorean) cross-reference ----------------
     A deliberate OPTIONAL MODULE, built exactly like the Feng Shui /
     Kua module: a second school, named as such, collapsed by default,
     and structurally forbidden from choosing a remedy, a crystal, a
     deity, a Vastu zone or a Dasha. It exists because a client who has
     read any Western numerology site arrives asking for their Life
     Path and Soul Urge, and the honest answer is "that is a different
     school, here is what it says, here is where it disagrees with
     yours" — not silence. */
  function renderWesternCrossRef(p) {
    const NI = insightsEngine();
    if (!NI) return "";
    const lang = getLang();
    const L = (en, hi, gu) => triText(lang, en, hi, gu);
    const w = NI.westernProfile({ name: p.name, day: p.day, month: p.month, year: p.year });
    const agrees = w.lifePath.reduced === p.conductor;
    const planeNames = {
      physical: L("Physical", "भौतिक", "ભૌતિક"), mental: L("Mental", "मानसिक", "માનસિક"),
      emotional: L("Emotional", "भावनात्मक", "ભાવનાત્મક"), intuitive: L("Intuitive", "सहज-ज्ञान", "સહજ-જ્ઞાન")
    };
    const planeRows = NI.PLANE_KEYS.map((key) => {
      const row = w.planes.planes[key];
      return `<tr data-plane="${key}">
        <td>${esc(planeNames[key])}</td>
        <td>${row.count}</td>
        <td>${row.letters.join(" ") || "—"}</td>
        <td>${row.count ? row.reduced : "—"}</td>
      </tr>`;
    }).join("");

    const num = (v) => `<strong>${v.master ? v.master : v.reduced}</strong>${v.master ? ` <span class="badge">${L("master", "मास्टर", "માસ્ટર")}</span>` : ""}`;

    return `<section class="rsection" id="western-section" data-authority="western-cross-reference" data-module="western-optional">
      <h2 class="rsection-title"><span class="idx idx-wide">${SECTION.western}</span>${L("Optional Module — Western (Pythagorean) Cross-Reference", "वैकल्पिक मॉड्यूल — पाश्चात्य (पाइथागोरियन) तुलना", "વૈકલ્પિક મોડ્યુલ — પાશ્ચાત્ય (પાયથાગોરિયન) તુલના")}</h2>
      <p class="rsection-desc">${L(
      "A different school, reported as a different school. Western numerology maps letters A=1…I=9 and keeps 11, 22 and 33 unreduced; your chart is Chaldean and Vedic. Nothing in this module selects a remedy, a crystal, a deity, a Vastu zone or a Dasha — it is here so that a number you read on a Western site can be placed, not so that it can compete.",
      "भिन्न परंपरा, भिन्न परंपरा के रूप में ही प्रस्तुत। पाश्चात्य अंकशास्त्र A=१…I=९ मानता है और ११, २२, ३३ को अखंड रखता है; आपकी कुंडली कैल्डियन एवं वैदिक है। इस मॉड्यूल से कोई उपाय, रत्न, देवता, वास्तु-क्षेत्र या दशा नहीं चुनी जाती — यह केवल इसलिए है कि किसी पाश्चात्य स्रोत पर पढ़ा अंक अपनी जगह पा सके।",
      "અલગ પરંપરા, અલગ પરંપરા તરીકે જ રજૂ. પાશ્ચાત્ય અંકશાસ્ત્ર A=૧…I=૯ ગણે છે અને ૧૧, ૨૨, ૩૩ અખંડ રાખે છે; તમારી કુંડળી કૅલ્ડિયન અને વૈદિક છે. આ મોડ્યુલથી કોઈ ઉપાય, રત્ન, દેવતા, વાસ્તુ-ક્ષેત્ર કે દશા પસંદ થતી નથી — તે માત્ર એટલા માટે છે કે પાશ્ચાત્ય સ્રોત પર વાંચેલો અંક પોતાની જગ્યા મેળવી શકે."
    )}</p>
      <details class="details-block western-details western-cross-reference">
        <summary>${L("Open the Western chart", "पाश्चात्य चार्ट खोलें", "પાશ્ચાત્ય ચાર્ટ ખોલો")}</summary>
        <div class="details-body">
          <div class="card" data-western-compare="${agrees ? "agrees" : "differs"}">
            <div class="card-title">${L("Where the two schools stand", "दोनों परंपराएँ कहाँ खड़ी हैं", "બંને પરંપરાઓ ક્યાં ઊભી છે")}</div>
            <div class="kit-value">${L("Western Life Path", "पाश्चात्य लाइफ पाथ", "પાશ્ચાત્ય લાઇફ પાથ")} ${num(w.lifePath)} ·
              ${L("your Conductor (Bhagyank)", "आपका भाग्यांक", "તમારો ભાગ્યાંક")} <strong>${p.conductor}</strong> —
              ${agrees
        ? L("the two agree on this chart.", "इस कुंडली पर दोनों सहमत हैं।", "આ કુંડળી પર બંને સંમત છે.")
        : L("they differ, and that is expected: the Western method reduces the month, day and year separately and preserves master numbers, while the Bhagyank reduces the full date. Neither is wrong; they are answering with different rules.", "ये भिन्न हैं, और यह अपेक्षित है: पाश्चात्य विधि मास, दिन और वर्ष को अलग-अलग घटाती है और मास्टर अंक सुरक्षित रखती है, जबकि भाग्यांक पूरी तिथि घटाता है। कोई गलत नहीं — नियम भिन्न हैं।", "તે અલગ છે, અને તે અપેક્ષિત છે: પાશ્ચાત્ય પદ્ધતિ માસ, દિવસ અને વર્ષને અલગ ઘટાડે છે અને માસ્ટર અંક સાચવે છે, જ્યારે ભાગ્યાંક આખી તારીખ ઘટાડે છે. કોઈ ખોટું નથી — નિયમો અલગ છે.")}</div>
          </div>
          <div class="card-grid three">
            <div class="card num-card"><div class="num-value">${w.soulUrge.master || w.soulUrge.reduced}</div><div class="num-label">${L("Soul Urge", "आत्मा-इच्छा", "આત્મા-ઇચ્છા")}</div><div class="num-traits">${L("Pythagorean vowels", "पाइथागोरियन स्वर", "પાયથાગોરિયન સ્વરો")} · ${w.soulUrge.compound}</div></div>
            <div class="card num-card"><div class="num-value alt">${w.personality.master || w.personality.reduced}</div><div class="num-label">${L("Personality", "व्यक्तित्व", "વ્યક્તિત્વ")}</div><div class="num-traits">${L("Pythagorean consonants", "पाइथागोरियन व्यंजन", "પાયથાગોરિયન વ્યંજનો")} · ${w.personality.compound}</div></div>
            <div class="card num-card"><div class="num-value">${w.expression.master || w.expression.reduced}</div><div class="num-label">${L("Expression", "अभिव्यक्ति", "અભિવ્યક્તિ")}</div><div class="num-traits">${L("Pythagorean full name", "पाइथागोरियन पूर्ण नाम", "પાયથાગોરિયન પૂર્ણ નામ")} · ${w.expression.compound}</div></div>
          </div>
          <div class="card">
            <div class="card-title">${L("The modifiers Western practice reads", "पाश्चात्य परंपरा के संशोधक", "પાશ્ચાત્ય પરંપરાના સંશોધકો")}</div>
            <div class="kit">
              <div class="kit-row"><div class="kit-ico">🎂</div><div class="kit-body"><div class="kit-label">${L("Birthday / Attitude", "जन्मदिन / दृष्टिकोण", "જન્મદિવસ / દૃષ્ટિકોણ")}</div><div class="kit-value">${w.birthday.reduced} / ${w.attitude.reduced}</div></div></div>
              <div class="kit-row"><div class="kit-ico">🌾</div><div class="kit-body"><div class="kit-label">${L("Maturity", "परिपक्वता", "પરિપક્વતા")}</div><div class="kit-value">${w.maturity.reduced} — ${L("the theme that strengthens from the mid-thirties onward", "जो विषय तीस के मध्य से प्रबल होता है", "જે વિષય ત્રીસના મધ્યથી પ્રબળ થાય છે")}</div></div></div>
              <div class="kit-row"><div class="kit-ico">⚖️</div><div class="kit-body"><div class="kit-label">${L("Balance", "संतुलन", "સંતુલન")}</div><div class="kit-value">${w.balance.reduced} — ${L("how you steady yourself in turbulence", "अशांति में आप स्वयं को कैसे संभालते हैं", "અશાંતિમાં તમે પોતાને કેવી રીતે સંભાળો છો")} (${esc(w.balance.initials.join(" · "))})</div></div></div>
              <div class="kit-row"><div class="kit-ico">🧠</div><div class="kit-body"><div class="kit-label">${L("Rational Thought", "तार्किक चिंतन", "તાર્કિક ચિંતન")}</div><div class="kit-value">${w.rationalThought.reduced} — ${L("how you reason a problem through", "आप समस्या को कैसे सोचते हैं", "તમે સમસ્યાને કેવી રીતે વિચારો છો")}</div></div></div>
              <div class="kit-row"><div class="kit-ico">📚</div><div class="kit-body"><div class="kit-label">${L("Karmic Lessons", "कार्मिक पाठ", "કાર્મિક પાઠ")}</div><div class="kit-value" data-karmic-lessons="${w.karmicLessons.join(",")}">${w.karmicLessons.length ? w.karmicLessons.join(", ") : L("none — every digit appears in your name", "कोई नहीं — हर अंक आपके नाम में है", "કોઈ નહીં — દરેક અંક તમારા નામમાં છે")}</div></div></div>
              <div class="kit-row"><div class="kit-ico">🔥</div><div class="kit-body"><div class="kit-label">${L("Hidden Passion", "गुप्त आवेग", "ગુપ્ત આવેગ")}</div><div class="kit-value">${w.hiddenPassion.numbers.join(", ") || "—"}${w.hiddenPassion.count ? ` (×${w.hiddenPassion.count})` : ""}</div></div></div>
              <div class="kit-row"><div class="kit-ico">🛡️</div><div class="kit-body"><div class="kit-label">${L("Subconscious Self", "अवचेतन आत्म", "અવચેતન સ્વ")}</div><div class="kit-value">${w.subconsciousSelf} — ${L("your composure when a crisis lands without warning", "बिना चेतावनी संकट आने पर आपका संयम", "ચેતવણી વિના સંકટ આવે ત્યારે તમારી સ્વસ્થતા")}</div></div></div>
            </div>
          </div>
          <div class="card">
            <div class="card-title">${L("Planes of Expression", "अभिव्यक्ति के तल", "અભિવ્યક્તિના સ્તરો")}</div>
            <div class="table-scroll"><table class="rtable">
              <thead><tr><th>${L("Plane", "तल", "સ્તર")}</th><th>${L("Letters", "अक्षर", "અક્ષરો")}</th><th>${L("Which", "कौन से", "કયા")}</th><th>${L("Value", "मान", "મૂલ્ય")}</th></tr></thead>
              <tbody>${planeRows}</tbody>
            </table></div>
            <div class="card-sub">${L("Strongest plane", "सबसे प्रबल तल", "સૌથી પ્રબળ સ્તર")}: <strong>${esc(planeNames[w.planes.dominant])}</strong> ·
              ${L("thinnest", "सबसे क्षीण", "સૌથી ક્ષીણ")}: <strong>${esc(planeNames[w.planes.weakest])}</strong>.
              ${L("A thin plane is not a defect — it is the channel you reach for last under pressure.", "क्षीण तल दोष नहीं — वह वह माध्यम है जिसकी ओर आप दबाव में सबसे अंत में जाते हैं।", "ક્ષીણ સ્તર દોષ નથી — તે એ માધ્યમ છે જેની તરફ તમે દબાણમાં છેલ્લે જાઓ છો.")}</div>
          </div>
        </div>
      </details>
    </section>`;
  }

  /* --- Panchang, Choghadiya and Abhijit --------------------------
     The Muhurtha section stopped at sunrise, sunset and Rahu Kaal,
     while every comparable Indian product ships the five limbs. All
     five are derived here from the same Meeus ephemeris the rest of
     the app is pinned to — nothing is read from a tabulated almanac —
     and each limb prints the time it ENDS, because a tithi that is
     reported without its boundary is the single most common error in
     consumer Panchang output: the Moon moves about 13° a day, so
     "today's tithi" is false for part of today. */
  function panchangBlock(astro, place, Y, M, D, tzEff, fmt, lang) {
    try {
      if (!astro || typeof astro.panchang !== "function") return "";
      const pc = astro.panchang(Y, M, D, place.lat, place.lon, tzEff);
      if (!pc || !pc.ok) return "";
      const L = (en, hi, gu) => triText(lang, en, hi, gu);
      const chog = typeof astro.choghadiya === "function" ? astro.choghadiya(Y, M, D, place.lat, place.lon, tzEff) : null;
      const abh = typeof astro.abhijitMuhurta === "function" ? astro.abhijitMuhurta(Y, M, D, place.lat, place.lon, tzEff) : null;
      const until = (h) => h === null || h === undefined ? "—" : `${L("until", "तक", "સુધી")} ${fmt(h % 24)}${h >= 24 ? ` (${L("next day", "अगले दिन", "બીજા દિવસે")})` : ""}`;

      const limb = (icon, label, value, note) => `<div class="kit-row"><div class="kit-ico">${icon}</div><div class="kit-body"><div class="kit-label">${label}</div><div class="kit-value">${value}<div class="card-sub">${note}</div></div></div></div>`;

      /* Day AND night. The engine always computed sixteen slots; the first
         cut of this section printed only the eight daytime ones, which is
         useless to the practitioner whose client asks about a 9 pm griha
         pravesh or an overnight journey. */
      const chogRow = (c, half) => `<tr data-choghadiya="${esc(c.name)}" data-choghadiya-half="${half}" data-choghadiya-quality="${esc(c.quality)}">
        <td>${esc(c.name)}</td>
        <td>${fmt(c.start)} – ${fmt(c.end)}</td>
        <td><span class="badge ${c.quality === "auspicious" ? "good" : c.quality === "inauspicious" ? "bad" : "info"}">${c.quality === "auspicious" ? L("Auspicious", "शुभ", "શુભ") : c.quality === "inauspicious" ? L("Avoid", "त्याज्य", "ત્યાજ્ય") : L("Neutral", "तटस्थ", "તટસ્થ")}</span></td>
      </tr>`;
      const chogDayRows = chog && chog.ok ? chog.day.map((c) => chogRow(c, "day")).join("") : "";
      const chogNightRows = chog && chog.ok ? chog.night.map((c) => chogRow(c, "night")).join("") : "";

      /* The classical day-division triad. Rahu Kaal alone was half the
         picture: Yamaganda and Gulika are cast by the identical
         construction (daylight / 8, one fixed part per weekday) and a
         practitioner checking a start time checks all three. */
      const triad = typeof astro.inauspiciousWindows === "function" ? astro.inauspiciousWindows(Y, M, D, place.lat, place.lon, tzEff) : null;
      const triadMeta = {
        rahu: { label: L("Rahu Kaal", "राहु काल", "રાહુ કાળ"), note: L("Confusion and reversal — avoid all new beginnings.", "भ्रम एवं उलटफेर — कोई भी शुभारंभ न करें।", "ભ્રમ અને ઉલટફેર — કોઈ પણ શુભારંભ ન કરો.") },
        yamaganda: { label: L("Yamaganda Kaal", "यमगण्ड काल", "યમગંડ કાળ"), note: L("Yama's window — classically withheld from ceremony and travel.", "यम की अवधि — शास्त्रतः संस्कार एवं यात्रा से वर्जित।", "યમની અવધિ — શાસ્ત્ર મુજબ સંસ્કાર અને યાત્રાથી વર્જિત.") },
        gulika: { label: L("Gulika Kaal", "गुलिक काल", "ગુલિક કાળ"), note: L("Saturn's son Mandi — whatever is begun here tends to repeat, so it is withheld from one-time acts and tolerated for recurring ones.", "शनिपुत्र मांदी — यहाँ आरंभ किया कार्य दोहराने की प्रवृत्ति रखता है, अतः एकबारगी कार्यों से वर्जित, आवर्ती कार्यों में सह्य।", "શનિપુત્ર માંદી — અહીં શરૂ કરેલું કાર્ય પુનરાવર્તનની વૃત્તિ ધરાવે છે, તેથી એકવારના કાર્યોથી વર્જિત, આવર્તી કાર્યોમાં સહ્ય.") }
      };
      const triadRows = triad && triad.ok ? triad.windows.map((wn) => `<tr data-day-division="${esc(wn.kind)}" data-division-part="${wn.part}">
        <td><strong>${triadMeta[wn.kind].label}</strong></td>
        <td>${fmt(wn.start)} – ${fmt(wn.end)}</td>
        <td>${L("part", "भाग", "ભાગ")} ${wn.part}/8</td>
        <td>${triadMeta[wn.kind].note}</td>
      </tr>`).join("") : "";

      /* Authority boundary, stated in the client's own view rather than
         only in the markup. This module is a clock: it reports when, and
         it is forbidden from touching what. Same cordon the Vimshottari
         card carries. */
      const horizonBadge = `<div class="card" data-panchang-scope="readout">
        <div class="card-title">${L("Timing &amp; horizon readout only", "केवल काल एवं क्षितिज गणना", "માત્ર કાળ અને ક્ષિતિજ ગણતરી")}</div>
        <div class="card-sub">${L(
        "Derived from geocentric Sun and Moon coordinates for your local horizon. This module does not alter Lo Shu void remedies, crystal assignments, deity selection or Vastu zone activations — it answers <em>when</em>, never <em>what</em>.",
        "आपके स्थानीय क्षितिज हेतु भूकेन्द्रित सूर्य-चंद्र निर्देशांकों से व्युत्पन्न। यह मॉड्यूल लो शु रिक्त-अंक उपाय, रत्न, देवता-चयन अथवा वास्तु-क्षेत्र सक्रियण में कोई परिवर्तन नहीं करता — यह <em>कब</em> का उत्तर देता है, <em>क्या</em> का कभी नहीं।",
        "તમારા સ્થાનિક ક્ષિતિજ માટે ભૂકેન્દ્રિત સૂર્ય-ચંદ્ર યામોથી વ્યુત્પન્ન. આ મોડ્યુલ લો શુ રિક્ત-અંક ઉપાય, રત્ન, દેવતા-પસંદગી કે વાસ્તુ-ક્ષેત્ર સક્રિયકરણમાં કોઈ ફેરફાર કરતું નથી — તે <em>ક્યારે</em> નો જવાબ આપે છે, <em>શું</em> નો ક્યારેય નહીં."
      )}</div>
        <div class="badge-row"><span class="badge info" data-panchang-tier="horizon">${L(
        `Calculated for the local horizon at ${esc(place.displayName || place.name || "your location")} — date and location only; no birth time required.`,
        `${esc(place.displayName || place.name || "आपके स्थान")} के स्थानीय क्षितिज हेतु गणित — केवल तिथि एवं स्थान; जन्म-समय आवश्यक नहीं।`,
        `${esc(place.displayName || place.name || "તમારા સ્થાન")} ના સ્થાનિક ક્ષિતિજ માટે ગણિત — માત્ર તારીખ અને સ્થાન; જન્મ-સમય જરૂરી નથી.`
      )}</span></div>
      </div>`;

      return `${horizonBadge}<div class="card-grid two" data-panchang="ok" data-tithi="${esc(pc.tithi.name)}" data-nakshatra="${esc(pc.nakshatra.name)}" data-authority="panchang">
        <div class="card">
          <div class="card-title">${L("Panchang — the five limbs (at sunrise)", "पंचांग — पाँच अंग (सूर्योदय पर)", "પંચાંગ — પાંચ અંગ (સૂર્યોદય પર)")}</div>
          <div class="kit">
            ${limb("🌙", L("Tithi", "तिथि", "તિથિ"),
        `${esc(pc.tithi.paksha)} ${esc(pc.tithi.name)}`,
        `${until(pc.tithi.endsAt)} · ${esc(pc.tithi.group)}${pc.tithi.rikta ? ` · ${L("Rikta — avoid beginnings", "रिक्ता — शुभारंभ से बचें", "રિક્તા — શુભારંભ ટાળો")}` : ""}`)}
            ${limb("⭐", L("Nakshatra", "नक्षत्र", "નક્ષત્ર"),
          `${esc(pc.nakshatra.name)} ${L("pada", "पाद", "પાદ")} ${pc.nakshatra.pada}`,
          `${until(pc.nakshatra.endsAt)} · ${L("lord", "स्वामी", "સ્વામી")} ${esc(pc.nakshatra.lord)}`)}
            ${limb("🧘", L("Yoga", "योग", "યોગ"),
            esc(pc.yoga.name),
            `${until(pc.yoga.endsAt)}${pc.yoga.caution ? ` · ${L("one of the nine cautioned yogas", "नौ सावधानी-योगों में से एक", "નવ સાવધાની-યોગોમાંનો એક")}` : ""}`)}
            ${limb("🔗", L("Karana", "करण", "કરણ"),
              esc(pc.karana.name),
              `${until(pc.karana.endsAt)}${pc.karana.vishti ? ` · ${L("Vishti (Bhadra) — postpone auspicious starts", "विष्टि (भद्रा) — शुभ कार्य टालें", "વિષ્ટિ (ભદ્રા) — શુભ કાર્ય ટાળો")}` : ""}`)}
            ${limb("📅", L("Vara", "वार", "વાર"), esc(dayOf(pc.vara.lordNumber)), L("reckoned sunrise to sunrise, not midnight to midnight", "सूर्योदय से सूर्योदय तक गिना जाता है, मध्यरात्रि से नहीं", "સૂર્યોદયથી સૂર્યોદય સુધી ગણાય છે, મધ્યરાત્રિથી નહીં"))}
          </div>
          <div class="card-sub">${L(
                "Computed from the Moon–Sun elongation and the sidereal Moon on this device, using the same ephemeris as your birth chart — not copied from a printed almanac. Each limb is stated with the time it ends because the Moon moves roughly 13° a day.",
                "इस उपकरण पर चंद्र-सूर्य अंतर और सायन-निरयन चंद्र से गणना — वही गणक जो आपकी जन्मकुंडली का है, किसी छपे पंचांग से नकल नहीं। हर अंग के साथ उसका समाप्ति-समय दिया है क्योंकि चंद्रमा प्रतिदिन लगभग १३° चलता है।",
                "આ ઉપકરણ પર ચંદ્ર-સૂર્ય અંતર અને નિરયન ચંદ્રથી ગણતરી — એ જ ગણક જે તમારી જન્મકુંડળીનો છે, છાપેલા પંચાંગમાંથી નકલ નહીં. દરેક અંગ સાથે તેનો સમાપ્તિ-સમય આપ્યો છે કારણ કે ચંદ્ર રોજ આશરે ૧૩° ચાલે છે."
              )}</div>
        </div>
        <div class="card">
          <div class="card-title">${L("Choghadiya & Abhijit (today, daytime)", "चौघड़िया एवं अभिजित (आज, दिन)", "ચોઘડિયા અને અભિજિત (આજે, દિવસ)")}</div>
          ${abh && abh.ok ? `<div class="kit"><div class="kit-row"><div class="kit-ico">🎯</div><div class="kit-body"><div class="kit-label">${L("Abhijit Muhurta", "अभिजित मुहूर्त", "અભિજિત મુહૂર્ત")}</div><div class="kit-value" data-abhijit="${abh.excluded ? "excluded" : "ok"}">${fmt(abh.start)} – ${fmt(abh.end)}${abh.excluded ? ` · ${L("not taken on a Wednesday", "बुधवार को नहीं लिया जाता", "બુધવારે લેવાતું નથી")}` : ` · ${L("the day's safest window for almost any beginning", "लगभग हर शुभारंभ के लिए दिन की सबसे सुरक्षित खिड़की", "લગભગ દરેક શુભારંભ માટે દિવસની સૌથી સલામત બારી")}`}</div></div></div></div>` : ""}
          ${chogDayRows ? `<div class="table-scroll"><table class="rtable micro-forecast-table">
            <thead><tr><th>${L("Day Choghadiya", "दिन चौघड़िया", "દિવસ ચોઘડિયા")}</th><th>${L("Window", "समय", "સમય")}</th><th>${L("Quality", "गुण", "ગુણ")}</th></tr></thead>
            <tbody>${chogDayRows}</tbody>
          </table></div>` : ""}
          ${chogNightRows ? `<details class="details-block choghadiya-night">
            <summary>${L("Night Choghadiya — sunset to sunrise", "रात्रि चौघड़िया — सूर्यास्त से सूर्योदय", "રાત્રિ ચોઘડિયા — સૂર્યાસ્તથી સૂર્યોદય")}</summary>
            <div class="details-body"><div class="table-scroll"><table class="rtable micro-forecast-table">
              <thead><tr><th>${L("Night Choghadiya", "रात्रि चौघड़िया", "રાત્રિ ચોઘડિયા")}</th><th>${L("Window", "समय", "સમય")}</th><th>${L("Quality", "गुण", "ગુણ")}</th></tr></thead>
              <tbody>${chogNightRows}</tbody>
            </table></div></div>
          </details>` : ""}
          <div class="card-sub">${L(
                "The eight day-parts run sunrise to sunset on the standard weekday cycle; Amrit, Shubh and Labh are the workable windows, Udvega, Roga and Kaal are the ones to route around. A window below still overrides a good Choghadiya.",
                "आठ दिन-भाग सूर्योदय से सूर्यास्त तक, मानक वार-चक्र पर; अमृत, शुभ और लाभ उपयोगी खिड़कियाँ हैं, उद्वेग, रोग और काल से बचें। ऊपर दिया राहु काल अच्छे चौघड़िया पर भी भारी पड़ता है।",
                "આઠ દિવસ-ભાગ સૂર્યોદયથી સૂર્યાસ્ત સુધી, પ્રમાણભૂત વાર-ચક્ર પર; અમૃત, શુભ અને લાભ ઉપયોગી બારીઓ છે, ઉદ્વેગ, રોગ અને કાળથી બચો. નીચેની બારી સારા ચોઘડિયા પર પણ ભારે પડે છે."
              )}</div>
        </div>
      </div>
      ${triadRows ? `<div class="card" data-day-division-triad="ok">
        <div class="card-title">${L("When not to begin — the three daylight windows", "कब आरंभ न करें — दिन की तीन अवधियाँ", "ક્યારે શરૂ ન કરવું — દિવસની ત્રણ અવધિઓ")}</div>
        <div class="table-scroll"><table class="rtable micro-forecast-table">
          <thead><tr><th>${L("Window", "अवधि", "અવધિ")}</th><th>${L("Today", "आज", "આજે")}</th><th>${L("Slot", "भाग", "ભાગ")}</th><th>${L("Why it is withheld", "क्यों वर्जित", "કેમ વર્જિત")}</th></tr></thead>
          <tbody>${triadRows}</tbody>
        </table></div>
        <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${L(
      "all three are cast by one construction — your actual daylight, sunrise to sunset, divided into eight equal parts, with one part fixed to each window per weekday (Rahu: Sun 8th, Mon 2nd, Tue 7th, Wed 5th, Thu 6th, Fri 4th, Sat 3rd; Yamaganda: Sun 5th, Mon 4th, Tue 3rd, Wed 2nd, Thu 1st, Fri 7th, Sat 6th; Gulika counts backwards from Saturn's own day: Sat 1st through Sun 7th). They never overlap. Because they are cut from your real sunrise rather than a 6 AM assumption, they move with your latitude and the season — which is the whole point.",
      "तीनों एक ही विधि से बनते हैं — आपका वास्तविक दिनमान, सूर्योदय से सूर्यास्त तक, आठ बराबर भागों में, और प्रत्येक वार हेतु एक भाग नियत (राहु: रवि ८, सोम २, मंगल ७, बुध ५, गुरु ६, शुक्र ४, शनि ३; यमगण्ड: रवि ५, सोम ४, मंगल ३, बुध २, गुरु १, शुक्र ७, शनि ६; गुलिक शनि के दिन से उल्टा गिनता है: शनि १ से रवि ७)। ये कभी नहीं टकरातीं। चूँकि ये आपके वास्तविक सूर्योदय से कटती हैं, न कि ६ बजे की कल्पना से, ये आपके अक्षांश और ऋतु के साथ चलती हैं — यही इसका उद्देश्य है।",
      "ત્રણેય એક જ રીતથી બને છે — તમારું વાસ્તવિક દિનમાન, સૂર્યોદયથી સૂર્યાસ્ત સુધી, આઠ સરખા ભાગમાં, અને દરેક વાર માટે એક ભાગ નિયત (રાહુ: રવિ ૮, સોમ ૨, મંગળ ૭, બુધ ૫, ગુરુ ૬, શુક્ર ૪, શનિ ૩; યમગંડ: રવિ ૫, સોમ ૪, મંગળ ૩, બુધ ૨, ગુરુ ૧, શુક્ર ૭, શનિ ૬; ગુલિક શનિના દિવસથી ઊલટું ગણે છે: શનિ ૧ થી રવિ ૭). આ ક્યારેય ટકરાતી નથી. કારણ કે આ તમારા વાસ્તવિક સૂર્યોદયથી કપાય છે, ૬ વાગ્યાની કલ્પનાથી નહીં, આ તમારા અક્ષાંશ અને ઋતુ સાથે ચાલે છે — એ જ એનો હેતુ છે."
    )}</div>
      </div>` : ""}`;
    } catch (e) {
      return "";
    }
  }

  /* --- 16A · Degree-precise Vastu compass -------------------------
     Professional Vastu suites sell a 16-zone / degree compass; this app
     read eight fixed sectors from a dropdown. The gap closes here, and
     it closes as GEOMETRY only: the sixteen zones resolve a degree, but
     the remedy that governs is still the shipped eight-direction remedy
     for the sector that degree falls in. No new prescription doctrine is
     introduced, which is why this does not cross the practitioner
     sign-off gate in CONTRIBUTING.md.

     The two things worth paying for are the honesty flags: a reading
     within 2 degrees of a zone edge is called unreliable instead of
     being reported to a false quarter-degree, and a reading near an
     8-sector boundary warns that ordinary compass error would change
     which classical direction governs the remedy. */
  function vastuCompassReport(p) {
    const NI = insightsEngine();
    if (!NI || typeof NI.vastuCompass !== "function") return null;
    const readings = { entrance: p.entranceDeg, kitchen: p.kitchenDeg, bedroom: p.bedroomDeg, water: p.waterDeg };
    const c = NI.vastuCompass(readings, { edgeTolerance: 2 });
    return c && c.ok ? c : null;
  }

  function renderVastuCompass(p) {
    const c = vastuCompassReport(p);
    if (!c) return "";
    const NI = insightsEngine();
    const lang = getLang();
    const db = getActiveDB();
    const L = (en, hi, gu) => triText(lang, en, hi, gu);
    const dirs = (db.vastu && db.vastu.directions) || {};
    const elementLabel = {
      entrance: L("Main entrance", "मुख्य द्वार", "મુખ્ય દ્વાર"),
      kitchen: L("Kitchen / burner", "रसोई / चूल्हा", "રસોડું / ચૂલો"),
      bedroom: L("Master bed", "मुख्य शयनकक्ष", "મુખ્ય શયનખંડ"),
      water: L("Water source / tank", "जल स्रोत / टंकी", "જળ સ્રોત / ટાંકી")
    };
    const zoneLabel = {
      N: L("North", "उत्तर", "ઉત્તર"), NNE: L("N-N-E", "उत्तर-उत्तर-पूर्व", "ઉત્તર-ઉત્તર-પૂર્વ"),
      NE: L("North-East", "ईशान", "ઈશાન"), ENE: L("E-N-E", "पूर्व-उत्तर-पूर्व", "પૂર્વ-ઉત્તર-પૂર્વ"),
      E: L("East", "पूर्व", "પૂર્વ"), ESE: L("E-S-E", "पूर्व-दक्षिण-पूर्व", "પૂર્વ-દક્ષિણ-પૂર્વ"),
      SE: L("South-East", "आग्नेय", "અગ્નિ"), SSE: L("S-S-E", "दक्षिण-दक्षिण-पूर्व", "દક્ષિણ-દક્ષિણ-પૂર્વ"),
      S: L("South", "दक्षिण", "દક્ષિણ"), SSW: L("S-S-W", "दक्षिण-दक्षिण-पश्चिम", "દક્ષિણ-દક્ષિણ-પશ્ચિમ"),
      SW: L("South-West", "नैऋत्य", "નૈઋત્ય"), WSW: L("W-S-W", "पश्चिम-दक्षिण-पश्चिम", "પશ્ચિમ-દક્ષિણ-પશ્ચિમ"),
      W: L("West", "पश्चिम", "પશ્ચિમ"), WNW: L("W-N-W", "पश्चिम-उत्तर-पश्चिम", "પશ્ચિમ-ઉત્તર-પશ્ચિમ"),
      NW: L("North-West", "वायव्य", "વાયવ્ય"), NNW: L("N-N-W", "उत्तर-उत्तर-पश्चिम", "ઉત્તર-ઉત્તર-પશ્ચિમ")
    };
    const verdictBadge = { ideal: "good", acceptable: "info", avoid: "bad" };
    const verdictWord = {
      ideal: L("Ideal", "उत्तम", "ઉત્તમ"),
      acceptable: L("Acceptable", "स्वीकार्य", "સ્વીકાર્ય"),
      avoid: L("Classical dosh", "शास्त्रीय दोष", "શાસ્ત્રીય દોષ")
    };

    /* The dial. Sixteen 22.5-degree wedges drawn as SVG paths, with a
       needle per tagged reading. Screen-reader users get the table
       below, so the figure itself is aria-hidden. */
    const R = 96, CX = 110, CY = 110;
    const pol = (deg, r) => {
      const a = (deg - 90) * Math.PI / 180;
      return [(CX + r * Math.cos(a)).toFixed(2), (CY + r * Math.sin(a)).toFixed(2)];
    };
    const wedges = NI.ZONE16.map((z, i) => {
      const start = i * 22.5 - 11.25, end = start + 22.5;
      const [x1, y1] = pol(start, R), [x2, y2] = pol(end, R);
      const hit = c.readings.filter((r) => r.zoneIndex === i);
      const cls = hit.length ? `cmp-wedge cmp-${hit[0].verdict}` : "cmp-wedge";
      return `<path class="${cls}" data-cmp-zone="${z.key}" d="M ${CX} ${CY} L ${x1} ${y1} A ${R} ${R} 0 0 1 ${x2} ${y2} Z" />`;
    }).join("");
    const ticks = NI.ZONE16.map((z, i) => {
      const [tx, ty] = pol(i * 22.5, R + 13);
      const cardinal = ["N", "E", "S", "W"].includes(z.key);
      return `<text class="cmp-tick${cardinal ? " cmp-tick-card" : ""}" x="${tx}" y="${ty}" text-anchor="middle" dominant-baseline="middle">${z.key}</text>`;
    }).join("");
    const needles = c.readings.map((r) => {
      const [nx, ny] = pol(r.degree, R - 6);
      return `<g class="cmp-needle cmp-needle-${r.verdict}" data-cmp-needle="${r.element}">
        <line x1="${CX}" y1="${CY}" x2="${nx}" y2="${ny}" />
        <circle cx="${nx}" cy="${ny}" r="4" />
      </g>`;
    }).join("");

    const rows = c.readings.map((r) => {
      const parent = dirs[r.sector] || {};
      const flags = [];
      if (r.boundary) flags.push(`<span class="badge warn" data-cmp-flag="boundary">${L("within 2° of a zone edge", "क्षेत्र-सीमा से २° भीतर", "ક્ષેત્ર-સીમાથી ૨° અંદર")}</span>`);
      if (r.sectorFlip) flags.push(`<span class="badge warn" data-cmp-flag="sector-flip">${L("a 2° error changes the governing direction", "२° की त्रुटि शासक दिशा बदल देती है", "૨° ની ભૂલ શાસક દિશા બદલે છે")}</span>`);
      const off = r.nearestIdeal
        ? `${Math.abs(r.nearestIdeal.delta).toFixed(1)}° ${r.nearestIdeal.delta > 0 ? L("clockwise of", "से दक्षिणावर्त", "થી ઘડિયાળ દિશામાં") : L("anticlockwise of", "से वामावर्त", "થી ઘડિયાળ વિરુદ્ધ")} ${esc(zoneLabel[r.nearestIdeal.sector] || r.nearestIdeal.sector)}`
        : "—";
      return `<tr data-cmp-reading="${esc(r.element)}" data-cmp-degree="${r.degree}" data-cmp-zone16="${esc(r.zone)}" data-cmp-sector="${esc(r.sector)}" data-cmp-verdict="${esc(r.verdict)}">
        <td><strong>${esc(elementLabel[r.element] || r.element)}</strong><div class="card-sub">${r.degree.toFixed(1)}°</div></td>
        <td><strong>${esc(zoneLabel[r.zone] || r.zone)}</strong> <span class="cmp-zonekey">${esc(r.zone)}</span>${r.intermediate ? `<div class="card-sub">${L("intermediate zone", "मध्यवर्ती क्षेत्र", "મધ્યવર્તી ક્ષેત્ર")}</div>` : ""}</td>
        <td>${esc(parent.label || zoneLabel[r.sector] || r.sector)}</td>
        <td><span class="badge ${verdictBadge[r.verdict]}">${verdictWord[r.verdict]}</span>${flags.length ? `<div class="cmp-flags">${flags.join(" ")}</div>` : ""}</td>
        <td>${off}</td>
      </tr>`;
    }).join("");

    const doshRows = c.readings.filter((r) => r.verdict === "avoid").map((r) => {
      const parent = dirs[r.sector] || {};
      return `<div class="kit-row" data-cmp-remedy="${esc(r.element)}"><div class="kit-ico">⚠️</div><div class="kit-body">
        <div class="kit-label">${esc(elementLabel[r.element] || r.element)} · ${esc(parent.label || r.sector)}</div>
        <div class="kit-value">${esc(parent.fix || "")}</div>
      </div></div>`;
    }).join("");

    return `<section class="rsection" id="vastu-compass-section" data-authority="home-vastu-context" data-vastu-compass="ok" data-compass-readings="${c.readings.length}" data-compass-avoid="${c.avoidCount}">
      <h2 class="rsection-title"><span class="idx idx-wide">${SECTION.compass}</span>${L("Degree Compass — the 16 zones", "अंश दिक्सूचक — १६ क्षेत्र", "અંશ દિશાસૂચક — ૧૬ ક્ષેત્ર")}</h2>
      <p class="rsection-desc">${L(
      "Section " + SECTION.vastu + " reads eight 45° sectors chosen from a list. This reads the actual bearing you measured, to the 22.5° zone. The finer zone tells you where you are; the classical 45° sector it falls in still decides the remedy, which is why both are printed side by side.",
      "खंड " + SECTION.vastu + " सूची से चुने आठ ४५° खंड पढ़ता है। यह आपके मापे वास्तविक अंश को २२.५° क्षेत्र तक पढ़ता है। सूक्ष्म क्षेत्र बताता है आप कहाँ हैं; उपाय अब भी वही शास्त्रीय ४५° खंड तय करता है जिसमें वह पड़ता है — इसीलिए दोनों साथ दिए हैं।",
      "વિભાગ " + SECTION.vastu + " યાદીમાંથી પસંદ કરેલા આઠ ૪૫° ખંડ વાંચે છે. આ તમારા માપેલા વાસ્તવિક અંશને ૨૨.૫° ક્ષેત્ર સુધી વાંચે છે. સૂક્ષ્મ ક્ષેત્ર કહે છે તમે ક્યાં છો; ઉપાય હજી એ જ શાસ્ત્રીય ૪૫° ખંડ નક્કી કરે છે જેમાં તે પડે છે — તેથી બંને સાથે આપ્યા છે."
    )}</p>
      <div class="compass-wrap">
        <svg class="compass-dial" viewBox="0 0 220 220" role="img" aria-hidden="true" focusable="false">
          <circle class="cmp-face" cx="${CX}" cy="${CY}" r="${R}" />
          ${wedges}
          <circle class="cmp-ring" cx="${CX}" cy="${CY}" r="${R}" />
          ${needles}
          <circle class="cmp-hub" cx="${CX}" cy="${CY}" r="5" />
          ${ticks}
        </svg>
        <div class="compass-side">
          <div class="table-scroll"><table class="rtable micro-forecast-table">
            <thead><tr>
              <th>${L("Element", "तत्व", "તત્વ")}</th>
              <th>${L("16-zone", "१६-क्षेत्र", "૧૬-ક્ષેત્ર")}</th>
              <th>${L("Governing direction", "शासक दिशा", "શાસક દિશા")}</th>
              <th>${L("Verdict", "निर्णय", "ચુકાદો")}</th>
              <th>${L("Off the ideal by", "आदर्श से अंतर", "આદર્શથી અંતર")}</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table></div>
        </div>
      </div>
      ${doshRows ? `<div class="card" data-compass-dosh>
        <div class="card-title">${L("Where the bearing puts you in a classical dosh", "जहाँ यह अंश शास्त्रीय दोष में डालता है", "જ્યાં આ અંશ શાસ્ત્રીય દોષમાં મૂકે છે")}</div>
        <div class="kit">${doshRows}</div>
        <div class="card-sub">${L(
      "These are the same remedies Section " + SECTION.vastu + " prescribes for those directions — the compass only identified the direction more precisely. It does not add, replace or re-source a single remedy.",
      "ये वही उपाय हैं जो खंड " + SECTION.vastu + " उन दिशाओं हेतु देता है — दिक्सूचक ने केवल दिशा अधिक सूक्ष्मता से पहचानी है। यह कोई उपाय जोड़ता, बदलता या पुनः-स्रोत नहीं करता।",
      "આ એ જ ઉપાયો છે જે વિભાગ " + SECTION.vastu + " એ દિશાઓ માટે આપે છે — દિશાસૂચકે ફક્ત દિશા વધુ ચોકસાઈથી ઓળખી છે. તે કોઈ ઉપાય ઉમેરતો, બદલતો કે પુનઃ-સ્રોત કરતો નથી."
    )}</div>
      </div>` : ""}
      <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${L(
      "the sixteen zones are 22.5° wide with North centred on 0°, so N runs 348.75°–11.25°. The eight classical sectors are 45° wide and are computed from the same bearing, not from the zone name — which is why an N-N-E reading at 20° is governed by the North and the same zone at 30° is governed by the North-East. Two flags protect you from false precision: a reading within 2° of a zone edge is marked unreliable, and a reading within 2° of a sector boundary is marked as one where ordinary compass error would change the governing direction. Take bearings against TRUE north; a phone compass usually shows magnetic north, which in India runs roughly 0°–3° east of true.",
      "सोलह क्षेत्र २२.५° चौड़े हैं और उत्तर ०° पर केन्द्रित — अतः उत्तर ३४८.७५°–११.२५° तक। आठ शास्त्रीय खंड ४५° के हैं और उसी अंश से गिने जाते हैं, क्षेत्र-नाम से नहीं — इसीलिए २०° पर उत्तर-उत्तर-पूर्व को उत्तर शासित करता है और ३०° पर वही क्षेत्र ईशान से। दो संकेत मिथ्या-सूक्ष्मता से बचाते हैं: क्षेत्र-किनारे से २° भीतर का पाठ अविश्वसनीय अंकित है, और खंड-सीमा से २° भीतर का पाठ वह है जहाँ सामान्य त्रुटि शासक दिशा बदल देगी। सदैव वास्तविक (ट्रू) उत्तर से मापें; मोबाइल दिक्सूचक प्रायः चुंबकीय उत्तर दिखाता है, जो भारत में वास्तविक से लगभग ०°–३° पूर्व रहता है।",
      "સોળ ક્ષેત્ર ૨૨.૫° પહોળા છે અને ઉત્તર ૦° પર કેન્દ્રિત — તેથી ઉત્તર ૩૪૮.૭૫°–૧૧.૨૫° સુધી. આઠ શાસ્ત્રીય ખંડ ૪૫° ના છે અને એ જ અંશથી ગણાય છે, ક્ષેત્ર-નામથી નહીં — તેથી ૨૦° પર ઉત્તર-ઉત્તર-પૂર્વને ઉત્તર શાસિત કરે છે અને ૩૦° પર એ જ ક્ષેત્ર ઈશાનથી. બે સંકેત મિથ્યા-ચોકસાઈથી બચાવે છે: ક્ષેત્ર-કિનારાથી ૨° અંદરનું વાચન અવિશ્વસનીય ગણાયું છે, અને ખંડ-સીમાથી ૨° અંદરનું વાચન એ છે જ્યાં સામાન્ય ભૂલ શાસક દિશા બદલી નાખશે. હંમેશાં સાચા (ટ્રૂ) ઉત્તરથી માપો; મોબાઇલ દિશાસૂચક સામાન્ય રીતે ચુંબકીય ઉત્તર બતાવે છે, જે ભારતમાં સાચાથી આશરે ૦°–૩° પૂર્વ રહે છે."
    )}</div>
    </section>`;
  }

  /* --- 7 (continued) · Internal digit flow ------------------------
     The total was the whole reading; the sequence was ignored. A client
     who recites their number twenty times a day is living with its
     internal adjacencies, not only its sum, and every commercial tool
     reads them. Two constraints make this worth shipping rather than
     a gimmick: each pair is classified by the SAME one-way Moolank
     Maitri relation the rest of the report uses (so the verdict is
     traceable to a row of the shipped chart, not to an invented table
     of two-digit meanings), and nothing here produces a percentage.
     "74% lucky" is unfalsifiable; "three hostile adjacencies, here
     they are" can be checked by eye. */
  function renderDigitFlow(p) {
    const NI = insightsEngine();
    if (!NI || typeof NI.digitFlow !== "function" || !p.mobile) return "";
    /* Inject the live relation so the pair table and the rest of the
       report can never disagree about who is friendly to whom. */
    const f = NI.digitFlow(p.mobile, { driver: p.driver, conductor: p.conductor }, { relationFn: relation });
    if (!f || !f.ok) return "";
    const lang = getLang();
    const db = getActiveDB();
    const L = (en, hi, gu) => triText(lang, en, hi, gu);
    const planetOf = (n) => esc(String(((db.numbers || {})[n] || {}).planet || n).split(" ")[0]);
    const kindWord = {
      friendly: L("friendly", "मैत्री", "મૈત્રી"), neutral: L("neutral", "तटस्थ", "તટસ્થ"),
      enemy: L("hostile", "शत्रु", "શત્રુ"), repeat: L("repeat", "पुनरावृत्ति", "પુનરાવર્તન"),
      void: L("no lord (0)", "स्वामी रहित (०)", "સ્વામી રહિત (૦)")
    };
    const kindClass = { friendly: "flow-friend", neutral: "flow-neutral", enemy: "flow-enemy", repeat: "flow-repeat", void: "flow-void" };

    const chain = f.pairs.map((pr) => `<span class="flow-pair ${kindClass[pr.kind]}" data-flow-pair="${esc(pr.text)}" data-flow-kind="${esc(pr.kind)}" title="${esc(`${pr.a}–${pr.b} · ${kindWord[pr.kind]}`)}">${pr.text}<em>${kindWord[pr.kind]}</em></span>`).join("");

    const hostileRows = f.pairs.filter((pr) => pr.kind === "enemy").map((pr) => `<tr data-flow-hostile="${esc(pr.text)}">
      <td><strong>${pr.text}</strong></td>
      <td>${planetOf(pr.a)} → ${planetOf(pr.b)}</td>
      <td>${L("position", "स्थान", "સ્થાન")} ${pr.index + 1}–${pr.index + 2}</td>
    </tr>`).join("");

    return `<div class="card" data-digit-flow="ok" data-flow-hostile-count="${f.hostileAdjacencies}" data-flow-clean-run="${f.longestCleanRun}">
      <div class="card-title">${L("Internal digit flow — how the number reads left to right", "आंतरिक अंक-प्रवाह — नंबर बाएँ से दाएँ कैसे पढ़ा जाता है", "આંતરિક અંક-પ્રવાહ — નંબર ડાબેથી જમણે કેવી રીતે વંચાય છે")}</div>
      <div class="flow-strip" data-flow-strip>${chain}</div>
      <div class="kit">
        <div class="kit-row"><div class="kit-ico">🔗</div><div class="kit-body">
          <div class="kit-label">${L("Adjacent pairs", "सन्निकट युग्म", "નજીકની જોડી")}</div>
          <div class="kit-value">${f.tally.friend} ${L("friendly", "मैत्री", "મૈત્રી")} · ${f.tally.neutral} ${L("neutral", "तटस्थ", "તટસ્થ")} · <strong>${f.tally.enemy}</strong> ${L("hostile", "शत्रु", "શત્રુ")}${f.tally.repeat ? ` · ${f.tally.repeat} ${L("repeat", "पुनरावृत्ति", "પુનરાવર્તન")}` : ""}${f.tally.void ? ` · ${f.tally.void} ${L("with 0", "शून्य सहित", "શૂન્ય સહિત")}` : ""}</div>
        </div></div>
        <div class="kit-row"><div class="kit-ico">📶</div><div class="kit-body">
          <div class="kit-label">${L("Longest unbroken stretch", "सबसे लंबी अखंड शृंखला", "સૌથી લાંબી અખંડ શૃંખલા")}</div>
          <div class="kit-value">${f.longestCleanRun} / ${f.pairs.length} ${L("pairs with no hostility", "युग्म बिना शत्रुता", "જોડી શત્રુતા વિના")}</div>
        </div></div>
        <div class="kit-row"><div class="kit-ico">🕳️</div><div class="kit-body">
          <div class="kit-label">${L("Digits absent from the number", "नंबर में अनुपस्थित अंक", "નંબરમાં ગેરહાજર અંકો")}</div>
          <div class="kit-value" data-flow-missing="${f.missing.join(",")}">${f.missing.length ? f.missing.map((m) => `${m} (${planetOf(m)})`).join(" · ") : L("none — all nine appear", "कोई नहीं — नौ ही उपस्थित", "કોઈ નહીં — નવેય હાજર")}</div>
        </div></div>
        ${f.repeated.length ? `<div class="kit-row"><div class="kit-ico">🔁</div><div class="kit-body">
          <div class="kit-label">${L("Digits carrying extra weight", "अधिक भार वाले अंक", "વધુ ભાર ધરાવતા અંકો")}</div>
          <div class="kit-value">${f.repeated.map((r) => `${r.digit} (${planetOf(r.digit)}) ×${r.count}`).join(" · ")}</div>
        </div></div>` : ""}
      </div>
      ${hostileRows ? `<div class="table-scroll"><table class="rtable micro-forecast-table">
        <thead><tr><th>${L("Hostile pair", "शत्रु युग्म", "શત્રુ જોડી")}</th><th>${L("Planets", "ग्रह", "ગ્રહો")}</th><th>${L("Where", "कहाँ", "ક્યાં")}</th></tr></thead>
        <tbody>${hostileRows}</tbody>
      </table></div>` : ""}
      <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${L(
      "each adjacent pair is classified by the same one-way Moolank Maitri relation the whole report uses, so every label here can be traced to a row of the friendship chart rather than to a table of invented two-digit meanings. Pairs containing 0 are reported as having no lord instead of being forced into a relation the system does not give them. There is deliberately no percentage: a count of hostile adjacencies you can verify by eye is worth more than a score you cannot. The total in the card above still governs the recommendation — this reading refines it, it does not overrule it.",
      "प्रत्येक सन्निकट युग्म उसी एकपक्षीय मूलांक मैत्री संबंध से वर्गीकृत है जो पूरी रिपोर्ट प्रयोग करती है — अतः यहाँ का हर लेबल मैत्री-चक्र की पंक्ति तक जाता है, किसी गढ़ी हुई दो-अंकी अर्थ-तालिका तक नहीं। शून्य वाले युग्म स्वामी-रहित बताए गए हैं, न कि किसी ऐसे संबंध में डाले गए जो शास्त्र देता ही नहीं। प्रतिशत जान-बूझकर नहीं है: आँखों से जाँची जा सकने वाली शत्रु-युग्मों की गिनती उस अंक से अधिक मूल्यवान है जिसे जाँचा नहीं जा सकता। ऊपर का कुल योग ही सिफ़ारिश तय करता है — यह पाठ उसे सूक्ष्म करता है, पलटता नहीं।",
      "દરેક નજીકની જોડી એ જ એકપક્ષીય મૂળાંક મૈત્રી સંબંધથી વર્ગીકૃત છે જે આખો અહેવાલ વાપરે છે — તેથી અહીંનું દરેક લેબલ મૈત્રી-ચક્રની પંક્તિ સુધી જાય છે, કોઈ ઘડેલી બે-અંકી અર્થ-યાદી સુધી નહીં. શૂન્ય ધરાવતી જોડી સ્વામી-રહિત બતાવી છે, એવા સંબંધમાં નાખી નથી જે શાસ્ત્ર આપતું જ નથી. ટકાવારી જાણીજોઈને નથી: આંખે ચકાસી શકાય એવી શત્રુ-જોડીની ગણતરી એ આંક કરતાં વધુ મૂલ્યવાન છે જે ચકાસી શકાતો નથી. ઉપરનો કુલ સરવાળો જ ભલામણ નક્કી કરે છે — આ વાચન તેને સૂક્ષ્મ કરે છે, પલટતું નથી."
    )}</div>
    </div>`;
  }

  function renderReport(p) {
    const db = getActiveDB();
    const lang = getLang();
    const nameSug = nameSuggestions(p);
    const mobSug = mobileSuggestion(p);
    const brand = p.brand ? brandAnalysis(p.brand, p) : null;
    const vehicle = vehicleAnalysis(p);
    const timing = timingAnalysis(p);
    const vastu = vastuReport(p);
    const goals = goalPlan(p);
    const priorities = priorityPlan(p);
    const triage = remedyTriage(p);
    const tier1Number = triage.tier1.mode === "acute" ? triage.tier1.n : null;
    const tier2Numbers = triage.tier2.map((item) => item.n);
    const watch = watchSpec(p);
    const evolving = evolvingChartData(p, timing);
    const summary = northstarSummary(p, triage);
    const activation = activationPlan(p, triage);
    lastActivation = activation;
    /* Layer 1 executive summary (2026-09 audit): surface the ACTIVE timing
       window from the PRIMARY Dasha engine right on the front page, so the
       client sees core numbers, top remedies, the live window and the weekly
       schedule together before any deep-dive analysis. */
    try {
      const vimNow = state.dashaEngine === "vimshottari" ? vimshottariTimeline(p) : null;
      const engineLabel = vimNow
        ? (lang === "hi" ? "विम्शोत्तरी (प्राथमिक)" : lang === "gu" ? "વિમ્શોત્તરી (પ્રાથમિક)" : "Vimshottari (primary)")
        : (lang === "hi" ? "अंक-ज्योतिष (प्राथमिक)" : lang === "gu" ? "અંક-જ્યોતિષ (પ્રાથમિક)" : "Ank Jyotish (primary)");
      if (vimNow) {
        summary.cards.splice(1, 0, {
          label: t("activeWindowLabel", "Active timing window"),
          value: `${esc(vimNow.current.md.lord)} MD · ${esc(vimNow.current.ad.lord)} AD`,
          note: `${lang === "hi" ? "अंतर्दशा" : lang === "gu" ? "અંતર્દશા" : "Antardasha"} ${esc(vimNow.current.ad.lord)} ${lang === "hi" ? "समाप्त होती है" : lang === "gu" ? "સમાપ્ત થાય છે" : "ends"} ${formatStampDate(new Date(vimNow.current.ad.endMs))} · ${engineLabel}`
        });
      } else {
        const dlNow = dashaTimeline(p);
        const mdNow = dlNow.current.md, adNow = dlNow.current.ad;
        const mdPlanetNow = String(((db.numbers || {})[mdNow.n] || {}).planet || mdNow.n).split(" ")[0];
        const adPlanetNow = String(((db.numbers || {})[adNow.n] || {}).planet || adNow.n).split(" ")[0];
        summary.cards.splice(1, 0, {
          label: t("activeWindowLabel", "Active timing window"),
          value: `${esc(mdPlanetNow)} MD · ${esc(adPlanetNow)} AD`,
          note: `${lang === "hi" ? "अंतर्दशा" : lang === "gu" ? "અંતર્દશા" : "Antardasha"} ${adNow.n} (${esc(adPlanetNow)}) ${lang === "hi" ? "समाप्त होती है" : lang === "gu" ? "સમાપ્ત થાય છે" : "ends"} ${formatStampDate(new Date(adNow.endMs))} · ${engineLabel}`
        });
      }
    } catch (e) { /* timing window is an enhancement — never break the summary */ }

    const dobDisplay = formatBirthDate(p); // unambiguous, locale-aware, timezone-safe
    const generatedOn = formatStampDate(new Date());

    const summarySection = `<section class="rsection summary-section" id="summary-section" data-report-layer="1">
      <div class="summary-shell">
        <p class="summary-kicker">${t("secSummary", "Northstar Summary")}</p>
        <h2 class="summary-title">${summary.headline}</h2>
        ${clinicalNoticeHtml()}
        <p class="summary-story">${summary.story}</p>
        <div class="summary-card-grid">
          ${summary.cards.map((card) => `<div class="summary-card"><div class="summary-label">${card.label}</div><div class="summary-value">${card.value}</div><p>${card.note}</p></div>`).join("")}
        </div>
        <!-- Layman Implementation Framework (Layer 1): the weekly schedule and
             explicit DO / DO-NOT cards live at the very front of the report. -->
        <div class="summary-action-layer" data-report-layer="1">
          ${renderMicroRoutine(p, activation, triage)}
          ${renderDoAvoidCards(p, triage, vastu)}
        </div>
        <div class="summary-next">
          <div>
            <h3>${t("firstThreeMoves", "Your first three moves")}</h3>
            <ol class="summary-actions">${summary.moves.map((move, idx) => `<li><span class="summary-step">${idx + 1}</span><span class="summary-move"><span class="summary-move-title">${move.title}</span><span class="summary-move-detail">${move.detail}</span></span></li>`).join("")}
            </ol>
            <a class="summary-cta" href="#plan-section">${t("open40DayPlan", "Open your full 40-Day Activation Plan ↓")}</a>
          </div>
          <div class="summary-way-forward">
            <h3>${t("wayForward", "Way forward")}</h3>
            ${summary.checks.map((line) => `<p>${line}</p>`).join("")}
            <p><strong>${lang === "hi" ? "इसे अपना मार्गदर्शक बनाएं:" : lang === "gu" ? "આને તમારું માર્ગદર્શન બનાવો:" : "Use this as your northstar:"}</strong> ${lang === "hi" ? `एक साथ सारे उपाय न करें। रिपोर्ट के अंत में दी गई ४०-दिवसीय योजना का पालन करें और परिणाम प्रगति चार्ट (खंड ${SECTION.memory}) में देखें।` : lang === "gu" ? `એક સાથે બધા ઉપાયો ન કરો. રિપોર્ટના અંતે આપેલી ૪૦ દિવસની યોજનાનું પાલન કરો અને પરિણામો પ્રગતિ ચાર્ટ (વિભાગ ${SECTION.memory}) માં જુઓ.` : `do not try every remedy at once. Walk the 40-day Activation Plan at the end of this report — tick each day off in its tracker — then review your results in Your Evolving Chart (Section ${SECTION.memory}).`}</p>
          </div>
        </div>
      </div>
    </section>`;

    const td = db.traits[p.driver], tc = db.traits[p.conductor];
    const traitsSection = `<section class="rsection" id="traits-section">
      <h2 class="rsection-title"><span class="idx">${SECTION.traits}</span>${t("secTraits", "Your Core Nature — Traits, Strengths & Shadows")}</h2>
      <div class="card">
        <div class="card-sub" style="text-transform:uppercase;letter-spacing:.05em;font-weight:600">${lang === "hi" ? "दो अंक आपके स्वभाव का निर्माण करते हैं" : lang === "gu" ? "બે અંક તમારા સ્વભાવનું નિર્માણ કરે છે" : "Two numbers shape your nature"}</div>
        <div class="nature-pair">
          <div class="nature-chip">
            <div class="num-value">${p.driver}</div>
            <div class="num-label">${t("driverLabel", "Driver (Moolank)")} · ${esc(db.numbers[p.driver].planet.split(" ")[0])}</div>
          </div>
          <div class="nature-chip">
            <div class="num-value alt">${p.conductor}</div>
            <div class="num-label">${t("conductorLabel", "Conductor (Bhagyank)")} · ${esc(db.numbers[p.conductor].planet.split(" ")[0])}</div>
          </div>
        </div>
        <div class="kit-value">${esc(td.nature)} ${lang === "hi" ? `गहराई में, आपका भाग्यांक ${esc(tc.innerDrive)} को दर्शाता है।` : lang === "gu" ? `ઊંડાણમાં, તમારો ભાગ્યાંક ${esc(tc.innerDrive)} દર્શાવે છે.` : `Beneath the surface, your Bhagyank carries ${esc(tc.innerDrive)}.`}</div>
        <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${lang === "hi" ? `आपका स्वभाव केवल मूलांक से नहीं देखा जाता। <strong>मूलांक</strong> आपकी दैनिक सोच और व्यक्तित्व है, जबकि <strong>भाग्यांक</strong> आपकी गहरी अंतःप्रेरणा है। हम दोनों को मिलाकर पूरा चित्र देखते हैं।` : lang === "gu" ? `તમારો સ્વભાવ માત્ર મૂળાંક પરથી નથી જોવાતો. <strong>મૂળાંક</strong> તમારી દૈનિક વિચારસરણી છે, જ્યારે <strong>ભાગ્યાંક</strong> તમારી ઊંડી આંતરિક પ્રેરણા છે. આપણે બંનેને મેળવીને સંપૂર્ણ ચિત્ર જોઈએ છીએ.` : "Your nature is not read from your Mulank alone. Your <strong>Mulank</strong> (from your birth day) is your visible, day-to-day personality, while your <strong>Bhagyank</strong> (from your full birth date) drives your deeper instincts. We read <strong>both together</strong> for the full picture."}</div>
      </div>
      <div class="card-grid two">
        <div class="card strength-card">
          <div class="card-title">${t("amplifyThese", "Your Strengths — Amplify These")}</div>
          <div class="kit">${td.strengths.map((s) => `<div class="kit-row"><div class="kit-ico good-ico">✓</div><div class="kit-body"><div class="kit-value">${esc(s)}</div></div></div>`).join("")}</div>
        </div>
        <div class="card shadow-card">
          <div class="card-title">${t("watchThese", "Your Shadows — Watch These")}</div>
          <div class="kit">${td.shadows.map((s) => `<div class="kit-row"><div class="kit-ico bad-ico">!</div><div class="kit-body"><div class="kit-value">${esc(s)}</div></div></div>`).join("")}</div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">${lang === "hi" ? "कौन से गुण अपनाएं, किन्हें त्यागें" : lang === "gu" ? "કયા ગુણો અપનાવવા, કયા છોડવા" : "Which Qualities to Adopt, Which to Let Go"}</div>
        <div class="adopt-release">
          <div class="adopt-col">
            <div class="kit-label" style="color:var(--positive)">${t("adopt", "Adopt")}</div>
            ${td.adopt.map((s) => `<div class="ar-item">+ ${esc(s)}</div>`).join("")}
          </div>
          <div class="release-col">
            <div class="kit-label" style="color:var(--danger)">${t("release", "Release")}</div>
            ${td.release.map((s) => `<div class="ar-item">− ${esc(s)}</div>`).join("")}
          </div>
        </div>
        <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${lang === "hi" ? "प्रत्येक मूलांक के साथ कुछ खास शक्तियां बढ़ाने और कुछ आदतों को छोड़ने का शास्त्रीय नियम जुड़ा होता है।" : lang === "gu" ? "દરેક મૂળાંક સાથે કેટલીક વિશેષ શક્તિઓ વધારવાનો અને કેટલીક આદતો છોડવાનો શાસ્ત્રીય નિયમ જોડાયેલો હોય છે." : "Each Mulank carries a signature set of strengths to <strong>amplify</strong> and tendencies to <strong>release</strong>, shaped by its ruling planet and how that planet tends to over- or under-express in daily life."}</div>
      </div>
    </section>`;

    const weakSection = p.loShuMissing.length
      ? `<section class="rsection" id="remedy-section" data-remedy-authority="lo-shu">
          <h2 class="rsection-title"><span class="idx">${SECTION.weak}</span>${t("secWeak", "Lo Shu Remedy Kits")}</h2>
          <p class="rsection-desc">${lang === "hi" ? "लो शू जन्म-पट्टिका में अनुपस्थित अंकों के पूर्ण उपाय किट — यही इस रिपोर्ट की एकमात्र missing-number remedy सूची है।" : lang === "gu" ? "લો શુ જન્મ-ગ્રિડમાં ખૂટતા અંકોના સંપૂર્ણ ઉપાય કિટ — આ જ રિપોર્ટની એકમાત્ર missing-number remedy સૂચિ છે." : `Full Lo Shu Foundation remedy kits for missing numbers — the only missing-number remedy list in this report.`}</p>
          ${isMinorProfile(p) ? `<p class="rsection-desc" data-age-guardrail="under-18">${lang === "hi" ? `18 से कम आयु — अभिभावकों के लिए: ${p.ageYears} वर्ष की विद्यार्थी-पट्टिका के लिए नीचे की आदत, रंग और दान पंक्तियाँ तथा खंड 4A के तत्व आधार ही पूर्ण उपाय हैं — रत्न नहीं। जहाँ किसी किट में भारी ग्रह-रत्न (ब्लू सैफायर/नीलम, हेसोनाइट/गोमेद, कैट्स आई/लहसुनिया) लिखा हो, उसे वयस्कता तक स्थगित समझें; पत्थर चाहिए भी, तो Amethyst, Citrine या Smoky Quartz जैसा हल्का पत्थर पर्याप्त है।` : lang === "gu" ? `18 થી ઓછી ઉંમર — વાલીઓ માટે: ${p.ageYears} વર્ષની વિદ્યાર્થી-પટ્ટિકા માટે નીચેની ટેવ, રંગ અને દાન હરોળ તથા વિભાગ 4A ના તત્વ આધાર જ સંપૂર્ણ ઉપાય છે — રત્ન નહીં. જ્યાં કોઈ કિટમાં ભારે ગ્રહ-રત્ન (બ્લુ સેફાયર/નીલમ, હેસોનાઇટ/ગોમેદ, કૅટ્સ આય/લહસુનિયા) લખ્યું હોય, તેને પુખ્ત ઉંમર સુધી મુલ્તવી ગણો; પથ્થર જ જોઈતો હોય તો Amethyst, Citrine કે Smoky Quartz જેવો હળવો પથ્થર પૂરતો છે.` : `Under-18 note for parents: at age ${p.ageYears} this school-age chart works best through the habit, colour and charity rows below and the Section 4A Tattva anchors — not gemstones. Where a kit names a heavy planetary gem (Blue Sapphire/Neelam, Hessonite/Gomed, Cat's Eye/Lehsunia), treat it as deferred until adulthood; a mild stone such as Amethyst, Citrine or Smoky Quartz is more than enough if a stone is wanted at all.`}</p>` : ""}
          <div class="card-grid two">${p.loShuMissing.slice(0, 4).map((n) => kitCard(n, undefined, p)).join("")}</div>
          ${p.loShuMissing.length > 4 ? `<p class="rsection-desc">+ ${p.loShuMissing.length - 4} more missing numbers — apply their quick balancers from Section ${SECTION.grid}.</p>` : ""}
        </section>` : "";

    const z = db.zodiac[p.zodiac] || {};
    /* Keep the sidereal Sun-sign as a descriptive Vedic reference, not a
       second source of crystals, affirmations or remedy obligations. */
    const zodiacSection = `<section class="rsection" id="vedic-section" data-authority="zodiac-reference">
      <h2 class="rsection-title"><span class="idx">${SECTION.zodiac}</span>${t("secZodiac", "Your Vedic Sun-sign Reference — {sign}").replace("{sign}", esc(p.zodiac))}</h2>
      <p class="rsection-desc">${lang === "hi" ? "यह आपकी वैदिक सूर्य राशि (सायडीरियल / निरयण, लाहिड़ी अयनांश) का संदर्भ है। यह स्वभाव और इरादों को समझने में मदद कर सकता है, लेकिन लो शू remedy checklist, crystals, affirmations, Rudraksha, इष्ट देवता, power days या दशा-वास्तु समय को नहीं बदलता।" : lang === "gu" ? "આ તમારી વૈદિક સૂર્ય રાશિ (સિડિરિયલ / નિરયણ, લાહિરી અયનામ્સા) નો સંદર્ભ છે. તે સ્વભાવ અને ઇરાદા સમજવામાં મદદ કરી શકે છે, પરંતુ લો શુ remedy checklist, crystals, affirmations, Rudraksha, ઇષ્ટ દેવતા, power days અથવા દશા-વાસ્તુ સમયને બદલતું નથી." : `This is your Vedic Sun-sign reference (sidereal / Nirayana, Lahiri ayanamsa). It can contextualise temperament and intentions, but it never changes the Lo Shu remedy checklist, crystals, affirmations, Rudraksha, guardian deities, power days or Dasha/Vastu timing. Western tropical reference: <strong>${esc(p.zodiacTropical)}</strong>.`}</p>
      <div class="card">
        <div class="goal-head">
          <div class="card-title">${esc(p.zodiac)} — ${esc(z.element || "")}</div>
          <span class="badge info">${lang === "hi" ? "संदर्भ मात्र" : lang === "gu" ? "ફક્ત સંદર્ભ" : "Reference only"}</span>
        </div>
        <div class="kit">
          <div class="kit-row"><div class="kit-ico">☉</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "तत्व और स्वामी" : lang === "gu" ? "તત્વ અને સ્વામી" : "Element and ruler"}</div><div class="kit-value">${esc(z.element || "")} · ${esc(db.numbers[z.ruler] && db.numbers[z.ruler].planet || "")}</div></div></div>
          <div class="kit-row"><div class="kit-ico">◎</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "चिंतन का विषय" : lang === "gu" ? "ચિંતનનો વિષય" : "Reflection theme"}</div><div class="kit-value">${esc(z.intentions || "")}</div></div></div>
        </div>
      </div>
      ${zodiacHarmonyNote(p, z)}
      ${vedicSnapshotCard(p)}
      ${vedicTierDisclosure(p)}
    </section>`;

    const nameVerdictTone = nameSug.verdict === "enemy" || (p.nameRelD === "enemy" || p.nameRelC === "enemy") ? "bad" : nameSug.verdict === "neutral" ? "warn" : "good";
    const nameMaster = masterNumber(p.nameCompound);
    /* Dual-name layer: the statutory reading and the two-window explainer sit
       directly under the everyday card; when no legal string was captured the
       client simply gets told what adding one would unlock. */
    const nameLayerBlock = p.nameDual
      ? `${legalNameCard(p)}${nameWindowsCard(p)}`
      : `<div class="card" id="legal-name-nudge">
          <div class="goal-head">
            <div class="card-title">${lang === "hi" ? "दस्तावेज़ी नाम की दूसरी परत जोड़ें" : lang === "gu" ? "દસ્તાવેજી નામનું બીજું સ્તર ઉમેરો" : "Unlock the Document / Legal layer"}</div>
            <span class="badge info">${lang === "hi" ? "वैकल्पिक" : lang === "gu" ? "વૈકલ્પિક" : "Optional"}</span>
          </div>
          <div class="kit-value">${lang === "hi" ? "आपने केवल एक नाम दर्ज किया है। फ़ॉर्म में <strong>पूरा कानूनी नाम (आधार/PAN अनुसार)</strong> जोड़ें ताकि इंजन दस्तावेज़ी कुल योग की गणना कर सके और आपके असली पितृ-नाम का पहला अक्षर (जैसे <em>किशोरभाई → K</em>) निकाल सके — यह वह शून्य-विकृति विकल्प है जो किसी भी काल्पनिक अक्षर से पहले आता है।" : lang === "gu" ? "તમે ફક્ત એક નામ દાખલ કર્યું છે. ફોર્મમાં <strong>આખું કાનૂની નામ (આધાર/PAN પ્રમાણે)</strong> ઉમેરો જેથી એન્જિન દસ્તાવેજી સરવાળો ગણી શકે અને તમારા સાચા પિતૃ-નામનો પ્રથમ અક્ષર (જેમ કે <em>કિશોરભાઈ → K</em>) કાઢી શકે — આ શૂન્ય-વિકૃતિ વિકલ્પ કોઈ પણ બનાવટી અક્ષર પહેલાં આવે છે." : `You entered one name, so the report scores the identity you live in — the everyday one. Add your <strong>Full Legal Name (as on Aadhaar / PAN)</strong> on the intake form and the engine also reads the statutory string, then extracts your real patronymic's first letter (<em>Kishorbhai → K</em>) as a zero-distortion tuning lever offered before any invented initial.`}</div>
        </div>`;
    const nameSection = `<section class="rsection">
      <h2 class="rsection-title"><span class="idx">${SECTION.name}</span>${t("secName", "Name Analysis & Spelling Correction")}</h2>
      <div class="card">
        <div class="goal-head">
          <div>
            ${p.nameDual ? `<div class="card-sub" data-name-layer="public">${lang === "hi" ? "दैनिक / सार्वजनिक एवं व्यावसायिक नाम" : lang === "gu" ? "દૈનિક / જાહેર અને વ્યાવસાયિક નામ" : "Everyday / Public & Professional name"}</div>` : ""}
            <div class="card-title">${esc(p.name)}</div>
          </div>
          <span class="badge info">${p.nameDual ? (lang === "hi" ? "सार्वजनिक कुल" : lang === "gu" ? "જાહેર સરવાળો" : "Public / Usage total") : "Chaldean total"} ${p.nameCompound}${nameMaster ? " (Master Number)" : ""} → Name Number ${p.nameNum}</span>
          ${relBadge(p.nameRelD === "enemy" || p.nameRelC === "enemy" ? "enemy" : p.nameRelD === "neutral" || p.nameRelC === "neutral" ? "neutral" : "friendly")}
        </div>
        <table class="rtable">
          <tr><th>Name number vs Driver ${p.driver}</th><td>${relBadge(p.nameRelD)} ${p.nameRelD === "enemy" ? "— clashes with your core mind/self energy" : ""}</td></tr>
          <tr><th>Name number vs Conductor ${p.conductor}</th><td>${relBadge(p.nameRelC)} ${p.nameRelC === "enemy" ? "— works against your destiny path" : ""}</td></tr>
        </table>
        ${nameMaster ? `<div class="judge-note"><strong>${esc(nameMaster.name)}:</strong> ${esc(nameMaster.meaning)}</div>` : (compoundMeaning(p.nameCompound) ? `<div class="judge-note"><strong>Compound Number ${p.nameCompound}:</strong> ${esc(compoundMeaning(p.nameCompound))}</div>` : "")}
        ${nameSug.needed
          ? (nameSug.variants && nameSug.variants.length
            ? `<div class="card-sub"><strong>${lang === "hi" ? "सुझाई गई स्पेलिंग" : lang === "gu" ? "સૂચવેલી સ્પેલિંગ" : "Recommended spellings"}</strong> — ${lang === "hi" ? "उच्चारण वही रहता है; अक्षरों को ध्वनि-सुरक्षित तरीके से बदला गया है:" : lang === "gu" ? "ઉચ્ચાર એ જ રહે છે; અક્ષરોને ધ્વનિ-સુરક્ષિત રીતે બદલવામાં આવ્યા છે:" : "pronunciation stays the same; letters are doubled, added or swapped for same-sound equivalents (the way Tripti became Triptii and Sunil became Suniel). Each row states <em>where</em> it applies and <em>how</em> it changes: <strong>Window 1 — Everyday / Public</strong> (business cards, profiles, letterheads; no paperwork) or <strong>Window 2 — Formal / Document</strong> (passport, KYC, Aadhaar, incorporation, where your patronymic stays exactly as printed). The <strong>authentic middle initial</strong> — the real first letter of your legal patronymic — is always offered before any spelling alteration, because it is a letter you already own. Priority is given to options that fill the missing numbers in your Lo Shu Foundation grid:"}</div>
               ${spellingTableHtml((nameSug.variants || []).concat(nameSug.legalVariants || []))}
               <div class="card-sub">${lang === "hi" ? `नई स्पेलिंग को रोज २१ बार ४० दिनों तक लिखें और ${dayOf(p.driver)} से शुरुआत करें।` : lang === "gu" ? `નવી સ્પેલિંગ રોજ ૨૧ વખત ૪૦ દિવસ સુધી લખો અને ${dayOf(p.driver)} ના દિવસે શરૂ કરો.` : `Write the new spelling 21 times daily for 40 days, update it on non-legal items first (email signature, social profiles, visiting cards), and introduce it on a ${DAY_OF[p.driver]}.`}</div>`
            : `<div class="card-sub">Consult a numerologist for a custom spelling — targets friendly to both your numbers are limited. Favour spellings totalling a number that fills a missing number in your grid (${p.loShuMissing.join(", ") || "none missing"}) or is friendly to Driver ${p.driver} and Conductor ${p.conductor}.</div>`)
          : `<div class="kit-value">${esc(db.nameAdvice[nameVerdictTone === "good" ? "friendly" : "neutral"])}</div>${(nameSug.optional && nameSug.optional.variants && nameSug.optional.variants.length) ? `<div class="card" style="margin-top:12px">
               <div class="goal-head">
                 <div class="card-title">${lang === "hi" ? "वैकल्पिक वृद्धि (Optional Enhancement)" : lang === "gu" ? "વૈકલ્પિક ઉન્નતિ (Optional Enhancement)" : "Optional Enhancement"}</div>
                 <span class="badge info">${lang === "hi" ? "केवल वैकल्पिक — कोई बदलाव आवश्यक नहीं" : lang === "gu" ? "માત્ર વૈકલ્પિક — કોઈ ફેરફાર જરૂરી નથી" : "Optional only — no change required"}</span>
               </div>
               <div class="kit-value">${lang === "hi" ? `आपका नाम पहले से ही आपके जन्म अंकों के अनुकूल है, इसलिए कुछ भी बदलना आवश्यक नहीं है। नीचे दी गई स्पेलिंगें आपके लो शू Foundation grid में अनुपस्थित अंक को जोड़ने का एक <em>वैकल्पिक</em> तरीका हैं — इनका उच्चारण समान रहता है, ये मूलांक ${p.driver} और भाग्यांक ${p.conductor} के अनुकूल रहती हैं, और ऐसे अंक में कभी वृद्धि नहीं करतीं जो आपके पास पहले से अधिक मात्रा में है। हर पंक्ति बताती है कि वह कहाँ लागू होगी — <strong>विंडो 1: दैनिक/सार्वजनिक</strong> (विज़िटिंग कार्ड, प्रोफ़ाइल, लेटरहेड; कोई कागज़ी कार्रवाई नहीं) या <strong>विंडो 2: औपचारिक/दस्तावेज़</strong> (पासपोर्ट, KYC, आधार, कंपनी पंजीकरण; पितृ-नाम ज्यों-का-त्यों)। आपके असली पितृ-नाम का अक्षर (प्रामाणिक मध्य आद्यक्षर) हमेशा किसी भी वर्तनी-परिवर्तन से पहले रखा जाता है।` : lang === "gu" ? `તમારું નામ પહેલેથી જ તમારા જન્મ અંકો સાથે સુમેળભર્યું છે, તેથી કંઈ બદલવાની જરૂર નથી. નીચે આપેલી સ્પેલિંગો તમારા લો શુ Foundation grid માં ખૂટતો અંક ઉમેરવાનો <em>વૈકલ્પિક</em> માર્ગ છે — ઉચ્ચાર એ જ રહે છે, તે મૂળાંક ${p.driver} અને ભાગ્યાંક ${p.conductor} સાથે અનુકૂળ રહે છે, અને એવા અંકમાં ક્યારેય વધારો કરતી નથી જે તમારી પાસે પહેલેથી વધુ માત્રામાં હોય. દરેક પંક્તિ કહે છે કે તે ક્યાં લાગુ પડશે — <strong>વિન્ડો 1: દૈનિક/જાહેર</strong> (વિઝિટિંગ કાર્ડ, પ્રોફાઇલ, લેટરહેડ; કોઈ કાગળકામ નહીં) અથવા <strong>વિન્ડો 2: ઔપચારિક/દસ્તાવેજ</strong> (પાસપોર્ટ, KYC, આધાર, કંપની નોંધણી; પિતૃ-નામ જેમ છે તેમ). તમારા સાચા પિતૃ-નામનો અક્ષર (અસલી મધ્ય આદ્યાક્ષર) હંમેશાં કોઈ પણ જોડણી-ફેરફાર પહેલાં રજૂ થાય છે.` : `Your name already harmonises with your birth numbers, so nothing needs to change. The spellings below are an <em>optional</em> way to consciously add a number your Lo Shu Foundation grid is missing — they keep the same pronunciation, stay harmonious with Driver ${p.driver} and Conductor ${p.conductor}, and never add fuel to a number you already have in excess. Choose a <strong>middle initial</strong> if the change should stay clean for banking and legal records, or a <strong>spelling alteration</strong> if you would rather keep the exact two-word name and use the new spelling on social, digital and card profiles.`}</div>
               ${spellingTableHtml((nameSug.optional.variants || []).concat(nameSug.optional.legalVariants || []))}
               <div class="card-sub">${lang === "hi" ? "वैकल्पिक: यदि चाहें तो नई स्पेलिंग को ४० दिनों तक रोज २१ बार लिखें और पहले गैर-कानूनी प्रोफाइल पर उपयोग करें — कोई कानूनी बदलाव आवश्यक नहीं।" : lang === "gu" ? "વૈકલ્પિક: જો ઇચ્છો તો નવી સ્પેલિંગ ૪૦ દિવસ સુધી રોજ ૨૧ વખત લખો અને પહેલાં બિન-કાનૂની પ્રોફાઇલ પર વાપરો — કોઈ કાનૂની ફેરફાર જરૂરી નથી." : `Optional: if you wish to activate it, write the new spelling 21 times daily for 40 days and use it on non-legal profiles first — no legal change is required.`}</div>
             </div>` : ""}`}
      </div>
      ${nameLayerBlock}
      ${brand ? `<div class="card">
        <div class="card-title">Business / Brand Name — Chaldean Success Reading</div>
        <div class="goal-head">
          <div class="card-title">${esc(brand.brand)}</div>
          <span class="badge info">Chaldean total ${brand.total}${brand.master ? " (Master Number)" : ""} → Number ${brand.root}</span>
          ${relBadge(brand.conflicting ? "enemy" : (brand.relD === "neutral" && brand.relC === "neutral" ? "neutral" : "friendly"))}
        </div>
        <table class="rtable">
          <tr><th>vs Driver ${p.driver}</th><td>${relBadge(brand.relD)}</td></tr>
          <tr><th>vs Conductor ${p.conductor}</th><td>${relBadge(brand.relC)}</td></tr>
        </table>
        ${brand.master ? `<div class="judge-note"><strong>${esc(brand.master.name)}:</strong> ${esc(brand.master.meaning)}</div>` : (brand.compound ? `<div class="judge-note"><strong>Compound Number ${brand.total}:</strong> ${esc(brand.compound)}</div>` : "")}
        ${brand.conflicting
          ? `<div class="kit-value">This brand name works against your birth numbers. <strong>Auspicious business roots for you: ${brand.auspicious.join(", ")}.</strong></div>${brand.suggestions.length ? `<div class="card-sub"><strong>Sound-preserving corrections</strong> (pronunciation stays the same):</div><div class="table-scroll"><table class="rtable"><tr><th>Suggested</th><th>Change</th><th>New total</th><th>Number</th><th>Why</th></tr>${brand.suggestions.map((v) => `<tr><td><strong>${esc(v.text)}</strong></td><td>${esc(v.change)}</td><td>${v.compound}</td><td>${v.reduced}</td><td>${esc(v.why)}</td></tr>`).join("")}</table></div>` : `<div class="card-sub">No pronunciation-preserving correction reaches an auspicious root — consult a numerologist for a custom brand name.</div>`}`
          : `<div class="kit-value">This brand name vibrates harmoniously with your birth numbers — an auspicious choice for your venture.</div>`}
      </div>` : ""}
    </section>`;

    const mobSection = `<section class="rsection">
      <h2 class="rsection-title"><span class="idx">${SECTION.mobile}</span>${t("secMobile", "Mobile Number Vibration")}</h2>
      <div class="card">
        <div class="goal-head">
          <div class="card-title">${esc(p.mobile)}</div>
          <span class="badge info">Digits total ${p.mobCompound} → Number ${p.mobNum} (${esc(db.numbers[p.mobNum].planet)})</span>
          ${(p.mobRelD === "enemy" || p.mobRelC === "enemy")
            ? relBadge("enemy")
            : mobSug.verdict === "off-target"
              /* The headline badge must not outrank the verdict below it. A
                 root that is friendly to one birth number and neutral to the
                 other used to print a green "Harmonious" — which read as a
                 clean bill of health directly above prose saying the number
                 sits outside the ideal set. */
              ? `<span class="badge warn" data-mobile-badge="off-target">${lang === "hi" ? "स्वीकार्य — आदर्श सूची से बाहर" : lang === "gu" ? "સ્વીકાર્ય — આદર્શ યાદીની બહાર" : "Acceptable — off ideal set"}</span>`
              : (p.mobRelD === "neutral" && p.mobRelC === "neutral" ? relBadge("neutral") : relBadge("friendly"))}
        </div>
        <table class="rtable">
          <tr><th>vs Driver ${p.driver}</th><td>${relBadge(p.mobRelD)}</td></tr>
          <tr><th>vs Conductor ${p.conductor}</th><td>${relBadge(p.mobRelC)}</td></tr>
        </table>
        ${compoundMeaning(p.mobCompound) ? `<div class="judge-note"><strong>Compound Number ${p.mobCompound}:</strong> ${esc(compoundMeaning(p.mobCompound))}</div>` : ""}
        ${mobSug.verdict === "hostile"
          ? `<div class="kit-value">${lang === "hi" ? `आपका मोबाइल नंबर जन्म अंकों के साथ अनुकूल नहीं है — भविष्य में ऐसा नंबर चुनें जिसका कुल योग <strong>${mobSug.goodTotals.join(", ")}</strong> हो।` : lang === "gu" ? `તમારો મોબાઈલ નંબર જન્મ અંકો સાથે સુમેળભર્યો નથી — ભવિષ્યમાં એવો નંબર પસંદ કરો જેનો કુલ સરવાળો <strong>${mobSug.goodTotals.join(", ")}</strong> થતો હોય.` : `Your mobile number works against your birth numbers — since your phone is your most-used device, this is a high-impact change. When choosing a new number, pick one whose digits total <strong>${mobSug.goodTotals.join(", ")}</strong>. Activate the new SIM on a ${dayOf(p.driver)} or ${dayOf(p.conductor)} morning.`}</div>`
          : mobSug.verdict === "off-target"
            ? `<div class="kit-value" data-mobile-verdict="off-target">${lang === "hi" ? `आपका मोबाइल नंबर जन्म अंकों के विरुद्ध नहीं है — कोई तत्काल बदलाव आवश्यक नहीं। परन्तु कुल योग <strong>${p.mobCompound}</strong> अंक <strong>${p.mobNum}</strong> (${esc(db.numbers[p.mobNum].planet)}) तक जाता है, जो आपके चालक ${p.driver} और कंडक्टर ${p.conductor} दोनों के साथ मैत्रीपूर्ण नहीं है। यदि आप अपने सर्वाधिक प्रयुक्त उपकरण के लिए सर्वश्रेष्ठ कंपन चाहते हैं, तो कुल योग <strong>${mobSug.goodTotals.join(", ")}</strong> वाले नंबर अभी भी आपके सर्वोत्तम विकल्प हैं।` : lang === "gu" ? `તમારો મોબાઈલ નંબર જન્મ અંકોની વિરુદ્ધ નથી — કોઈ તાત્કાલિક ફેરફાર જરૂરી નથી. પરંતુ કુલ સરવાળો <strong>${p.mobCompound}</strong> અંક <strong>${p.mobNum}</strong> (${esc(db.numbers[p.mobNum].planet)}) સુધી જાય છે, જે તમારા ડ્રાઈવર ${p.driver} અને કંડક્ટર ${p.conductor} બંને સાથે મૈત્રીપૂર્ણ નથી. જો તમે તમારા સૌથી વધુ વપરાતા ઉપકરણ માટે શ્રેષ્ઠ કંપન ઈચ્છતા હો, તો કુલ સરવાળો <strong>${mobSug.goodTotals.join(", ")}</strong> વાળા નંબર હજી પણ તમારા શ્રેષ્ઠ વિકલ્પો છે.` : `Your mobile number is not hostile to your birth numbers — no urgent change required. But it totals <strong>${p.mobCompound}</strong>, reducing to Number <strong>${p.mobNum}</strong> (${esc(db.numbers[p.mobNum].planet)}), which is not friendly to <em>both</em> Driver ${p.driver} and Conductor ${p.conductor}, so it sits outside your ideal set. Your number is keepable; if you want the strongest vibration for your most-used device, totals <strong>${mobSug.goodTotals.join(", ")}</strong> remain your best picks. Activate any new SIM on a ${dayOf(p.driver)} or ${dayOf(p.conductor)} morning.`}</div>`
            : `<div class="kit-value" data-mobile-verdict="optimal">${lang === "hi" ? "आपका मोबाइल नंबर आपके जन्म अंकों के अनुकूल है — बदलने की आवश्यकता नहीं है।" : lang === "gu" ? "તમારો મોબાઈલ નંબર તમારા જન્મ અંકો સાથે સુમેળભર્યો છે — બદલવાની જરૂર નથી." : "Your mobile number vibrates acceptably with your birth numbers — no change required."}</div>`}
      </div>
      ${renderDigitFlow(p)}
    </section>`;

    const vehicleSection = `<section class="rsection">
      <h2 class="rsection-title"><span class="idx">${SECTION.vehicle}</span>${t("secVehicle", "Vehicle Number Vibration")}</h2>
      <p class="rsection-desc">${lang === "hi" ? "आप प्रतिदिन अपने वाहन की ऊर्जा में यात्रा करते हैं — इसका रजिस्ट्रेशन नंबर चालडियन पद्धति से विश्लेषित किया जाता है।" : lang === "gu" ? "તમે દરરોજ તમારા વાહનની ઊર્જામાં મુસાફરી કરો છો — તેનો રજીસ્ટ્રેશન નંબર ચાલ્ડિયન પદ્ધતિથી વિશ્લેષિત થાય છે." : "You travel inside your vehicle's vibration every day — its registration number carries Chaldean letter values plus digit values."}</p>
      ${vehicle.provided
        ? `<div class="card">
            <div class="goal-head">
              <div class="card-title">${esc(vehicle.raw)}</div>
              <span class="badge info">Letters ${vehicle.letterVal} + digits ${vehicle.digitVal} = ${vehicle.total} → Number ${vehicle.num} (${esc(db.numbers[vehicle.num].planet)})</span>
              ${relBadge(vehicle.conflicting ? "enemy" : vehicle.relD === "neutral" && vehicle.relC === "neutral" ? "neutral" : "friendly")}
            </div>
            <table class="rtable">
              <tr><th>vs Driver ${p.driver}</th><td>${relBadge(vehicle.relD)}</td></tr>
              <tr><th>vs Conductor ${p.conductor}</th><td>${relBadge(vehicle.relC)}</td></tr>
            </table>
            ${vehicle.conflicting
              ? `<div class="kit-value">${lang === "hi" ? `यह वाहन नंबर जन्म अंकों के साथ अनुकूल नहीं है। नया वाहन लेते समय कुल योग <strong>${vehicle.goodTotals.join(", ")}</strong> वाला नंबर चुनें। तब तक वाहन में छोटा ${esc(db.numbers[p.driver].crystal.split(" ")[0])} रखें।` : lang === "gu" ? `આ વાહન નંબર જન્મ અંકો સાથે સુમેળભર્યો નથી. નવું વાહન લેતી વખતે કુલ સરવાળો <strong>${vehicle.goodTotals.join(", ")}</strong> વાળો નંબર પસંદ કરો. ત્યાં સુધી વાહનમાં નાનો ${esc(db.numbers[p.driver].crystal.split(" ")[0])} રાખો.` : `This number works against your birth numbers. When you next register or change a vehicle, choose a plate whose letters (Chaldean) + digits total <strong>${vehicle.goodTotals.join(", ")}</strong>. Until then, keep a small ${esc(db.numbers[p.driver].crystal.split(" ")[0])} or ${esc(db.numbers[p.driver].planet.split(" ")[0])} yantra in the vehicle and start new journeys on ${DAY_OF[p.driver]}.`}</div>`
              : `<div class="kit-value">${lang === "hi" ? "आपका वाहन नंबर जन्म अंकों के अनुकूल है — इसे बनाए रखें।" : lang === "gu" ? "તમારો વાહન નંબર જન્મ અંકો સાથે સુમેળભર્યો છે — તેને જાળવી રાખો." : "Your vehicle number vibrates acceptably with your birth numbers — keep it. For your next vehicle, the totals below remain your best picks."}</div>`}
          </div>`
        : `<div class="card"><div class="kit-value">${lang === "hi" ? "कोई वाहन नंबर दर्ज नहीं किया गया था — नया वाहन खरीदते समय नीचे दिए गए मार्गदर्शन का उपयोग करें।" : lang === "gu" ? "કોઈ વાહન નંબર દાખલ કરવામાં આવ્યો ન હતો — નવું વાહન ખરીદતી વખતે નીચે આપેલા માર્ગદર્શનનો ઉપયોગ કરો." : "No vehicle number was entered — use the guidance below whenever you buy a car/bike or choose a registration number."}</div></div>`}
      <div class="card">
        <div class="card-title">${lang === "hi" ? "शुभ वाहन नंबर का चयन" : lang === "gu" ? "શુભ વાહન નંબરની પસંદગી" : "Choosing a Lucky Vehicle Number"}</div>
        <div class="kit-value">${lang === "hi" ? `ऐसा नंबर चुनें जिसके <strong>अक्षरों + अंकों का कुल योग</strong>: <strong>${vehicle.goodTotals.join(", ")}</strong> हो। शुभ वाहन रंग: <strong>${esc(vehicle.luckyColors.join(" या "))}</strong>। नए वाहन की डिलीवरी <strong>${dayOf(p.driver)}</strong> या <strong>${dayOf(p.conductor)}</strong> को लें।` : lang === "gu" ? `એવો નંબર પસંદ કરો જેના <strong>અક્ષરો + અંકોનો કુલ સરવાળો</strong>: <strong>${vehicle.goodTotals.join(", ")}</strong> થતો હોય. શુભ વાહન રંગો: <strong>${esc(vehicle.luckyColors.join(" અથવા "))}</strong>. નવા વાહનની ડિલિવરી <strong>${dayOf(p.driver)}</strong> કે <strong>${dayOf(p.conductor)}</strong> ના દિવસે લો.` : `Pick a registration whose <strong>letter values + digits total</strong> is one of: <strong>${vehicle.goodTotals.join(", ")}</strong> (these reduce to numbers in harmony with Driver ${p.driver} and Conductor ${p.conductor}). Favour vehicle colours <strong>${esc(vehicle.luckyColors.join(" or "))}</strong>. Take delivery of a new vehicle on a <strong>${DAY_OF[p.driver]}</strong> or <strong>${DAY_OF[p.conductor]}</strong>, ideally in the morning.`}</div>
      </div>
    </section>`;

    const watchSection = `<section class="rsection">
      <h2 class="rsection-title"><span class="idx">${SECTION.watch}</span>${t("secWatch", "Watch & Wearable Remedy")}</h2>
      <p class="rsection-desc">Your watch sits on your pulse all day — its metal, colour and geometry continuously feed planetary energy. Spec aligned to Driver ${p.driver} (${esc(db.numbers[p.driver].planet)}) + Conductor ${p.conductor} (${esc(db.numbers[p.conductor].planet)}).</p>
      <div class="table-scroll"><table class="rtable">
        <tr><th>Element</th><th>Recommended</th><th>Why</th></tr>
        ${watch.rows.map((r) => `<tr><td><strong>${esc(r[0])}</strong></td><td>${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join("")}
      </table></div>
      ${watch.avoids.length ? `<div class="card"><div class="card-title">Avoid</div>${watch.avoids.map((a) => `<div class="kit-value">• ${esc(a)}</div>`).join("")}</div>` : ""}
      ${watch.currentVerdict ? `<div class="card"><div class="goal-head"><div class="card-title">${lang === "hi" ? "आपकी वर्तमान घड़ी" : lang === "gu" ? "તમારી હાલની ઘડિયાળ" : "Your current watch"}</div><span class="badge ${watch.currentVerdict.tone}">${watch.currentVerdict.tone === "good" ? "Aligned" : watch.currentVerdict.tone === "warn" ? "Caution" : "Note"}</span></div><div class="kit-value">${esc(watch.currentVerdict.text)}</div></div>` : ""}
      <div class="card"><div class="card-title">${lang === "hi" ? "शुभ मुहूर्त में धारण" : lang === "gu" ? "શુભ મુહૂર્તમાં ધારણ" : "Auspicious Activation"}</div><div class="kit-value">${lang === "hi" ? `नई घड़ी को पहली बार <strong>${watch.days.join(" या ")}</strong> की सुबह, ${watch.time} में पहनें।` : lang === "gu" ? `નવી ઘડિયાળને પ્રથમ વખત <strong>${watch.days.join(" કે ")}</strong> ની સવારે, ${watch.time} માં પહેરો.` : `Wear the new watch for the first time on a <strong>${watch.days.join(" or ")}</strong> morning, ${watch.time}. Set a clear intention for your ${esc(p.goals[0] || "goal")} goal while putting it on.`}</div></div>
    </section>`;

    const cg = crystalGuide(p);
    /* Under-18 charts never surface a heavy Saturn/Rahu/Ketu gem card: the
       pick is swapped to the gentle substitute named in the same kit, and a
       parent-facing note explains the deferral. */
    const minorChart = isMinorProfile(p);
    const cgPicks = minorChart
      ? [...new Set(cg.picks.map((k) => (HEAVY_GEM_PICK_SWAP[k] && db.crystals[HEAVY_GEM_PICK_SWAP[k]] ? HEAVY_GEM_PICK_SWAP[k] : k)))]
      : cg.picks;
    const cgSwapped = minorChart && cg.picks.some((k) => HEAVY_GEM_PICK_SWAP[k]);
    const cgSubstituteOf = {};
    if (cgSwapped) cg.picks.forEach((k) => { const swap = HEAVY_GEM_PICK_SWAP[k]; if (swap && cgPicks.includes(swap)) cgSubstituteOf[swap] = k; });
    const crystalSection = `<section class="rsection" data-remedy-authority="lo-shu">
      <h2 class="rsection-title"><span class="idx">${SECTION.crystal}</span>${t("secCrystal", "Crystal Companion Guide")}</h2>
      <p class="rsection-desc">${lang === "hi" ? `ये crystal और Rudraksha सुझाव केवल लो शू में अनुपस्थित अंक ${cg.remedyNumbers.length ? `<strong>${cg.remedyNumbers.join(" / ")}</strong>` : "के अभाव"} से आते हैं। मूलांक/भाग्यांक, राशि और उन्नत वैदिक grid इन्हें नहीं बदलते।` : lang === "gu" ? `આ crystal અને Rudraksha સૂચનો ફક્ત લો શુંમાં ખૂટતા અંક ${cg.remedyNumbers.length ? `<strong>${cg.remedyNumbers.join(" / ")}</strong>` : "ના અભાવ"} પરથી આવે છે. મૂળાંક/ભાગ્યાંક, રાશિ અને ઉન્નત વૈદિક grid તેને બદલતા નથી.` : `These crystal and Rudraksha suggestions come only from missing Lo Shu number${cg.remedyNumbers.length === 1 ? "" : "s"} ${cg.remedyNumbers.length ? `<strong>${cg.remedyNumbers.join(" / ")}</strong>` : "— none are required"}. Driver/Conductor, zodiac and the advanced Vedic grid do not change them.`}</p>
      ${minorChart && cgPicks.length ? `<div class="card" data-age-guardrail="under-18"><div class="goal-head"><div class="card-title">${lang === "hi" ? "🛡 अभिभावकों के लिए — 18 से कम आयु की पट्टिका" : lang === "gu" ? "🛡 વાલીઓ માટે — 18 થી ઓછી ઉંમરની પટ્ટિકા" : "🛡 For parents — an under-18 chart"}</div><span class="badge info">${lang === "hi" ? `आयु ${p.ageYears}` : lang === "gu" ? `ઉંમર ${p.ageYears}` : `Age ${p.ageYears}`}</span></div><div class="kit-value">${lang === "hi" ? `इस आयु में कोई भारी ग्रह-रत्न नहीं: ब्लू सैफायर (नीलम), हेसोनाइट (गोमेद) और कैट्स आई (लहसुनिया) 18 वर्ष तक स्थगित रहते हैं और तब भी विशेषज्ञ परीक्षण मांगते हैं। ऊपर की सूची पहले से ही हल्के विकल्प दिखाती है। असली उपाय विद्यार्थी-आयु में खंड 4A के तत्व आधार और प्रत्येक किट की जीवनशैली पंक्तियाँ हैं; पत्थर चाहिए भी, तो Amethyst या Citrine जैसा हल्का, जैविक पत्थर ही सुरक्षित शुरुआत है।` : lang === "gu" ? `આ ઉંમરે કોઈ ભારે ગ્રહ-રત્ન નહીં: બ્લુ સેફાયર (નીલમ), હેસોનાઇટ (ગોમેદ) અને કૅટ્સ આય (લહસુનિયા) 18 વર્ષ સુધી મુલ્તવી રહે છે અને પછી પણ નિષ્ણાત પરીક્ષણ માંગે છે. ઉપરની યાદી પહેલેથી હળવા વિકલ્પો બતાવે છે. વિદ્યાર્થી-ઉંમરે સાચો ઉપાય વિભાગ 4A ના તત્વ આધાર અને દરેક કિટની જીવનશૈલી હરોળ છે; પથ્થર જ જોઈતો હોય તો Amethyst કે Citrine જેવો હળવો, ઓર્ગેનિક પથ્થર જ સુરક્ષિત શરૂઆત છે.` : `No heavy planetary gems at this age: Blue Sapphire (Neelam), Hessonite (Gomed) and Cat's Eye (Lehsunia) stay deferred until 18 and demand an expert trial even then — the list above already shows the gentle substitutes. The real remedy at school age is the Section 4A Tattva anchors plus each kit's lifestyle rows; if a stone is still wanted, keep it mild and organic — Amethyst or Citrine are the safe starters.`}</div></div>` : ""}
      ${moonColdCrystalNoteHtml(p, cgPicks, lang)}
      ${doshaContraCrystalNoteHtml(p, cgPicks, lang)}
      ${cgPicks.length ? `<div class="card-grid two">${cgPicks.map((k) => {
        const c = db.crystals[k];
        return `<div class="card"${cgSubstituteOf[k] ? ` data-gentle-substitute="${esc(cgSubstituteOf[k])}"` : ""}>
          <div class="card-title">💎 ${esc(k)}${cgSubstituteOf[k] ? ` <span class="badge info" data-age-guardrail="under-18">${lang === "hi" ? `हल्का विकल्प — ${esc(cgSubstituteOf[k])} के स्थान पर` : lang === "gu" ? `હળવો વિકલ્પ — ${esc(cgSubstituteOf[k])} ના સ્થાને` : `gentle stand-in for ${esc(cgSubstituteOf[k])}`}</span>` : ""}</div>
          <div class="kit">
            <div class="kit-row"><div class="kit-ico">⚡</div><div class="kit-body"><div class="kit-label">Energy / Chakra</div><div class="kit-value">${esc(c.chakra)}</div></div></div>
            <div class="kit-row"><div class="kit-ico">✨</div><div class="kit-body"><div class="kit-label">Core Benefits</div><div class="kit-value">${esc(c.benefits)}</div></div></div>
            <div class="kit-row"><div class="kit-ico">🔗</div><div class="kit-body"><div class="kit-label">Best Paired With</div><div class="kit-value">${esc(c.pair)}</div></div></div>
          </div>
        </div>`;
      }).join("")}</div>` : `<div class="card"><div class="kit-value">${lang === "hi" ? "लो शू में कोई अनुपस्थित अंक नहीं है, इसलिए अतिरिक्त remedial crystal आवश्यक नहीं है। दोहराए अंक को पत्थर से बढ़ाने के बजाय उसकी ऊर्जा को आदत में दिशा दें।" : lang === "gu" ? "લો શુંમાં કોઈ ખૂટતો અંક નથી, તેથી વધારાનો remedial crystal જરૂરી નથી. પુનરાવર્તિત અંકને પથ્થરથી વધારવાને બદલે તેની ઊર્જાને ટેવમાં દિશા આપો." : "No Lo Shu number is missing, so no extra remedial crystal is required. Channel a repeated number through its habit rather than feeding it with another stone."}</div></div>`}
      <div class="card">
        <div class="card-title">🧼 Cleansing &amp; Charging — the Selenite Rule</div>
        <div class="kit-value">${esc(db.crystals["Selenite"].benefits)}<br><strong>${esc(db.seleniteRitual)}</strong></div>
      </div>
      ${cg.rudrakshaNote ? `<div class="card"><div class="card-title">📿 5 Mukhi Rudraksha Note</div><div class="kit-value">${esc(cg.rudrakshaNote.benefits)} Best paired with: ${esc(cg.rudrakshaNote.pair)}.</div></div>` : ""}
    </section>`;

    const powerDaySet = [...new Set([dayOf(p.driver), dayOf(p.conductor)])];
    const colorSection = `<section class="rsection">
      <h2 class="rsection-title"><span class="idx">${SECTION.colours}</span>${t("secColours", "Lucky Colours & Day-wise Dressing")}</h2>
      <div class="card">
        <div class="card-title">Your Power Colours</div>
        <div class="kit-value">${lang === "hi" ? `अधिकांशतः <strong>${esc(db.numbers[p.driver].color)}</strong> पहनें — यह आपके मूलांक ${p.driver} (${esc(db.numbers[p.driver].planet)}) को शक्ति देता है। महत्वपूर्ण बैठकों और निर्णयों में <strong>${esc(db.numbers[p.conductor].color)}</strong> जोड़ें।` : lang === "gu" ? `મોટેભાગે <strong>${esc(db.numbers[p.driver].color)}</strong> પહેરો — આ તમારા મૂળાંક ${p.driver} (${esc(db.numbers[p.driver].planet)}) ને બળ આપે છે. મહત્વના કાર્યોમાં <strong>${esc(db.numbers[p.conductor].color)}</strong> ઉમેરો.` : `Wear <strong>${esc(db.numbers[p.driver].color)}</strong> most often — they feed your Driver ${p.driver} (${esc(db.numbers[p.driver].planet)}), your core personality. Add <strong>${esc(db.numbers[p.conductor].color)}</strong> for important days, meetings and decisions — they support your Conductor ${p.conductor} (${esc(db.numbers[p.conductor].planet)}).`}</div>
      </div>
      <div class="card">
        <div class="card-title">${lang === "hi" ? "दिन अनुसार क्या पहनें" : lang === "gu" ? "વાર મુજબ શું પહેરવું" : "What to Wear, Day by Day"}</div>
        <div class="table-scroll"><table class="rtable">
          <tr><th>Day</th><th>Planet</th><th>Wear these colours</th><th>Note</th></tr>
          ${db.dayWear.map((d) => `<tr${powerDaySet.includes(d.day) ? ' class="hl-row"' : ""}>
            <td><strong>${esc(d.day)}</strong>${powerDaySet.includes(d.day) ? ` <span class="badge good">${lang === "hi" ? "आपका मुख्य शुभ वार" : lang === "gu" ? "તમારો મુખ્ય શુભ વાર" : "Your power day"}</span>` : ""}</td>
            <td>${esc(db.numbers[d.num].planet.split(" ")[0])}</td>
            <td>${esc(d.colors)}</td>
            <td>${esc(d.note)}</td>
          </tr>`).join("")}
        </table></div>
        <div class="card-sub">${lang === "hi" ? "नियम: अपने मुख्य शुभ वार पर कभी फटे या पुराने कपड़े न पहनें — उस दिन ग्रह ऊर्जा सीधे आकर्षित होती है।" : lang === "gu" ? "નિયમ: તમારા મુખ્ય શુભ વારે ક્યારેય ફાટેલા કે જૂના કપડાં ન પહેરો — તે દિવસે ગ્રહ ઊર્જા સીધી આકર્ષિત થાય છે." : "Rule of thumb: never wear dull or torn clothes on your power days — that is when your planets receive energy most directly."}</div>
      </div>
    </section>`;

    const driverCareers = db.careers[p.driver], conductorCareers = db.careers[p.conductor];
    const overlap = driverCareers.filter((c) => conductorCareers.includes(c));
    const careerSection = `<section class="rsection">
      <h2 class="rsection-title"><span class="idx">${SECTION.career}</span>${t("secCareer", "Best Fields & Professions")}</h2>
      <p class="rsection-desc">Fields ruled by your Driver suit your natural talent; fields ruled by your Conductor bring destiny-level success. The sweet spot is where they overlap.</p>
      <div class="card-grid two">
        <div class="card">
          <div class="card-title">Natural Talent — Driver ${p.driver} (${esc(db.numbers[p.driver].planet)})</div>
          <div class="kit">${driverCareers.map((c) => `<div class="kit-row"><div class="kit-ico">›</div><div class="kit-body"><div class="kit-value">${esc(c)}</div></div></div>`).join("")}</div>
        </div>
        <div class="card">
          <div class="card-title">Destiny Growth — Conductor ${p.conductor} (${esc(db.numbers[p.conductor].planet)})</div>
          <div class="kit">${conductorCareers.map((c) => `<div class="kit-row"><div class="kit-ico">›</div><div class="kit-body"><div class="kit-value">${esc(c)}</div></div></div>`).join("")}</div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">Career Direction Verdict</div>
        <div class="kit-value">${overlap.length
          ? (lang === "hi" ? `आपकी प्रतिभा और भाग्य का सुंदर मिलन: <strong>${overlap.map(esc).join(", ")}</strong> — इन क्षेत्रों को प्राथमिकता दें।` : lang === "gu" ? `તમારી આવડત અને ભાગ્યનો સુંદર મેળ: <strong>${overlap.map(esc).join(", ")}</strong> — આ ક્ષેત્રોને પ્રાથમિકતા આપો.` : `Your talent and destiny align beautifully in: <strong>${overlap.map(esc).join(", ")}</strong> — prioritise these for the highest chance of excelling.`)
          : (lang === "hi" ? `मूलांक और भाग्यांक अलग-अलग क्षेत्रों की ओर संकेत करते हैं — दोनों को मिलाएं (जैसे मूलांक ${p.driver} का कौशल भाग्यांक ${p.conductor} के उद्योग में लगाएं)।` : lang === "gu" ? `મૂળાંક અને ભાગ્યાંક અલગ ક્ષેત્રો સૂચવે છે — બંનેને જોડો (જેમ કે મૂળાંક ${p.driver} નું કૌશલ્ય ભાગ્યાંક ${p.conductor} ના ઉદ્યોગમાં વાપરો).` : `Your Driver and Conductor pull towards different fields — combine them (e.g. a Driver-${p.driver} skill applied inside a Conductor-${p.conductor} industry) and success probability multiplies.`)}
          ${p.loShuMissing.includes(3) ? ` Number 3 (Jupiter) is missing from your grid — careers involving teaching, finance or advisory need extra Jupiter remedy support (see Section 4).` : ""}
          ${p.loShuMissing.includes(8) ? ` Number 8 (Saturn) is missing — long-term career stability improves as you apply the Saturn remedies in Section 4.` : ""}</div>
      </div>
    </section>`;

    const pinn = timing.pinnacles || { phases: [], firstEnd: null };
    const agesLbl = lang === "hi" ? "आयु" : lang === "gu" ? "ઉંમર" : "Ages";
    const pinnacleCard = `<div class="card" id="pinnacles-card">
        <div class="card-title">${t("pinnacleCardTitle", "Four Life Phases — Pinnacles & Challenges")}</div>
        <div class="table-scroll"><table class="rtable">
          <tr><th>${lang === "hi" ? "चरण" : lang === "gu" ? "તબક્કો" : "Phase"}</th><th>${lang === "hi" ? "आयु व वर्ष" : lang === "gu" ? "ઉંમર અને વર્ષ" : "Ages & Years"}</th><th>${lang === "hi" ? "पिनेकल (शिखर) — उभरती ऊर्जा" : lang === "gu" ? "પિનેકલ (શિખર) — ઊભરતી ઊર્જા" : "Pinnacle — rising energy"}</th><th>${lang === "hi" ? "चुनौती — सीखने योग्य पाठ" : lang === "gu" ? "પડકાર — શીખવા જેવી સીખ" : "Challenge — lesson to master"}</th></tr>
          ${pinn.phases.map((ph) => {
            const pk = (db.pinnacle && db.pinnacle[ph.pinnacle]) || {};
            const cl = (db.challengeLesson && db.challengeLesson[ph.challenge]) || {};
            const ageSpan = ph.to === null ? `${agesLbl} ${ph.from}+` : `${agesLbl} ${ph.from}–${ph.to}`;
            const yearSpan = ph.to === null ? `${p.year + ph.from} →` : `${p.year + ph.from}–${p.year + ph.to}`;
            const cur = timing.curAge >= ph.from && (ph.to === null || timing.curAge <= ph.to);
            return `<tr${cur ? ' class="hl-row"' : ""}>
            <td><strong>${lang === "hi" ? "चरण" : lang === "gu" ? "તબક્કો" : "Phase"} ${ph.i}</strong>${cur ? ` <span class="badge info">${lang === "hi" ? "वर्तमान" : lang === "gu" ? "હાલમાં" : "Now"}</span>` : ""}</td>
            <td>${ageSpan} <span class="card-sub">(${yearSpan})</span></td>
            <td><strong>${ph.pinnacle}</strong> (${esc(db.numbers[ph.pinnacle].planet.split(" ")[0])}) — ${esc(loc(pk.theme, lang))}</td>
            <td><strong>${ph.challenge}</strong> — ${esc(loc(cl, lang))}</td>
          </tr>`;
          }).join("")}
        </table></div>
        <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${lang === "hi" ? "पिनेकल जन्मतिथि से निकाले जाते हैं — दिन+माह, दिन+वर्ष, उन दोनों का योग, और माह+वर्ष। चुनौतियां इन्हीं घटकों के अंतर हैं। पहला चरण <strong>36 − भाग्यांक</strong> की उम्र तक चलता है, उसके बाद प्रत्येक चरण ९ वर्ष का होता है। हर चरण की शिखर-ऊर्जा को साधें और चुनौती की सीख अपनाएं — यही उस दौर का सबसे तेज़ मार्ग है।" : lang === "gu" ? "પિનેકલ જન્મતારીખથી નિગમે છે — દિવસ+માસ, દિવસ+વર્ષ, તે બંનેનો સરવાળો, અને માસ+વર્ષ. પડકારો એ જ ઘટકોના તફાવત છે. પહેલો તબક્કો <strong>36 − ભાગ્યાંક</strong> ઉંમર સુધી ચાલે છે, પછી દરેક તબક્કો ૯ વર્ષનો. દરેક તબક્કાની શિખર-ઊર્જાને વધારો અને પડકારની સીખ અપનાવો — એ જ તે સમયનો સૌથી ઝડપી માર્ગ છે." : "Pinnacles are derived from your birth date — day+month, day+year, their sum, and month+year. Challenges are the gaps between those same components. The first phase runs to <strong>36 − Conductor</strong>, each phase after spans 9 years. Grow into each phase's rising energy while mastering its challenge — that is the fastest route through the period."}</div>
      </div>`;

    const timingSection = `<section class="rsection" id="timing-section" data-authority="personal-year-context">
      <h2 class="rsection-title"><span class="idx">${SECTION.timing}</span>${t("secTiming", "Long-range Personal-Year Context")}</h2>
      <p class="rsection-desc">${lang === "hi" ? "यह मूलांक/भाग्यांक से निकला व्यापक personal-year संदर्भ है, सक्रिय भविष्यवाणी नहीं। वर्तमान दशा की तिथियां, event windows और Active Vastu Zone केवल नीचे के Dasha roadmap से तय होते हैं।" : lang === "gu" ? "આ મૂળાંક/ભાગ્યાંક પરથી આવેલો વ્યાપક personal-year સંદર્ભ છે, સક્રિય આગાહી નથી. વર્તમાન દશાની તારીખો, event windows અને Active Vastu Zone ફક્ત નીચેના Dasha roadmap થી નક્કી થાય છે." : "This is broad Driver/Conductor personal-year context, not active prediction. Current Dasha dates, event windows and the Active Vastu Zone are determined only by the Dasha roadmap below."}</p>
      <div class="card">
        <div class="card-title">${lang === "hi" ? "व्यक्तिगत वर्ष संदर्भ" : lang === "gu" ? "વ્યક્તિગત વર્ષ સંદર્ભ" : "Personal-Year Reference"}</div>
        <div class="table-scroll"><table class="rtable">
          <tr><th>Year</th><th>Personal Year</th><th>Reflection theme — not Dasha timing</th></tr>
          ${timing.years.map((y) => `<tr${y.current ? ' class="hl-row"' : ""}>
            <td><strong>${y.yr}</strong>${y.current ? ` <span class="badge info">${lang === "hi" ? "वर्तमान" : lang === "gu" ? "હાલમાં" : "Now"}</span>` : ""}</td>
            <td>${y.n} (${esc(db.numbers[y.n].planet.split(" ")[0])})</td>
            <td>${esc(y.meaning)}</td>
          </tr>`).join("")}
        </table></div>
      </div>
      ${pinnacleCard}
      <div class="card-grid two">
        <div class="card">
          <div class="card-title">${lang === "hi" ? "सहायक personal-year themes" : lang === "gu" ? "સહાયક personal-year themes" : "Supportive Personal-Year Themes"}</div>
          <div class="kit">${timing.luckyYears.map((l) => `<div class="kit-row"><div class="kit-ico"><strong>${l.yr}</strong></div><div class="kit-body"><div class="kit-value">Personal year ${l.py} — ${esc(l.why)}</div></div></div>`).join("")}</div>
          <div class="card-sub">${lang === "hi" ? "इन्हें व्यापक reflection के रूप में पढ़ें; किसी भी समय-संवेदी निर्णय के लिए नीचे की दशा-window देखें।" : lang === "gu" ? "તેને વ્યાપક reflection તરીકે વાંચો; કોઈ પણ સમય-સંવેદનશીલ નિર્ણય માટે નીચેની દશા-window જુઓ." : "Read these as broad reflection themes; use the Dasha windows below for time-sensitive decisions."}</div>
        </div>
        <div class="card">
          <div class="card-title">${lang === "hi" ? "जीवन के पड़ाव — reflection" : lang === "gu" ? "જીવનના પડાવ — reflection" : "Milestone Ages — Reflection"}</div>
          <div class="kit">${timing.milestones.map((m) => `<div class="kit-row"><div class="kit-ico"><strong>${m.age}</strong></div><div class="kit-body"><div class="kit-value">Year ${m.yr} — ${esc(m.why)}</div></div></div>`).join("")}</div>
          <div class="card-sub">${lang === "hi" ? "ये उम्र आत्म-चिंतन के पड़ाव हैं; सक्रिय अवसर-दिनांक और दिशा के लिए दशा roadmap देखें।" : lang === "gu" ? "આ ઉમર આત્મ-ચિંતનના પડાવ છે; સક્રિય તક-તારીખો અને દિશા માટે દશા roadmap જુઓ." : "These ages are reflection milestones; use the Dasha roadmap for active opportunity dates and direction."}</div>
        </div>
      </div>
    </section>`;

    /* ---- Section: Numerology Dasha timeline + life-event windows ---- */
    
    /* ---- Muhurtha / Rahu Kaal foundation (Meeus Ch.16) -----------------
       Same engine that fixed the hardcoded 6:30-8:30 window now powers
       Rahu Kaal, sunrise/sunset, day-length. DST and polar-day handled.
       This is the foundation for the future Muhurtha module. */
    const muhurthaSection = (function () {
      try {
        const astro = (typeof window !== "undefined" && window.NVAstro) ? window.NVAstro : null;
        if (!astro || typeof astro.sunriseSunset !== "function") return "";
        const place = p.astro && p.astro.place ? p.astro.place : null;
        if (!place || !isFinite(place.lat) || !isFinite(place.lon)) {
          return `<section class="rsection" id="muhurtha-section" data-muhurtha="no-place">
      <h2 class="rsection-title"><span class="idx">${SECTION.timing}b</span>${lang === "hi" ? "आज का मुहूर्त — सूर्योदय / राहु काल" : lang === "gu" ? "આજનું મુહૂર્ત — સૂર્યોદય / રાહુ કાળ" : "Today's Muhurtha — Sunrise & Rahu Kaal"}</h2>
      <p class="rsection-desc">${lang === "hi" ? "जन्म स्थान उपलब्ध होने पर यहाँ आज के वास्तविक सूर्योदय, सूर्यास्त और राहु काल की गणना दिखाई देगी (दिन-बचत समय और ध्रुवीय दिन/रात सहित)।" : lang === "gu" ? "જન્મ સ્થાન ઉપલબ્ધ હોય ત્યારે અહીં આજના વાસ્તવિક સૂર્યોદય, સૂર્યાસ્ત અને રાહુ કાળની ગણતરી બતાવવામાં આવશે (દિવસ-બચત સમય અને ધ્રુવીય દિવસ/રાત સહિત)." : "Add your birth place to see actual sunrise, sunset and Rahu Kaal for today at your location (daylight-saving and polar-day aware)."}</p>
      <div class="card"><div class="card-sub">${lang === "hi" ? "उदाहरण: त्रिवेंद्रम में सूर्योदय ६:०४ और श्रीनगर में ६:४७ एक ही दिन — बर्मिंघम GMT में ०८:०५ — इसलिए ६:३०-८:३० का हार्डकोड गलत था। अब वास्तविक गणना से समय निकलता है।" : lang === "gu" ? "ઉદાહરણ: ત્રિવેન્દ્રમમાં સૂર્યોદય ૬:૦૪ અને શ્રીનગરમાં ૬:૪૭ એક જ દિવસે — બર્મિંગહામ GMT માં ૦૮:૦૫ — તેથી ૬:૩૦-૮:૩૦ નો હાર્ડકોડ ખોટો હતો. હવે વાસ્તવિક ગણતરીથી સમય નીકળે છે." : "Example: 6:04 Trivandrum vs 6:47 Srinagar same day, 08:05 Birmingham GMT — so the hardcoded 6:30-8:30 window was inaccurate. Now computed from your actual location."}</div></div>
    </section>`;
        }
        const now = new Date();
        const Y = now.getFullYear(), M = now.getMonth()+1, D = now.getDate();
        let tzEff = place.tz;
        try { if (typeof astro.effectiveTz === "function") tzEff = astro.effectiveTz(place, Y, M, D); } catch(e){}
        const ss = astro.sunriseSunset(Y, M, D, place.lat, place.lon, tzEff);
        const rk = (typeof astro.getRahuKaal === "function") ? astro.getRahuKaal(Y, M, D, place.lat, place.lon, tzEff) : null;
        const fmt = (dec) => {
          try { if (typeof astro.formatSunTime === "function") return astro.formatSunTime(dec, lang); } catch(e){}
          if (!isFinite(dec)) return "—";
          let h = ((dec % 24)+24)%24;
          let hr = Math.floor(h), mn = Math.floor((h-hr)*60+0.5);
          if (mn>=60){ mn-=60; hr=(hr+1)%24; }
          let ampm = hr>=12?"PM":"AM"; let h12=hr%12; if(h12===0)h12=12;
          return h12+":"+String(mn).padStart(2,"0")+" "+ampm;
        };
        const fmt24 = (dec) => {
          try { if (typeof astro.formatSunTime24 === "function") return astro.formatSunTime24(dec); } catch(e){}
          if (!isFinite(dec)) return "—";
          let h = ((dec % 24)+24)%24;
          let hr = Math.floor(h), mn = Math.floor((h-hr)*60+0.5);
          if (mn>=60){ mn-=60; hr=(hr+1)%24; }
          return String(hr).padStart(2,"0")+":"+String(mn).padStart(2,"0");
        };
        let sunriseStr = ss && ss.ok && ss.sunrise!=null ? fmt(ss.sunrise) : (ss && ss.alwaysDay ? (lang==="hi"?"ध्रुवीय दिन — सूर्य अस्त नहीं होता":lang==="gu"?"ધ્રુવીય દિવસ — સૂર્ય આથમતો નથી":"Polar day — sun up all day") : (ss && ss.alwaysNight ? (lang==="hi"?"ध्रुवीय रात — सूर्य उदय नहीं होता":lang==="gu"?"ધ્રુવીય રાત — સૂર્ય ઊગતો નથી":"Polar night — no sunrise") : "—"));
        let sunsetStr = ss && ss.ok && ss.sunset!=null ? fmt(ss.sunset) : (ss && ss.alwaysDay ? (lang==="hi"?"ध्रुवीय दिन":lang==="gu"?"ધ્રુવીય દિવસ":"Polar day") : (ss && ss.alwaysNight ? (lang==="hi"?"ध्रुवीय रात":lang==="gu"?"ધ્રુવીય રાત":"Polar night") : "—"));
        let transitStr = ss && ss.ok && ss.transit!=null ? fmt(ss.transit) : "—";
        let dayLenStr = ss && ss.ok ? (ss.dayLength>=24 ? "24h" : ss.dayLength.toFixed(2)+"h") : "—";
        let rahuStr = "", rahuNote = "";
        if (rk && rk.ok) {
          rahuStr = fmt(rk.rahuStart) + " – " + fmt(rk.rahuEnd);
          const wdNames = lang==="hi" ? ["रवि","सोम","मंगल","बुध","गुरु","शुक्र","शनि"] : lang==="gu" ? ["રવિ","સોમ","મંગળ","બુધ","ગુરુ","શુક્ર","શનિ"] : ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
          const wd = wdNames[rk.weekday] || "";
          rahuNote = (lang==="hi" ? `आज ${wd}वार — राहु काल दिन का ${rk.rahuIndex+1}वाँ भाग (८ में से), ${rk.partDuration.toFixed(2)} घंटे प्रति भाग। सूर्योदय ${fmt(rk.sunrise)} से सूर्यास्त ${fmt(rk.sunset)} तक दिन-मान ${rk.dayLength.toFixed(2)}h।` : lang==="gu" ? `આજે ${wd}વાર — રાહુ કાળ દિવસનો ${rk.rahuIndex+1}મો ભાગ (૮ માંથી), ${rk.partDuration.toFixed(2)} કલાક પ્રતિ ભાગ. સૂર્યોદય ${fmt(rk.sunrise)} થી સૂર્યાસ્ત ${fmt(rk.sunset)} સુધી દિવસ-માન ${rk.dayLength.toFixed(2)}h.` : `Today ${wd} — Rahu Kaal is part ${rk.rahuIndex+1} of 8 (${rk.partDuration.toFixed(2)}h per part). Day-length ${rk.dayLength.toFixed(2)}h from sunrise ${fmt(rk.sunrise)} to sunset ${fmt(rk.sunset)}.`);
        } else {
          rahuStr = lang==="hi" ? "गणना उपलब्ध नहीं" : lang==="gu" ? "ગણતરી ઉપલબ્ધ નથી" : "Not available for polar day/night";
          rahuNote = lang==="hi" ? "ध्रुवीय दिन/रात पर राहु काल पारंपरिक ६-१८ के मानक दिन से लिया जाता है।" : lang==="gu" ? "ધ્રુવીય દિવસ/રાત પર રાહુ કાળ પરંપરાગત ૬-૧૮ ના પ્રમાણભૂત દિવસ પરથી લેવાય છે." : "For polar day/night, Rahu Kaal falls back to a standard 6-18 day.";
        }
        const placeLabel = esc(place.name || (place.lat.toFixed(4)+", "+place.lon.toFixed(4))) + " (UTC"+(tzEff>=0?"+":"")+tzEff+")";
        return `<section class="rsection" id="muhurtha-section" data-muhurtha="ok" data-lat="${place.lat}" data-lon="${place.lon}" data-tz="${tzEff}">
      <h2 class="rsection-title"><span class="idx">${SECTION.timing}b</span>${lang === "hi" ? "आज का मुहूर्त — सूर्योदय / राहु काल (वास्तविक गणना)" : lang === "gu" ? "આજનું મુહૂર્ત — સૂર્યોદય / રાહુ કાળ (વાસ્તવિક ગણતરી)" : "Today's Muhurtha — Sunrise & Rahu Kaal (actual calculation)"}</h2>
      <p class="rsection-desc">${lang === "hi" ? `स्थान ${placeLabel} पर आज ${Y}-${String(M).padStart(2,"0")}-${String(D).padStart(2,"0")} की वास्तविक सूर्य-गणना — दिन-बचत समय और ध्रुवीय दिन/रात सहित। यही गणना घड़ी पहनने के समय और power-day शुभ समय को भी ठीक करती है।` : lang === "gu" ? `સ્થાન ${placeLabel} પર આજે ${Y}-${String(M).padStart(2,"0")}-${String(D).padStart(2,"0")} ની વાસ્તવિક સૂર્ય-ગણતરી — દિવસ-બચત સમય અને ધ્રુવીય દિવસ/રાત સહિત. આ જ ગણતરી ઘડિયાળ પહેરવાના સમય અને power-day શુભ સમયને પણ ઠીક કરે છે.` : `Actual solar calculation for ${Y}-${String(M).padStart(2,"0")}-${String(D).padStart(2,"0")} at ${placeLabel} — daylight-saving and polar-day aware. The same calculation fixes watch wearing time and power-day windows.`}</p>
      <div class="card-grid two">
        <div class="card">
          <div class="card-title">${lang === "hi" ? "सूर्योदय / सूर्यास्त" : lang === "gu" ? "સૂર્યોદય / સૂર્યાસ્ત" : "Sunrise / Sunset"}</div>
          <div class="kit">
            <div class="kit-row"><div class="kit-ico">🌅</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "सूर्योदय" : lang === "gu" ? "સૂર્યોદય" : "Sunrise"}</div><div class="kit-value">${sunriseStr} <span class="card-sub">${ss && ss.sunrise!=null ? fmt24(ss.sunrise) : ""} local</span></div></div></div>
            <div class="kit-row"><div class="kit-ico">🌇</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "सूर्यास्त" : lang === "gu" ? "સૂર્યાસ્ત" : "Sunset"}</div><div class="kit-value">${sunsetStr} <span class="card-sub">${ss && ss.sunset!=null ? fmt24(ss.sunset) : ""} local</span></div></div></div>
            <div class="kit-row"><div class="kit-ico">☀️</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "मध्याह्न / दिन-मान" : lang === "gu" ? "મધ્યાહ્ન / દિવસ-માન" : "Transit / Day-length"}</div><div class="kit-value">${transitStr} / ${dayLenStr}</div></div></div>
          </div>
          <div class="card-sub practitioner-only" data-technical="ephemeris-debug">${lang === "hi" ? "मानक अपवर्तन + सौर त्रिज्या h0=-0.8333° के साथ hour-angle विधि। ध्रुवीय क्षेत्रों में sunrise/sunset null और alwaysDay/alwaysNight flag सेट होता है।" : lang === "gu" ? "પ્રમાણભૂત રીફ્રેક્શન + સૌર ત્રિજ્યા h0=-0.8333° સાથે hour-angle પદ્ધતિ. ધ્રુવીય ક્ષેત્રોમાં sunrise/sunset null અને alwaysDay/alwaysNight flag સેટ થાય છે." : "Hour-angle method with standard refraction + solar radius h0=-0.8333°. Polar regions return null sunrise/sunset with alwaysDay/alwaysNight flags."}</div>
        </div>
        <div class="card">
          <div class="card-title">${lang === "hi" ? "राहु काल (आज)" : lang === "gu" ? "રાહુ કાળ (આજે)" : "Rahu Kaal (today)"}</div>
          <div class="kit">
            <div class="kit-row"><div class="kit-ico">⏳</div><div class="kit-body"><div class="kit-label">Rahu Kaal</div><div class="kit-value">${rahuStr}</div></div></div>
            <div class="kit-row"><div class="kit-ico">📅</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "विवरण" : lang === "gu" ? "વિગત" : "Detail"}</div><div class="kit-value">${rahuNote}</div></div></div>
          </div>
          <div class="card-sub">${lang === "hi" ? "सोम=१, शनि=२, शुक्र=३, बुध=४, गुरु=५, मंगल=६, रवि=७ — दिन को ८ बराबर भागों में बाँटकर। यही मुहूर्त मॉड्यूल की नींव है।" : lang === "gu" ? "સોમ=૧, શનિ=૨, શુક્ર=૩, બુધ=૪, ગુરુ=૫, મંગળ=૬, રવિ=૭ — દિવસને ૮ સરખા ભાગમાં વહેંચીને. આ જ મુહૂર્ત મોડ્યુલનો પાયો છે." : "Mon=1, Sat=2, Fri=3, Wed=4, Thu=5, Tue=6, Sun=7 — day divided into 8 equal parts. Foundation for the Muhurtha module."}</div>
        </div>
      </div>
      ${panchangBlock(astro, place, Y, M, D, tzEff, fmt, lang)}
    </section>`;
      } catch (e) {
        return "";
      }
    })();

    const dashaSection = (function () {
      const dl = dashaTimeline(p);
      const dashaDB = db.dasha || (window.DB && window.DB.dasha) || {};
      if (!dashaDB[1]) return "";
      const planetOf = (n) => esc(db.numbers[n].planet.split(" ")[0]);
      /* Dual-Dasha dilemma fix (2026-09 audit): the two systems used to sit
         side by side with equal visual weight, so a client read "you are in
         Mercury Mahadasha" on one page and "Jupiter Mahadasha" a few pages
         later and took it as a contradiction. The practitioner now picks a
         PRIMARY engine (default: Ank Jyotish); the other engine is cordoned
         off as a collapsed "Advanced Astrological Cross-Reference" appendix
         and the banner below states plainly that two different clocks can
         name two different current lords. */
      const primaryEngine = state.dashaEngine === "vimshottari" ? "vimshottari" : "ank";
      const vTimeline = vimshottariTimeline(p);
      const yearOfMs = (ms) => new Date(ms).getFullYear();
      const cur = dl.current;
      const mdInfo = dashaDB[cur.md.n] || {}, adInfo = dashaDB[cur.ad.n] || {}, pdInfo = dashaDB[cur.pd.n] || {};
      const nowLbl = lang === "hi" ? "वर्तमान" : lang === "gu" ? "હાલમાં" : "Now";
      const agesLbl2 = lang === "hi" ? "आयु" : lang === "gu" ? "ઉંમર" : "Ages";
      /* Mahadasha badge: how the MD lord relates to the native (Driver).
         Antardasha badge: how the AD lord relates to the MD lord that is
         filtering it — the MD × AD sambandha. The AD badge must never be
         judged against Driver/Conductor alone; that produced "Friendly to you"
         on Moon AD inside a Rahu MD, directly contradicting the Grahan Yoga
         synthesis and the Conflicting verdict shown in Compatibility. */
      const relBadgeFor = (n) => {
        const rd = relation(p.driver, n);
        return rd === "friendly" ? `<span class="badge good">${lang === "hi" ? "मित्र ग्रह" : lang === "gu" ? "મિત્ર ગ્રહ" : "Friendly to you"}</span>`
          : rd === "enemy" ? `<span class="badge warn">${lang === "hi" ? "सावधानी काल" : lang === "gu" ? "સાવધાની કાળ" : "Handle with care"}</span>`
          : `<span class="badge info">${lang === "hi" ? "तटस्थ" : lang === "gu" ? "તટસ્થ" : "Neutral"}</span>`;
      };
      const sambandha = getDashaRelationship(cur.md.n, cur.ad.n, p.driver);
      const stackRelation = sambandha.relation;
      const stackBadge = stackRelation === "enemy"
        ? `<span class="badge bad ${sambandha.cssClass}" data-md-ad-relation="enemy" data-sambandha="${sambandha.source}">${lang === "hi" ? `चुनौतीपूर्ण — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}, सावधानी से साधें` : lang === "gu" ? `પડકારજનક — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}, સાવચેતીથી સાધો` : `Challenging — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}: neutralise with care`}</span>`
        : stackRelation === "friendly"
          ? `<span class="badge good ${sambandha.cssClass}" data-md-ad-relation="friendly" data-sambandha="${sambandha.source}">${lang === "hi" ? `सहयोगी — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}` : lang === "gu" ? `સહયોગી — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}` : `Supportive — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)} cooperate`}</span>`
          : `<span class="badge ${sambandha.tone} ${sambandha.cssClass}" data-md-ad-relation="neutral" data-sambandha="${sambandha.source}">${lang === "hi" ? `तटस्थ — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}` : lang === "gu" ? `તટસ્થ — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}` : `Neutral — ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)}`}</span>`;
      const personalRel = relation(p.driver, cur.ad.n);
      const personalNote = lang === "hi"
        ? `(मूलांक ${p.driver} के प्रति ${personalRel === "friendly" ? "मित्र" : personalRel === "enemy" ? "शत्रु" : "सम"}, पर सक्रिय संबंध महादशा × अंतर्दशा का है)`
        : lang === "gu"
          ? `(મૂળાંક ${p.driver} પ્રત્યે ${personalRel === "friendly" ? "મિત્ર" : personalRel === "enemy" ? "શત્રુ" : "સમ"}, પણ સક્રિય સંબંધ મહાદશા × અંતર્દશાનો છે)`
          : `(${personalRel === "friendly" ? "friendly" : personalRel === "enemy" ? "hostile" : "neutral"} to your Driver ${p.driver} in isolation — but the operative relationship is MD × AD)`;

      /* ---- Rolling 90-day micro-forecast: the Pratyantar roadmap ---- */
      const upcoming = dl.upcoming || [];
      const nextPd = upcoming.find((u) => !u.current) || null;
      const focusOf = (n) => {
        const info = dashaDB[n] || {};
        // "Operating focus" = the classical event set, trimmed to a short clause.
        const ev = String(loc(info.events, lang) || "");
        const parts = ev.split(/,\s*/).slice(0, 3);
        return esc(parts.join(", "));
      };
      const microActionOf = (n) => {
        const info = dashaDB[n] || {};
        const zone = tidyText(loc(info.zone, lang));
        /* Clause-per-line. One long wrapped sentence is both slower to scan and
           where a PDF line-wrap can strand a hyphen (a wrapped "clutter-free;"
           extracts as "clutterfree-;"), so each remedy clause prints as its own
           bullet with its own full stop. */
        const clauses = String(loc(info.zoneRemedy, lang)).split(/;\s*/).filter(Boolean)
          .map((clause) => `<li>${esc(sentenceClause(clause))}</li>`)
          .join("");
        return `<strong>${esc(zone)}</strong><ul class="micro-action-list micro-forecast-list">${clauses}</ul>`;
      };
      const rangeLabel = (u, i) => {
        const from = i === 0 && u.current ? (lang === "hi" ? "अभी" : lang === "gu" ? "હમણાં" : "Now") : prettyDate(u.startMs);
        return `${from} → ${prettyDate(u.endMs)}`;
      };
      // Always show the table through the first Antardasha hand-over (plus one
      // row after it) so the reader sees what takes over; compress the rest.
      const adChangeIdx = upcoming.findIndex((u) => u.adChange);
      const MICRO_ROW_CAP = Math.min(8, Math.max(4, adChangeIdx >= 0 ? adChangeIdx + 2 : 4));
      const shownUpcoming = upcoming.slice(0, MICRO_ROW_CAP);
      const overflowUpcoming = upcoming.slice(MICRO_ROW_CAP);
      const overflowLine = overflowUpcoming.length
        ? `<div class="card-sub micro-forecast-overflow">${lang === "hi" ? "फिर:" : lang === "gu" ? "પછી:" : "Then:"} ${overflowUpcoming.map((u) => `${planetOf(u.n)} (${u.n}) ${prettyDate(u.startMs)} → ${prettyDate(u.endMs)}${u.adChange ? ` [${lang === "hi" ? "नई अंतर्दशा" : lang === "gu" ? "નવી અંતર્દશા" : "new AD"} ${u.adN}]` : ""}`).join(" · ")}</div>`
        : "";
      const microRows = shownUpcoming.map((u, i) => {
        const adTag = u.adChange
          ? ` <span class="badge ${getDashaRelationship(u.mdN, u.adN, p.driver).relation === "enemy" ? "warn" : "info"}">${lang === "hi" ? `नई अंतर्दशा ${u.adN}` : lang === "gu" ? `નવી અંતર્દશા ${u.adN}` : `New AD ${u.adN} · ${planetOf(u.adN)}`}</span>`
          : "";
        // The Pratyantar sits inside its Antardasha exactly as the AD sits
        // inside the MD — judge it by the same Sambhandha rules.
        const rel = getDashaRelationship(u.adN, u.n, p.driver).relation;
        const relTag = rel === "enemy" ? ` <span class="badge bad">${lang === "hi" ? "टकराव" : lang === "gu" ? "ટકરાવ" : "Friction with AD"}</span>` : "";
        return `<tr${u.current ? ' class="hl-row"' : ""} data-micro-period="${u.n}">
          <td><strong>${rangeLabel(u, i)}</strong>${u.current ? ` <span class="badge good">${nowLbl}</span>` : ""}${adTag}</td>
          <td><strong>${planetOf(u.n)} (${u.n})</strong>${relTag}<div class="card-sub">${lang === "hi" ? "महादशा" : lang === "gu" ? "મહાદશા" : "MD"} ${u.mdN} · ${lang === "hi" ? "अंतर्दशा" : lang === "gu" ? "અંતર્દશા" : "AD"} ${u.adN}</div></td>
          <td>${focusOf(u.n)}<div class="card-sub"><em>${esc(loc((dashaDB[u.n] || {}).caution, lang))}</em></div></td>
          <td>${microActionOf(u.n)}</td>
        </tr>`;
      }).join("");
      const microForecastCard = upcoming.length ? `<div class="card dasha-micro-forecast" data-predictive-layer="pratyantar-roadmap">
        <div class="goal-head">
          <div class="card-title">${lang === "hi" ? "अगले ९० दिन — प्रत्यंतर सूक्ष्म-पूर्वानुमान" : lang === "gu" ? "આગામી ૯૦ દિવસ — પ્રત્યંતર સૂક્ષ્મ-આગાહી" : "Next 90 Days — Pratyantar Micro-Forecast"}</div>
          <span class="badge info">${lang === "hi" ? "आगे की दृश्यता" : lang === "gu" ? "આગળની દૃશ્યતા" : "Forward visibility"}</span>
        </div>
        <div class="card-sub">${lang === "hi" ? `वर्तमान प्रत्यंतर के बाद कौन-सी ऊर्जा संभालती है — ${prettyDate(cur.pd.endMs)} के बाद का रोडमैप।` : lang === "gu" ? `વર્તમાન પ્રત્યંતર પછી કઈ ઊર્જા સંભાળે છે — ${prettyDate(cur.pd.endMs)} પછીનો રોડમેપ.` : `What takes over after the current Pratyantar ends on ${prettyDate(cur.pd.endMs)} — each shift, its operating focus and the one Vastu micro-action to make.`}</div>
        <div class="table-scroll"><table class="rtable micro-forecast-table">
          <tr><th>${lang === "hi" ? "अवधि" : lang === "gu" ? "સમયગાળો" : "Period dates"}</th><th>${lang === "hi" ? "उप-स्वामी" : lang === "gu" ? "ઉપ-સ્વામી" : "Sub-lord"}</th><th>${lang === "hi" ? "कार्य-केंद्र" : lang === "gu" ? "કાર્ય-કેન્દ્ર" : "Operating focus"}</th><th>${lang === "hi" ? "वास्तु सूक्ष्म-क्रिया" : lang === "gu" ? "વાસ્તુ સૂક્ષ્મ-ક્રિયા" : "Vastu micro-action"}</th></tr>
          ${microRows}
        </table></div>
        ${overflowLine}
        ${cur.nextAd ? `<div class="kit-value next-antardasha" data-next-antardasha="${cur.nextAd.n}"><strong>${lang === "hi" ? "अगली अंतर्दशा:" : lang === "gu" ? "આગામી અંતર્દશા:" : "Next Antardasha:"}</strong> ${planetOf(cur.nextAd.n)} (${cur.nextAd.n}) ${lang === "hi" ? "से" : lang === "gu" ? "થી" : "from"} ${prettyDate(cur.nextAd.startMs)} → ${prettyDate(cur.nextAd.endMs)}${cur.nextAd.mdN !== cur.md.n ? ` — ${lang === "hi" ? `नई महादशा ${cur.nextAd.mdN} (${planetOf(cur.nextAd.mdN)}) के साथ` : lang === "gu" ? `નવી મહાદશા ${cur.nextAd.mdN} (${planetOf(cur.nextAd.mdN)}) સાથે` : `opening the new Mahadasha ${cur.nextAd.mdN} (${planetOf(cur.nextAd.mdN)})`}` : ""}. ${esc(loc((dashaDB[cur.nextAd.n] || {}).theme, lang))}</div>` : ""}
      </div>` : "";

      /* ---- Personal Year × Dasha transit synthesis ---- */
      const py = cur.personalYear;
      const pyMeaning = (db.personalYear && db.personalYear[py]) || (window.DB && window.DB.personalYear && window.DB.personalYear[py]) || "";
      const pyRelMd = relation(cur.md.n, py), pyRelAd = relation(cur.ad.n, py);
      const pyAlignment = (pyRelMd === "enemy" || pyRelAd === "enemy") ? "friction" : (pyRelMd === "friendly" && pyRelAd === "friendly") ? "aligned" : "mixed";
      const nextAdRelPy = cur.nextAd ? relation(cur.nextAd.n, py) : null;
      const nextAdRelMd = cur.nextAd ? relation(cur.nextAd.mdN, cur.nextAd.n) : null;
      // The next sub-period is a better window when its lord no longer fights
      // its own Mahadasha lord (the stack stops being hostile). Whether it also
      // befriends the Personal-Year number decides how strongly we phrase it.
      const postWindowBetter = !!cur.nextAd && nextAdRelMd !== "enemy";
      const postWindowHarmonious = postWindowBetter && nextAdRelPy !== "enemy";
      const pyThemeShort = esc(String(pyMeaning).split(" — ")[0] || "");
      const grahan = sambandha.grahan;
      const synthesisEn = (function () {
        const opening = `${cur.year} carries an overarching focus on ${pyThemeShort.toLowerCase()} (Personal Year ${py} · ${planetOf(py)}).`;
        const stack = `Until ${prettyDate(cur.ad.endMs)} the ${planetOf(cur.md.n)}–${planetOf(cur.ad.n)} stack (MD ${cur.md.n} · AD ${cur.ad.n}) is the engine that year runs through`;
        const climate = stackRelation === "enemy"
          ? `${stack} — and because those two lords ${grahan ? "form the eclipse (Grahan) axis" : "are mutually hostile"}, expect ${grahan ? "emotional second-guessing, disturbed sleep and sudden expenses" : "delays, second-guessing and friction around exactly the Personal-Year themes"}.`
          : stackRelation === "friendly"
            ? `${stack} — the lords cooperate, so the Personal-Year themes can be acted on directly.`
            : `${stack} — a neutral pairing: the Personal-Year themes advance steadily rather than dramatically.`;
        const verdict = stackRelation === "enemy"
          ? (postWindowBetter
              ? `Defer the biggest Personal-Year commitments (${py === 6 ? "relationship commitments, home purchases, large comfort spending" : py === 3 ? "expansion capital, teaching or advisory launches" : py === 8 ? "career restructuring, property paperwork" : py === 9 ? "property closures and confrontations" : py === 1 ? "solo launches and public declarations" : "the irreversible decisions in this theme"}) until ${planetOf(cur.nextAd.n)} AD opens on ${prettyDate(cur.nextAd.startMs)}${postWindowHarmonious ? ", when the transit and the Dasha align harmoniously." : `, when the eclipse pressure lifts and the stack turns ${nextAdRelMd === "friendly" ? "supportive" : "neutral"}. ${planetOf(cur.nextAd.n)} does not favour ${planetOf(py)} themes outright, so move with structure and written terms rather than impulse.`}`
              : `Take the Personal-Year themes in small, reversible steps until the ${planetOf(cur.ad.n)} sub-period closes on ${prettyDate(cur.ad.endMs)}.`)
          : (pyAlignment === "friction"
              ? `The Personal-Year number ${py} itself sits uneasily with the active lords — keep its themes practical and avoid over-reaching before ${prettyDate(cur.ad.endMs)}.`
              : `Transit and Dasha point the same way — this is a window to act on the Personal-Year themes with confidence.`);
        return `${opening} ${climate} ${verdict}`;
      })();
      const synthesisHi = `${cur.year} का व्यक्तिगत वर्ष ${py} (${planetOf(py)}) — ${esc(pyMeaning)} ${prettyDate(cur.ad.endMs)} तक ${planetOf(cur.md.n)}–${planetOf(cur.ad.n)} दशा-क्रम (महादशा ${cur.md.n} · अंतर्दशा ${cur.ad.n}) ही वह इंजन है जिससे यह वर्ष चलता है${stackRelation === "enemy" ? ` — दोनों स्वामी परस्पर विरोधी हैं, इसलिए भावनात्मक दुविधा और अचानक खर्च संभव हैं। बड़े निर्णय ${cur.nextAd ? `${prettyDate(cur.nextAd.startMs)} (${planetOf(cur.nextAd.n)} अंतर्दशा) के बाद` : "इस उप-काल के बाद"} लें।` : "।"}`;
      const synthesisGu = `${cur.year} નું વ્યક્તિગત વર્ષ ${py} (${planetOf(py)}) — ${esc(pyMeaning)} ${prettyDate(cur.ad.endMs)} સુધી ${planetOf(cur.md.n)}–${planetOf(cur.ad.n)} દશા-ક્રમ (મહાદશા ${cur.md.n} · અંતર્દશા ${cur.ad.n}) એ જ એન્જિન છે જેનાથી આ વર્ષ ચાલે છે${stackRelation === "enemy" ? ` — બંને સ્વામી પરસ્પર વિરોધી છે, તેથી ભાવનાત્મક દ્વિધા અને અચાનક ખર્ચ શક્ય છે. મોટા નિર્ણયો ${cur.nextAd ? `${prettyDate(cur.nextAd.startMs)} (${planetOf(cur.nextAd.n)} અંતર્દશા) પછી` : "આ ઉપ-કાળ પછી"} લો.` : "."}`;
      const transitSynthesisCard = `<div class="card dasha-transit-synthesis" data-predictive-layer="personal-year-transit" data-personal-year="${py}" data-alignment="${pyAlignment}">
        <div class="goal-head">
          <div class="card-title">${lang === "hi" ? `वार्षिक ट्रांज़िट × दशा — ${cur.year} का संश्लेषण` : lang === "gu" ? `વાર્ષિક ટ્રાન્ઝિટ × દશા — ${cur.year} નું સંશ્લેષણ` : `Annual Transit × Dasha — the ${cur.year} synthesis`}</div>
          <span class="badge ${stackRelation === "enemy" ? "warn" : pyAlignment === "aligned" ? "good" : "info"}">${lang === "hi" ? `व्यक्तिगत वर्ष ${py}` : lang === "gu" ? `વ્યક્તિગત વર્ષ ${py}` : `Personal Year ${py} · ${planetOf(py)}`}</span>
        </div>
        <div class="kit-value">${lang === "hi" ? synthesisHi : lang === "gu" ? synthesisGu : synthesisEn}</div>
        ${isMinorProfile(p) && stackRelation === "enemy" ? `<div class="kit-value student-stack-note" data-student-stack-note="true"><strong>${lang === "hi" ? `विद्यार्थी दृष्टि (आयु ${p.ageYears}):` : lang === "gu" ? `વિદ્યાર્થી દૃષ્ટિ (ઉંમર ${p.ageYears}):` : `Student lens (age ${p.ageYears}):`}</strong> ${lang === "hi"
          ? `${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)} जैसा परस्पर-शत्रु क्रम विद्यालय और घर में प्रायः नियम व अधिकार (${planetOf(cur.md.n)}) बनाम निजी स्वतंत्रता की ललक (${planetOf(cur.ad.n)}) के रूप में दिखता है। हर शैक्षणिक बदलाव छोटे, उलटने योग्य कदमों में रखें; गर्मी को खेल और शारीरिक गति में ढालें; अभिभावक ढांचा थोपें नहीं — बातचीत से तय करें। उपरोक्त सलाह — छोटे, उलटने योग्य कदम और क्रोध को शांत रखना — ${prettyDate(cur.ad.endMs)} को ${planetOf(cur.ad.n)} उप-काल बंद होने तक समयोचित है।`
          : lang === "gu"
            ? `${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)} જેવો પરસ્પર-શત્રુ ક્રમ શાળા અને ઘરે સામાન્યતઃ નિયમો-સત્તા (${planetOf(cur.md.n)}) વિરુદ્ધ અંગત સ્વતંત્રતાની ઝુંબેશ (${planetOf(cur.ad.n)}) તરીકે દેખાય છે. દરેક શૈક્ષણિક ફેરફાર નાના, પછી ફેરવી શકાય એવા પગલાંઓમાં રાખો; ગરમીને રમતગમત અને શારીરિક ગતિમાં ઢાળો; વાલી માળખું ઠલવે નહીં — વાતચીતથી નક્કી કરે. ઉપરની સલાહ — નાના, પછી ફેરવી શકાય એવા પગલાં અને ગુસ્સો શાંત રાખવો — ${prettyDate(cur.ad.endMs)} એ ${planetOf(cur.ad.n)} ઉપ-કાળ પૂરો થાય ત્યાં સુધી સમયોચિત છે.`
            : `a mutual-enemy stack like ${planetOf(cur.md.n)} × ${planetOf(cur.ad.n)} usually plays out at school and at home as friction between rules and authority (${planetOf(cur.md.n)}) and the pull for personal independence (${planetOf(cur.ad.n)}). Keep every academic transition in small, reversible steps, channel the heat into sport and movement, and let parents negotiate structure rather than impose it. The guidance above — small, reversible steps and a cooled temper — is timely until the ${planetOf(cur.ad.n)} sub-period closes on ${prettyDate(cur.ad.endMs)}.`}</div>` : ""}
        <div class="card-sub">${lang === "hi" ? "व्यक्तिगत वर्ष वार्षिक ट्रांज़िट-इंजन है; दशा तय करती है कि वह ऊर्जा कब और किस रूप में फलित होती है। तिथियां केवल दशा से आती हैं।" : lang === "gu" ? "વ્યક્તિગત વર્ષ વાર્ષિक ટ્રાન્ઝિટ-એન્જિન છે; દશા નક્કી કરે છે કે તે ઊર્જા ક્યારે અને કયા રૂપે ફળે છે. તારીખો ફક્ત દશાથી આવે છે." : "Personal Year is the annual transit engine; the Dasha decides when and in what form that energy converts. All dates above come from the Dasha alone."}</div>
      </div>`;

      const stackCard = `<div class="card">
        <div class="goal-head">
          <div class="card-title">${lang === "hi" ? "आपका सक्रिय दशा-क्रम" : lang === "gu" ? "તમારો સક્રિય દશા-ક્રમ" : "Your Active Dasha Stack"}</div>
          <span class="badge info">${lang === "hi" ? "शास्त्रीय आनुपातिक (४५-वर्ष)" : lang === "gu" ? "શાસ્ત્રીય પ્રમાણસર (૪૫-વર્ષ)" : "Classical Proportional (45-Yr)"}</span>
        </div>
        <div class="card-grid" style="margin-top:10px">
          <div class="card num-card">
            <div class="num-value">${cur.md.n}</div>
            <div class="num-label">${lang === "hi" ? "महादशा" : lang === "gu" ? "મહાદશા" : "Mahadasha"} · ${planetOf(cur.md.n)}</div>
            <div class="num-sub">${yearOfMs(cur.md.startMs)}–${yearOfMs(cur.md.endMs)} (${agesLbl2} ${cur.md.fromAge}–${cur.md.toAge}) ${relBadgeFor(cur.md.n)}</div>
          </div>
          <div class="card num-card">
            <div class="num-value alt">${cur.ad.n}</div>
            <div class="num-label">${lang === "hi" ? "अंतर्दशा" : lang === "gu" ? "અંતર્દશા" : "Antardasha"} · ${planetOf(cur.ad.n)}</div>
            <div class="num-sub">${prettyDate(cur.ad.startMs)} → ${prettyDate(cur.ad.endMs)}</div>
            <div class="num-sub" data-stack-badge="md-ad">${stackBadge}</div>
            <div class="num-sub stack-badge-note">${personalNote}</div>
            ${lang === "en" ? `<div class="num-sub stack-badge-guidance" data-sambandha-guidance="${sambandha.source}">${esc(sambandha.guidance)}</div>` : ""}
            <div class="progress-track" role="progressbar" aria-valuenow="${cur.adProgress}" aria-valuemin="0" aria-valuemax="100"><div class="progress-fill" style="width:${cur.adProgress}%"></div></div>
            <div class="num-sub">${cur.adProgress}% ${lang === "hi" ? "पूर्ण" : lang === "gu" ? "પૂર્ણ" : "elapsed"}</div>
          </div>
          <div class="card num-card">
            <div class="num-value" style="font-size:26px">${cur.pd.n}</div>
            <div class="num-label">${lang === "hi" ? "प्रत्यंतर दशा" : lang === "gu" ? "પ્રત્યંતર દશા" : "Pratyantar Dasha"} · ${planetOf(cur.pd.n)}</div>
            <div class="num-sub">${cur.pdDaysLeft} ${lang === "hi" ? "दिन शेष" : lang === "gu" ? "દિવસ બાકી" : "days remaining"} (${lang === "hi" ? "तक" : lang === "gu" ? "સુધી" : "until"} ${prettyDate(cur.pd.endMs)})</div>
            ${nextPd ? `<div class="num-sub next-horizon" data-next-pratyantar="${nextPd.n}">${lang === "hi" ? `आगे: ${planetOf(nextPd.n)} (${nextPd.n}) ${prettyDate(nextPd.startMs)} से` : lang === "gu" ? `આગળ: ${planetOf(nextPd.n)} (${nextPd.n}) ${prettyDate(nextPd.startMs)} થી` : `Next: ${planetOf(nextPd.n)} (${nextPd.n}) takes over from ${prettyDate(nextPd.startMs)}`}</div>` : ""}
          </div>
        </div>
        <div class="kit-value"><strong>${lang === "hi" ? `इस काल का स्वर — महादशा ${cur.md.n} (${planetOf(cur.md.n)}):` : lang === "gu" ? `આ સમયગાળાનો સૂર — મહાદશા ${cur.md.n} (${planetOf(cur.md.n)}):` : `The tone of this chapter — Mahadasha ${cur.md.n} (${planetOf(cur.md.n)}):`}</strong> ${esc(loc(mdInfo.theme, lang))}</div>
        <div class="kit-value"><strong>${lang === "hi" ? `इस वर्ष की धारा — अंतर्दशा ${cur.ad.n} (${planetOf(cur.ad.n)}):` : lang === "gu" ? `આ વર્ષની ધારા — અંતર્દશા ${cur.ad.n} (${planetOf(cur.ad.n)}):` : `The current within it — Antardasha ${cur.ad.n} (${planetOf(cur.ad.n)}):`}</strong> ${esc(loc(adInfo.events, lang))}. <em>${esc(loc(adInfo.caution, lang))}</em></div>
        <div class="kit-row" data-dasha-vastu-zone="active" data-authority="dasha-vastu-zone"><div class="kit-ico">🧭</div><div class="kit-body">
          <div class="kit-label">${lang === "hi" ? "सक्रिय वास्तु क्षेत्र: इस उप-काल में इसे साधें" : lang === "gu" ? "સક્રિય વાસ્તુ ક્ષેત્ર: આ ઉપ-કાળમાં આને સાધો" : "Active Vastu Zone: Prioritise this sector now"}</div>
          <div class="kit-value">${lang === "hi" ? `आपके वर्तमान उप-स्वामी <strong>${planetOf(cur.ad.n)} (अंतर्दशा ${cur.ad.n})</strong> का क्षेत्र <strong>${esc(loc(adInfo.zone, lang))}</strong> (${esc(adInfo.zoneElement || "")}) है। ${esc(loc(adInfo.zoneRemedy, lang))}` : lang === "gu" ? `તમારા વર્તમાન ઉપ-સ્વામી <strong>${planetOf(cur.ad.n)} (અંતર્દશા ${cur.ad.n})</strong> નું ક્ષેત્ર <strong>${esc(loc(adInfo.zone, lang))}</strong> (${esc(adInfo.zoneElement || "")}) છે. ${esc(loc(adInfo.zoneRemedy, lang))}` : `Your current sub-ruler is <strong>${planetOf(cur.ad.n)} (AD ${cur.ad.n})</strong> — its sector is the <strong>${esc(loc(adInfo.zone, lang))}</strong> (${esc(adInfo.zoneElement || "")}). ${esc(loc(adInfo.zoneRemedy, lang))}`}</div>
          <div class="kit-value">${lang === "hi" ? `सूक्ष्म-काल के लिए: प्रत्यंतर स्वामी ${planetOf(cur.pd.n)} — ${esc(loc(pdInfo.zone, lang))} को भी स्वच्छ रखें।` : lang === "gu" ? `સૂક્ષ્મ-કાળ માટે: પ્રત્યંતર સ્વામી ${planetOf(cur.pd.n)} — ${esc(loc(pdInfo.zone, lang))} ને પણ સ્વચ્છ રાખો.` : `For the micro-period: Pratyantar lord ${planetOf(cur.pd.n)} — also keep the ${esc(loc(pdInfo.zone, lang))} clean and serviced.`}</div>
          <div class="kit-value" data-dual-zone="${cur.ad.n}-${cur.md.n}"><strong>${lang === "hi" ? "द्वि-क्षेत्र वास्तु युग्म:" : lang === "gu" ? "દ્વિ-ક્ષેત્ર વાસ્તુ જોડી:" : "Dual-Zone Vastu pairing:"}</strong> ${lang === "hi" ? `प्राथमिक उप-क्षेत्र (${planetOf(cur.ad.n)}): ${esc(loc(adInfo.zone, lang))} — ${esc(loc(adInfo.zoneRemedy, lang))} स्थिरक क्षेत्र (${planetOf(cur.md.n)}): ${esc(loc(mdInfo.zone, lang))} — ${esc(loc(mdInfo.zoneRemedy, lang))}` : lang === "gu" ? `પ્રાથમિક ઉપ-ક્ષેત્ર (${planetOf(cur.ad.n)}): ${esc(loc(adInfo.zone, lang))} — ${esc(loc(adInfo.zoneRemedy, lang))} સ્થિરક ક્ષેત્ર (${planetOf(cur.md.n)}): ${esc(loc(mdInfo.zone, lang))} — ${esc(loc(mdInfo.zoneRemedy, lang))}` : `Primary Sub-Zone (${planetOf(cur.ad.n)}, AD ${cur.ad.n}): <strong>${esc(loc(adInfo.zone, lang))}</strong> — ${esc(loc(adInfo.zoneRemedy, lang))} Anchor Stabilizer (${planetOf(cur.md.n)}, MD ${cur.md.n}): <strong>${esc(loc(mdInfo.zone, lang))}</strong> — ${esc(loc(mdInfo.zoneRemedy, lang))}${stackRelation === "enemy" ? " Because the two lords are in conflict, the anchor zone matters as much as the primary one — ground it first." : ""}`}</div>
        </div></div>
      </div>`;

      const relWord = stackRelation === "enemy" ? "Conflicting" : stackRelation === "friendly" ? "Harmonious" : "Neutral";
      const pairSynthesis = grahan
        ? `<div class="card predictive-synthesis" data-predictive-layer="md-ad-sambhandha" data-md-ad-relation="${stackRelation}"><div class="goal-head"><div class="card-title">Vedic Predictive Synthesis — Grahan Yoga</div><span class="badge bad">${relWord} · ${cur.md.n} × ${cur.ad.n}</span></div><div class="kit-value"><strong>Current Stack:</strong> ${planetOf(cur.md.n)} MD (${cur.md.n}) + ${planetOf(cur.ad.n)} AD (${cur.ad.n}) — the eclipse axis. This is the same Conflicting relationship shown for ${cur.md.n} × ${cur.ad.n} in the Compatibility section; the Antardasha badge above reflects it.</div><div class="kit-value">Rahu amplifies ambition and unconventional moves, but filtered through Moon's emotional lens it can produce mental restlessness, sleep volatility, vivid dreams and sudden emotional decisions.</div><div class="kit-value"><strong>Predictive Guidance:</strong> Avoid signing long-term partnership contracts during the final degrees of this sub-period (it closes ${prettyDate(cur.ad.endMs)}); channel emotional intensity into creative, technical or research output.${cur.nextAd ? ` The pressure lifts when ${planetOf(cur.nextAd.n)} AD (${cur.nextAd.n}) opens on ${prettyDate(cur.nextAd.startMs)}.` : ""}</div></div>`
        : `<div class="card predictive-synthesis" data-predictive-layer="md-ad-sambhandha" data-md-ad-relation="${stackRelation}"><div class="goal-head"><div class="card-title">Vedic Predictive Synthesis — MD × AD</div><span class="badge ${stackRelation === "enemy" ? "bad" : stackRelation === "friendly" ? "good" : "info"}">${relWord} · ${cur.md.n} × ${cur.ad.n}</span></div><div class="kit-value"><strong>Current Stack:</strong> ${planetOf(cur.md.n)} MD (${cur.md.n}) + ${planetOf(cur.ad.n)} AD (${cur.ad.n}).</div><div class="kit-value">${stackRelation === "enemy"
            ? `The Mahadasha lord and the Antardasha lord are mutually hostile, so the ${planetOf(cur.ad.n)} themes (${esc(loc(adInfo.events, lang))}) arrive with friction: expect delays, second-guessing and the need to neutralise rather than force. ${esc(loc(adInfo.caution, lang))}`
            : stackRelation === "friendly"
              ? `The two lords cooperate: the ${planetOf(cur.md.n)} climate actively supports the ${planetOf(cur.ad.n)} themes (${esc(loc(adInfo.events, lang))}). Act on them directly.`
              : `A neutral pairing: the Mahadasha sets the macro climate and the Antardasha filters it into the immediate emotional and practical decisions without either amplifying or blocking the other.`}</div></div>`;

      /* ---- Classical Vimshottari card (separate Vedic tradition) ----------
         Rendered beside — never inside — the Ank Jyotish roadmap so the two
         clocks stay visibly independent. Carries its own authority tag and
         deliberately holds no remedy/zone content: the Classical layer is a
         timing read-out only. */
      const vimshottariCard = (function () {
        const v = vTimeline;
        if (!v) {
          return `<div class="card vimshottari-card" data-authority="vimshottari" data-vimshottari="unavailable">
        <div class="goal-head"><div class="card-title">${t("vimshottariTitle", "Classical Vimshottari Dasha — Moon-Nakshatra Anchored")}</div><span class="badge info">${t("vimshottariKicker", "Vedic · nakshatra-anchored · fixed 120-year cycle")}</span></div>
        <div class="kit-value">${t("vimshottariNoTime", "")}</div>
      </div>`;
        }
        const fmtD = (ms) => new Date(ms).toLocaleDateString(lang === "hi" ? "hi-IN" : lang === "gu" ? "gu-IN" : "en-GB", { day: "2-digit", month: "short", year: "numeric" });
        // The Ank Jyotish lord name lives on db.numbers, not on the dasha
        // period entry, so read it from the same source planetOf() uses.
        const ankLordOf = (n) => String(((db.numbers || {})[n] || {}).planet || "").split(" ")[0];
        const ankMdLord = ankLordOf(cur.md.n);
        const agree = ankMdLord && ankMdLord.toLowerCase() === v.current.md.lord.toLowerCase();
        const vmd = v.current.md, vad = v.current.ad, vpd = v.current.pd;
        const stackRow = (labelKey, fallback, seg) => `<tr>
          <td><strong>${t(labelKey, fallback)}</strong></td>
          <td>${esc(seg.lord)} <span class="card-sub">(${seg.n})</span></td>
          <td>${fmtD(seg.startMs)} → ${fmtD(seg.endMs)}</td>
          <td>${t("vimshottariAge", "Ages")} ${seg.fromAge}–${seg.toAge}</td>
        </tr>`;
        return `<div class="card vimshottari-card" data-authority="vimshottari" data-vimshottari="available" data-vimshottari-md="${esc(vmd.lord)}" data-vimshottari-ad="${esc(vad.lord)}" data-vimshottari-agrees="${agree ? "yes" : "no"}">
        <div class="goal-head">
          <div class="card-title">${t("vimshottariTitle", "Classical Vimshottari Dasha — Moon-Nakshatra Anchored")}</div>
          <span class="badge info">${t("vimshottariKicker", "Vedic · nakshatra-anchored · fixed 120-year cycle")}</span>
        </div>
        <div class="kit-value">${t("vimshottariIntro", "")}</div>
        <div class="kit-value vimshottari-anchor">
          <strong>${t("vimshottariAnchorLabel", "Anchor")}:</strong> ${esc(v.anchor.nakshatra)} · pada ${v.anchor.pada} · ${esc(v.anchor.lord)} ·
          ${esc(v.anchor.moonSign)} ${esc(v.anchor.moonDeg)} (${esc(v.anchor.span)}) · ${v.anchor.elapsedPct}% ${t("vimshottariElapsed", "elapsed")}
        </div>
        <div class="kit-value">
          <strong>${t("vimshottariBalanceLabel", "Balance of the birth lord at birth")}:</strong> ${v.balanceYears} ${lang === "hi" ? "वर्ष" : lang === "gu" ? "વર્ષ" : "years"} ${esc(v.anchor.lord)}
          <div class="card-sub">${t("vimshottariBalanceNote", "")}</div>
        </div>
        <div class="card-title vimshottari-subhead">${t("vimshottariCurrentTitle", "Active Vimshottari stack")}</div>
        <div class="table-scroll"><table class="rtable">
          <tr><th>${lang === "hi" ? "स्तर" : lang === "gu" ? "સ્તર" : "Level"}</th><th>${lang === "hi" ? "ग्रह" : lang === "gu" ? "ગ્રહ" : "Lord"}</th><th>${lang === "hi" ? "अवधि" : lang === "gu" ? "અવધિ" : "Period"}</th><th>${t("vimshottariAge", "Ages")}</th></tr>
          ${stackRow("vimshottariMD", "Mahadasha", vmd)}
          ${stackRow("vimshottariAD", "Antardasha", vad)}
          ${stackRow("vimshottariPD", "Pratyantar", vpd)}
        </table></div>
        <div class="kit-value vimshottari-progress"><strong>${v.adProgress}%</strong> ${t("vimshottariElapsed", "elapsed")} · ${esc(vad.lord)} ${t("vimshottariAD", "Antardasha")}</div>
        <div class="card-title vimshottari-subhead">${t("vimshottariLadderTitle", "Mahadasha ladder (fixed 120-year cycle)")}</div>
        <div class="table-scroll"><table class="rtable">
          <tr><th>${t("vimshottariMD", "Mahadasha")}</th><th>${t("vimshottariAge", "Ages")}</th><th>${lang === "hi" ? "वर्ष" : lang === "gu" ? "વર્ષ" : "Years"}</th></tr>
          ${v.mahadashas.map((m) => `<tr${m.current ? ' class="hl-row"' : ""}>
            <td><strong>${esc(m.lord)}</strong> <span class="card-sub">(${m.n})</span>${m.current ? ` <span class="badge info">${nowLbl}</span>` : ""}${m.balance ? ` <span class="badge warn">${t("vimshottariBalanceTag", "balance carried from birth")}</span>` : ""}</td>
            <td>${t("vimshottariAge", "Ages")} ${m.fromAge}–${m.toAge} <span class="card-sub">(${new Date(m.startMs).getFullYear()}–${new Date(m.endMs).getFullYear()})</span></td>
            <td>${m.years.toFixed(3)}</td>
          </tr>`).join("")}
        </table></div>
        <div class="card-title vimshottari-subhead">${t("vimshottariCompareTitle", "Why this differs from the Ank Jyotish roadmap")}</div>
        <div class="kit-value" data-vimshottari-comparison="${agree ? "agree" : "differ"}">${agree
          ? t("vimshottariCompareAgree", "")
          : `${t("vimshottariCompareDiffer", "")} <strong>Ank Jyotish: ${esc(ankMdLord ? `${ankMdLord} (${cur.md.n})` : String(cur.md.n))} · Vimshottari: ${esc(vmd.lord)} (${vmd.n}).</strong>`}</div>
        <div class="card-sub">${t("vimshottariBoundary", "")}</div>
      </div>`;
      })();

      const ladderCard = `<div class="card">
        <div class="card-title">${lang === "hi" ? "जीवन-भर की महादशा सीढ़ी" : lang === "gu" ? "જીવનભરની મહાદશા સીડી" : "Lifetime Mahadasha Ladder"}</div>
        <div class="card-sub">${t("dashaLadderNote", "The ladder is computed well past the 80-year average-lifespan horizon so every life-event band — including wealth & business till 75 — stays covered for the whole of life.")}</div>
        <div class="table-scroll"><table class="rtable">
          <tr><th>${lang === "hi" ? "महादशा" : lang === "gu" ? "મહાદશા" : "Mahadasha"}</th><th>${lang === "hi" ? "आयु व वर्ष" : lang === "gu" ? "ઉંમર અને વર્ષ" : "Ages & Years"}</th><th>${lang === "hi" ? "काल का विषय" : lang === "gu" ? "કાળનો વિષય" : "Theme of the period"}</th></tr>
          ${dl.mahadashas.map((m) => {
            const info = dashaDB[m.n] || {};
            return `<tr${m.current ? ' class="hl-row"' : ""}>
              <td><strong>${m.n}</strong> · ${planetOf(m.n)}${m.current ? ` <span class="badge info">${nowLbl}</span>` : ""}</td>
              <td>${agesLbl2} ${m.fromAge}–${m.toAge} <span class="card-sub">(${yearOfMs(m.startMs)}–${yearOfMs(m.endMs)})</span></td>
              <td>${esc(loc(info.theme, lang))}</td>
            </tr>`;
          }).join("")}
        </table></div>
      </div>`;

      const eventRows = dl.events.map((e) => {
        const lbl = esc(loc(e.def.label, lang));
        const windows = e.future.length
          ? e.future.map((w) => {
              const badge = w.active ? ` <span class="badge good">${lang === "hi" ? "अभी सक्रिय" : lang === "gu" ? "હમણાં સક્રિય" : "Active now"}</span>` : "";
              const conv = w.conversion || natalConversion(e.def, w.mdN, w.adN, p);
              const zoneOf = (n) => esc(loc((dashaDB[n] || {}).zone, lang));
              const gradeBadge = conv.grade === "high"
                ? `<span class="badge good" data-conversion="high">${lang === "hi" ? "उच्च संभावना — प्रत्यक्ष फल" : lang === "gu" ? "ઉચ્ચ સંભાવના — પ્રત્યક્ષ ફળ" : "High probability — direct conversion"}</span>`
                : conv.grade === "moderate"
                  ? `<span class="badge info" data-conversion="moderate">${lang === "hi" ? "मध्यम — महादशा-कारक से समर्थित" : lang === "gu" ? "મધ્યમ — મહાદશા-કારકથી સમર્થિત" : "Moderate — carried by the Mahadasha significator"}</span>`
                  : `<span class="badge warn" data-conversion="conditional">${lang === "hi" ? "सशर्त — पहले वास्तु क्षेत्र सक्रिय करें" : lang === "gu" ? "શરતી — પહેલા વાસ્તુ ક્ષેત્ર સક્રિય કરો" : "Conditional — activate the Vastu sector first"}</span>`;
              // Strict grid tagging: this sentence must name the exact array
              // natalConversion() evaluated (the Vedic Ank Kundali). A generic
              // "birth grid" label was the 2026-09 bug: readers matched it
              // against the Lo Shu grid and read a contradiction.
              const convGrid = conv.grid || NATAL_CONVERSION_GRID;
              const gridNameVedic = lang === "hi" ? "वैदिक अंक-कुंडली ग्रिड (3–1–9 / 6–7–5 / 2–8–4)" : lang === "gu" ? "વૈદિક અંક-કુંડળી ગ્રિડ (3–1–9 / 6–7–5 / 2–8–4)" : "Vedic Ank Kundali grid (3–1–9 / 6–7–5 / 2–8–4)";
              const divergenceNote = Array.isArray(conv.divergence) && conv.divergence.length
                ? (lang === "hi" ? `<div class="card-sub grid-divergence-note" data-grid-divergence="${conv.divergence.join("-")}">ग्रिड-जांच: अंक ${conv.divergence.join(", ")} लो शू और वैदिक ग्रिड में अलग-अलग उपस्थिति दिखाते हैं — यह ग्रेड केवल ${gridNameVedic} से जांचा गया है, लो शू से नहीं।</div>`
                  : lang === "gu" ? `<div class="card-sub grid-divergence-note" data-grid-divergence="${conv.divergence.join("-")}">ગ્રિડ-તપાસ: અંક ${conv.divergence.join(", ")} લો શુ અને વૈદિક ગ્રિડમાં જુદી હાજરી બતાવે છે — આ ગ્રેડ ફક્ત ${gridNameVedic} પર ચકાસાયો છે, લો શુ પર નહીં.</div>`
                  : `<div class="card-sub grid-divergence-note" data-grid-divergence="${conv.divergence.join("-")}">Grid cross-check: number${conv.divergence.length > 1 ? "s" : ""} ${conv.divergence.join(", ")} plot${conv.divergence.length > 1 ? "" : "s"} differently in the Lo Shu and Vedic grids — this grade was evaluated against the ${gridNameVedic} only, not the Lo Shu grid.</div>`)
                : "";
              const natalLabel = conv.grade === "high"
                ? (lang === "hi" ? `कारक ${w.adN} (${planetOf(w.adN)}) ${gridNameVedic} में उपस्थित है — यह विंडो सीधे फलित हो सकती है।` : lang === "gu" ? `કારક ${w.adN} (${planetOf(w.adN)}) ${gridNameVedic} માં હાજર છે — આ વિન્ડો સીધી ફળી શકે છે.` : `Natal significator present — ${planetOf(w.adN)} (${w.adN}) sits in your ${gridNameVedic}, so this window can convert directly.`)
                : conv.grade === "moderate"
                  ? (lang === "hi" ? `अंतर्दशा-कारक ${w.adN} ${gridNameVedic} में अनुपस्थित है, पर महादशा-कारक ${w.mdN} (${planetOf(w.mdN)}) उपस्थित है — फल आता है, थोड़ा विलंब से।` : lang === "gu" ? `અંતર્દશા-કારક ${w.adN} ${gridNameVedic} માં ગેરહાજર છે, પણ મહાદશા-કારક ${w.mdN} (${planetOf(w.mdN)}) હાજર છે — ફળ આવે છે, થોડું મોડું.` : `AD lord ${planetOf(w.adN)} (${w.adN}) is absent from your ${gridNameVedic}, but the Mahadasha significator ${planetOf(w.mdN)} (${w.mdN}) is present — results arrive, usually a beat later than the window opens.`)
                  : (lang === "hi" ? `कारक ${conv.missing.join(", ")} ${gridNameVedic} में अनुपस्थित हैं — यह विंडो तभी फलित होती है जब ${zoneOf(w.adN)} क्षेत्र को पहले सक्रिय किया जाए (उपाय: ${esc(loc((dashaDB[w.adN] || {}).zoneRemedy, lang))})।` : lang === "gu" ? `કારક ${conv.missing.join(", ")} ${gridNameVedic} માં ગેરહાજર છે — આ વિન્ડો ત્યારે જ ફળે છે જ્યારે ${zoneOf(w.adN)} ક્ષેત્રને પહેલા સક્રિય કરાય (ઉપાય: ${esc(loc((dashaDB[w.adN] || {}).zoneRemedy, lang))}).` : `Significator${conv.missing.length > 1 ? "s" : ""} ${conv.missing.map((n) => `${planetOf(n)} (${n})`).join(" and ")} absent from your ${gridNameVedic} — the window is real but needs remedy activation of the ${zoneOf(w.adN)} sector before realisation: ${esc(loc((dashaDB[w.adN] || {}).zoneRemedy, lang))}`);
              const lateBadge = w.beyondBand ? ` <span class="badge info" data-beyond-band="true">${lang === "hi" ? `शास्त्रीय आयु-सीमा ${e.def.band[0]}–${e.def.band[1]} के बाद` : lang === "gu" ? `શાસ્ત્રીય ઉંમર-મર્યાદા ${e.def.band[0]}–${e.def.band[1]} પછી` : `Late window — beyond the classical ${e.def.band[0]}–${e.def.band[1]} age band`}</span>` : "";
              return `<div class="kit-value" data-window-grade="${conv.grade}" data-natal-grid="${esc(convGrid)}"${w.beyondBand ? ' data-beyond-band="true"' : ""}><strong>${yearOfMs(w.startMs)}–${yearOfMs(w.endMs)}</strong> (${agesLbl2} ${w.fromAge}–${w.toAge}) — ${lang === "hi" ? "महादशा" : lang === "gu" ? "મહાદશા" : "MD"} ${w.mdN} (${planetOf(w.mdN)}) · ${lang === "hi" ? "अंतर्दशा" : lang === "gu" ? "અંતર્દશા" : "AD"} ${w.adN} (${planetOf(w.adN)})${badge} ${gradeBadge}${lateBadge}<div class="card-sub">${natalLabel}</div>${divergenceNote}</div>`;
            }).join("")
          : `<div class="kit-value">${lang === "hi" ? "इस scan में निकट भविष्य की कोई प्रबल दशा-window नहीं है — व्यवहारिक तैयारी जारी रखें और अगला दशा संक्रमण देखें।" : lang === "gu" ? "આ scan માં નજીકના ભવિષ્યની કોઈ પ્રબળ દશા-window નથી — વ્યવહારિક તૈયારી ચાલુ રાખો અને આગળનું દશા પરિવર્તન જુઓ." : "No strong upcoming Dasha window appears in this scan — keep practical preparation steady and watch the next Dasha transition."}</div>`;
        const bandLine = e.bandClosed
          ? `<div class="card-sub" data-band-closed="true">${lang === "hi" ? `इस घटना की शास्त्रीय आयु-सीमा (${e.def.band[0]}–${e.def.band[1]}) बीत चुकी है; ऊपर की विंडो देर-से आने वाले कारक-काल हैं — विंडो हटाई नहीं गई, केवल वर्गीकृत की गई है।` : lang === "gu" ? `આ ઘટનાની શાસ્ત્રીય ઉંમર-મર્યાદા (${e.def.band[0]}–${e.def.band[1]}) વીતી ગઈ છે; ઉપરની વિન્ડો મોડેથી આવતા કારક-કાળ છે — વિન્ડો કાઢી નથી, માત્ર વર્ગીકૃત કરી છે.` : `The classical age band for this event (${e.def.band[0]}–${e.def.band[1]}) has closed, so these are late significator windows — shown and graded rather than purged. Read them as renewal or second-commitment periods.`}</div>`
          : "";
        const pastLine = e.pastBest
          ? `<div class="card-sub">${lang === "hi" ? `पिछली प्रबल विंडो: ${yearOfMs(e.pastBest.startMs)}–${yearOfMs(e.pastBest.endMs)} (आयु ${e.pastBest.fromAge}–${e.pastBest.toAge}) — मिलान करें कि उस दौर में क्या घटा था।` : lang === "gu" ? `ગત પ્રબળ વિન્ડો: ${yearOfMs(e.pastBest.startMs)}–${yearOfMs(e.pastBest.endMs)} (ઉંમર ${e.pastBest.fromAge}–${e.pastBest.toAge}) — તે સમયગાળામાં શું બન્યું હતું તે સરખાવો.` : `Strongest past window: ${yearOfMs(e.pastBest.startMs)}–${yearOfMs(e.pastBest.endMs)} (ages ${e.pastBest.fromAge}–${e.pastBest.toAge}) — cross-check what actually happened then; it is your personal proof of how this cycle speaks.`}</div>`
          : "";
        const coverage = e.coverage || { total: 0, last: null };
        const coverageLine = coverage.last
          ? `<div class="card-sub" data-lifetime-coverage="${coverage.total}" data-coverage-last="${coverage.last.fromAge}-${coverage.last.toAge}">${lang === "hi" ? `जीवन-भर कवरेज: ${e.def.band[0]}–${e.def.band[1]} आयु-पट्टी में ${coverage.total} कारक-विंडो; अंतिम विंडो ${coverage.last.fromAge}–${coverage.last.toAge} आयु (महादशा ${coverage.last.mdN} · अंतर्दशा ${coverage.last.adN})। ऊपर केवल निकटतम प्रबल विंडो विस्तृत हैं।` : lang === "gu" ? `જીવનભર કવરેજ: ${e.def.band[0]}–${e.def.band[1]} ઉંમર-પટ્ટીમાં ${coverage.total} કારક-વિન્ડો; છેલ્લી વિન્ડો ${coverage.last.fromAge}–${coverage.last.toAge} ઉંમર (મહાદશા ${coverage.last.mdN} · અંતર્દશા ${coverage.last.adN}). ઉપર ફક્ત નજીકની પ્રબળ વિન્ડો વિગતવાર છે.` : `Lifetime coverage: ${coverage.total} significator windows inside the ${e.def.band[0]}–${e.def.band[1]} age band; the furthest lands at ages ${coverage.last.fromAge}–${coverage.last.toAge} (MD ${coverage.last.mdN} · AD ${coverage.last.adN}). Only the nearest strong windows are detailed above.`}</div>`
          : "";
        return `<div class="kit-row"><div class="kit-ico">${e.def.icon || "★"}</div><div class="kit-body">
          <div class="kit-label">${lbl}</div>
          ${windows}
          ${bandLine}
          ${pastLine}
          ${coverageLine}
        </div></div>`;
      }).join("");

      const eventsCard = `<div class="card">
        <div class="card-title">${lang === "hi" ? "जीवन-घटना विंडो — विवाह, विदेश, करियर, संपत्ति, धन" : lang === "gu" ? "જીવન-ઘટના વિન્ડો — લગ્ન, વિદેશ, કારકિર્દી, મિલકત, ધન" : "Life-Event Windows — marriage, abroad, career, property, wealth"}</div>
        <div class="card-sub">${lang === "hi" ? "प्रत्येक विंडो वह अवधि है जब उस घटना के शास्त्रीय कारक ग्रह (जैसे विवाह के लिए शुक्र-चंद्र, विदेश के लिए राहु-केतु) महादशा-अंतर्दशा में सक्रिय होते हैं। ये दशा-आधारित अनुकूल अवसर-काल हैं, निश्चित भविष्यवाणी नहीं।" : lang === "gu" ? "દરેક વિન્ડો એ સમયગાળો છે જ્યારે તે ઘટનાના શાસ્ત્રીય કારક ગ્રહો (જેમ કે લગ્ન માટે શુક્ર-ચંદ્ર, વિદેશ માટે રાહુ-કેતુ) મહાદશા-અંતર્દશામાં સક્રિય હોય છે. આ દશા-આધારિત અનુકૂળ તક-કાળ છે, નિશ્ચિત ભવિષ્યવાણી નથી." : "Each window marks when the classical significators of that event (Venus–Moon for marriage, Rahu–Ketu for abroad, Sun–Saturn for career, and so on) become active in your Mahadasha–Antardasha stack. Read them as Dasha-based favourable opportunity periods, not fixed predictions."}</div>
        <div class="card-sub">${t("dashaCoverageNote", "Coverage: wealth & business windows are scanned across ages 21–75, and every Dasha horizon assumes an 80-year average lifespan. Once a classical band closes, late significator windows are scanned till age 80 (or 15 years ahead, whichever reaches further) rather than leaving the card blank.")}</div>
        <div class="kit">${eventRows}</div>
      </div>`;

      /* Primary-engine banner + cross-reference gating. Both current MD lords
         are named up-front so a differing pair reads as two clocks, not as a
         contradiction inside one system. */
      const ankLordName = String(((db.numbers || {})[cur.md.n] || {}).planet || "").split(" ")[0];
      const vimLordName = vTimeline ? vTimeline.current.md.lord : "";
      const lordsAgree = vimLordName && ankLordName && vimLordName.toLowerCase() === ankLordName.toLowerCase();
      const engineBadge = primaryEngine === "vimshottari"
        ? `<span class="badge info" data-primary-dasha="vimshottari">${lang === "hi" ? "प्राथमिक इंजन: विम्शोत्तरी" : lang === "gu" ? "પ્રાથમિક એન્જિન: વિમ્શોત્તરી" : "Primary engine: Vimshottari"}</span>`
        : `<span class="badge info" data-primary-dasha="ank">${lang === "hi" ? "प्राथमिक इंजन: अंक-ज्योतिष" : lang === "gu" ? "પ્રાથમિક એન્જિન: અંક-જ્યોતિષ" : "Primary engine: Ank Jyotish"}</span>`;
      const engineBanner = `<div class="card dasha-engine-banner" data-dasha-primary="${primaryEngine}" data-dasha-agree="${lordsAgree ? "yes" : "no"}">
        <div class="goal-head">
          <div class="card-title">${lang === "hi" ? "दो दशा-घड़ियाँ — एक ही समय पर दो अलग नाम संभव हैं" : lang === "gu" ? "બે દશા-ઘડિયાળો — એક જ સમયે બે જુદા નામ શક્ય છે" : "Two Dasha clocks — two different current lords are normal"}</div>
          ${engineBadge}
        </div>
        <div class="kit-value">${lang === "hi"
          ? `इस रिपोर्ट की <strong>${primaryEngine === "vimshottari" ? "विम्शोत्तरी (१२०-वर्ष, नक्षत्र-आधारित)" : "अंक-ज्योतिष (४५-वर्ष, अंक-आधारित)"}</strong> प्रणाली प्राथमिक है। ${vimLordName && ankLordName ? `वर्तमान महादशा: अंक-ज्योतिष <strong>${esc(ankLordName)} (${cur.md.n})</strong> · विम्शोत्तरी <strong>${esc(vimLordName)}</strong>।` : ""} ${lordsAgree ? "दोनों घड़ियाँ इस समय एक ही ग्रह दिखा रही हैं।" : "ये दो अलग-अलग घड़ियाँ हैं, इसलिए इस क्षण दो अलग ग्रह दिखना कोई विरोधाभास नहीं — नीचे दोनों को स्पष्ट रूप से अलग-अलग लेबल किया गया है।"}`
          : lang === "gu"
            ? `આ રિપોર્ટની <strong>${primaryEngine === "vimshottari" ? "વિમ્શોત્તરી (૧૨૦-વર્ષ, નક્ષત્ર-આધારિત)" : "અંક-જ્યોતિષ (૪૫-વર્ષ, અંક-આધારિત)"}</strong> પદ્ધતિ પ્રાથમિક છે. ${vimLordName && ankLordName ? `વર્તમાન મહાદશા: અંક-જ્યોતિષ <strong>${esc(ankLordName)} (${cur.md.n})</strong> · વિમ્શોત્તરી <strong>${esc(vimLordName)}</strong>.` : ""} ${lordsAgree ? "બંને ઘડિયાળો આ સમયે એક જ ગ્રહ બતાવે છે." : "આ બે જુદી ઘડિયાળો છે, એટલે આ ક્ષણે બે જુદા ગ્રહ દેખાવવા વિરોધાભાસ નથી — નીચે બંનેને સ્પષ્ટ રીતે અલગ લેબલ કર્યા છે."}`
            : `This report's <strong>${primaryEngine === "vimshottari" ? "Vimshottari (120-year, nakshatra-anchored)" : "Ank Jyotish (45-year, number-anchored)"}</strong> system is the primary timing engine. ${vimLordName && ankLordName ? `Current Mahadasha: Ank Jyotish <strong>${esc(ankLordName)} (${cur.md.n})</strong> · Vimshottari <strong>${esc(vimLordName)}</strong>.` : ""} ${lordsAgree ? "Both clocks agree on the active lord right now." : "These are two separate clocks, so two different current lords at this moment is expected, not a contradiction — each is clearly labelled below."}`}</div>
        <div class="card-sub">${lang === "hi" ? "सेटिंग में आप प्राथमिक दशा-इंजन बदल सकते हैं; द्वितीय इंजन 'एडवांस्ड क्रॉस-रेफरेंस' के रूप में रहता है।" : lang === "gu" ? "સેટિંગમાં તમે પ્રાથમિક દશા-એન્જિન બદલી શકો છો; બીજું એન્જિન 'એડવાન્સ્ડ ક્રોસ-રેફરન્સ' તરીકે રહે છે." : "Change the primary Dasha engine in Settings; the secondary engine stays available as an Advanced Cross-Reference."}</div>
      </div>`;

      /* Cordon the non-primary engine into a collapsed appendix. */
      const crossRefTitle = lang === "hi" ? "एडवांस्ड ज्योतिष क्रॉस-रेफरेंस (केवल ज्योतिष अभ्यासियों के लिए)" : lang === "gu" ? "એડવાન્સ્ડ જ્યોતિષ ક્રોસ-રેફરન્સ (ફક્ત જ્યોતિષ અભ્યાસીઓ માટે)" : "Advanced Astrological Cross-Reference (for Jyotish practitioners)";
      const vimshottariBlock = primaryEngine === "vimshottari"
        ? vimshottariCard
        : `<details class="card dasha-crossref" data-crossref-engine="vimshottari">
            <summary class="dasha-crossref-summary"><strong>${crossRefTitle}</strong> — ${lang === "hi" ? "विम्शोत्तरी १२०-वर्ष चक्र" : lang === "gu" ? "વિમ્શોત્તરી ૧૨૦-વર્ષ ચક્ર" : "Vimshottari 120-year cycle"}</summary>
            <div class="dasha-crossref-body">${vimshottariCard}</div>
          </details>`;
      const ankCards = `${stackCard}${microForecastCard}${pairSynthesis}${transitSynthesisCard}${ladderCard}${eventsCard}`;
      const ankBlock = primaryEngine === "ank"
        ? ankCards
        : `<details class="card dasha-crossref" data-crossref-engine="ank">
            <summary class="dasha-crossref-summary"><strong>${crossRefTitle}</strong> — ${lang === "hi" ? "अंक-ज्योतिष ४५-वर्ष चक्र" : lang === "gu" ? "અંક-જ્યોતિષ ૪૫-વર્ષ ચક્ર" : "Ank Jyotish 45-year cycle"}</summary>
            <div class="dasha-crossref-body">${ankCards}</div>
          </details>`;

      return `<section class="rsection" id="dasha-section" data-authority="dasha" data-primary-dasha-engine="${primaryEngine}">
        <h2 class="rsection-title"><span class="idx">${SECTION.dasha}</span>${t("secDasha", "Dasha Timeline — Life Event Windows")}</h2>
        <p class="rsection-desc">${lang === "hi" ? "अंक-ज्योतिष की दशा प्रणाली: जन्म से आपका मूलांक अपनी महादशा शुरू करता है (अंक = वर्ष), फिर क्रम ९ अंकों में घूमता है। हर महादशा के भीतर अंतर्दशा और प्रत्यंतर दशा उसी अनुपात में चलती हैं — यही बताता है कि कौन-सा ग्रह अभी आपके जीवन का 'ऑपरेटिंग सिस्टम' चला रहा है।" : lang === "gu" ? "અંક-જ્યોતિષની દશા પ્રણાલી: જન્મથી તમારો મૂળાંક પોતાની મહાદશા શરૂ કરે છે (અંક = વર્ષ), પછી ક્રમ ૯ અંકોમાં ફરે છે. દરેક મહાદશાની અંદર અંતર્દશા અને પ્રત્યંતર દશા એ જ પ્રમાણમાં ચાલે છે — એ જ બતાવે છે કે કયો ગ્રહ અત્યારે તમારા જીવનની 'ઓપરેટિંગ સિસ્ટમ' ચલાવે છે." : "The Ank Jyotish dasha system: from birth, your Moolank opens its own Mahadasha (number = years), then the sequence walks the 9 numbers in order. Inside every Mahadasha run proportional Antardashas and Pratyantar dashas — together they show which planet is running your life's operating system right now."}</p>
        ${engineBanner}
        ${primaryEngine === "vimshottari" ? vimshottariBlock : ""}
        ${primaryEngine === "vimshottari" ? ankBlock : stackCard}
        ${primaryEngine === "ank" ? `${microForecastCard}${pairSynthesis}${transitSynthesisCard}${ladderCard}${eventsCard}` : ""}
        ${primaryEngine === "ank" ? vimshottariBlock : ""}
        <div class="judge-note"><strong>${t("howWeJudge", "How we judge this:")}</strong> ${t("dashaJudgeNote", "")}${p.birthTime ? (lang === "hi" ? " आपका सटीक जन्म समय चक्र-सीमाओं को स्थिर करता है।" : lang === "gu" ? " તમારો ચોક્કસ જન્મ સમય ચક્ર-સીમાઓને સ્થિર કરે છે." : " Your exact birth time anchors the cycle boundaries.") : (lang === "hi" ? " चक्र-सीमाएँ जन्म तिथि की मध्यरात्रि पर टिकी हैं — बारीक सीमाओं के लिए जन्म समय भरें।" : lang === "gu" ? " ચક્ર-સીમાઓ જન્મ તારીખની મધ્યરાત્રિએ ટકે છે — બારીક સીમાઓ માટે જન્મ સમય ભરો." : " Cycle boundaries are anchored to your date of birth at midnight — add your exact birth time in the intake form for finer boundaries.")}</div>
      </section>`;
    })();

    const memorySection = `<section class="rsection" id="memory-section">
      <h2 class="rsection-title"><span class="idx">${SECTION.memory}</span>${t("secMemory", "Your Evolving Chart")}</h2>
      <p class="rsection-desc">This section is private, on-device memory only. It helps the app learn your own journey over time without uploading personal data.</p>
      <div class="insight-grid">
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "सुरक्षित चार्ट" : lang === "gu" ? "સેવ કરેલા ચાર્ટ" : "Saved snapshots"}</div>
          <div class="metric-value">${evolving.snapshots.length}</div>
          <div class="metric-sub">${lang === "hi" ? `नवीनतम: ${evolving.snapshots[0] ? prettyDate(evolving.snapshots[0].savedAt) : "अभी सुरक्षित नहीं"}` : lang === "gu" ? `તાજેતરનું: ${evolving.snapshots[0] ? prettyDate(evolving.snapshots[0].savedAt) : "હજી સેવ નથી"}` : `Latest saved on ${evolving.snapshots[0] ? prettyDate(evolving.snapshots[0].savedAt) : "this device not yet"}`}</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "इस वर्ष का प्रभाव" : lang === "gu" ? "આ વર્ષનો પ્રભાવ" : "This year in context"}</div>
          <div class="metric-value">${evolving.currentYearLucky ? (lang === "hi" ? "अनुकूल" : lang === "gu" ? "અનુકૂળ" : "Favourable") : (lang === "hi" ? "धैर्य से निर्माण" : lang === "gu" ? "ધીરજથી નિર્માણ" : "Build steadily")}</div>
          <div class="metric-sub">${evolving.currentYearLucky ? (lang === "hi" ? "यह वर्ष आपके शुभ वर्षों की सूची में आता है।" : lang === "gu" ? "આ વર્ષ તમારા શુભ વર્ષોની યાદીમાં આવે છે." : "This year appears in your lucky-year window.") : (lang === "hi" ? "अनुशासन और निरंतरता बनाए रखें।" : lang === "gu" ? "શિસ્ત અને સાતત્ય જાળવી રાખો." : "Not one of your top timing windows — use discipline and consistency.")}</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "इस वर्ष दर्ज कदम" : lang === "gu" ? "આ વર્ષે નોંધેલા પગલાં" : "Moves logged this year"}</div>
          <div class="metric-value">${evolving.movesThisYear}</div>
          <div class="metric-sub">A local reality-check against your timing cycle.</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "ज्ञान का स्रोत" : lang === "gu" ? "જ્ઞાનનો સ્ત્રોત" : "Knowledge source"}</div>
          <div class="metric-value">v${esc(activePack().packVersion)}</div>
          <div class="metric-sub">${esc(activePack().source === "remote" ? "Live-updated content pack" : activePack().source === "cached" ? "Cached content pack" : "Bundled starter pack")}</div>
        </div>
      </div>
      <div class="card-grid two">
        <div class="card">
          <div class="card-title">${lang === "hi" ? "इस महीने उपायों का अभ्यास" : lang === "gu" ? "આ મહિને ઉપાયોનો અભ્યાસ" : "Remedy engagement this month"}</div>
          <div class="card-sub">${lang === "hi" ? "एक टैप से अपने मुख्य ग्रहों का चेक-इन दर्ज करें।" : lang === "gu" ? "એક ટેપથી તમારા મુખ્ય ગ્રહોનું ચેક-ઇન નોંધો." : "One tap adds a private check-in for the planets that matter most in this chart."}</div>
          <div class="engagement-list">
            ${evolving.practiceSummary.map((item) => `<div class="engagement-item"><div><strong>${item.n} — ${esc(db.numbers[item.n].planet)}</strong><span>${item.month} logged this month · ${item.total} total</span></div><button class="btn btn-secondary btn-32" type="button" data-practice-number="${item.n}">${lang === "hi" ? "अभ्यास दर्ज करें" : lang === "gu" ? "અભ્યાસ નોંધો" : "Log practice"}</button></div>`).join("")}
          </div>
        </div>
        <div class="card">
          <div class="card-title">${lang === "hi" ? "शुभ समय बनाम वास्तविक कर्म" : lang === "gu" ? "શુભ સમય વિરુદ્ધ વાસ્તવિક કર્મ" : "Lucky-year timing vs what you actually did"}</div>
          <div class="card-sub">${lang === "hi" ? "कोई बड़ा निर्णय या उपाय की शुरुआत यहां स्थानीय रूप से दर्ज करें।" : lang === "gu" ? "કોઈ મોટો નિર્ણય કે ઉપાયની શરૂઆત અહીં નોંધો." : "Log a real-world move locally — job switch, launch, purchase, proposal, relocation, or a strong 40-day remedy push."}</div>
          <form id="localJournalForm" class="mini-form">
            <input id="localJournalText" class="input" type="text" maxlength="160" placeholder="${lang === "hi" ? "जैसे: शुक्रवार के शुक्र उपाय शुरू किए और बेडरूम का वास्तु सुधारा" : lang === "gu" ? "જેમ કે: શુક્રવારના શુક્ર ઉપાયો શરૂ કર્યા અને બેડરૂમનું વાસ્તુ સુધાર્યું" : "e.g. Started Friday Venus remedy streak and redesigned bedroom"}" />
            <button class="btn btn-primary btn-32" type="submit">${lang === "hi" ? "सुरक्षित करें" : lang === "gu" ? "સેવ કરો" : "Save locally"}</button>
          </form>
          <div class="timeline">
            ${evolving.journal.length ? evolving.journal.map((entry) => `<div class="timeline-item"><div><strong>${esc(entry.text)}</strong><span>${prettyDate(entry.at)}</span></div></div>`).join("") : `<div class="timeline-item"><div><strong>${lang === "hi" ? "अभी कोई नोट दर्ज नहीं है" : lang === "gu" ? "હજી કોઈ નોંધ દાખલ નથી" : "No local moves logged yet"}</strong><span>${lang === "hi" ? "आपकी टिप्पणियां पूरी तरह आपके डिवाइस पर ही रहती हैं।" : lang === "gu" ? "તમારી નોંધ સંપૂર્ણપણે તમારા ડિવાઇસ પર જ રહે છે." : "Your notes stay on this device and never enter the anonymous contribution payload."}</span></div></div>`}
          </div>
        </div>
      </div>
      <!-- Technical-leak guard (2026-09 audit): the raw serialization payload
           used to print verbatim in the client PDF ("schemaVersion": 1 …).
           It is developer scaffolding, not guidance — hidden in Client mode
           and never rendered to print for clients. -->
      <div class="card practitioner-only" data-technical="contribution-scaffold" aria-hidden="true">
        <div class="goal-head">
          <div class="card-title">Anonymous contribution scaffold</div>
          <span class="badge ${state.contributionEnabled ? "good" : "warn"}">${state.contributionEnabled ? "Opted in" : "Off by default"}</span>
        </div>
        <div class="kit-value">${state.contributionEnabled ? "Only anonymous aggregate counts are prepared. If a contribution endpoint is configured in a future knowledge pack, the app can send just these counts — never names, DOBs, phones, vehicle numbers or your private notes." : "Anonymous cross-user learning is currently disabled for this device. You can turn it on in the intake form at any time."}</div>
        <div class="code-block">${esc(JSON.stringify(evolving.previewPayload, null, 2))}</div>
      </div>
    </section>`;

    /* Classical Vedic directional authenticity (2026-09 audit): the report
       now anchors its Vastu read in the classical Ashta Dikpalaka guardians
       matched to this engine's Vedic planetary compass, so the 16-zone Vastu
       layer stands on its own Vedic footing and never leans on the separate
       (Feng Shui) Kua module for directionality. */
    const dikpalakaRows = [
      { dir: lang === "hi" ? "पूर्व" : lang === "gu" ? "પૂર્વ" : "East (Pūrva)", deity: "Indra", n: VEDIC_VASTU_COMPASS_PLANETS.E },
      { dir: lang === "hi" ? "आग्नेय" : lang === "gu" ? "આગ્નેય" : "South-East (Āgneya)", deity: "Agni", n: VEDIC_VASTU_COMPASS_PLANETS.SE },
      { dir: lang === "hi" ? "दक्षिण" : lang === "gu" ? "દક્ષિણ" : "South (Dakshiṇa)", deity: "Yama", n: VEDIC_VASTU_COMPASS_PLANETS.S },
      { dir: lang === "hi" ? "नैऋत्य" : lang === "gu" ? "નૈઋત્ય" : "South-West (Nairṛtya)", deity: "Nirṛti", n: VEDIC_VASTU_COMPASS_PLANETS.SW },
      { dir: lang === "hi" ? "पश्चिम" : lang === "gu" ? "પશ્ચિમ" : "West (Paścima)", deity: "Varuṇa", n: VEDIC_VASTU_COMPASS_PLANETS.W },
      { dir: lang === "hi" ? "वायव्य" : lang === "gu" ? "વાયવ્ય" : "North-West (Vāyavya)", deity: "Vāyu", n: VEDIC_VASTU_COMPASS_PLANETS.NW },
      { dir: lang === "hi" ? "उत्तर" : lang === "gu" ? "ઉત્તર" : "North (Uttara)", deity: "Kubera", n: VEDIC_VASTU_COMPASS_PLANETS.N },
      { dir: lang === "hi" ? "ईशान" : lang === "gu" ? "ઈશાન" : "North-East (Īśānya)", deity: "Īśāna", n: VEDIC_VASTU_COMPASS_PLANETS.NE }
    ].map((row) => `<tr><td><strong>${esc(row.dir)}</strong></td><td>${esc(row.deity)}</td><td>${esc(db.numbers[row.n].planet)} (${row.n})</td></tr>`).join("");
    const dikpalakaCard = `<div class="card ashta-dikpalaka-card" data-authority="vedic-direction-rulers">
      <div class="goal-head">
        <div class="card-title">${lang === "hi" ? "शास्त्रीय वैदिक दिशा-स्वामी — अष्ट दिक्पालक" : lang === "gu" ? "શાસ્ત્રીય વૈદિક દિશા-સ્વામી — અષ્ટ દિક્પાલક" : "Classical Vedic direction rulers — Ashta Dikpālaka"}</div>
        <span class="badge info">${lang === "hi" ? "वैदिक वास्तु" : lang === "gu" ? "વૈદિક વાસ્તુ" : "Vedic Vastu"}</span>
      </div>
      <div class="table-scroll"><table class="rtable">
        <tr><th>${lang === "hi" ? "दिशा" : lang === "gu" ? "દિશા" : "Direction"}</th><th>${lang === "hi" ? "दिक्पालक" : lang === "gu" ? "દિક્પાલક" : "Guardian"}</th><th>${lang === "hi" ? "ग्रह-स्वामी (इस रिपोर्ट का वास्तु कम्पास)" : lang === "gu" ? "ગ્રહ-સ્વામી (આ રિપોર્ટનો વાસ્તુ કોમ્પાસ)" : "Planetary ruler (this report's Vastu compass)"}</th></tr>
        ${dikpalakaRows}
      </table></div>
      <div class="card-sub">${lang === "hi" ? "इस रिपोर्ट के सभी वास्तु-निर्णय इन्हीं शास्त्रीय वैदिक दिशाओं से आते हैं। कुआ/फेंगशुई (खंड " + SECTION.kua + ") एक अलग वैकल्पिक मॉड्यूल है और इन क्षेत्रों को नहीं बदलता।" : lang === "gu" ? "આ રિપોર્ટના બધા વાસ્તુ-નિર્ણયો આ જ શાસ્ત્રીય વૈદિક દિશાઓમાંથી આવે છે. કુઆ/ફેંગશુઈ (વિભાગ " + SECTION.kua + ") એક અલગ વૈકલ્પિક મોડ્યુલ છે અને આ ક્ષેત્રોને બદલતું નથી." : `Every Vastu decision in this report comes from these classical Vedic directions. The Kua / Feng Shui module (Section ${SECTION.kua}) is a separate optional module and never changes these zones.`}</div>
    </div>`;

    /* This is a fixed home-placement context scan. It is intentionally placed
       in Timeline beside the Dasha-led active zone, but it never chooses that
       active zone or changes a period date. */
    const vastuSection = vastu.length
      ? `<section class="rsection" id="vastu-section" data-authority="home-vastu-context">
          <h2 class="rsection-title"><span class="idx">${SECTION.vastu}</span>${t("secVastu", "Home Vastu Context")}</h2>
          <p class="rsection-desc">${lang === "hi" ? "यह आपके दिए गए कमरे/दिशा विवरण का स्थिर home-context scan है। ऊपर का ‘Active Vastu Zone’ केवल वर्तमान दशा के स्वामियों से चुना जाता है; यह सूची उसे नहीं बदलती।" : lang === "gu" ? "આ તમારા આપેલા રૂમ/દિશા વિગતોનું સ્થિર home-context scan છે. ઉપરનો ‘Active Vastu Zone’ ફક્ત વર્તમાન દશાના સ્વામીઓ પરથી પસંદ થાય છે; આ યાદી તેને બદલતી નથી." : "This is a fixed home-context scan from the room directions you supplied. The ‘Active Vastu Zone’ above is selected only from the current Dasha lords; this list never changes it."}</p>
          <div class="card">
            <div class="kit">
            ${vastu.map((f) => `<div class="kit-row">
              <div class="kit-ico">${f.tone === "good" ? "✓" : f.tone === "warn" ? "!" : "✕"}</div>
              <div class="kit-body">
                <div class="kit-value"><strong>${esc(f.item)}</strong> <span class="badge ${f.tone}">${esc(f.label)}</span></div>
                <div class="card-sub">${esc(f.note)}</div>
              </div>
            </div>`).join("")}
            </div>
          </div>
          <p class="rsection-desc">${lang === "hi" ? "सामान्य रखरखाव: घर के मध्य (ब्रह्मस्थान) को खाली और साफ रखें; दोष वाले स्थान पर समुद्री नमक की कटोरी रखें और हर हफ्ते बदलें; ईशान कोण में रोज दीया जलाएं।" : lang === "gu" ? "સામાન્ય જાળવણી: ઘરના મધ્ય (બ્રહ્મસ્થાન) ને ખાલી અને સ્વચ્છ રાખો; દોષ વાળી જગ્યાએ દરિયાઈ મીઠાની વાટકી રાખો અને દર અઠવાડિયે બદલો; ઇશાન ખૂણામાં રોજ દીવો પ્રગટાવો." : "General upkeep: keep the centre (Brahmasthan) of the property empty and clean; place a bowl of sea salt in dosh zones and replace it weekly; keep the northeast lit with a daily diya."}</p>
          ${dikpalakaCard}
        </section>`
      : `<section class="rsection" id="vastu-section" data-authority="home-vastu-context">
          <h2 class="rsection-title"><span class="idx">${SECTION.vastu}</span>${t("secVastu", "Home Vastu Context")}</h2>
          <p class="rsection-desc">${lang === "hi" ? "यह स्थिर home-context scan है; सक्रिय वास्तु क्षेत्र केवल वर्तमान दशा से आता है।" : lang === "gu" ? "આ સ્થિર home-context scan છે; સક્રિય વાસ્તુ ક્ષેત્ર ફક્ત વર્તમાન દશાથી આવે છે." : "This is a fixed home-context scan; the active Vastu zone comes only from the current Dasha."}</p>
          <div class="card"><div class="kit-value">${lang === "hi" ? "कोई वास्तु विवरण नहीं दिया गया था — मुख्य द्वार, रसोई, बेडरूम और टॉयलेट दर्ज कर पुनः जांचें।" : lang === "gu" ? "કોઈ વાસ્તુ વિગત આપી ન હતી — મુખ્ય દ્વાર, રસોડું, બેડરૂમ અને ટોઇલેટ દાખલ કરી ફરી તપાસો." : "No direction details were provided — re-run with your entrance, kitchen, bedroom and toilet directions for a full dosh scan."}</div></div>
          ${dikpalakaCard}
        </section>`;

    const kuaInfo = p.kua ? db.kua[p.kua] : null;
    /* Kua system segregation (2026-09 audit): Kua is a Feng Shui (Chinese)
       directional system. Mixing its East/West-group directionality into the
       classical 16-zone Vedic Vastu read (Brahmasthan, Ishanya, etc.) diluted
       the authenticity of a "Vedic Numerology & Vastu" product. It is now
       cordoned off into an explicit, collapsible OPTIONAL module that stays
       out of the Vastu section entirely and never overrides a Vastu zone. */
    const kuaSection = `<section class="rsection" id="kua-section" data-module="feng-shui-optional" data-authority="feng-shui">
      <h2 class="rsection-title"><span class="idx">${SECTION.kua}</span>${t("secKua", "Optional Module — Feng Shui Alignment (Kua Number)")}</h2>
      <p class="rsection-desc">${lang === "hi" ? "नोट: <strong>कुआ अंक फेंगशुई (चीनी पद्धति)</strong> का हिस्सा है, शास्त्रीय वैदिक वास्तु का नहीं। यह एक <strong>वैकल्पिक, अलग मॉड्यूल</strong> है — यह ऊपर के वैदिक वास्तु क्षेत्रों (ब्रह्मस्थान, ईशान आदि) को बदलता या ओवरराइड नहीं करता।" : lang === "gu" ? "નોંધ: <strong>કુઆ અંક ફેંગશુઈ (ચીની પદ્ધતિ)</strong> નો ભાગ છે, શાસ્ત્રીય વૈદિક વાસ્તુનો નહીં. આ એક <strong>વૈકલ્પિક, અલગ મોડ્યુલ</strong> છે — તે ઉપરના વૈદિક વાસ્તુ ક્ષેત્રો (બ્રહ્મસ્થાન, ઈશાન વગેરે) ને બદલતું કે ઓવરરાઈડ કરતું નથી." : 'Note: the <strong>Kua number is a Feng Shui (Chinese) system</strong>, not classical Vastu Shastra. This is an <strong>optional, separate module</strong> — it does not change or override the Vedic Vastu zones (Brahmasthan, Ishanya, etc.) above.'}</p>
      <details class="card optional-module-card" data-kua-module="true" open>
        <summary class="optional-module-summary">${lang === "hi" ? "फेंगशुई अलाइनमेंट (वैकल्पिक मॉड्यूल) — खोलें / बंद करें" : lang === "gu" ? "ફેંગશુઈ અલાઇનમેન્ટ (વૈકલ્પિક મોડ્યુલ) — ખોલો / બંધ કરો" : "Feng Shui alignment (optional module) — open / close"}</summary>
      ${kuaInfo ? `<div class="card-body">
        <div class="goal-head">
          <div class="card-title">${lang === "hi" ? `आपका कुआ अंक ${p.kua} है — ${esc(kuaInfo.group)}, ${esc(kuaInfo.element)} तत्व` : lang === "gu" ? `તમારો કુઆ અંક ${p.kua} છે — ${esc(kuaInfo.group)}, ${esc(kuaInfo.element)} તત્વ` : `Your Kua number is ${p.kua} — ${esc(kuaInfo.group)} group, ${esc(kuaInfo.element)} element`}</div>
          <span class="badge info">Feng Shui · optional module</span>
        </div>
        <div class="kit-value">${lang === "hi" ? `आपकी सर्वोत्तम दिशा (शेंग ची — धन व सफलता) <strong>${esc(kuaInfo.shengChi)}</strong> है। काम करते या सोते समय इस दिशा में मुंह/सिर रखें।` : lang === "gu" ? `તમારી સર્વોત્તમ દિશા (શેંગ ચી — ધન અને સફળતા) <strong>${esc(kuaInfo.shengChi)}</strong> છે. કામ કરતી વખતે કે સૂતી વખતે આ દિશા તરફ મોં/માથું રાખો.` : `Your best direction (Sheng Chi — wealth &amp; success) is <strong>${esc(kuaInfo.shengChi)}</strong>. Face this direction when working or sleeping for maximum support.`}</div>
        <div class="kit-value">${lang === "hi" ? `आपकी चार शुभ दिशाएं: <strong>${kuaInfo.auspicious.map(esc).join(", ")}</strong>। टेबल, बिस्तर और मुख्य द्वार को इन दिशाओं में रखें।` : lang === "gu" ? `તમારી ચાર શુભ દિશાઓ: <strong>${kuaInfo.auspicious.map(esc).join(", ")}</strong>. ટેબલ, પલંગ અને મુખ્ય દ્વારને આ દિશાઓમાં રાખો.` : `Your four auspicious directions: <strong>${kuaInfo.auspicious.map(esc).join(", ")}</strong>. Orient your desk, bed head and main door towards these wherever practical.`}</div>
        <div class="card-sub">${lang === "hi" ? "यह मॉड्यूल केवल वैकल्पिक व्यक्तिगत-दिशा संदर्भ है; इस रिपोर्ट के वास्तु-निर्णय केवल शास्त्रीय वैदिक वास्तु से आते हैं।" : lang === "gu" ? "આ મોડ્યુલ ફક્ત વૈકલ્પિક વ્યક્તિગત-દિશા સંદર્ભ છે; આ રિપોર્ટના વાસ્તુ-નિર્ણયો ફક્ત શાસ્ત્રીય વૈદિક વાસ્તુમાંથી આવે છે." : "This module is an optional personal-direction reference only; every Vastu decision in this report comes from classical Vedic Vastu alone."}</div>
      </div>` : `<div class="card-body"><div class="kit-value">${lang === "hi" ? "कुआ अंक जानने के लिए फॉर्म में 'विवरण बदलें' पर जाकर अपना लिंग (Gender) चुनें।" : lang === "gu" ? "કુઆ અંક જાણવા માટે ફોર્મમાં 'વિગત બદલો' પર જઈને તમારી જાતિ (Gender) પસંદ કરો." : 'Add your <strong>gender</strong> in the intake form (use "Edit Details" and re-run) to compute your Kua number and personal lucky directions.'}</div></div>`}
      </details>
    </section>`;

    const partnerValid = p.partnerName && p.partnerDob && !isNaN(new Date(p.partnerDob).getTime());
    const partnerFirst = (p.partnerName || "").trim().split(/\s+/)[0] || (lang === "hi" ? "पार्टनर" : lang === "gu" ? "પાર્ટનર" : "partner");
    /* The partner chart runs through the same computeProfile() as the primary
       chart, including the optional Vedic precision inputs. When the partner's
       time/place are blank they stay blank all the way down: computeProfile
       yields a Tier 1 partner whose astro.tier is "sun", and the Moon layer
       below degrades instead of guessing. */
    const partnerProfile = partnerValid
      ? computeProfile({
          name: p.partnerName, dob: p.partnerDob, mobile: "", goals: [], vehicle: "", watchType: "none",
          entrance: "unsure", kitchen: "unsure", bedroom: "unsure", toilet: "unsure", gender: "",
          birthTime: p.partnerBirthTime || "", birthPlace: p.partnerBirthPlace || ""
        })
      : null;
    const compat = partnerValid ? compatibility(p, partnerProfile) : null;
    const cRem = compat ? compatRemedies(p, partnerProfile, compat) : null;
    const moonPairing = partnerValid ? chandraBala(p, partnerProfile) : null;
    const LT = (en, hi, gu) => (lang === "hi" ? hi : lang === "gu" ? gu : en);
    /* Companion positional card. Returns "" unless the partner chart reached
       Tier 2, so the Tier 1 path is untouched. */
    const partnerAstroCardHtml = partnerValid ? partnerAstroSnapshotCard(p, partnerProfile, partnerFirst, lang) : "";
    /* Companion timing card: the partner's own classical Vimshottari stack.
       "" unless the partner chart reached Tier 2 — there is no Tier 1
       variant, and the Chandra-bala banner already asks for the missing
       partner data. */
    const partnerVimCardHtml = partnerValid ? partnerVimshottariCard(p, partnerProfile, partnerFirst, lang) : "";

    /* Compatibility remains a relationship-reflection feature. It intentionally
       does not mint a second crystal/Rudraksha checklist or a competing
       40-day remedy plan; those remain governed by the primary Lo Shu chart. */
    const compatReflectionCard = !cRem ? "" : (function () {
      const rows = [];
      const friendlyPairs = compat.pairs.filter(function (pair) { return pair.r === "friendly"; });
      const neutralPairs = compat.pairs.filter(function (pair) { return pair.r === "neutral"; });
      const pairList = function (pairs) {
        return pairs.map(function (pair) { return "<strong>" + esc(pair.a) + " × " + esc(pair.b) + "</strong>"; }).join(" · ");
      };
      const intro = (compat.verdict === "Strong" || compat.verdict === "Good")
        ? LT("This pairing has a cooperative baseline. Read the strengths, watch points and communication cues below as shared planning prompts, not as a remedial checklist.",
             "इस मिलान का सहयोगी आधार है। नीचे की शक्तियों, ध्यान-बिंदुओं और संवाद-संकेतों को साझा योजना के संकेत की तरह लें, उपाय-list की तरह नहीं।",
             "આ જોડાણનો સહયોગી આધાર છે. નીચેની શક્તિઓ, ધ્યાન-બિંદુઓ અને સંવાદ-સંકેતોને સહભાગી આયોજનના સંકેત તરીકે લો, ઉપાય-list તરીકે નહીં.")
        : LT("This pairing benefits from conscious communication. The strengths, blind spots and practical cues below help you make agreements together; they are not a replacement for professional relationship support.",
             "इस मिलान को सजग संवाद से लाभ होगा। नीचे की शक्तियां, सावधानी-बिंदु और व्यावहारिक संकेत साथ में समझौते बनाने में मदद करते हैं; ये पेशेवर relationship support का विकल्प नहीं हैं।",
             "આ જોડાણને સજાગ સંવાદથી લાભ થશે. નીચેની શક્તિઓ, સાવચેતીના મુદ્દા અને વ્યવહારુ સંકેતો સાથે મળીને કરાર બનાવવા મદદ કરે છે; તે વ્યાવસાયિક relationship support નો વિકલ્પ નથી.");
      rows.push('<div class="card" id="compatibility-reflection" data-authority="compatibility-reflection">');
      rows.push('<div class="compatibility-reflection-intro">');
      rows.push('<div class="goal-head"><div class="card-title">🤝 ' + LT("Compatibility reflection", "सामंजस्य चिंतन", "સુસંગતતા ચિંતન") + " — " + esc(p.name.split(/\s+/)[0]) + " &amp; " + esc(partnerFirst) + '</div><span class="badge ' + (compat.enemy ? "warn" : "good") + '">' + (cRem.conflicts.length ? cRem.conflicts.length + " " + LT("friction pair(s)", "घर्षण जोड़(ें)", "ઘર્ષણ જોડી(ઓ)") : LT("no major friction", "मुख्य घर्षण नहीं", "મુખ્ય ઘર્ષણ નથી")) + "</span></div>");
      rows.push('<div class="kit-value">' + intro + "</div>");
      rows.push("</div>");

      rows.push('<div class="kit-row compatibility-strengths"><div class="kit-ico">✨</div><div class="kit-body"><div class="kit-label">' + LT("Mutual strengths", "परस्पर शक्तियां", "પરસ્પર શક્તિઓ") + '</div><div class="kit-value">' + (friendlyPairs.length
        ? LT(pairList(friendlyPairs) + " form supportive lanes between your two Driver/Conductor pairs. Use these natural points of agreement for shared decisions, appreciation and momentum.",
             pairList(friendlyPairs) + " आपके दो मूलांक/भाग्यांक जोड़ों के सहयोगी मार्ग हैं। इन सहज सहमतियों को साझा निर्णय, सराहना और गति के लिए उपयोग करें।",
             pairList(friendlyPairs) + " તમારા બે મૂળાંક/ભાગ્યાંક જોડીઓ વચ્ચે સહાયક માર્ગ બનાવે છે. આ સહજ સહમતીઓનો ઉપયોગ સહભાગી નિર્ણય, પ્રશંસા અને ગતિ માટે કરો.")
        : LT("No pair is marked harmonious yet. Build strength by making expectations and repair steps explicit rather than assuming alignment.",
             "अभी कोई जोड़ी harmonious चिह्नित नहीं है। अनकही सहमति मानने के बजाय अपेक्षाएं और सुधार के कदम स्पष्ट करके शक्ति बनाएं।",
             "હજી કોઈ જોડી harmonious તરીકે ચિહ્નિત નથી. અનકહી સહમતી માનવાને બદલે અપેક્ષાઓ અને સુધારાના પગલાં સ્પષ્ટ કરીને શક્તિ બનાવો.")) + "</div></div></div>");

      if (neutralPairs.length) {
        rows.push('<div class="kit-row compatibility-watch-points"><div class="kit-ico">👀</div><div class="kit-body"><div class="kit-label">' + LT("Watch points", "ध्यान-बिंदु", "ધ્યાન-બિંદુઓ") + '</div><div class="kit-value">' + LT(pairList(neutralPairs) + " are workable rather than automatic strengths. Name assumptions early, agree roles and revisit decisions before small differences accumulate.",
          pairList(neutralPairs) + " साध्य हैं, अपने-आप बनने वाली शक्तियां नहीं। धारणाएं जल्दी स्पष्ट करें, भूमिकाएं तय करें और छोटे मतभेद बढ़ने से पहले निर्णय दोबारा देखें।",
          pairList(neutralPairs) + " સાધ્ય છે, આપમેળે બનતી શક્તિઓ નથી. ધારણાઓ વહેલી સ્પષ્ટ કરો, ભૂમિકાઓ નક્કી કરો અને નાના મતભેદ વધે તે પહેલાં નિર્ણય ફરી જુઓ.") + "</div></div></div>");
      }

      if (cRem.conflicts.length) {
        cRem.conflicts.forEach(function (c) {
          rows.push('<div class="kit-row compatibility-blind-spot"><div class="kit-ico">⚡</div><div class="kit-body"><div class="kit-label">' + LT("Potential blind spot", "संभावित सावधानी-बिंदु", "સંભવિત સાવચેતીનો મુદ્દો") + " · " + esc(c.a) + " (" + esc(c.planetA.split(" ")[0]) + ") × " + esc(c.b) + " (" + esc(c.planetB.split(" ")[0]) + ")</div>");
          rows.push(c.friction
            ? '<div class="kit-value">' + esc(c.friction[lang] || c.friction.en) + '</div><div class="compatibility-cue">🌉 <strong>' + LT("Communication cue:", "संवाद संकेत:", "સંવાદ સંકેત:") + "</strong> " + esc(c.bridge[lang] || c.bridge.en) + "</div>"
            : '<div class="compatibility-cue">🌉 <strong>' + LT("Communication cue:", "संवाद संकेत:", "સંવાદ સંકેત:") + "</strong> " + LT("Name the difference, make one small agreement, then review it together.", "अंतर को नाम दें, एक छोटा समझौता बनाएं, फिर उसे साथ में देखें।", "તફાવતને નામ આપો, એક નાનો કરાર બનાવો, પછી સાથે તેની સમીક્ષા કરો.") + "</div>");
          rows.push("</div></div>");
        });
      } else {
        rows.push('<div class="kit-row compatibility-blind-spot"><div class="kit-ico">🛡</div><div class="kit-body"><div class="kit-label">' + LT("Potential blind spots", "संभावित सावधानी-बिंदु", "સંભવિત સાવચેતીના મુદ્દા") + '</div><div class="kit-value">' + LT("No conflicting Driver/Conductor pair appears in this comparison. Protect the bond by keeping communication specific when priorities or timing differ.", "इस तुलना में कोई विरोधी मूलांक/भाग्यांक जोड़ी नहीं है। प्राथमिकताएं या समय अलग हों तो संवाद को स्पष्ट रखकर संबंध की रक्षा करें।", "આ સરખામણીમાં કોઈ વિરોધી મૂળાંક/ભાગ્યાંક જોડી નથી. પ્રાથમિકતાઓ અથવા સમય અલગ હોય ત્યારે સંવાદને સ્પષ્ટ રાખીને સંબંધનું રક્ષણ કરો.") + '</div><div class="compatibility-cue">🌉 <strong>' + LT("Communication cue:", "संवाद संकेत:", "સંવાદ સંકેત:") + '</strong> ' + LT("Keep a short recurring check-in for decisions, appreciation and any change in priorities.", "निर्णय, सराहना और प्राथमिकताओं में बदलाव के लिए छोटा नियमित check-in रखें।", "નિર્ણય, પ્રશંસા અને પ્રાથમિકતાઓમાં ફેરફાર માટે ટૂંકો નિયમિત check-in રાખો.") + "</div></div></div>");
      }

      if (cRem.bridges.length) {
        rows.push('<div class="kit-row compatibility-shared-cues"><div class="kit-ico">🌉</div><div class="kit-body"><div class="kit-label">' + LT("Shared reference numbers", "साझा संदर्भ अंक", "સહભાગી સંદર્ભ અંકો") + '</div><div class="kit-value">' + cRem.bridges.map(function (br) { return "<strong>" + br.n + "</strong> (" + esc(br.planet) + ")"; }).join(" · ") + '</div><div class="card-sub">' + LT("Use these as conversation cues for shared projects, not remedy targets, power days or event-timing instructions.", "इनको साझा परियोजनाओं के लिए संवाद-संकेत की तरह लें, remedy targets, power days या event-timing निर्देश की तरह नहीं।", "તેનો ઉપયોગ સહભાગી યોજનાઓ માટે સંવાદ-સંકેત તરીકે કરો, remedy targets, power days અથવા event-timing સૂચના તરીકે નહીં.") + "</div></div></div>");
      }
      rows.push('<div class="judge-note"><strong>' + LT("Scope:", "सीमा:", "મર્યાદા:") + "</strong> " + LT("Compatibility does not add crystals, Rudraksha, affirmations, lifestyle obligations or a second 40-day plan. Use the Lo Shu Foundation for those; use Timeline for Dasha timing and active Vastu.", "सामंजस्य crystals, Rudraksha, affirmations, lifestyle obligations या दूसरी 40-दिन योजना नहीं जोड़ता। इनके लिए लो शू Foundation और दशा समय/सक्रिय वास्तु के लिए Timeline देखें।", "સુસંગતતા crystals, Rudraksha, affirmations, lifestyle obligations અથવા બીજી ૪૦-દિવસની યોજના ઉમેરતી નથી. તેના માટે લો શુ Foundation અને દશા સમય/સક્રિય વાસ્તુ માટે Timeline જુઓ.") + "</div>");
      rows.push("</div>");
      return rows.join("");
    })();

    /* ---- Section 18 Moon layer -------------------------------------------
       Two states, no third. Either both natal Moons are computable and the
       classical Chandra-bala axis is shown with its working, or the module
       says in plain words that it was not computed and what is missing. There
       is no "approximate", no assumed noon and no default city. */
    const moonLayerHtml = !moonPairing ? "" : (function () {
      if (!moonPairing.chandraBalaComputed) {
        const needPartnerTime = moonPairing.missing.indexOf("partner-birth-time") !== -1;
        const needPartnerPlace = moonPairing.missing.indexOf("partner-birth-place") !== -1;
        const partnerPlaceUnmatched = moonPairing.missing.indexOf("partner-birth-place-unmatched") !== -1;
        const needSelfTime = moonPairing.missing.indexOf("self-birth-time") !== -1;
        const needSelfPlace = moonPairing.missing.indexOf("self-birth-place") !== -1;
        const selfPlaceUnmatched = moonPairing.missing.indexOf("self-birth-place-unmatched") !== -1;
        const askList = [];
        if (needPartnerTime || needPartnerPlace) {
          const bits = [];
          if (needPartnerTime) bits.push(LT("exact birth time", "सटीक जन्म समय", "ચોક્કસ જન્મ સમય"));
          if (needPartnerPlace) bits.push(LT("birth city / place", "जन्म शहर / स्थान", "જન્મ શહેર / સ્થળ"));
          askList.push(LT("your partner's ", "साथी का ", "સાથીદારનો ") + bits.join(LT(" and ", " और ", " અને ")));
        }
        if (partnerPlaceUnmatched) askList.push(LT("a partner birthplace the offline atlas recognises — “City, State” or coordinates like “28.41, 77.32”", "ऑफ़लाइन एटलस द्वारा पहचाना जाने वाला साथी का जन्मस्थान — “शहर, राज्य” या “28.41, 77.32” जैसे निर्देशांक", "ઑફલાઇન ઍટલસ ઓળખે તેવું સાથીદારનું જન્મસ્થળ — “શહેર, રાજ્ય” અથવા “28.41, 77.32” જેવા અક્ષાંશ/રેખાંશ"));
        if (needSelfTime || needSelfPlace) {
          const bits = [];
          if (needSelfTime) bits.push(LT("exact birth time", "सटीक जन्म समय", "ચોક્કસ જન્મ સમય"));
          if (needSelfPlace) bits.push(LT("birth city / place", "जन्म शहर / स्थान", "જન્મ શહેર / સ્થળ"));
          askList.push(LT("your own ", "आपका अपना ", "તમારો પોતાનો ") + bits.join(LT(" and ", " और ", " અને ")));
        }
        if (selfPlaceUnmatched) askList.push(LT("a birthplace of yours the offline atlas recognises", "आपका ऐसा जन्मस्थान जिसे ऑफ़लाइन एटलस पहचानता हो", "તમારું એવું જન્મસ્થળ જે ઑફલાઇન ઍટલસ ઓળખે"));
        const ask = askList.join(LT(", plus ", ", साथ ही ", ", સાથે જ "));
        return `<div class="card chandra-bala-card" id="chandra-bala" data-authority="chandra-bala" data-chandra-bala="not-computed" data-chandra-tier="1">
          <div class="goal-head">
            <div class="card-title">🌙 ${LT("Chandra-bala &amp; Vedic Moon pairing", "चंद्र-बल एवं वैदिक चंद्र मिलान", "ચંદ્ર-બલ અને વૈદિક ચંદ્ર મિલન")}</div>
            <span class="badge info">${LT("Tier 1 only", "केवल लेवल १", "ફક્ત લેવલ ૧")}</span>
          </div>
          <div class="kit-value"><strong>${LT("Chandra-bala not computed", "चंद्र-बल की गणना नहीं हुई", "ચંદ્ર-બલ ગણાયું નથી")}</strong> — ${LT("add " + ask + " (Edit Details → Compatibility) to unlock it.", ask + " जोड़ें (विवरण बदलें → संगतता) तब यह खुलेगा।", ask + " ઉમેરો (વિગત બદલો → સુસંગતતા) ત્યારે તે ખૂલશે.")}</div>
          <div class="card-sub">${LT("What you are reading below is the Driver / Conductor numerological comparison only. The Moon travels about 13°20′ a day — a full Nakshatra — so a Moon Rashi, a Nakshatra pada or a Chandra-bala verdict cannot be derived from a date of birth. Rather than assume a noon birth or a stand-in city, this layer stays uncomputed until the data exists.",
            "नीचे जो है वह केवल मूलांक / भाग्यांक अंकशास्त्रीय तुलना है। चंद्रमा प्रतिदिन लगभग १३°२०′ — पूरा एक नक्षत्र — चलता है, इसलिए चंद्र राशि, नक्षत्र पद या चंद्र-बल केवल जन्मतिथि से नहीं निकाले जा सकते। दोपहर का जन्म या कोई स्थान मान लेने के बजाय यह परत आँकड़े आने तक अगणित रहती है।",
            "નીચે જે છે તે માત્ર મૂળાંક / ભાગ્યાંક અંકશાસ્ત્રીય સરખામણી છે. ચંદ્ર રોજ આશરે ૧૩°૨૦′ — આખું એક નક્ષત્ર — ચાલે છે, તેથી ચંદ્ર રાશિ, નક્ષત્ર પાદ કે ચંદ્ર-બલ ફક્ત જન્મ તારીખથી કાઢી શકાતાં નથી. બપોરનો જન્મ કે કોઈ સ્થળ માની લેવાને બદલે આ સ્તર માહિતી આવે ત્યાં સુધી અગણિત રહે છે.")}</div>
        </div>`;
      }

      const cb = moonPairing;
      const qualityBadge = cb.axis.quality === "supportive" ? "good" : cb.axis.quality === "challenging" ? "bad" : "warn";
      const qualityWord = cb.axis.quality === "supportive"
        ? LT("Supportive", "सहायक", "સહાયક")
        : cb.axis.quality === "challenging"
          ? LT("Classical caution", "शास्त्रीय सावधानी", "શાસ્ત્રીય સાવચેતી")
          : LT("Workable", "साध्य", "સાધ્ય");
      const axisLabel = cb.axis.label ? (cb.axis.label[lang] || cb.axis.label.en) : cb.axis.key;
      const axisNote = cb.axis.note ? (cb.axis.note[lang] || cb.axis.note.en) : "";
      const moonLine = (side, first) => `<strong>${esc(first)}</strong> — ${esc(side.glyph)} ${esc(side.sign)} ${esc(side.degStr)} (${LT("lord", "स्वामी", "સ્વામી")} ${esc(side.lord)})${side.nakshatra ? ` · ${esc(side.nakshatra.glyph)} ${esc(side.nakshatra.name)} ${LT("pada", "पद", "પાદ")} ${side.nakshatra.pada}` : ""}`;
      return `<div class="card chandra-bala-card" id="chandra-bala" data-authority="chandra-bala" data-chandra-bala="computed" data-chandra-tier="2" data-chandra-axis="${esc(cb.axis.key)}">
        <div class="goal-head">
          <div class="card-title">🌙 ${LT("Chandra-bala verdict", "चंद्र-बल निर्णय", "ચંદ્ર-બલ નિર્ણય")} — ${esc(axisLabel)}</div>
          <span class="badge ${qualityBadge}">${esc(qualityWord)} · ${esc(cb.axis.key)}</span>
        </div>
        <div class="kit-value">${moonLine(cb.self, p.name.split(/\s+/)[0])}</div>
        <div class="kit-value">${moonLine(cb.partner, partnerFirst)}</div>
        <div class="kit-value">${LT(`Counted from your Moon, the partner's Moon stands in the <strong>${houseOrdinal(cb.axis.forward, lang)}</strong>; counted back, yours stands in the <strong>${houseOrdinal(cb.axis.reverse, lang)}</strong> — the <strong>${esc(cb.axis.sanskrit)}</strong> relationship.`,
          `आपके चंद्र से गिनने पर साथी का चंद्र <strong>${cb.axis.forward}</strong>वें भाव में है; उल्टा गिनने पर आपका <strong>${cb.axis.reverse}</strong>वें भाव में — यह <strong>${esc(cb.axis.sanskrit)}</strong> संबंध है।`,
          `તમારા ચંદ્રથી ગણતાં સાથીદારનો ચંદ્ર <strong>${cb.axis.forward}</strong>મા ભાવમાં છે; ઊલટું ગણતાં તમારો <strong>${cb.axis.reverse}</strong>મા ભાવમાં — આ <strong>${esc(cb.axis.sanskrit)}</strong> સંબંધ છે.`)}</div>
        <div class="kit-value">${esc(axisNote)}</div>
        ${cb.doshaRelaxedBySharedLord ? `<div class="chandra-bala-relax">${LT("Both Moon signs share the same rashi lord (" + esc(cb.self.lord) + "), which a widely-followed classical rule treats as cancelling this dosha. Schools differ on the scope of that cancellation, so it is reported as a fact of the chart, not applied as a score.",
          "दोनों चंद्र राशियों का स्वामी एक ही है (" + esc(cb.self.lord) + "), जिसे एक व्यापक रूप से मान्य शास्त्रीय नियम इस दोष का निवारण मानता है। इस निवारण की सीमा पर मत भिन्न हैं, इसलिए इसे कुंडली का तथ्य बताया गया है, अंक के रूप में लागू नहीं किया गया।",
          "બંને ચંદ્ર રાશિઓનો સ્વામી એક જ છે (" + esc(cb.self.lord) + "), જેને વ્યાપકપણે માન્ય શાસ્ત્રીય નિયમ આ દોષનું નિવારણ ગણે છે. તે નિવારણની મર્યાદા વિશે મતભેદ છે, તેથી તેને કુંડળીની હકીકત તરીકે જણાવ્યું છે, ગુણ તરીકે લાગુ કર્યું નથી.")}</div>` : ""}
        ${cb.tara && cb.tara.computed ? (() => {
          const tb = cb.tara;
          const word = (d) => d.auspicious
            ? LT("traditionally auspicious", "पारम्परिक रूप से शुभ", "પારંપરાગત રીતે શુભ")
            : LT("traditionally inauspicious", "पारम्परिक रूप से अशुभ", "પારંપરાગત રીતે અશુભ");
          const overall = tb.bothAuspicious
            ? LT("Both directions are traditionally auspicious.",
               "दोनों दिशाएं पारम्परिक रूप से शुभ हैं।",
               "બંને દિશા પારંપરાગત રીતે શુભ છે.")
            : tb.bothInauspicious
              ? LT("Both directions are traditionally inauspicious.",
                 "दोनों दिशाएं पारम्परिक रूप से अशुभ हैं।",
                 "બંને દિશા પારંપરાગત રીતે અશુભ છે.")
              : LT("One direction is traditionally auspicious and the other traditionally inauspicious — the traditional reading is mixed, reported here as the fact of the two charts rather than averaged away.",
                 "एक दिशा पारम्परिक रूप से शुभ है और दूसरी पारम्परिक रूप से अशुभ — पारम्परिक पठन मिश्र है, इसे यहाँ दोनों कुंडलियों का तथ्य बताया गया है, औसत में घोलकर नहीं।",
                 "એક દિશા પારંપરાગત રીતે શુભ છે અને બીજી પારંપરાગત રીતે અશુભ — પારંપરાગત વાંચન મિશ્ર છે, તે અહીં બંને કુંડળીઓનું તથ્ય તરીકે જણાવવામાં આવ્યું છે, સરેરાશમાં ભળાડ્યા વગર.");
          return `<div id="tara-bala" data-tara="computed" data-tara-fwd="${tb.forward.count}" data-tara-rev="${tb.reverse.count}" data-tara-fwd-rem="${tb.forward.remainder}" data-tara-rev-rem="${tb.reverse.remainder}" data-tara-verdict="${tb.bothAuspicious ? "auspicious" : tb.bothInauspicious ? "inauspicious" : "mixed"}">
            <div class="card-title chandra-bala-subhead">🌟 ${LT("Tara Bala — Nakshatra-level layer", "तारा बल — नक्षत्र-स्तर की परत", "તારા બલ — નક્ષત્ર-સ્તરની સ્તર")}</div>
            <div class="kit-value">${LT(`Counted from ${esc(partnerFirst)}'s Moon Nakshatra (${esc(tb.partnerNak.name)}) to yours (${esc(tb.selfNak.name)}), the span is <strong>${tb.forward.count} Nakshatras</strong> — remainder <strong>${tb.forward.remainder}</strong> on division by 9, ${word(tb.forward)}. Counted the other way, the span is <strong>${tb.reverse.count}</strong> — remainder <strong>${tb.reverse.remainder}</strong>, ${word(tb.reverse)}. ${overall}`,
              `${esc(partnerFirst)} के चंद्र नक्षत्र (${esc(tb.partnerNak.name)}) से आपके चंद्र नक्षत्र (${esc(tb.selfNak.name)}) तक गिनती <strong>${tb.forward.count} नक्षत्र</strong> है — ९ से भाग देने पर शेष <strong>${tb.forward.remainder}</strong>, ${word(tb.forward)}। उल्टी गिनती में दूरी <strong>${tb.reverse.count}</strong> — शेष <strong>${tb.reverse.remainder}</strong>, ${word(tb.reverse)}। ${overall}`,
              `${esc(partnerFirst)}ના ચંદ્ર નક્ષત્ર (${esc(tb.partnerNak.name)})થી તમારા ચંદ્ર નક્ષત્ર (${esc(tb.selfNak.name)}) સુધી ગણતરી <strong>${tb.forward.count} નક્ષત્ર</strong> છે — ૯ વડે ભાગતાં શેષ <strong>${tb.forward.remainder}</strong>, ${word(tb.forward)}। ઊલટી ગણતરીમાં અંતર <strong>${tb.reverse.count}</strong> — શેષ <strong>${tb.reverse.remainder}</strong>, ${word(tb.reverse)}। ${overall}`)}</div>
            ${tb.sameNakshatra ? `<div class="chandra-bala-relax">${LT("Both Moons share one Nakshatra — Janma Tara, the count is 1 in both directions. Schools differ on how they read this case, so it is reported as a fact of the charts rather than a fixed verdict.",
              "दोनों चंद्र एक ही नक्षत्र में हैं — जन्म तारा, दोनों दिशाओं में गिनती १ है। इस स्थिति को पढ़ने पर शास्त्रों में मतभेद है, इसलिए इसे कुंडलियों का तथ्य बताया गया है, स्थिर निर्णय की तरह नहीं।",
              "બંને ચંદ્ર એક જ નક્ષત્રમાં છે — જન્મ તારા, બંને દિશાઓમાં ગણતરી ૧ છે. આ સ્થિતિને વાંચવામાં શાસ્ત્રોનો મતભેદ છે, તેથી તેને કુંડળીઓનું તથ્ય જણાવવામાં આવ્યું છે, સ્થિર નિર્ણય તરીકે નહીં.")}</div>` : ""}
            <div class="card-sub">${LT("Tara is one of the eight classical Ashtakoota factors. It is reported here with its own working — not folded into any 36-point score — and it prescribes nothing: no remedy, no muhurtha, no Vastu zone.",
              "तारा आठ शास्त्रीय अष्टकूट घटकों में से एक है। यह यहाँ अपनी गिनती के साथ बताया गया है — कोई ३६-गुण अंक इसमें नहीं जाता — और यह कुछ भी निर्धारित नहीं करता: न उपाय, न मुहूर्त, न वास्तु क्षेत्र।",
              "તારા આઠ શાસ્ત્રીય અષ્ટકૂટ ઘટકોમાંથી એક છે. તે અહીં પોતાની ગણતરી સાથે જણાવવામાં આવી છે — કોઈ ૩૬-ગુણ અંક તેમાં જોડતો નથી — અને તે કશું નિર્ધારિત કરતું નથી: ન ઉપાય, ન મુહૂર્ત, ન વાસ્તુ પ્રદેશ.")}</div>
          </div>`;
        })() : ""}
        <div class="judge-note"><strong>${LT("Scope:", "सीमा:", "મર્યાદા:")}</strong> ${LT("This card carries two classical Moon-pairing read-outs, computed on this device from both birth times and places: the Rashi (Bhakoot) axis between the two natal Moons, and the Nakshatra-level Tara count beneath it. It is not a 36-point Ashtakoota score — Gana, Nadi, Yoni and Graha Maitri are not computed — and it prescribes nothing: no remedy, no muhurtha, no Vastu zone.",
          "यह कार्ड दो शास्त्रीय चंद्र-मिलान पठन रखता है, जो दोनों के जन्म समय व स्थान से इसी डिवाइस पर गणित हैं: दोनों जन्म-चंद्रों के बीच का राशि (भकूट) अक्ष, और उसके नीचे नक्षत्र-स्तर की तारा गिनती। यह ३६ गुण अष्टकूट मिलान नहीं है — गण, नाड़ी, योनि और ग्रह मैत्री की गणना नहीं हुई — और यह कुछ भी निर्धारित नहीं करता: न उपाय, न मुहूर्त, न वास्तु क्षेत्र।",
          "આ કાર્ડ બે શાસ્ત્રીય ચંદ્ર-મિલાન વાંચન ધરાવે છે, જે બંનેના જન્મ સમય અને સ્થળથી આ જ ડિવાઇસ પર ગણાય છે: બંને જન્મ-ચંદ્રો વચ્ચેનો રાશિ (ભકૂટ) અક્ષ, અને તેની નીચે નક્ષત્ર-સ્તરની તારા ગણતરી. તે ૩૬ ગુણ અષ્ટકૂટ મિલન નથી — ગણ, નાડી, યોનિ અને ગ્રહ મૈત્રી ગણાયાં નથી — અને તે કશું નિર્ધારિત કરતું નથી: ન ઉપાય, ન મુહૂર્ત, ન વાસ્તુ પ્રદેશ.")}</div>
      </div>`;
    })();

    const compatSection = `<section class="rsection" id="compatibility-section">
      <div class="compatibility-overview">
        <h2 class="rsection-title"><span class="idx">${SECTION.compatibility}</span>${t("secCompat", "Compatibility & Matchmaking")}</h2>
        ${compat ? `<p class="rsection-desc">Pairwise Driver / Conductor match between <strong>${esc(p.name)}</strong> and <strong>${esc(p.partnerName)}</strong> (marriage or business partnership).</p>
          ${moonPairing && !moonPairing.chandraBalaComputed ? moonLayerHtml : ""}
          <div class="card compatibility-overview-card">
            <div class="goal-head">
              <div class="card-title">Overall verdict: ${compat.verdict}</div>
              <span class="badge ${compat.verdict === "Strong" || compat.verdict === "Good" ? "good" : compat.verdict === "Workable" ? "warn" : "bad"}">${compat.friendly} harmonious · ${compat.neutral} neutral · ${compat.enemy} conflicting</span>
            </div>
            <div class="table-scroll"><table class="rtable">
              <tr><th>Pairing</th><th>Relation</th></tr>
              ${compat.pairs.map((pr) => `<tr><td>${esc(pr.a)} × ${esc(pr.b)}</td><td>${relBadge(pr.r)}</td></tr>`).join("")}
            </table></div>
            <div class="kit-value">${compat.verdict === "Strong" ? (lang === "hi" ? "स्वाभाविक रूप से सहयोगी और शुभ मिलान — आपके अंक एक दूसरे को शक्ति देते हैं।" : lang === "gu" ? "કુદરતી રીતે સહયોગી અને શુભ મિલાન — તમારા અંકો એકબીજાને બળ આપે છે." : "A naturally cooperative pairing — your numbers reinforce each other.") : compat.verdict === "Good" ? (lang === "hi" ? "सकारात्मक और अनुकूल मिलान — कुछ सामान्य कड़ियों के साथ यह संबंध सुखद रहेगा।" : lang === "gu" ? "હકારાત્મક અને અનુકૂળ મિલાન — કેટલીક સામાન્ય કડીઓ સાથે આ સંબંધ સુખદ રહેશે." : "A supportive pairing with a couple of neutral links — manageable and mostly aligned.") : compat.verdict === "Workable" ? (lang === "hi" ? "साध्य मिलान, किंतु थोड़ा प्रयास आवश्यक है — प्रतिकूल कड़ियों पर समझदारी जरूरी है।" : lang === "gu" ? "સાધ્ય મિલાન, પણ થોડો પ્રયાસ જરૂરી છે — પ્રતિકૂળ કડીઓ પર સમજણ જરૂરી છે." : "Workable, but needs conscious effort — the conflicting links are the areas to manage.") : (lang === "hi" ? "चुनौतीपूर्ण मिलान — विरोधी अंकों के प्रभाव को समझने के लिए साफ संवाद और व्यवहारिक समझौते जरूरी हैं।" : lang === "gu" ? "પડકારરૂપ મિલાન — વિરોધી અંકોના પ્રભાવને સમજવા માટે સ્પષ્ટ સંવાદ અને વ્યવહારુ સમજોતાં જરૂરી છે." : "Challenging pairing — the conflicting numbers need clear communication and practical agreements to bridge.")}</div>
          </div>
          ${moonPairing && moonPairing.chandraBalaComputed ? moonLayerHtml : ""}
          ${partnerAstroCardHtml}
          ${partnerVimCardHtml}`
        : `<div class="card compatibility-overview-card">
            <div class="card-title">${lang === "hi" ? "आपके लिए कौन से अंक अनुकूल हैं?" : lang === "gu" ? "તમારા માટે કયા અંકો અનુકૂળ છે?" : "Who are you compatible with?"}</div>
            <div class="kit-value">${lang === "hi" ? "पूर्ण मिलान के लिए पार्टनर का नाम और जन्मतिथि जोड़ें। इस बीच, यहां देखें कि आपके अंक अन्य मूलांकों से कैसे मेल खाते हैं:" : lang === "gu" ? "સંપૂર્ણ મિલાન માટે પાર્ટનરનું નામ અને જન્મ તારીખ ઉમેરો. દરમિયાન, અહીં જુઓ કે તમારા અંકો અન્ય મૂળાંકો સાથે કેવી રીતે મેળ ખાય છે:" : "Add a <strong>partner's name and date of birth</strong> (Edit Details → Compatibility) for a full two-person Driver / Conductor match. Meanwhile, here is how your numbers relate to every other Driver:"}</div>
            <div class="table-scroll"><table class="rtable">
              <tr><th>${lang === "hi" ? "अन्य व्यक्ति का मूलांक" : lang === "gu" ? "અન્ય વ્યક્તિનો મૂળાંક" : "Other person's Driver"}</th><th>vs your Driver ${p.driver}</th><th>vs your Conductor ${p.conductor}</th></tr>
              ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<tr><td><strong>${n}</strong> (${esc(db.numbers[n].planet.split(" ")[0])})</td><td>${relBadge(relation(p.driver, n))}</td><td>${relBadge(relation(p.conductor, n))}</td></tr>`).join("")}
            </table></div>
          </div>`}
      </div>
      ${compat ? compatReflectionCard : ""}
    </section>`;

    const goalsStart = SECTION.goalsStart;
    /* Copy-paste redundancy fix (2026-09 audit): Money, Business and Career all
       map to the same missing number (e.g. missing 5) used to emit three
       byte-identical full pages of the same beej mantra, crystals and guardrails.
       We now aggregate goals whose remedy signature is identical into a single
       "Combined Strategic Focus" section rendered exactly once. Health stays in
       its own section because it carries distinct clinical banners. */
    const goalSig = (g) => g.goal === "Health"
      ? "health"
      : `w:${g.weak.slice().sort((a, b) => a - b).join(",")}|f:${g.focus.map((f) => f.n).sort((a, b) => a - b).join(",")}`;
    const goalGroups = [];
    goals.forEach((g) => {
      const sig = goalSig(g);
      const last = goalGroups[goalGroups.length - 1];
      if (last && last.sig === sig && g.goal !== "Health") last.goals.push(g);
      else goalGroups.push({ sig, goals: [g] });
    });
    const goalSections = goalGroups.map((group, i) => {
      const names = group.goals.map((g) => g.goal);
      const merged = names.length > 1;
      const first = group.goals[0];
      const weakNums = first.weak;
      // De-duplicate the remedy kits by number so a combined group never
      // repeats the same planet's card.
      const seenKit = new Set();
      const kits = [];
      group.goals.forEach((g) => g.focus.forEach((f) => {
        if (!seenKit.has(f.n)) { seenKit.add(f.n); kits.push(f); }
      }));
      const focusPlanet = kits.length ? esc(db.numbers[kits[0].n].planet.split(" ")[0]) : "";
      const focusNum = kits.length ? kits[0].n : null;
      const titleSuffix = merged
        ? (lang === "hi" ? "संयुक्त रणनीतिक फोकस" : lang === "gu" ? "સંયુક્ત વ્યૂહાત્મક ફોકસ" : "Combined Strategic Focus")
        : (lang === "hi" ? "लो शू उपाय फोकस" : lang === "gu" ? "લો શુ ઉપાય ફોકસ" : "Lo Shu Remedy Focus");
      const title = merged && focusNum
        ? `${titleSuffix}: ${names.map(esc).join(", ")} (${focusPlanet} ${focusNum})`
        : `${names.map(esc).join(", ")} — ${titleSuffix}`;
      // Health focus carries the Moon-cold banner at section level (the Moon
      // governs Health), plus an echo of any intake Health sub-tags.
      const isHealth = first.goal === "Health";
      const healthBanner = isHealth ? moonColdHealthFocusHtml(p, lang) : "";
      const doshaHealthBanner = isHealth ? doshaContraHealthFocusHtml(p, lang) : "";
      const taggedHealth = isHealth ? healthTagsOf(p) : [];
      const healthTagLine = taggedHealth.length
        ? `<p class="rsection-desc" data-health-tags="${esc(taggedHealth.join(","))}">${lang === "hi" ? "आपने चुना" : lang === "gu" ? "તમે પસંદ કર્યું" : "You flagged"}: <strong>${taggedHealth.map((tag) => esc(healthTagLabel(tag, lang))).join(" · ")}</strong></p>`
        : "";
      const mergedIntro = merged
        ? (lang === "hi" ? `<p class="rsection-desc" data-combined-goals="${esc(names.join(","))}">${names.map(esc).join(", ")} — ये सभी लक्ष्य एक ही अनुपस्थित लो शू अंक <strong>${weakNums.join(", ")}</strong> से जुड़ते हैं, इसलिए इनका उपाय-सेट एक ही बार दिया गया है (दोहराया नहीं)।</p>` : lang === "gu" ? `<p class="rsection-desc" data-combined-goals="${esc(names.join(","))}">${names.map(esc).join(", ")} — આ બધા લક્ષ્યો એક જ ખૂટતા લો શુ અંક <strong>${weakNums.join(", ")}</strong> સાથે જોડાય છે, એટલે તેમનો ઉપાય-સેટ એક જ વાર અપાયો છે (પુનરાવર્તિત નથી).</p>` : `<p class="rsection-desc" data-combined-goals="${esc(names.join(","))}">${names.map(esc).join(", ")} all map to the same missing Lo Shu number${weakNums.length > 1 ? "s" : ""} <strong>${weakNums.join(", ")}</strong>, so their remedy set is presented once below — not repeated once per goal.</p>`)
        : "";
      return `<section class="rsection" data-remedy-authority="lo-shu"${merged ? ' data-goal-aggregation="combined"' : ""}>
      <h2 class="rsection-title"><span class="idx">${goalsStart + i}</span>${title}</h2>
      ${mergedIntro}
      <p class="rsection-desc">${first.weak.length
        ? (lang === "hi" ? `आपके लो शू जन्म-ग्रिड में अनुपस्थित अंक <strong>${first.weak.join(", ")}</strong> इस फोकस के लिए practice targets हैं।` : lang === "gu" ? `તમારા લો શુ જન્મ-ગ્રિડમાં ખૂટતા અંક <strong>${first.weak.join(", ")}</strong> આ ફોકસ માટે practice targets છે.` : `Missing Lo Shu Birth Grid number${first.weak.length > 1 ? "s" : ""} <strong>${first.weak.join(", ")}</strong> ${merged ? "are" : "is"} the practice target${first.weak.length > 1 ? "s" : ""} for this focus.`)
        : (lang === "hi" ? "इस फोकस से जुड़े लो शू अंक उपस्थित हैं — कोई अतिरिक्त remedy kit आवश्यक नहीं है।" : lang === "gu" ? "આ ફોકસ સાથે જોડાયેલા લો શુ અંકો હાજર છે — વધારાની remedy kit જરૂરી નથી." : `The Lo Shu numbers connected to this focus are present — no extra remedy kit is required.`)}</p>
      ${healthTagLine}
      ${healthBanner}
      ${doshaHealthBanner}
      ${first.weak.length ? `<div class="card-grid two">${kits.map((f) => kitCard(f.n, undefined, p)).join("")}</div>` : `<div class="card"><div class="kit-value">${lang === "hi" ? "40-दिन की लो शू practice में पहले से चुने गए missing/repeated signal पर बने रहें; किसी present number को नया remedy target न बनाएं।" : lang === "gu" ? "૪૦-દિવસના લો શુ અભ્યાસમાં પહેલેથી પસંદ કરેલા missing/repeated signal પર જ રહો; કોઈ present number ને નવો remedy target ન બનાવો." : "Stay with the missing/repeated signal already selected in your 40-day Lo Shu practice; do not turn a present number into a new remedy target."}</div></div>`}
    </section>`;
    }).join("");

    const cadenceLabel = {
      daily: lang === "hi" ? "दैनिक" : lang === "gu" ? "દૈનિક" : "Daily",
      weekly: lang === "hi" ? "साप्ताहिक" : lang === "gu" ? "સાપ્તાહિક" : "Weekly",
      once: lang === "hi" ? "एक बार" : lang === "gu" ? "એક વાર" : "One-time"
    };
    const planKey = state.activeProfileKey || profileKeyOf(p);
    const planState = readPlan(planKey);
    const PLAN_DAYS = 40;
    const planDays = Array.from({ length: PLAN_DAYS }, (_, i) => !!planState.days[i]);
    const planDone = planDays.filter(Boolean).length;
    const planNext = planDays.indexOf(false);
    const planStatus = planDone >= PLAN_DAYS
      ? (lang === "hi" ? `मंडल पूर्ण — ४० में से ४० दिन संपन्न! अब प्रगति चार्ट में परिणाम देखें।` : lang === "gu" ? `મંડળ પૂર્ણ — ૪૦ માંથી ૪૦ દિવસ સંપન્ન! હવે પ્રગતિ ચાર્ટમાં પરિણામો જુઓ.` : `Mandala complete — ${PLAN_DAYS} of ${PLAN_DAYS} days done. Now review what shifted in Your Evolving Chart (Section ${SECTION.memory}).`)
      : planDone === 0
        ? (lang === "hi" ? `अपने लो शू अभ्यास के साथ आज शुरुआत करें और दिन १ पर टैप करें। निरंतरता ही उपाय है।` : lang === "gu" ? `તમારા લો શુ અભ્યાસ સાથે આજે શરૂઆત કરો અને દિવસ ૧ પર ટેપ કરો. સાતત્ય જ ઉપાય છે.` : `Begin your Lo Shu practice today, then tap Day 1. Consistency is the remedy.`)
        : (lang === "hi" ? `${planDone} / ${PLAN_DAYS} दिन पूर्ण — अगला दिन ${planNext + 1} है। नियम न तोड़ें।` : lang === "gu" ? `${planDone} / ${PLAN_DAYS} દિવસ પૂર્ણ — આગામી દિવસ ${planNext + 1} છે. સાતત્ય જાળવી રાખો.` : `${planDone} of ${PLAN_DAYS} days done — Day ${planNext + 1} is next${planNext + 1 <= PLAN_DAYS ? `, ${PLAN_DAYS - planDone} day${PLAN_DAYS - planDone === 1 ? "" : "s"} to go` : ""}. Keep the thread unbroken.`);

    /* Calendar export. Counts are resolved up front so the card can tell
       the client exactly how many entries each checkbox will add to their
       calendar before they commit to importing anything — the opposite of
       a notification they never agreed to. */
    const icsPreview = practiceCalendarPlan(p, activation, planState, {
      profileKey: planKey,
      include: { practice: true, phases: true, power: true, dates: true, windows: true }
    });
    const icsOpt = (keyName, checked, label, count) => `<label class="ics-opt"><input type="checkbox" data-ics-opt="${keyName}"${checked ? " checked" : ""}><span class="ics-opt-label">${label}</span><span class="ics-count" data-ics-count="${keyName}">${count}</span></label>`;
    const icsCard = !icsPreview.ok ? "" : `<div class="card ics-card" data-ics-export="ok" data-ics-sunrise="${icsPreview.sunrise ? "computed" : "nominal"}">
        <div class="goal-head">
          <div class="card-title">${triText(lang, "Export to your own calendar (.ics)", "अपने कैलेंडर में निर्यात करें (.ics)", "તમારા પોતાના કેલેન્ડરમાં નિકાસ કરો (.ics)")}</div>
          <span class="badge info">${triText(lang, "On-device", "डिवाइस पर", "ડિવાઇસ પર")}</span>
        </div>
        <div class="card-sub">${triText(lang,
          "Writes a standard calendar file on this device and hands it to you. Import it into Google, Apple or Outlook and your practice sits beside the rest of your life. There is no notification service here, nothing to subscribe to and nothing that reports back — once the file is downloaded this app is out of the loop.",
          "यह डिवाइस पर एक मानक कैलेंडर फ़ाइल बनाकर आपको देता है। इसे Google, Apple या Outlook में आयात करें और आपका अभ्यास बाकी जीवन के साथ दिखेगा। यहाँ कोई notification सेवा नहीं, कोई subscription नहीं और कुछ भी वापस रिपोर्ट नहीं होता — फ़ाइल डाउनलोड होते ही यह ऐप बीच से हट जाता है।",
          "આ ડિવાઇસ પર એક પ્રમાણભૂત કેલેન્ડર ફાઇલ બનાવીને તમને આપે છે. તેને Google, Apple કે Outlook માં આયાત કરો અને તમારો અભ્યાસ બાકીના જીવન સાથે દેખાશે. અહીં કોઈ notification સેવા નથી, કોઈ subscription નથી અને કશું પાછું રિપોર્ટ થતું નથી — ફાઇલ ડાઉનલોડ થતાં જ આ એપ વચ્ચેથી હટી જાય છે."
        )}</div>
        <div class="ics-options">
          ${icsOpt("practice", true, triText(lang, "Daily practice at your sunrise", "आपके सूर्योदय पर दैनिक अभ्यास", "તમારા સૂર્યોદય પર દૈનિક અભ્યાસ"), icsPreview.counts.practice)}
          ${icsOpt("phases", true, triText(lang, "Phase milestones", "चरण-पड़ाव", "તબક્કાના પડાવ"), icsPreview.counts.phases)}
          ${icsOpt("power", true, triText(lang, "Power-day check-ins", "पावर-डे चेक-इन", "પાવર-ડે ચેક-ઇન"), icsPreview.counts.power)}
          ${icsOpt("dates", false, triText(lang, "Favourable dates from Section " + SECTION.cycles, "खंड " + SECTION.cycles + " की अनुकूल तिथियाँ", "વિભાગ " + SECTION.cycles + " ની અનુકૂળ તારીખો"), icsPreview.counts.dates)}
          ${icsPreview.counts.windows ? icsOpt("windows", false, triText(lang, "Rahu / Yamaganda / Gulika windows", "राहु / यमगंड / गुलिक काल", "રાહુ / યમગંડ / ગુલિક કાળ"), icsPreview.counts.windows) : ""}
          ${icsOpt("alarm", false, triText(lang, "Add a 10-minute reminder to each practice entry", "प्रत्येक अभ्यास प्रविष्टि पर १० मिनट पहले स्मरण जोड़ें", "દરેક અભ્યાસ એન્ટ્રી પર ૧૦ મિનિટ પહેલાં સ્મરણ ઉમેરો"), "")}
        </div>
        <div class="ics-actions">
          <button class="btn btn-primary btn-32" type="button" data-ics-download>${triText(lang, "Download calendar file", "कैलेंडर फ़ाइल डाउनलोड करें", "કેલેન્ડર ફાઇલ ડાઉનલોડ કરો")}</button>
          <span class="ics-total" data-ics-total></span>
        </div>
        <div class="judge-note">
          <p>${icsPreview.sunrise
            ? triText(lang,
                `Each of the 40 entries carries that day's own sunrise for ${esc(icsPreview.placeName)} — sunrise moves by around 25 minutes across a 40-day cycle, so one repeating alarm would be wrong for most of it. Sitting length is ${icsPreview.practiceMinutes} minutes, taken from the practice depth you chose.`,
                `चालीसों प्रविष्टियाँ ${esc(icsPreview.placeName)} के उसी दिन के सूर्योदय पर बनी हैं — ४० दिनों में सूर्योदय लगभग २५ मिनट खिसकता है, अतः एक ही दोहराया अलार्म अधिकांश दिनों में ग़लत होता। बैठक की अवधि ${icsPreview.practiceMinutes} मिनट है, जो आपकी चुनी हुई अभ्यास-गहराई से आती है।`,
                `ચાલીસેય એન્ટ્રી ${esc(icsPreview.placeName)} ના તે જ દિવસના સૂર્યોદય પર બની છે — ૪૦ દિવસમાં સૂર્યોદય આશરે ૨૫ મિનિટ ખસે છે, તેથી એક જ પુનરાવર્તિત એલાર્મ મોટા ભાગના દિવસોમાં ખોટો પડે. બેઠકની અવધિ ${icsPreview.practiceMinutes} મિનિટ છે, જે તમે પસંદ કરેલી અભ્યાસ-ઊંડાઈમાંથી આવે છે.`)
            : triText(lang,
                "No birthplace is on file, so the daily entries use a nominal 6:30 AM slot. Add a recognised birthplace in Edit Details and re-export to get your real sunrise on every day of the cycle.",
                "फ़ाइल में जन्मस्थान नहीं है, अतः दैनिक प्रविष्टियाँ नाममात्र ६:३० AM पर हैं। विवरण संपादित करें में मान्य जन्मस्थान जोड़कर पुनः निर्यात करें — तब हर दिन का वास्तविक सूर्योदय मिलेगा।",
                "ફાઇલમાં જન્મસ્થળ નથી, તેથી દૈનિક એન્ટ્રી નામમાત્ર ૬:૩૦ AM પર છે. વિગતો સંપાદિત કરોમાં માન્ય જન્મસ્થળ ઉમેરીને ફરી નિકાસ કરો — ત્યારે દરેક દિવસનો વાસ્તવિક સૂર્યોદય મળશે.")}</p>
          <p>${triText(lang,
            "Times are written as plain local clock times, so they stay where you put them and do not shift if you travel. The file identifies your entries by a one-way hash, never by your name or date of birth — so importing it into a shared or work calendar reveals nothing about your chart. Re-exporting updates these same entries instead of duplicating them.",
            "समय सामान्य स्थानीय घड़ी के अनुसार लिखे गए हैं — वे वहीं रहते हैं और यात्रा करने पर नहीं खिसकते। फ़ाइल आपकी प्रविष्टियों को एकतरफ़ा hash से पहचानती है, नाम या जन्मतिथि से कभी नहीं — अतः साझा या कार्यालयी कैलेंडर में आयात करने पर आपकी कुंडली का कुछ भी उजागर नहीं होता। पुनः निर्यात इन्हीं प्रविष्टियों को अद्यतन करता है, नई नहीं बनाता।",
            "સમય સામાન્ય સ્થાનિક ઘડિયાળ મુજબ લખાયા છે — તે ત્યાં જ રહે છે અને મુસાફરી કરતાં ખસતા નથી. ફાઇલ તમારી એન્ટ્રીઓને એકતરફી hash થી ઓળખે છે, નામ કે જન્મતારીખથી ક્યારેય નહીં — તેથી સહિયારા કે ઓફિસના કેલેન્ડરમાં આયાત કરતાં તમારી કુંડળીનું કશું ઉઘાડું પડતું નથી. ફરી નિકાસ આ જ એન્ટ્રીઓ અપડેટ કરે છે, નવી બનાવતો નથી.")}</p>
        </div>
      </div>`;

    const prioritySection = `<section class="rsection" id="plan-section" data-remedy-authority="lo-shu">
      <h2 class="rsection-title"><span class="idx">${goalsStart + goals.length}</span>${t("secPlan", "Your 40-Day Activation Plan")}</h2>
      <p class="rsection-desc">${lang === "hi" ? "४० दिन का मंडल आपके लो शू जन्म-ग्रिड के अनुपस्थित और दोहराए संकेतों से चुना जाता है। मंत्र, affirmation, crystal, Rudraksha और आदतों का यह एकमात्र remedy अभ्यास है। मूलांक/भाग्यांक के power days नीचे केवल अलग scheduling reference हैं; दशा की तारीखें और सक्रिय वास्तु क्षेत्र Timeline में रहते हैं।" : lang === "gu" ? "૪૦ દિવસનું મંડળ તમારા લો શુ જન્મ-ગ્રિડના ખૂટતા અને પુનરાવર્તિત સંકેતો પરથી પસંદ થાય છે. મંત્ર, affirmation, crystal, Rudraksha અને ટેવોનો આ એકમાત્ર remedy અભ્યાસ છે. મૂળાંક/ભાગ્યાંકના power days નીચે ફક્ત અલગ scheduling reference છે; દશાની તારીખો અને સક્રિય વાસ્તુ ક્ષેત્ર સમયરેખામાં રહે છે." : "This 40-day mandala is selected from missing and repeated signals in your Lo Shu Birth Grid. It is the one remedy practice for mantras, affirmations, crystals, Rudraksha and habits. Driver/Conductor power days below are a separate scheduling reference only; Dasha dates and the active Vastu zone live in Timeline."}</p>
      <div class="card-grid two">
        <div class="card ritual-card" data-remedy-authority="lo-shu" data-ritual-target="${activation.targetN}" data-ritual-mode="${activation.tier1Mode}">
          <div class="card-title">${lang === "hi" ? "आपकी लो शू दैनिक मुख्य साधना" : lang === "gu" ? "તમારી લો શુ દૈનિક મુખ્ય સાધના" : "Your Lo Shu Daily Core Ritual"}</div>
          <div class="kit">
            ${activation.daily.map((row) => `<div class="kit-row"><div class="kit-ico">${row.ico}</div><div class="kit-body"><div class="kit-label">${row.label}</div><div class="kit-value">${row.value}<br><span class="card-sub">${row.sub}</span></div></div></div>`).join("")}
            ${(activation.targetN === 2 && !activation.holdJapa) ? moonColdKitGuardrailHtml(activation.targetN, p, lang) : ""}
            ${!activation.holdJapa ? doshaContraKitGuardrailHtml(activation.targetN, p, lang) : ""}
            <div class="kit-row ritual-triage-sync" data-ritual-sync="${activation.tier1Mode}"><div class="kit-ico">🎯</div><div class="kit-body"><div class="kit-label">${lang === "hi" ? "ट्राइएज सिंक" : lang === "gu" ? "ટ્રાયએજ સિંક" : "Triage sync"}</div><div class="kit-value">${activation.triageNote}</div></div></div>
          </div>
        </div>
        <div class="card" data-authority="driver-conductor">
          <div class="card-title">${lang === "hi" ? "मूलांक / भाग्यांक Power Days" : lang === "gu" ? "મૂળાંક / ભાગ્યાંક Power Days" : "Driver / Conductor Power Days"}</div>
          <div class="card-sub">${lang === "hi" ? "ये केवल मूलांक और भाग्यांक से आते हैं। ये लो शू के remedy targets को नहीं चुनते या बदलते।" : lang === "gu" ? "આ ફક્ત મૂળાંક અને ભાગ્યાંક પરથી આવે છે. તે લો શુના remedy targets પસંદ કરતા કે બદલતા નથી." : "These come only from Driver and Conductor. They do not choose or change Lo Shu remedy targets."}</div>
          <div class="table-scroll"><table class="rtable">
            <tr><th>Day</th><th>Planet</th><th>Charity</th><th>Fast</th></tr>
            ${activation.powerDays.map((w) => `<tr>
              <td><strong>${esc(w.day)}</strong></td>
              <td>${w.planet}<br><span class="card-sub">${w.note}</span></td>
              <td>${esc(w.charity)}</td>
              <td>${esc(w.fast)}</td>
            </tr>`).join("")}
          </table></div>
        </div>
      </div>
      ${sadhanaPlanBlock(p, activation)}
      ${renderTriageCard(p, triage)}
      <div class="plan-subhead">${lang === "hi" ? "मंडल के चार चरण" : lang === "gu" ? "મંડળના ચાર તબક્કા" : "The four phases of your mandala"}</div>
      <div class="phase-grid">
        ${activation.phases.map((phase) => `<div class="phase-card">
          <span class="phase-badge">${phase.badge}</span>
          <div class="phase-title">${phase.title}</div>
          <div class="phase-rows">${phase.rows.map((r) => `<div class="phase-row">${r}</div>`).join("")}</div>
        </div>`).join("")}
      </div>
      <div class="plan-subhead">${lang === "hi" ? "आपकी कार्य सूची — आवृत्ति अनुसार" : lang === "gu" ? "તમારી કાર્ય સૂચિ — આવૃત્તિ મુજબ" : "Your action checklist — tagged by cadence"}</div>
      <div class="priority-list">${priorities.map((item) => {
        const tier = item.n === tier1Number ? 1 : tier2Numbers.includes(item.n) ? 2 : 0;
        const tierBadge = tier === 1
          ? `<span class="badge good triage-flag">${lang === "hi" ? "टियर १ · अभी" : lang === "gu" ? "ટિયર ૧ · હમણાં" : "Tier 1 · now"}</span>`
          : tier === 2
            ? `<span class="badge warn triage-flag">${lang === "hi" ? "टियर २ · प्रतीक्षा" : lang === "gu" ? "ટિયર ૨ · રાહ" : "Tier 2 · hold"}</span>`
            : "";
        // Moon checklist rows that chant the lunar mantra carry a warm-form flag.
        const moonPriorityNote = (item.n === 2 && moonColdSensitivity(p))
          ? `<span class="priority-guardrail" data-clinical-guardrail="moon-cold">${lang === "hi" ? "🛡 सर्दी-संवेदनशील: उष्ण रूप — शिव जप, गुनगुना चांदी-जल" : lang === "gu" ? "🛡 શરદી-સંવેદનશીલ: ઉષ્ણ રૂપ — શિવ જાપ, ગુનગુનું ચાંદી-જળ" : "🛡 Cold-sensitive: run warm — Shiva japa, lukewarm silver water"}</span>`
          : "";
        // Checklist rows for other loaded numbers carry the mild-form flag.
        const doshaPriorityNote = (() => {
          if (item.n === 2) return "";
          if (!doshaContraSensitivity(item.n, p)) return "";
          const rule = DOSHA_CONTRA_RULES[item.n];
          const copy = DOSHA_CONTRA_COPY[item.n];
          if (!rule || !copy) return "";
          const micro = copy.micro[lang] || copy.micro.en;
          const dosha = doshaLabel(rule.channel, lang);
          const text = lang === "hi" ? `🛡 ${dosha}-\u0938\u0902\u0935\u0947\u0926\u0928\u0936\u0940\u0932: ${micro}` : lang === "gu" ? `🛡 ${dosha}-\u0ab8\u0a82\u0ab5\u0ac7\u0aa6\u0aa8\u0ab6\u0ac0\u0ab2: ${micro}` : `🛡 ${dosha}-sensitive: ${micro}`;
          return `<span class="priority-guardrail" data-clinical-guardrail="dosha-contra" data-contra-number="${item.n}">${esc(text)}</span>`;
        })();
        return `<div class="priority-item"${tier ? ` data-triage-tier="${tier}" data-triage-number="${item.n}"` : ""}><span class="cadence cadence-${item.cadence}">${cadenceLabel[item.cadence] || "Daily"}</span><span class="priority-text">${item.text}</span>${tierBadge}${moonPriorityNote}${doshaPriorityNote}</div>`;
      }).join("")}
      </div>
      ${icsCard}
      <div class="card tracker-card" id="plan-tracker">
        <div class="goal-head">
          <div class="card-title">${lang === "hi" ? "४०-दिवसीय ट्रैकर — प्रत्येक दिन पूर्ण होने पर टैप करें" : lang === "gu" ? "૪૦ દિવસનો ટ્રેકર — પૂર્ણ થયેલ દરેક દિવસ પર ટેપ કરો" : "40-Day Tracker — tap each day you complete"}</div>
          <span class="badge ${planDone >= PLAN_DAYS ? "good" : planDone > 0 ? "info" : "warn"}">${planDone}/${PLAN_DAYS}</span>
        </div>
        <div class="kit-value">${planStatus}</div>
        <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${PLAN_DAYS}" aria-valuenow="${planDone}"><div class="progress-fill" style="width:${Math.round((planDone / PLAN_DAYS) * 100)}%"></div></div>
        <div class="tracker-grid">
          ${planDays.map((done, i) => `<button type="button" class="tracker-cell${done ? " done" : ""}${!done && i === planNext ? " next" : ""}" data-plan-day="${i + 1}" aria-pressed="${done}" aria-label="Day ${i + 1}${done ? " completed" : ""}">${done ? "✓" : i + 1}</button>`).join("")}
        </div>
        <div class="tracker-foot">
          <span>${planState.startedAt ? `Cycle started ${prettyDate(planState.startedAt)} · ` : ""}Progress is saved privately on this device, per profile.</span>
          ${planDone > 0 ? `<button class="btn btn-secondary btn-32" type="button" data-plan-reset>${t("resetCycle", "Reset cycle")}</button>` : ""}
        </div>
      </div>
    </section>`;

    const birthLine = [p.birthTimeDisplay, p.birthPlace].filter(Boolean).join(", ");
    let vedicPill;
    if (p.vedicTier === 2 && p.astro && p.astro.tier === "full") {
      const m = p.astro.moon, l = p.astro.lagna;
      vedicPill = `<span class="status-pill status-vedic">Vedic chart unlocked — ${l.glyph} ${esc(l.sign)} Lagna · ${m.glyph} ${esc(m.nakshatra.name)} Star</span>`;
    } else if (p.vedicTier === 2) {
      vedicPill = `<span class="status-pill status-vedic">Vedic Tier 2 — add a recognised birthplace</span>`;
    } else if (p.vedicTier === "partial") {
      vedicPill = `<span class="status-pill status-vedic">Vedic Tier 2 partially unlocked</span>`;
    } else {
      vedicPill = `<span class="status-pill status-vedic">Vedic Sun Sign · Sidereal (Lahiri)</span>`;
    }

    const activeModule = reportModuleFromHash();
    const foundationHidden = activeModule !== "foundation" ? " hidden" : "";
    const timelineHidden = activeModule !== "timeline" ? " hidden" : "";
    const cockpitHidden = activeModule !== "cockpit" ? " hidden" : "";
    const foundationSelected = activeModule === "foundation";
    const timelineSelected = activeModule === "timeline";
    const cockpitSelected = activeModule === "cockpit";

    return `
      <div class="report-hero">
        <div class="invocation">ॐ श्री गणेशाय नमः</div>
        <h1>${t("reportHeroTitle", "Remedy Report — {name}").replace("{name}", esc(p.name))}</h1>
        <p>${t("reportHeroMeta", "DOB <strong>{dob}</strong>{birthLine} · Focus: {goals}")
          .replace("{dob}", esc(dobDisplay))
          .replace("{birthLine}", birthLine ? ` · ${t("born", "Born")} ${esc(birthLine)}` : "")
          .replace("{goals}", p.goals.map(esc).join(", "))}</p>
        <p class="gen-line">${t("reportGenLine", "Report generated {date} · computed locally on your device — nothing leaves your browser").replace("{date}", esc(generatedOn))}</p>
        <div class="report-meta">
          <span class="status-pill status-private">${t("statusPrivate", "Private & local")}</span>
          <span class="status-pill status-knowledge">Knowledge pack v${esc(activePack().packVersion)}</span>
          <span class="status-pill status-memory">${evolving.snapshots.length} local snapshot${evolving.snapshots.length === 1 ? "" : "s"}</span>
          ${vedicPill}
        </div>
        <div class="report-controls" data-report-controls>
          <div class="report-mode-switch" role="group" aria-label="${t("reportModeLabel", "Report mode")}">
            <button type="button" class="btn btn-secondary btn-32${state.reportMode === "client" ? " active" : ""}" data-report-mode-btn="client" aria-pressed="${state.reportMode === "client"}" title="${t("clientModeHint", "Punchy client dossier — technical telemetry, JSON scaffolds and the cockpit stay out of the PDF.")}">${t("modeClient", "Client dossier")}</button>
            <button type="button" class="btn btn-secondary btn-32${state.reportMode === "practitioner" ? " active" : ""}" data-report-mode-btn="practitioner" aria-pressed="${state.reportMode === "practitioner"}" title="${t("practitionerModeHint", "Full practitioner compendium — cockpit, telemetry and dual-dasha internals included.")}">${t("modePractitioner", "Practitioner compendium")}</button>
          </div>
          <label class="dasha-engine-picker">${t("primaryDashaEngine", "Primary Dasha engine")}
            <select data-dasha-engine-select aria-label="${t("primaryDashaEngine", "Primary Dasha engine")}">
              <option value="ank"${state.dashaEngine === "ank" ? " selected" : ""}>${t("engineAnk", "Ank Jyotish (default)")}</option>
              <option value="vimshottari"${state.dashaEngine === "vimshottari" ? " selected" : ""}>${t("engineVimshottari", "Vimshottari (classical)")}</option>
            </select>
          </label>
        </div>
        <div class="module-tabs" role="tablist" aria-label="${t("moduleNavigation", "Report modules")}">
          <button class="module-tab${foundationSelected ? " active" : ""}" id="foundation-tab" type="button" role="tab" aria-selected="${foundationSelected}" aria-controls="foundation-panel" tabindex="${foundationSelected ? "0" : "-1"}" data-module-tab="foundation">${t("tabFoundation", "Foundation · Lo Shu")}</button>
          <button class="module-tab${timelineSelected ? " active" : ""}" id="timeline-tab" type="button" role="tab" aria-selected="${timelineSelected}" aria-controls="timeline-panel" tabindex="${timelineSelected ? "0" : "-1"}" data-module-tab="timeline">${t("tabTimeline", "Timeline · Ank Jyotish Dasha")}</button>
          <button class="module-tab${cockpitSelected ? " active" : ""}" id="cockpit-tab" type="button" role="tab" aria-selected="${cockpitSelected}" aria-controls="cockpit-panel" tabindex="${cockpitSelected ? "0" : "-1"}" data-module-tab="cockpit">${t("tabCockpit", "Cockpit · Practitioner")}</button>
        </div>
        <nav class="report-nav" aria-label="${t("moduleQuickNavigation", "Module navigation")}">
          <a href="#foundation" data-module-jump="foundation">${t("navFoundation", "Foundation")}</a>
          <a href="#loshu-grid-section">${t("navLoShu", "Lo Shu Blueprint")}</a>
          <a href="#timeline" data-module-jump="timeline">${t("navTimeline", "Timeline")}</a>
          <a href="#dasha-section">${t("navDasha", "Dasha")}</a>
          <a href="#vastu-section">${t("navVastu", "Vastu")}</a>
          <a href="#plan-section">${t("navPlan", "40-Day Plan")}</a>
          <a href="#cockpit" data-module-jump="cockpit">${t("navCockpit", "Cockpit")}</a>
        </nav>
      </div>
      <section class="report-module-panel foundation-panel" id="foundation-panel" role="tabpanel" aria-labelledby="foundation-tab"${foundationHidden}>
        <div class="module-panel-heading"><p class="summary-kicker">${t("tabFoundation", "Foundation · Lo Shu")}</p><h2>${t("foundationPanelTitle", "Your psychological blueprint and practice")}</h2><p>${t("foundationPanelDesc", "Use the classic Lo Shu Birth, Name and Combined grids to understand patterns, then build your practical 40-day activation plan.")}</p></div>
        <div class="card reading-guide">
          <div class="card-title">${t("readingGuideTitle", "How to read this report")}</div>
          <div class="reading-guide-grid">
            <div class="reading-guide-item">${t("readingGuideDriver", "<strong>Driver (Moolank)</strong> — your mind, personality and day-to-day energy; <strong>Conductor (Bhagyank)</strong> — your destiny path. Both derive from your birth date.")}</div>
            <div class="reading-guide-item">${t("readingGuideGrid", "<strong>Lo Shu grid</strong> — which of the nine number energies (1–9, each ruled by a planet) are present, repeated or missing in your birth date and name. Section {grid} reads every gap: your first gaps get full remedy kits in Section {kits}, the rest get quick balancers, and the Remedy Triage stages one acute target at a time.").replace("{grid}", SECTION.grid).replace("{kits}", SECTION.weak)}</div>
            <div class="reading-guide-item">${t("readingGuideFlow", "Numbered sections build from identity → remedies → timing → Vastu across the Foundation, Timeline and Cockpit tabs. The <strong>40-Day Activation Plan</strong> at the end of Foundation is your starting point — practise it consistently for 40 days.")}</div>
          </div>
        </div>
        ${summarySection}
        <section class="rsection" id="core-profile">
          <h2 class="rsection-title"><span class="idx">${SECTION.core}</span>${t("secProfile", "Core Numerology Profile")}</h2>
          <div class="card-grid">
            ${numCard(t("driverLabel", "Driver (Moolank)"), p.driver, lang === "hi" ? "आपकी सोच, व्यक्तित्व और दैनिक ऊर्जा" : lang === "gu" ? "તમારી વિચારસરણી, વ્યક્તિત્વ અને દૈનિક ઊર્જા" : "Your mind, personality and day-to-day energy")}
            ${numCard(t("conductorLabel", "Conductor (Bhagyank)"), p.conductor, lang === "hi" ? "आपका भाग्य मार्ग और दीर्घकालिक सफलता" : lang === "gu" ? "તમારો ભાગ્ય માર્ગ અને દીર્ઘકાલીન સફળતા" : "Your destiny path and long-term results")}
            ${numCard("Name Number", p.nameNum, `Chaldean total ${p.nameCompound} — ${lang === "hi" ? "दुनिया आपको कैसे स्वीकारती है" : lang === "gu" ? "દુનિયા તમને કેવી રીતે સ્વીકારે છે" : "how the world receives you"}`)}
            ${numCard("Mobile Number", p.mobNum, `Digits total ${p.mobCompound} — ${lang === "hi" ? "सर्वाधिक प्रयुक्त दैनिक ऊर्जा" : lang === "gu" ? "સૌથી વધુ વપરાતી દૈનિક ઊર્જા" : "your most-used vibration"}`)}
            <div class="card num-card" data-authority="zodiac-reference"><div class="num-value" style="font-size:26px">${esc(p.zodiac)}</div><div class="num-label">Vedic Sun Sign · Surya Rashi</div><div class="num-planet">${esc(db.zodiac[p.zodiac].element)} · Ruled by ${esc(db.numbers[db.zodiac[p.zodiac].ruler].planet)}</div><div class="num-traits">Sidereal / Lahiri reference only — it does not choose remedies, crystals or timing.</div><div class="num-traits vedic-western-ref">Western tropical reference: ${esc(p.zodiacTropical)}</div></div>
          </div>
          <div class="card"><div class="card-title">Driver ${p.driver} × Conductor ${p.conductor} combination</div><div class="kit-value">Your mind runs on <strong>${esc(db.numbers[p.driver].planet)}</strong> (${esc(db.numbers[p.driver].traits.split(",")[0].toLowerCase())}) while your destiny demands <strong>${esc(db.numbers[p.conductor].planet)}</strong> (${esc(db.numbers[p.conductor].traits.split(",")[0].toLowerCase())}). This pair is <strong>${relation(p.driver, p.conductor)}</strong> — ${relation(p.driver, p.conductor) === "friendly" ? "a naturally cooperative chart; remedies will amplify what already flows." : relation(p.driver, p.conductor) === "neutral" ? "a workable chart; targeted remedies will sharpen results." : "the remedies below are chosen to bridge these two energies."}</div></div>
          ${karmicDebtCard(p)}
          ${doshaCard(p)}
          ${deityCard(p)}
        </section>
        ${traitsSection}
        ${renderLoShuGrid(p)}
        ${renderVedicBirthComparison(p)}
        ${weakSection}
        ${renderVedicTattvaSection(p)}
        ${zodiacSection}
        ${nameSection}
        ${renderNameArchitecture(p, nameSug)}
        ${mobSection}
        ${vehicleSection}
        ${renderPremises(p)}
        ${watchSection}
        ${crystalSection}
        ${colorSection}
        ${careerSection}
        ${memorySection}
        ${kuaSection}
        ${renderWesternCrossRef(p)}
        ${compatSection}
        ${goalSections}
        ${prioritySection}
      </section>
      <section class="report-module-panel timeline-panel" id="timeline-panel" role="tabpanel" aria-labelledby="timeline-tab"${timelineHidden}>
        <div class="module-panel-heading timeline-panel-heading" id="timeline-top"><p class="summary-kicker">${t("tabTimeline", "Timeline · Ank Jyotish Dasha")}</p><h2>${t("timelinePanelTitle", "Your Dasha roadmap")}</h2><p>${t("timelinePanelDesc", "Read the current Ank Jyotish Dasha stack, active Vastu zone and life-event windows as a time-based roadmap. This proportional numerology clock is not classical Vimshottari and never uses either grid to alter timing.")}</p><nav class="timeline-anchor-nav" aria-label="${t("timelineNavigation", "Timeline navigation")}"><a href="#timing-section">${t("navTiming", "Timing")}</a><a href="#muhurtha-section">${t("navMuhurtha", "Muhurtha")}</a><a href="#dasha-section">${t("navDasha", "Dasha roadmap")}</a><a href="#vastu-section">${t("navVastu", "Home Vastu")}</a><a href="#timeline-top">${t("backToTimeline", "Timeline top")}</a></nav></div>
        ${timingSection}
        ${renderPersonalCycles(p)}
        ${muhurthaSection}
        ${dashaSection}
        ${vastuSection}
        ${renderVastuCompass(p)}
      </section>
      <section class="report-module-panel cockpit-panel" id="cockpit-panel" role="tabpanel" aria-labelledby="cockpit-tab"${cockpitHidden}>
        <div class="module-panel-heading cockpit-panel-heading" id="cockpit-top"><p class="summary-kicker">${t("tabCockpit", "Cockpit · Practitioner")}</p><h2>${t("cockpitPanelTitle", "Your one-page clinical cockpit")}</h2><p>${t("cockpitPanelDesc", "A single printable consultation sheet: identity, both grids, the live Dasha stack judged by classical Sambhandha, the triaged prescription and graded event windows. It never recalculates anything — it condenses.")}</p></div>
        ${renderPractitionerCockpit(p)}
      </section>
      <div class="report-closing">
        <div class="report-closing-brand">${t("reportClosingBrand", "NumeroVastu 360 — Private Report")}</div>
        <div class="report-closing-line">${t("reportClosingDisclaimer", "Guidance based on classical Vedic numerology &amp; Vastu principles — supportive practices, not a substitute for professional medical, legal or financial advice.")}</div>
      </div>
    `;
  }

  function numCard(label, val, sub) {
    return `<div class="card num-card">
      <div class="num-value">${val}</div>
      <div class="num-label">${label}</div>
      <div class="num-sub">${sub}</div>
    </div>`;
  }

  /* ---------------- view switching & interactions ---------------- */
  let lastProfile = null;
  /* The resolved 40-day plan for the chart currently on screen. Cached so
     the calendar export serialises exactly the practice the client is
     reading, rather than re-resolving it and risking a different answer. */
  let lastActivation = null;

  function reportModuleFromHash(hash) {
    const id = String(hash === undefined ? window.location.hash : hash || "").replace(/^#/, "");
    if (id === "timeline" || id === "timeline-panel" || id === "timeline-top" || id === "timing-section" || id === "dasha-section" || id === "vastu-section") return "timeline";
    if (id === "cockpit" || id === "cockpit-panel" || id === "cockpit-top" || id === "practitioner-cockpit") return "cockpit";
    return "foundation";
  }

  function moduleForTarget(targetId) {
    if (!targetId) return "foundation";
    const target = document.getElementById(targetId);
    if (target && target.closest("#timeline-panel")) return "timeline";
    if (target && target.closest("#cockpit-panel")) return "cockpit";
    return reportModuleFromHash(`#${targetId}`);
  }

  function setReportModule(moduleName, options) {
    const opts = options || {};
    const next = (moduleName === "timeline" || moduleName === "cockpit") ? moduleName : "foundation";
    const root = $("#reportRoot");
    if (!root) return;
    const foundation = $("#foundation-panel", root);
    const timeline = $("#timeline-panel", root);
    const cockpit = $("#cockpit-panel", root);
    const tabs = $$('[data-module-tab]', root);
    if (foundation) foundation.hidden = next !== "foundation";
    if (timeline) timeline.hidden = next !== "timeline";
    if (cockpit) cockpit.hidden = next !== "cockpit";
    tabs.forEach((tab) => {
      const selected = tab.dataset.moduleTab === next;
      tab.classList.toggle("active", selected);
      tab.setAttribute("aria-selected", String(selected));
      tab.tabIndex = selected ? 0 : -1;
    });
    state.reportModule = next;
    if (opts.writeHash) {
      const wanted = `#${next}`;
      if (window.location.hash !== wanted) window.location.hash = wanted;
    }
    if (opts.focus) {
      const selected = $(`[data-module-tab="${next}"]`, root);
      if (selected) selected.focus();
    }
    if (opts.scrollToHash) {
      const targetId = String(window.location.hash || "").replace(/^#/, "");
      const target = targetId && document.getElementById(targetId);
      if (target && typeof target.scrollIntoView === "function") {
        const schedule = window.requestAnimationFrame || ((fn) => setTimeout(fn, 0));
        schedule(() => target.scrollIntoView({ block: "start", behavior: "auto" }));
      }
    }
  }

  function bindReportModuleNavigation() {
    const root = $("#reportRoot");
    if (!root) return;
    $$('[data-module-tab]', root).forEach((tab) => {
      if (tab.dataset.moduleBound) return;
      tab.dataset.moduleBound = "true";
      tab.addEventListener("click", () => setReportModule(tab.dataset.moduleTab, { writeHash: true, focus: true }));
      tab.addEventListener("keydown", (event) => {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
        event.preventDefault();
        const ordered = $$('[data-module-tab]', root);
        let index = ordered.indexOf(tab);
        if (event.key === "ArrowRight") index = (index + 1) % ordered.length;
        if (event.key === "ArrowLeft") index = (index - 1 + ordered.length) % ordered.length;
        if (event.key === "Home") index = 0;
        if (event.key === "End") index = ordered.length - 1;
        const next = ordered[index];
        setReportModule(next.dataset.moduleTab, { writeHash: true, focus: true });
      });
    });
    $$('a[href^="#"]', root).forEach((link) => {
      if (link.dataset.moduleBound) return;
      link.dataset.moduleBound = "true";
      link.addEventListener("click", () => {
        const explicit = link.dataset.moduleJump;
        const targetId = String(link.getAttribute("href") || "").replace(/^#/, "");
        setReportModule(explicit || moduleForTarget(targetId), { writeHash: false });
      });
    });
  }

  /* Cockpit-only printing: the practitioner usually wants the single
     consultation sheet, not the 40-page client report. A body class narrows
     the print stylesheet to the cockpit and is always removed afterwards. */
  function printPractitionerCockpit() {
    const body = document.body;
    body.classList.add("print-cockpit");
    const clear = () => body.classList.remove("print-cockpit");
    if (typeof window.onafterprint !== "undefined") {
      window.addEventListener("afterprint", clear, { once: true });
    }
    setTimeout(clear, 1500);
    window.print();
  }

  function bindReportInteractions() {
    bindReportModuleNavigation();
    // Conditional section bundling: Client / Practitioner mode switch and the
    // primary Dasha engine picker (2026-09 audit). Both persist to localStorage
    // and re-render so the on-screen report always matches the PDF.
    $$("[data-report-mode-btn]", $("#reportRoot")).forEach((btn) => {
      if (btn.dataset.bound) return;
      btn.dataset.bound = "true";
      btn.addEventListener("click", () => setReportMode(btn.dataset.reportModeBtn));
    });
    $$("[data-dasha-engine-select]", $("#reportRoot")).forEach((sel) => {
      if (sel.dataset.bound) return;
      sel.dataset.bound = "true";
      sel.addEventListener("change", () => setDashaEngine(sel.value));
    });
    const cockpitPrint = $("#printCockpitBtn", $("#reportRoot"));
    if (cockpitPrint && !cockpitPrint.dataset.bound) {
      cockpitPrint.dataset.bound = "true";
      cockpitPrint.addEventListener("click", printPractitionerCockpit);
    }
    $$('[data-practice-number]', $("#reportRoot")).forEach((btn) => {
      btn.addEventListener("click", () => {
        const n = Number(btn.getAttribute("data-practice-number"));
        if (!state.activeProfileKey || !n) return;
        const db = getActiveDB();
        logPractice(state.activeProfileKey, n);
        showToast(`Logged ${db.numbers[n].planet} practice locally`, "good");
        if (state.lastInput) {
          lastProfile = computeProfile(state.lastInput);
          rerenderEvolving();
        }
      });
    });

    const journalForm = $("#localJournalForm", $("#reportRoot"));
    if (journalForm) {
      journalForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const input = $("#localJournalText", journalForm);
        const text = input ? input.value.trim() : "";
        if (!text || !state.activeProfileKey) return;
        addJournalEntry(state.activeProfileKey, text);
        if (input) input.value = "";
        showToast("Note saved locally", "good");
        if (state.lastInput) {
          lastProfile = computeProfile(state.lastInput);
          rerenderEvolving();
        }
      });
    }

    function rerenderEvolving() {
      const sec = $("#memory-section", $("#reportRoot"));
      if (!sec || !lastProfile) return;
      const timing = timingAnalysis(lastProfile);
      const evolving = evolvingChartData(lastProfile, timing);
      const db = getActiveDB();
      const lang = getLang();
      sec.querySelector(".insight-grid").innerHTML = `
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "सुरक्षित चार्ट" : lang === "gu" ? "સેવ કરેલા ચાર્ટ" : "Saved snapshots"}</div>
          <div class="metric-value">${evolving.snapshots.length}</div>
          <div class="metric-sub">${lang === "hi" ? `नवीनतम: ${evolving.snapshots[0] ? prettyDate(evolving.snapshots[0].savedAt) : "अभी सुरक्षित नहीं"}` : lang === "gu" ? `તાજેતરનું: ${evolving.snapshots[0] ? prettyDate(evolving.snapshots[0].savedAt) : "હજી સેવ નથી"}` : `Latest saved on ${evolving.snapshots[0] ? prettyDate(evolving.snapshots[0].savedAt) : "this device not yet"}`}</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "इस वर्ष का प्रभाव" : lang === "gu" ? "આ વર્ષનો પ્રભાવ" : "This year in context"}</div>
          <div class="metric-value">${evolving.currentYearLucky ? (lang === "hi" ? "अनुकूल" : lang === "gu" ? "અનુકૂળ" : "Favourable") : (lang === "hi" ? "धैर्य से निर्माण" : lang === "gu" ? "ધીરજથી નિર્માણ" : "Build steadily")}</div>
          <div class="metric-sub">${evolving.currentYearLucky ? (lang === "hi" ? "यह वर्ष आपके शुभ वर्षों की सूची में आता है।" : lang === "gu" ? "આ વર્ષ તમારા શુભ વર્ષોની યાદીમાં આવે છે." : "This year appears in your lucky-year window.") : (lang === "hi" ? "अनुशासन और निरंतरता बनाए रखें।" : lang === "gu" ? "શિસ્ત અને સાતત્ય જાળવી રાખો." : "Not one of your top timing windows — use discipline and consistency.")}</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "इस वर्ष दर्ज कदम" : lang === "gu" ? "આ વર્ષે નોંધેલા પગલાં" : "Moves logged this year"}</div>
          <div class="metric-value">${evolving.movesThisYear}</div>
          <div class="metric-sub">A local reality-check against your timing cycle.</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">${lang === "hi" ? "ज्ञान का स्रोत" : lang === "gu" ? "જ્ઞાનનો સ્ત્રોત" : "Knowledge source"}</div>
          <div class="metric-value">v${esc(activePack().packVersion)}</div>
          <div class="metric-sub">${esc(activePack().source === "remote" ? "Live-updated content pack" : activePack().source === "cached" ? "Cached content pack" : "Bundled starter pack")}</div>
        </div>
      `;
      sec.querySelector(".engagement-list").innerHTML = evolving.practiceSummary.map((item) => `<div class="engagement-item"><div><strong>${item.n} — ${esc(db.numbers[item.n].planet)}</strong><span>${item.month} logged this month · ${item.total} total</span></div><button class="btn btn-secondary btn-32" type="button" data-practice-number="${item.n}">${lang === "hi" ? "अभ्यास दर्ज करें" : lang === "gu" ? "અભ્યાસ નોંધો" : "Log practice"}</button></div>`).join("");
      sec.querySelector(".timeline").innerHTML = evolving.journal.length ? evolving.journal.map((entry) => `<div class="timeline-item"><div><strong>${esc(entry.text)}</strong><span>${prettyDate(entry.at)}</span></div></div>`).join("") : `<div class="timeline-item"><div><strong>${lang === "hi" ? "अभी कोई नोट दर्ज नहीं है" : lang === "gu" ? "હજી કોઈ નોંધ દાખલ નથી" : "No local moves logged yet"}</strong><span>${lang === "hi" ? "आपकी टिप्पणियां पूरी तरह आपके डिवाइस पर ही रहती हैं।" : lang === "gu" ? "તમારી નોંધ સંપૂર્ણપણે તમારા ડિવાઇસ પર જ રહે છે." : "Your notes stay on this device and never enter the anonymous contribution payload."}</span></div></div>`;
      bindReportInteractions();
    }

    function rerenderToPlan() {
      if (!lastProfile) return;
      const planKey = state.activeProfileKey || profileKeyOf(lastProfile);
      const planState = readPlan(planKey);
      const PLAN_DAYS = 40;
      const planDays = Array.from({ length: PLAN_DAYS }, (_, i) => !!planState.days[i]);
      const planDone = planDays.filter(Boolean).length;
      const planNext = planDays.indexOf(false);
      const lang = getLang();

      const planStatus = planDone >= PLAN_DAYS
        ? (lang === "hi" ? `मंडल पूर्ण — ४० में से ४० दिन संपन्न! अब प्रगति चार्ट में परिणाम देखें।` : lang === "gu" ? `મંડળ પૂર્ણ — ૪૦ માંથી ૪૦ દિવસ સંપન્ન! હવે પ્રગતિ ચાર્ટમાં પરિણામો જુઓ.` : `Mandala complete — ${PLAN_DAYS} of ${PLAN_DAYS} days done. Now review what shifted in Your Evolving Chart (Section ${SECTION.memory}).`)
        : planDone === 0
          ? (lang === "hi" ? `सर्वोत्तम शुरुआत के लिए <strong>${dayOf(lastProfile.driver)}</strong> की सुबह से प्रारंभ करें और दिन १ पर टैप करें।` : lang === "gu" ? `શ્રેષ્ઠ શરૂઆત માટે <strong>${dayOf(lastProfile.driver)}</strong> ની સવારથી પ્રારંભ કરો અને દિવસ ૧ પર ટેપ કરો.` : `Begin on a <strong>${DAY_OF[lastProfile.driver]}</strong> morning for the strongest start, then tap Day 1. The ritual takes under 10 minutes — consistency is the remedy.`)
          : (lang === "hi" ? `${planDone} / ${PLAN_DAYS} दिन पूर्ण — अगला दिन ${planNext + 1} है। नियम न तोड़ें।` : lang === "gu" ? `${planDone} / ${PLAN_DAYS} દિવસ પૂર્ણ — આગામી દિવસ ${planNext + 1} છે. સાતત્ય જાળવી રાખો.` : `${planDone} of ${PLAN_DAYS} days done — Day ${planNext + 1} is next${planNext + 1 <= PLAN_DAYS ? `, ${PLAN_DAYS - planDone} day${PLAN_DAYS - planDone === 1 ? "" : "s"} to go` : ""}. Keep the thread unbroken.`);

      const tracker = $("#plan-tracker", $("#reportRoot"));
      if (!tracker) return;
      tracker.querySelector(".badge").textContent = `${planDone}/${PLAN_DAYS}`;
      tracker.querySelector(".badge").className = `badge ${planDone >= PLAN_DAYS ? "good" : planDone > 0 ? "info" : "warn"}`;
      tracker.querySelector(".kit-value").innerHTML = planStatus;
      tracker.querySelector(".progress-fill").style.width = `${Math.round((planDone / PLAN_DAYS) * 100)}%`;
      tracker.querySelector(".progress-track").setAttribute("aria-valuenow", String(planDone));
      tracker.querySelector(".tracker-grid").innerHTML = planDays.map((done, i) => `<button type="button" class="tracker-cell${done ? " done" : ""}${!done && i === planNext ? " next" : ""}" data-plan-day="${i + 1}" aria-pressed="${done}" aria-label="Day ${i + 1}${done ? " completed" : ""}">${done ? "✓" : i + 1}</button>`).join("");
      tracker.querySelector(".tracker-foot").innerHTML = `
        <span>${planState.startedAt ? `Cycle started ${prettyDate(planState.startedAt)} · ` : ""}Progress is saved privately on this device, per profile.</span>
        ${planDone > 0 ? `<button class="btn btn-secondary btn-32" type="button" data-plan-reset>${t("resetCycle", "Reset cycle")}</button>` : ""}
      `;
      bindReportInteractions();
    }

    $$("[data-plan-day]", $("#reportRoot")).forEach((cell) => {
      cell.addEventListener("click", () => {
        const dayIdx = Number(cell.getAttribute("data-plan-day")) - 1;
        if (dayIdx < 0 || dayIdx >= 40) return;
        const key = state.activeProfileKey || (state.lastInput ? profileKeyOf(state.lastInput) : "");
        if (!key) return;
        const plan = readPlan(key);
        const PLAN_DAYS = 40;
        const days = Array.from({ length: PLAN_DAYS }, (_, i) => !!plan.days[i]);
        const currentlyDone = !!days[dayIdx];
        days[dayIdx] = !currentlyDone;
        const newStartedAt = plan.startedAt || isoDate();
        writePlan(key, { startedAt: newStartedAt, days });
        showToast(currentlyDone ? `Day ${dayIdx + 1} marked incomplete` : `Day ${dayIdx + 1} complete — keep going!`, currentlyDone ? "info" : "good");
        rerenderToPlan();
      });
    });

    /* Calendar export. Everything happens inside this handler: read the
       checkboxes, serialise, hand the Blob to the browser. No fetch, no
       registration, no permission prompt — the client gets a file and
       the app's involvement ends there. */
    const icsCardEl = $("[data-ics-export]", $("#reportRoot"));
    if (icsCardEl) {
      const readIncludes = () => {
        const include = {};
        $$("[data-ics-opt]", icsCardEl).forEach((box) => {
          include[box.getAttribute("data-ics-opt")] = !!box.checked;
        });
        return include;
      };
      const refreshTotal = () => {
        const include = readIncludes();
        if (!lastProfile) return;
        const preview = practiceCalendarPlan(lastProfile, lastActivation, readPlan(state.activeProfileKey || profileKeyOf(lastProfile)), {
          include, profileKey: state.activeProfileKey || profileKeyOf(lastProfile)
        });
        const total = preview.events.length;
        const totalEl = $("[data-ics-total]", icsCardEl);
        if (totalEl) {
          totalEl.textContent = total
            ? triText(getLang(), `${total} entries`, `${total} प्रविष्टियाँ`, `${total} એન્ટ્રી`)
            : triText(getLang(), "Nothing selected", "कुछ चयनित नहीं", "કશું પસંદ નથી");
        }
        const btn = $("[data-ics-download]", icsCardEl);
        if (btn) btn.disabled = total === 0;
      };
      $$("[data-ics-opt]", icsCardEl).forEach((box) => box.addEventListener("change", refreshTotal));
      refreshTotal();

      const icsBtn = $("[data-ics-download]", icsCardEl);
      if (icsBtn) {
        icsBtn.addEventListener("click", () => {
          if (!lastProfile) return;
          const include = readIncludes();
          const key = state.activeProfileKey || profileKeyOf(lastProfile);
          const result = downloadPracticeCalendar(lastProfile, lastActivation, readPlan(key), {
            include,
            profileKey: key,
            alarmMinutes: include.alarm ? 10 : 0
          });
          if (!result || !result.ok) {
            showToast(triText(getLang(),
              "Could not write the calendar file on this device.",
              "इस डिवाइस पर कैलेंडर फ़ाइल नहीं बन सकी।",
              "આ ડિવાઇસ પર કેલેન્ડર ફાઇલ બની શકી નહીં."), "warn");
            return;
          }
          showToast(triText(getLang(),
            `${result.events.length} entries saved to ${result.filename} — import it into your own calendar.`,
            `${result.events.length} प्रविष्टियाँ ${result.filename} में सहेजी गईं — इसे अपने कैलेंडर में आयात करें।`,
            `${result.events.length} એન્ટ્રી ${result.filename} માં સાચવાઈ — તેને તમારા કેલેન્ડરમાં આયાત કરો.`), "good");
        });
      }
    }

    const planResetBtn = $("[data-plan-reset]", $("#reportRoot"));
    if (planResetBtn) {
      planResetBtn.addEventListener("click", () => {
        const key = state.activeProfileKey || (state.lastInput ? profileKeyOf(state.lastInput) : "");
        if (!key) return;
        writePlan(key, { startedAt: null, days: [] });
        showToast("40-day tracker reset — begin again on your Driver day", "info");
        rerenderToPlan();
      });
    }
  }

  function showReport(p, options) {
    const opts = options || {};
    const scrollTop = window.scrollY || 0;
    lastProfile = p;
    applyReportModeClass();
    $("#reportRoot").innerHTML = renderReport(p);
    $("#intakeView").classList.add("hidden");
    $("#reportView").classList.remove("hidden");
    $("#editBtn").classList.remove("hidden");
    $("#printBtn").classList.remove("hidden");
    $("#fieldBtn").classList.remove("hidden");
    bindReportInteractions();
    setReportModule(reportModuleFromHash(), { scrollToHash: !!window.location.hash && !opts.preserveScroll });
    window.scrollTo({ top: opts.preserveScroll ? scrollTop : 0, behavior: "auto" });
    document.title = `Report — ${p.name} | NumeroVastu 360`;
  }

  function showIntake() {
    $("#reportView").classList.add("hidden");
    $("#intakeView").classList.remove("hidden");
    $("#editBtn").classList.add("hidden");
    $("#printBtn").classList.add("hidden");
    $("#fieldBtn").classList.add("hidden");
    document.title = "NumeroVastu 360 — Numerology & Vastu Remedy Report";
    window.scrollTo({ top: 0 });
  }

  /* ---------------- language switching ---------------- */
  function applyLanguageToUI() {
    const lang = getLang();
    populateDirectionSelects();

    // Update buttons in header and form
    $$("#langSelector .lang-btn").forEach((btn) => btn.classList.toggle("active", btn.dataset.lang === lang));
    $$("#formLangPicker .lang-chip").forEach((chip) => chip.classList.toggle("active", chip.dataset.lang === lang));

    if ($("#editBtn .btn-text")) $("#editBtn .btn-text").textContent = t("editDetails", "Edit Details");
    if ($("#printBtn .btn-text")) $("#printBtn .btn-text").textContent = t("savePrint", "Save / Print Report");
    if ($("#fieldBtn .btn-text")) $("#fieldBtn .btn-text").textContent = t(fieldMode ? "fieldModeOff" : "fieldModeOn", fieldMode ? "Exit field mode" : "Field mode");
    if ($("#fieldBtn")) $("#fieldBtn").setAttribute("aria-label", t("fieldModeToggle", "Toggle field read mode"));
    if ($("#installBtn")) {
      const installLabel = t("installApp", "Install app");
      $("#installBtn .btn-text").textContent = installLabel;
      $("#installBtn").setAttribute("aria-label", installLabel);
      $("#installBtn").setAttribute("title", installLabel);
    }
    if ($(".brand-sub")) $(".brand-sub").textContent = t("brandSub", "Numerology & Vastu Remedy Engine");

    // Intake intro
    if ($(".intro-title")) $(".intro-title").textContent = t("introTitle", "Your 360° Remedy Report");
    if ($(".intro-desc")) $(".intro-desc").textContent = t("introDesc", "Enter your details once...");
    if ($("#lblReportLang")) $("#lblReportLang").textContent = t("reportLanguage", "Report Language");
    if ($("#descReportLang")) $("#descReportLang").textContent = t("reportLanguageDesc", "Choose your preferred language for the report.");

    // Generate button
    if ($("#generateBtn")) {
      const btn = $("#generateBtn");
      btn.innerHTML = `${t("generateBtn", "Generate My Remedy Report")} <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`;
    }

    /* Generic intake-form localisation: any element carrying
         data-i18n="key"      -> textContent
         data-i18n-html="key" -> innerHTML (trusted pack content only)
         data-i18n-ph="key"   -> placeholder attribute
       is translated from the active i18n pack, falling back to the markup
       text already present in index.html. This keeps the form, its hints and
       its error messages in the same language as the generated report. */
    $$("[data-i18n]").forEach((el) => { el.textContent = t(el.getAttribute("data-i18n"), el.textContent); });
    $$("[data-i18n-html]").forEach((el) => { el.innerHTML = t(el.getAttribute("data-i18n-html"), el.innerHTML); });
    $$("[data-i18n-ph]").forEach((el) => { el.setAttribute("placeholder", t(el.getAttribute("data-i18n-ph"), el.getAttribute("placeholder") || "")); });
  }

  function setLanguage(lang) {
    if (!window.I18N || !window.I18N[lang]) return;
    state.lang = lang;
    try { localStorage.setItem(STORAGE_KEYS.lang, lang); } catch (e) {}
    applyLanguageToUI();

    if (!$("#reportView").classList.contains("hidden") && state.lastInput) {
      lastProfile = computeProfile(state.lastInput);
      showReport(lastProfile, { preserveScroll: true });
    }

    const langObj = window.I18N[lang];
    const langNative = (langObj && langObj.meta && langObj.meta.native) || lang;
    const msg = lang === "hi" ? `भाषा: ${langNative} सेट की गई` : lang === "gu" ? `ભાષા: ${langNative} પસંદ કરી` : `Language: ${langNative}`;
    showToast(msg, "good");
  }

  window.addEventListener("hashchange", () => {
    if (!$("#reportView").classList.contains("hidden")) {
      setReportModule(reportModuleFromHash(), { scrollToHash: true });
    }
  });

  // Bind language buttons
  $$("#langSelector .lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => setLanguage(btn.dataset.lang));
  });
  $$("#formLangPicker .lang-chip").forEach((chip) => {
    chip.addEventListener("click", () => setLanguage(chip.dataset.lang));
  });

  populateDirectionSelects();
  hydrateState();
  updateContributionUI();
  updateKnowledgeUI();
  updateMemoryUI();
  applyLanguageToUI();
  applyFieldMode();

  // DOB fields are plain text expecting day-month-year (e.g. 05-08-1976).
  if ($("#dob")) { maskDobInput($("#dob")); $("#dob").value = formatDobForDisplay($("#dob").value); }
  if ($("#partnerDob")) { maskDobInput($("#partnerDob")); $("#partnerDob").value = formatDobForDisplay($("#partnerDob").value); }

  $("#contributeAnonymous").addEventListener("change", (e) => {
    state.contributionEnabled = !!e.target.checked;
    writeStore(STORAGE_KEYS.contributionEnabled, state.contributionEnabled);
    updateContributionUI();
    showToast(state.contributionEnabled ? "Anonymous aggregate contribution enabled" : "Anonymous aggregate contribution turned off", state.contributionEnabled ? "good" : "info");
  });

  /* Report & Timing Settings (intake form). The report-hero controls call the
     same setReportMode / setDashaEngine helpers, so the two stay in sync. */
  if ($("#dashaEngineSelect")) {
    $("#dashaEngineSelect").value = state.dashaEngine;
    $("#dashaEngineSelect").addEventListener("change", (e) => setDashaEngine(e.target.value));
  }
  if ($("#reportModeSelect")) {
    $("#reportModeSelect").value = state.reportMode;
    $("#reportModeSelect").addEventListener("change", (e) => setReportMode(e.target.value));
  }
  applyReportModeClass();
  $("#refreshKnowledgeBtn").addEventListener("click", () => { refreshKnowledgePack({ silent: false }); });
  $("#loadLatestBtn").addEventListener("click", () => {
    const snap = latestSnapshot();
    if (!snap) return;
    fillFormFromSnapshot(snap);
    showToast(`Loaded local chart for ${snap.name}`, "info");
  });

  $("#intakeForm").addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validate()) return;
    const input = {
      name: $("#fullName").value.trim(),
      // Full legal string (Aadhaar / PAN spelling). Absent keeps the classic
      // single-name behaviour, so every saved chart still loads unchanged.
      legalName: ($("#legalName") && $("#legalName").value.trim()) || "",
      dob: normalizeDobInput($("#dob").value),
      mobile: $("#mobile").value.replace(/[^\d+]/g, ""),
      vehicle: $("#vehicle").value.trim(),
      // Premises number — optional; absent keeps every existing chart identical.
      premises: ($("#premises") && $("#premises").value.trim()) || "",
      premisesKind: ($("#premisesKind") && $("#premisesKind").value) || "home",
      // Degree-precise Vastu readings — optional, and purely additive: the
      // eight-direction dropdowns above still drive every existing remedy.
      entranceDeg: ($("#entranceDeg") && $("#entranceDeg").value.trim()) || "",
      kitchenDeg: ($("#kitchenDeg") && $("#kitchenDeg").value.trim()) || "",
      bedroomDeg: ($("#bedroomDeg") && $("#bedroomDeg").value.trim()) || "",
      waterDeg: ($("#waterDeg") && $("#waterDeg").value.trim()) || "",
      goals: Array.from(selectedGoals),
      healthTags: Array.from(selectedHealthTags),
      sadhana: selectedSadhana,
      entrance: $("#entrance").value,
      kitchen: $("#kitchen").value,
      bedroom: $("#bedroom").value,
      toilet: $("#toilet").value,
      study: $("#study").value,
      staircase: $("#staircase").value,
      plotShape: $("#plotShape").value,
      watchType: $("#watchType").value,
      gender: $("#gender").value,
      birthTime: $("#birthTime").value,
      birthPlace: $("#birthPlace").value.trim(),
      birthLat: ($("#birthLat") && $("#birthLat").value.trim()) || "",
      birthLon: ($("#birthLon") && $("#birthLon").value.trim()) || "",
      birthTz: ($("#birthTz") && $("#birthTz").value.trim()) || "",
      brand: $("#brand").value.trim(),
      partnerName: $("#partnerName").value.trim(),
      partnerDob: normalizeDobInput($("#partnerDob").value),
      // Optional Tier 2 partner inputs — absent values stay absent.
      partnerBirthTime: ($("#partnerBirthTime") && $("#partnerBirthTime").value) || "",
      partnerBirthPlace: ($("#partnerBirthPlace") && $("#partnerBirthPlace").value.trim()) || ""
    };
    // Keep the visible fields tidy as day-month-year (canonical ISO is stored).
    if ($("#dob")) $("#dob").value = formatDobForDisplay(input.dob);
    if ($("#partnerDob")) $("#partnerDob").value = formatDobForDisplay(input.partnerDob);
    state.lastInput = Object.assign({}, input);
    lastProfile = computeProfile(input);
    const timing = timingAnalysis(lastProfile);
    saveSnapshot(input, lastProfile, timing);
    queueAnonymousContribution(lastProfile, timing);
    showReport(lastProfile);
  });

  $("#editBtn").addEventListener("click", showIntake);
  $("#printBtn").addEventListener("click", () => window.print());
  $("#fieldBtn").addEventListener("click", toggleFieldMode);

  /* ---- Install app -----------------------------------------------------
     Chrome/Edge expose the native PWA install sheet through this event. Keep
     the call-to-action hidden until the browser confirms that installation
     is available, so it never nags browsers that cannot install the PWA. */
  (function setupInstallPrompt() {
    const installBtn = $("#installBtn");
    if (!installBtn) return;
    let deferredPrompt = null;
    const isStandalone = window.matchMedia && window.matchMedia("(display-mode: standalone)").matches;
    const isIOSStandalone = window.navigator.standalone === true;
    if (isStandalone || isIOSStandalone) return;

    window.addEventListener("beforeinstallprompt", (event) => {
      event.preventDefault();
      deferredPrompt = event;
      installBtn.classList.remove("hidden");
    });

    installBtn.addEventListener("click", async () => {
      if (!deferredPrompt) return;
      const promptEvent = deferredPrompt;
      deferredPrompt = null;
      installBtn.classList.add("hidden");
      try {
        await promptEvent.prompt();
        await promptEvent.userChoice;
      } catch (err) {
        // The browser owns the sheet; a dismissed or unavailable prompt is
        // not an application error and should not interrupt the workflow.
      }
    });

    window.addEventListener("appinstalled", () => {
      deferredPrompt = null;
      installBtn.classList.add("hidden");
      showToast(t("installAppToast", "App installed successfully."), "good");
    });
  })();


  refreshKnowledgePack({ silent: true });

  /* ---- PWA service worker registration -------------------------------
     Offline installability is a bonus, never a requirement: every failure
     path is silent and the app runs exactly as before without a worker.
     Registered from here rather than an inline <script> because the page
     ships a strict `script-src 'self'` CSP. The worker caches static shell
     assets only — chart data lives in localStorage and is never uploaded.
     Append ?sw=off to the URL to unregister, so a bad worker can always be
     bypassed without clearing browser storage. */
  (function registerOfflineWorker() {
    if (!navigator.serviceWorker) return;
    const https = location.protocol === "https:";
    const local = location.hostname === "localhost" || location.hostname === "127.0.0.1";
    if (!https && !local) return;
    if (/[?&]sw=off\b/.test(location.search)) {
      navigator.serviceWorker.getRegistrations()
        .then((regs) => regs.forEach((r) => r.unregister()))
        .catch(() => {});
      return;
    }
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => { /* optional */ });
    });
  })();

  /* expose for smoke tests and external control */
  window.__NV = {
    computeProfile, generateLoShuGrid, generateVedicGrid, nameSuggestions, buildOptionalSpellings, brandAnalysis, spellingCandidates,
    mobileSuggestion, vehicleAnalysis, timingAnalysis, pinnacleAnalysis, dashaTimeline, zodiacSign,
    vimshottariTimeline, VIMSHOTTARI_LORDS, VIMSHOTTARI_TOTAL_YEARS,
    DASHA_LIFESPAN_YEARS, DASHA_LATE_LOOKAHEAD_YEARS, DASHA_FUTURE_WINDOWS, DASHA_LATE_WINDOWS,
    loShuPracticeTargets, activationPlan, priorityPlan, crystalGuide, vastuReport,
    formatConductorBreakdown, getDashaRelationship, qualifyEventWindow, remedyTriage, nextActivation,
    practitionerCockpit, renderPractitionerCockpit, printPractitionerCockpit, renderTriageCard,
    zodiacSignSidereal, kuaNumber, compatibility, compatRemedies, chandraBala, taraBala, taraCount, compoundMeaning,
    masterNumber, reduce, reductionChain, relation, chaldeanValue, validatePack, natalConversion, vedicPlaneReadings, vedicTattvaAnchors, renderVedicTattvaSection,
    currentAgeYears, isMinorProfile, solarLoadOf, solarOverload, solarModerationNote,
    healthTagsOf, hasRespiratoryTag, vataInBaseline, mercuryVataNumber, hasHealthFocus,
    normalizeSadhana, sadhanaScaleOf, sadhanaI18n, sadhanaPlanBlock, clinicalNoticeHtml, localNumber,
    moonColdSensitivity, getRemedyClinicalGuardrail, healthTagLabel, doshaChannelInBaseline, doshaContraSensitivity,
    normalizeDobInput, formatDobForDisplay, formatBirthDate, formatStampDate,
    normalizePack, contributionPayload, formatBirthTime, setLanguage, getLang,
    setReportMode, setDashaEngine, namePracticality, nameStrategyOf, nameWindowOf, initialCandidates, tidyText,
    nameIdentity, nameTokens, isInitialToken, firstLetterOf, authenticInitialAnalysis, nameCandidatePool,
    compressionCandidates, legalWindowCandidates, buildLegalWindowVariants, NAME_WINDOW, SPELLING_TIER_ORDER,
    renderLoShuGrid, renderVedicGrid, renderVedicBirthComparison, renderReport, showReport, showIntake, getActiveDB,
    setReportModule, reportModuleFromHash,
    /* 2026-10 parity layers */
    nameArchitecture, renderNameArchitecture, premisesReport, renderPremises,
    renderPersonalCycles, renderWesternCrossRef, panchangBlock, relBadgeText, triText,
    practiceCalendarPlan, downloadPracticeCalendar, planCalendarAnchor, lastActivation: () => lastActivation,
    /* 2026-10 operational layers */
    vastuCompassReport, renderVastuCompass, renderDigitFlow,
    loShuGridLayout: LO_SHU_GRID_LAYOUT.map((row) => row.slice()),
    vedicGridLayout: VEDIC_GRID_LAYOUT.map((row) => row.slice())
  };
})();
